---
title: "Meaning rationalism, a priori , and transparency of content"
source_type: "paper"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Szubka-2000-Meaning rationalism a priori and transparency of content-Philosophical Psychology.pdf"
source_id: "szubka-2000-meaning-rationalism-a-priori-and-transparency-of-content-philosophical-psychology-f204c6501b24"
source_sha256: "f204c6501b24cf14b3cce2b730aacf9931b046024bff74e40953b659211c4ce2"
conversion_status: "extracted"
conversion_date: "2026-11-10T02:29:07+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/szubka-2000-meaning-rationalism-a-priori-and-transparency-of-content-philosophical-psychology-f204c6501b24-7a19f5c00c.json"
---

# Meaning rationalism, a priori , and transparency of content

<!-- page: pdf=0001 printed=1 -->

## **Philosophical Psychology** 

**ISSN: 0951-5089 (Print) 1465-394X (Online) Journal homepage: www.tandfonline.com/journals/cphp20** 


# **Meaning rationalism, a priori , and transparency of content** 

#### **Tadeusz Szubka** 

**To cite this article:** Tadeusz Szubka (2000) Meaning rationalism, a priori , and transparency of content, Philosophical Psychology, 13:4, 491-503, DOI: 10.1080/09515080020007625 

**To link to this article:** <u>https://doi.org/10.1080/09515080020007625</u> 


Published online: 19 Aug 2010. 


Submit your article to this journal 

Article views: 94 


View related articles 


Citing articles: 1 View citing articles

<!-- page: pdf=0002 printed=2 -->

# **Meaning rationalism,** **_a priori_ , and transparency of content** 

### TADEUSZ SZUBKA 

ABSTRACT _Most current theories of meaning and mental content accept externalism. One of its forceful exponents is Ruth Garrett Millikan. She argues that externalism leads to the abandonment of “the last myth of the given”, that is, of the idea that identity of meaning and mental content is somehow unproblematically given to us, and that we can easily recognize the sameness of meaning and mental content. If one refuses such a “mythical” giveness or meaning rationalism, one has to admit that there is no logical possibility known_ a priori _. The paper tries to show that even if one abandons meaning rationalism one can still hold that there are logical possibilities known_ a priori _. The claim is defended by arguing that_ a priori _knowledge is not completely independent from experience and does not demand the absolute transparency of meaning from the �rst-person point of view._ A priori _knowledge requires only_ a priori _justi�cation, that is, such a justi�cation that is based merely on relations between meanings or contents._ 

##### **Introduction** 

The prevailing number of current theories of meaning and mental content accept a thesis of externalism. Very roughly, externalism holds that meaning or mental content is constituted and individuated not only by factors lying inside one’s head, or inside one’s subjective realm, but also and foremost by external and environmental factors of which a thinker thinking a given meaning, or having a given mental content, may even be unaware. The driving force of externalism has been a series of ingenious thought experiments formulated by Hilary Putnam and Tyler Burge. However, in the writings of those two philosophers externalism seems to be a claim endorsed under some restrictions or applied merely to some (but not all) kinds of mental content. The global or radical externalism is rather an invention of other thinkers, making use of the original Putnam’s and Burge’s arguments and supplementing them by their own ideas. One of the most interesting and forceful exponents of such a radical externalism is Ruth Garrett Millikan. In the title essay of her collection _White Queen psychology and other essays for Alice_ (1993), she wants to convince us that externalism leads to the abandonment of “the last myth of the given”, that is, of the idea that identity of meaning and mental content is somehow 

_Tadeusz Szubka, Faculty of Philosophy, Catholic University of Lublin, Al. Rac�awickie 14, PL 20–950 Lublin, Poland, email: szubka@kul.lublin.pl_

<!-- page: pdf=0003 printed=3 -->

unproblematically given to us in such a way that we can easily recognize sameness of meaning and mental content. If we refuse such “mythical” giveness, we have to admit that there is no logical possibility knowable _a priori_ . Moreover, since rationality requires the ability to identify thought content, it is also not _a priori_ ; it is not just in the head but environmentally dependent. In addition, the abandonment of “the last myth of the given” has one substantial methodological consequence: the old intentional rational psychology con�ned to the content of our minds should be transformed into an ecological and biological science. 

Each of these three results of Millikan’s externalism is challenging enough to deserve a wide discussion. Here I shall focus only on the �rst of them and try to show that there is a sense in which logical possibility is known _a priori_ after all. Subsequently, I shall distinguish two versions—strong and weak—of what Millikan calls “the last myth of the given”, but what is more often known as the transparency of content requirement, and argue that in its weak version we have no choice but to endorse it. However, before approaching these issues I shall sketch the main steps of Millikan’s arguments leading to the refusal of “the last myth of the given”. 

##### **Meaning rationalism attacked** 

The main target of Millikan’s criticism is a certain conception of transparency of meaning which she calls “meaning rationalism”. This conception consists of three epistemological claims: (1) the epistemic giveness of meaning identity and difference, according to which a rational person has the capacity to recognize _a priori_ whether or not any two of his or her thoughts comprehend the same term or proposition, i.e. have the same meaning; (2) the epistemic giveness of univocity, according to which a rational person has the ability to recognize _a priori_ whether he or she entertains a thought with double or ambiguous meaning; and (3) the epistemic giveness of meaningfulness, according to which a rational person has the ability to discern _a priori_ whether he or she means a term or proposition, or whether his or her thought is empty of meaning (Millikan, 1993, p. 287) [1]. Since (2), under some assumptions, follows from (1), the successful criticism of meaning rationalism must proceed by way of refuting of (1) and (3). 

Before giving an outline of the argument against meaning rationalism, a few clari�cations and distinctions are needed. First, concerning the phrase “a rational person”. Millikan rightly insists that this is a potentially confusing phrase, because it can be understood in two ways. In one sense it stands simply for a “mechanically” or “psychologically” rational person, i.e. “… one whose head is intact, in good mechanical order, not diseased, not broken; a person who is not deranged, whose psyche is in no way at fault, who is normally intelligent and cognitively mentally healthy” (Millikan, 1993, p. 289). In the other sense the phrase stands for a “semantically” rational person, whose thoughts follow logical patterns, whose thought processes are governed or constituted by meanings of terms and propositions. If we understand “a rational person” in the latter sense, then, of course, meaning rationalism is true, but it is trivially true, and assuming that each of us _is_

<!-- page: pdf=0004 printed=4 -->

a rational person we simply beg the question. Therefore, Millikan insists, we have to stick consistently to the former sense [2]. 

Second, some elucidations of the notions “term” and “proposition”, and especially of the criteria of identity of terms and propositions, are necessary. To put it brie�y, there are three ways of understanding the identity in question [3]. One can treat terms and propositions as identical if they have the same extension (say, sets of objects in the case of terms and the truth-values in the case of propositions); or, besides having the same extension, if they are structured in the same way; or, besides these, if they are also “presented in the same manner”. If an advocate of meaning rationalism takes the �rst, loose construal of identity, he or she must claim that any person who believes one truth believes also all truths which are logically or extensionally equivalent to it. This position is so counter-intuitive that an elaborate argument against it seems to be unnecessary. But one cannot dispense so easily with meaning rationalists who understand identity of terms and propositions in the remaining two ways. Millikan argues against them separately. For convenience, one can call them _content rationalists_ and _mode rationalists_ , respectively. 

In elaborating their position content rationalists can make use of variously structured terms and propositions (e.g. of descriptions and compound propositions). But in the end they cannot but agree that the theory of content gets its decisive shape from an account of its primitives, that is, from an account of simple names, indexicals, and so on. These are the terms of which nothing can be said except that they possess certain individuals as their referents (perhaps changing with the change of context). They are, in other words, “directly referential”. After making that assumption, the general line of Millikan’s argument against the content rationalist is relatively straightforward. Here as she puts it: 

… the primitives for constructing thought [c]ontent, the simples for the theory of [c]ontent for thought, cannot have [c]ontents that are epistemically given in the way required by the [c]ontent rationalist. More precisely, these [c]ontents cannot be epistemically given unless we resort to directapprehension theories for thought [c]ontent, and that, I take it, should settle the matter. But if the simple terms of thought [c]ontent do not conform to the [c]ontent rationalist’s requirements, clearly the complexes cannot either. For example, if the simple terms out of which thought descriptions are built cannot necessarily be correctly reidenti�ed by the thinker, clearly the descriptions themselves cannot, nor can any propositions built on these descriptions. (Millikan, 1993, p. 303) [4] 

The gist of this argument reduces then to a familiar externalist idea that semantic content of a term or proposition is determined or individuated by an object or fact to which it refers. Provided that the object or fact is a part of the external world and that the relation of reference has causal–historical character, an individual thinker cannot grasp meaning identity and difference _a priori_ , and many of his or her identi�cations may be, as a matter of fact, mistaken. A defender of meaning rationalism can respond in two ways. He or she may insist that, after all, direct and non-causal apprehension of individuals (W. Ockham) or general forms and proper-

<!-- page: pdf=0005 printed=5 -->

ties (Plato) is possible. Or, being reluctant to that move, which tends to make our knowledge of the external world radically unnatural, he or she can take Russellian strategy: we are directly acquainted with sensory data and their properties, which give basic semantic content to our thought, and all the rest is constructed out of it. In addition, this seems to provide a plausible account of why we have infallible knowledge of our own thoughts and can come to erroneous beliefs about the external world. But even taking this Russellian strategy the advocate of meaning rationalism has to ignore the Wittgensteinian and Sellarsian criticisms of the idea of sensory given, because otherwise he or she would have to end with nothing to think at all [5]. 

How do these considerations bear on the issues of logical possibility and the _a priori_ ? On one reading of the concept of logical possibility, what is logically possible or impossible is determined by meaning, or at least somehow dependent on it. But if we agree on that and also construe meaning as content, we must also agree that logical possibility is not something known _a priori_ . For the above mentioned reasons, it is not an epistemic given for a thinker that he or she has a thought with the same content as a few minutes ago. If so, he or she will be unable to recognize _a priori_ that his or her thoughts are content-contradictory, because this would require the ability to recognize _a priori_ the same thought content again, that is, to recognize it under negation. Hence, if we want to hold that logical possibility depends on meaning and is known _a priori_ , we cannot replace “content” for “meaning”, and consequently have to look for another construal. 

Perhaps there is a way of saving logical possibility and its _a priori_ giveness by taking “meaning” as “mode of presentation”. For instance, Frege claimed that a rational person will not af�rm and deny the same propositional content under the same _mode of presentation_ , and this seems to be a perfectly reasonable claim. But such a position has, according to Millikan, unacceptable consequences. It implies that under some favourable circumstances, that is, under the right modes of presentation, we can tell _a priori_ what is objectively logically impossible (logically impossible on the level of content), and from there infer what, in opposition to that, is objectively logically necessary (logically necessary on the level of content). However, the rest, what on the level of mode of presentation appears as logically possible, would correspond to a heterogeneous class consisting both of what is objectively logically possible (logically possible on the level of content) and objectively logically impossible (impossible on the level of content), although not known _a priori_ . To put it differently, logical possibilities lose under this account their objective ontological signi�cance: they “correspond not to sets of possible worlds but to _thoughts_ that cannot be rejected without further evidence” (Millikan, 1993, p. 321). 

Nevertheless, even this dubiously coherent position may be undermined by further analysis of what modes of presentations really are. Either they are simply psychological roles having no semantical or contentful facet, or they are semantical modes but are not given _a priori_ . We should then �nally give up meaning rationalism as “a Very Bad Idea and a Hopeless Dead End”, along with belief in objective logical possibility which is given _a priori_ .

<!-- page: pdf=0006 printed=6 -->

##### **_A priori_ knowledge defended** 

This has been the general line of Millikan’s argument which she thinks of as supporting the conclusion that logical possibilities and impossibilities are not given _a priori_ . Of course, if true, this conclusion decisively refutes the view that we can _a priori_ know logical possibilities and impossibilities, and consequently logical truths. But there are at least two forms of that view. According to the �rst form, we can _always_ know _a priori_ whether something is logically possible or impossible. However, if such a view entails that any logical truth can be established by means of a deductive _a priori_ proof, then one may wonder who really holds it. After all such a view seems to be in salient con�ict with various metalogical limitative theorems, for instance, with the theorem about undecidability of predicate logic. So if Millikan has argued against this unrestrictive view, she would argue against a view that (almost) nobody holds. So let us suppose that her argument is directed against restrictive and modest form of the view in question (which is indeed quite widely held), namely, that we can _sometimes_ know _a priori_ whether something is logically possible or impossible. But under that supposition her critical remarks against the position described by her as “mode rationalism” seem to lose their force. This is because the proponent of the restrictive view is quite ready to admit that from the epistemological point of view logical possibilities indeed constitute rather heterogenous class: there are logical possibilities which can be shown _a priori_ to obtain, and ones that perhaps cannot be established neither _a priori_ , nor empirically. 

Nonetheless, one can question Millikan’s criticism of meaning rationalism and her refusal of _a priori_ knowledge of logical truths not only by raising these worries about a particular step of her argument, the worries which at best can lead merely to some modi�cations or quali�cations of her general conclusion. I believe that there is a prospect of a more thoroughgoing criticism here, since arguably without undermining most of her background presuppositions one can still succeed in showing that, after all, at least some logical possibilities and impossibilities are known _a priori_ . 

Let’s start from the clari�cation of the claim that something is known _a priori_ . The traditional, often invoked de�nition says that something is known _a priori_ if it is known independently of experience. But such a de�nition is hardly illuminating without making explicit what kind of independence is in question and what is meant by experience. Here are two recent proposals which try to be more explicit about that. 

Philip Kitcher (1980) holds that _a priori_ knowledge cannot be knowledge gained either through “outer experience”, that is, through sensory states produced by stimuli external to a person’s body, or through “inner experience”, that is, through sensory states brought about by internal stimuli. _A priori_ knowledge is independent from experience in the sense that a person could have had that knowledge whatever experience he or she had had. Kitcher admits, however, that we must allow a minimal role of experience in _a priori_ knowledge: experience may be needed in acquiring and understanding of the concepts involved in such knowledge. Hence the condition of independence for _a priori_ knowledge may be put in the

<!-- page: pdf=0007 printed=7 -->

following way: “knowledge is independent of experience if any experience which would enable us to acquire the concepts involved would enable us to have the knowledge” (Kitcher, 1980, p. 5). By talking of experience in this context one has usually in mind not experience of a person in a certain particular moment _t_ but his or her total sequence of experiences. Kitcher proposes to call such a sequence “a life of a person”, adding that if a person with that life can gain a suf�cient understanding of believing in a given proposition _p_ , his or her life is “suf�cient” for _p_ . The next step in Kitcher’s proposal is a sketch of his favoured account of knowledge which he concludes with the following de�nition of _a priori_ knowledge: 

- (1) _X_ knows _a priori_ that _p_ if and only if _X_ knows that _p_ and _X_ ’s belief that _p_ was produced by a process which is an _a priori_ warrant for it. 

- (2) _w_ is an _a priori_ warrant for _X_ ’s belief that _p_ if and only if _w_ is a process such that, given any life _e_ , suf�cient for _X_ for _p_ , then 

   - (a) some process of the same type could produce in _X_ a belief that _p_ , 

   - (b) if a process of the same type were to produce in _X_ a belief that _p_ then it would warrant _X_ in believing that _p_ , 

   - (c) if a process of the same type were to produce in _X_ a belief that _p_ then (Kitcher, 1980, pp. 9–10). 

As a matter of fact this is merely a form of de�nition of _a priori_ knowledge. To make it more instructive one should go through a detailed account of processes producing beliefs and their types. But for the purpose of my argument against Millikan the most important feature of Kitcher’s analysis is his emphasis on the fact that in some sense experience may be needed for _a priori_ knowledge, and that the crucial factor in making knowledge _a priori_ is not how concepts used in it are constituted and identi�ed, but what is a warranting mechanism of that knowledge or its justi�cation. 

A somewhat similar way of proceeding in de�ning _a priori_ knowledge is preferred by Tyler Burge (1993) [6]. He says that a person’s knowledge is _a priori_ when it is underwritten by _a priori_ justi�cation or entitlement that needs no further justi�cation or entitlement to make it knowledge. A justi�cation or entitlement is _a priori_ if its “justi�cational force is in no way constituted or enhanced by reference to or reliance on the speci�cs of some range of sense experiences or perceptual beliefs” (Burge, 1993, p. 458). The difference between entitlement and justi�cation is such that entitlements are warrants that need not be understood by or even accessible to the subject. The warrants of this kind cannot be relevant to justi�cations, since the latter involve only reasons accessible to the subject. Burge emphasizes that for a justi�cation or entitlement to be _a priori_ it is not necessary to have its justi�cational force constituted in complete isolation from experience. The justi�cational force must be in that case independent from _speci�cs_ of sense experiences, but it can depend on entirely general aspects of them. Moreover, what is at stake while talking of independence of _a priori_ knowledge from experience is its _justi�cational force_ . It is obvious, Burge maintains, that _a priori_ justi�cation always depends in some way on experience: some sensory experiences are typically necess-

<!-- page: pdf=0008 printed=8 -->

ary for the acquisition and understanding of concepts, beliefs and propositions involved in _a priori_ knowledge [7]. 

What lesson can be drawn from those accounts of _a priori_ knowledge? They clearly show, I think, that one can accept Millikan’s criticism of meaning rationalism, along with the claim that meanings are not given in an epistemically privileged way and that in their understanding a lot of information gathered from experience and “third-person” point of view are involved, but _still_ hold that logical truths are known _a priori_ . It is so because justi�cation of those truths is _a priori_ : it does not have to rely on anything other than meanings of terms used in them. The amount of empirical knowledge required for the correct grasp of meanings of the terms is simply irrelevant to the _a priori_ character of justi�cation [8]. 

The obvious response to such a defence of _a priori_ knowledge is to say that there are simply no justi�cations which are _a priori_ in the above sense, that is, there are no justi�cations (or entitlements in Burge’s sense) based only on meanings. Nevertheless taking this strategy inevitably leads to the thesis that all meanings or contents are simple, unstructured items and completely independent of each other. If one is not willing to accept such a thesis and admits structured contents, overlapping meanings, constitution of some contents by other contents, he or she already has everything that is necessary to argue for the possibility of _a priori_ justi�cations [9]. 

But what really prevents us from claiming that meanings or contents are indeed unstructured and independent items? The most plausible answer is: a simple re�ection on what it is to possess a certain content. For example, possession of the concept of square by a given subject consists, among other things, in his or her disposition to accept the statements like “square is a �gure”, “square is some kind of rectangular”, “square has four equal sides”, etc. If someone is not disposed to accept any of those statements, it would be highly implausible to claim that he or she has the concept of square. This shows, it seems to me, that in order to possess such an apparently simple concept as square one must have a range of various other concepts, more or less closely related to it. It suggests also how we can know the truth-values of some statements without acquiring additional empirical evidence, and how their _a priori_ justi�cation would proceed. To put that brie�y: we just make explicit or “unpack” the content of a given concept or its possession conditions. 

Nevertheless, this proposal is vulnerable to the following two-pronged objection [10]. First, it is not at all clear how to single out the class of statements that someone has to be disposed to accept in order to possess a given content or concept. Is it really the case that if someone is not disposed to accept one or two basic statements mentioned above, he or she does not possess the concept of square? Maybe it is still plausible to claim that the person in question has the concept of square, although his or her knowledge of square is just not so rich as ours. Second, the basic statements associated with the use of a given concept presumably include such simple truths as “children are taught about squares and their properties in primary schools”. However, one can easily imagine a person who has no knowledge whatsoever about schooling but still may be said to possess the concept of square, and even have perfect geometrical knowledge. Moreover, by binding such truths with the pos-

<!-- page: pdf=0009 printed=9 -->

session conditions of a concept, one would incorporate the contingent knowledge of the world into the possession condition of a given concept. And since, in accordance with what has been suggested here, _a priori_ justi�cation and knowledge are based upon those possession conditions, _a priori_ knowledge would amount to the knowledge we already have, which clearly is not the case. Therefore, to make the proposal plausible one has to specify what can be included in the possession conditions of a given concept, and what cannot, as well as to supply at least a general guideline (if not a precise criterion) for the distinction between what counts as a possession condition that can be used in justifying the alleged _a priori_ knowledge and what counts as the knowledge we already have that cannot be used for that purpose. 

The most plausible reply to that objection would be along the following lines. In selecting the statements intimately connected with the possession condition of a given concept one should not be guided merely by the fact that they are simple, or obviously true, or primitively compelling. One has to settle whether they are constitutive of a given concept and its possession conditions. But how to decide whether they are constitutive or not? A familiar strategy would be to engage in thought experiments that would enable one to determine if there is a possible world in which someone possessing a given concept may be not prepared to accept the statement in question. Of course, it is quite easy to imagine such a world in the case of the concept of square and the statement “children are taught about squares and their properties in primary schools”, but not in the case of the statement “square is a �gure” or “square has four sides”. But even if that strategy appears to be successful, am I not, by endorsing it, running into the risk of claiming—what seems to be extremely implausible—that only necessary statements may count as constitutive of the possession conditions of a given concept? Arguably not. One should be careful here and distinguish between necessary truths (holding in all possible worlds), and truths that hold �xedly, or in a stable way, in the actual world and in any possible world in which a given concept is possessed by a thinker (whether a given concept is possessed or not is of course quite a contingent matter). Yet, if Millikan grants what has been said in the preceding paragraphs [11], she may still question the relevance of those considerations by pointing out that such conceived _a priori_ knowledge does not have the attributes traditionally ascribed to it: certainty, indubitability, incorrigibility, unrevisability, non-triviality, necessity. It is quite likely that while determining the possession conditions of a given concept or “unpacking” its content we may make mistakes (for instance, we may assume that square and circle belong to two radically different categories and no important relations hold between their respective concepts constitutive of their contents). If we decide to eliminate the possibility of error and insist on keeping strong links between certainty or incorrigibility and _a priori_ knowledge, then we would have to do it by restricting the scope of _a priori_ knowledge to a set of very elementary and trivial truths (“square is a �gure”, “square has four sides”, etc.). Hence, Millikan might conclude, the refutation of meaning rationalism still entails the thesis that there are no logical truths known _a priori_ , provided that we stick to the traditional or standard sense and scope of aprioricity, according to which _a priori_ knowledge is for the most part substantial, incorrigible and necessary knowledge. The mere play with words

<!-- page: pdf=0010 printed=10 -->

and watering down the notion of aprioricity is not able to diminish the signi�cance of that refutation. 

Now Millikan’s opponent can either concentrate on further reasons supporting his or her supposedly broad account of _a priori_ knowledge, or inquire what is exactly the character of logical modalities, as well as logical and mathematical knowledge, under the assumption that radical externalism is true. It seems that externalism goes naturally with empiricist theory of logical and mathematical knowledge: logic and mathematics exemplify a special kind of inductive empirical knowledge, and logical possibilities and impossibilities are nothing more than very general empirical possibilities and impossibilities. Taking into account Millikan’s enthusiasm for a posteriori knowledge, and providing that she would be rather reluctant to introduce metaphysical possibilities and impossibilities into nature, this view should appeal to her as a plausible philosophy of logic and mathematics. But if so, she would have against her view a fair amount of developmental psychological research showing that infants’ and children’s sensitivity to numbers and logical relations does not �t very well with empiricist epistemology [12]. The logical and mathematical abilities appear simply too early in order to be fully explained as a result of experience of the world by an infant or child. But here Millikan can give a quick answer: those psychological experiments show only that infants have some innate knowledge, which was genetically acquired from their parents, and they in turn got it from their ancestors, and so forth. What we call innate knowledge was shaped by long-term evolutionary processes. Therefore this knowledge is not _a priori_ at all. It is independent from experience merely in relation to a particular individual but not in relation to human species in general, especially if we see it in a wide evolutionary perspective. But this answer leads us back to the issue of the proper analysis of _a priori_ knowledge. At this point, however, we can see clearly that the strategy of imposing more and more strong conditions on _a priori_ knowledge results in our gradual losing a grip on how and in what circumstances humans might attain such knowledge. This is obviously not a strategy to be preferred if one does not want to presuppose from the beginning that there is no _a priori_ knowledge. 

Thus the outcome of the above discussion seems to support the following conclusion: given a reasonably modest conception of _a priori_ knowledge, what Millikan takes as a decisive refutation of meaning rationalism does not entail that logical truths are not knowable _a priori_ . In other words, the impossibility of _a priori_ knowledge does not follow from the refusal of meaning rationalism. 

##### **Transparency of content moderated** 

After establishing that conclusion one may take a further step back and consider whether Millikan is really right in her campaign against meaning rationalism or transparency of content. Remember that she takes meaning rationalism as a doctrine consisting in three claims: (1) a rational person can recognize _a priori_ whether any of his or her thoughts have the same meaning; (2) a rational person is able to recognize _a priori_ whether his or her thought is ambiguous or not; and (3) a rational person can settle _a priori_ whether his or her thought is meaningful or not. In other

<!-- page: pdf=0011 printed=11 -->

words, meaning rationalism assumes _a priori_ giveness of meaning identity and difference, of univocity, and of meaningfulness. Let us compare this doctrine with the following statement of meaning transparency which one �nds in Dummett’s writings: 

It is undeniable feature of the notion of meaning—obscure as that notion is—that meaning is _transparent_ in the sense that, if someone attaches a meaning to each of two words, he must know whether these meanings are the same. (Dummett, 1978, p. 131) 

Surely the quoted passage is undetermined in one crucial aspect: Dummett does not say in what way the person acquires knowledge whether meaning of the two words in question are the same. But there cannot be much doubt that he has in mind here some kind of _a priori_ knowledge, which the person may get without recourse to empirical evidence [13]. However, even after that plausible addition Dummett’s formulation of meaning transparency is by no means equivalent to what Millikan understands by meaning rationalism. Of course, she can argue that Dummett does not intend to restrict the postulated transparency merely to the _a priori_ knowledge of meaning sameness, since the transparency of meaning difference is closely related to it (indeed this seems to be the other side of the same coin—if someone believes that meaning of two words are not the same, he or she holds in effect that they are different). Moreover, if one agrees with Millikan’s claim that the second element of her meaning rationalism—the _a priori_ giveness of univocity—is derivable, under some assumptions, from the �rst, it would not be perhaps mistaken to say that Dummett’s transparency requirement is equivalent to the �rst two constituents of Millikan’s meaning rationalism. Thus we are left with the third constituent, that is, with the _a priori_ giveness of meaningfulness. That constituent is certainly a very substantial addition to the �rst two claims of meaning rationalism, provided that it is understood in the light of Millikan’s externalist view on determination of content (roughly speaking, the view that a semantic content or meaning of an expression is determined by the object to which it refers). Its obtaining would give us a lot of _a priori_ information about the external world and enable us to refute certain forms of scepticism in a very simple way. Given those paradoxical consequences, one may wonder whether meaning rationalism is such a widespread doctrine as Millikan supposes. 

However, this does not seem to be the only difference between Dummettian meaning transparency and meaning rationalism as construed by Millikan. The other crucial thing is what kind of meaning sameness or difference is involved in these two conceptions. Millikan thinks that a proponent of meaning rationalism ascribes to a rational person the ability to discern _a priori_ whether he or she thinks the same thought again, attaches the same meaning to a word used again after a considerable lapse of time, etc. That is to say, she assumes that meaning rationalism attributes to a thinker the _a priori_ ability to identify and reidentify over time the entertained thoughts, the objects referred to, the properties being ascribed, and the like. In this vein she construes, for instance, the requirement which is sometimes called “Russell’s Principle”, to the effect that in order to think about an object one must

<!-- page: pdf=0012 printed=12 -->

know which object it is that one is thinking about; she sees it as requiring that a rational person should be able to tell on the _a priori_ grounds whether he or she is thinking about the same object again or not [14]. This is indeed a very strong requirement, and if the thinking subjects happen to be philosophers having a lot of worries whether during last night they have not been transported on Twin Earth, they may come to the conclusion that it is impossible to have transparent thoughts about at least all objects lasting in time. What is usually taken as the transparency of meaning requirement seems to be much weaker: it requires only the subject’s ability to discern _a priori_ whether now he or she attaches the same meaning to two given expressions at a certain time. We can then expand the Dummett’s formulation of meaning transparency as follows: 

It is undeniable feature of the notion of meaning—obscure as that notion is—that meaning is _transparent_ in the sense that, if someone attaches at a certain time a meaning to each of two words, he must know _a priori_ , at that time, whether these meanings are the same or different. 

One really needs a lot of philosophical ingenuity and strong assumptions to get from that modest transparency of meaning (which would be indeed impossible to rebut successfully) the meaning rationalism which Millikan makes a target of her attack. 

It seems to me that against the modest or weak transparency of meaning Millikan can merely raise some worries based on her epistemological principle claiming priority of the third-person point of view over the �rst-person point of view. She may insist that Dummett’s requirement somehow puts the �rst-person knowledge before the third-person knowledge, but—strictly speaking—only the latter provides us with genuine knowledge of what is there anyway. Of course, sticking to that epistemological principle, she can always �nd a gap and divergence between objective semantic relations, established from the third-person point of view, and subjective psychological roles and thought connections, which make themselves manifest from the �rst-person point of view. This is the main reason why her arguments against meaning rationalism seem sometimes to be so convincing all the way through. Millikan thinks that this epistemological preference has a very simple justi�cation: “[p]hilosophy in the �rst person cannot be primary, for the �rst person is as much in the empirical world as anything else and can be accessed at all only by understanding its relation to the rest of the world it is in” (Millikan, 1993, p. 201). Nevertheless, while agreeing with this observation, one can still press the question of the precise epistemological status of the third-person point of view, and the extent to which it transcends and undermines the �rst-person point of view. It seems to me that even for someone without deep veri�cationist or anti-realist sympathies, the unquali�ed talk about the superiority of the third-person point of view comes too close to the “God’s eye view” that none of us is able to attain. 

##### **Acknowledgements** 

A former version of that paper was presented at 43rd Annual Conference of New Zealand Division of Australasian Association for Philosophy, Massey University,

<!-- page: pdf=0013 printed=13 -->

August 1996, and an early ancestor of it was given at 4th Annual Conference of European Society for Philosophy and Psychology, Oxford University, August 1995. For stimulating discussions and insightful comments I am indebted to John Bigelow, Andre´ Gallois, Ruth Garrett Millikan, Tim Williamson, and an anonymous referee for _Philosophical Psychology_ . The paper was completed during the tenure of my University of Queensland postdoctoral research fellowship. 

##### **Notes** 

- [1] As long as Millikan sharply distinguishes between psychological thoughts and semantical meanings, she can argue that the refusal of meaning rationalism does not amount to the denial of self-knowledge, of the intuitive idea that we have privileged access to our own thoughts. But she must certainly admit that this refusal substantially diminishes the extent of our self-knowledge. 

- [2] Actually the matters in this respect are more complicated than suggested by Millikan’s remarks. For someone who takes that rationality and propositional mental states have essentially normative status, they seem to invite and encourage an attempt to get a normative notion of semantical rationality out of the descriptive notion of “mechanical” rationality, which apparently has to commit some form of the naturalistic fallacy, or, in other words, accept the framework of crude psychologism. For a proponent of such a view to say that a rational person is a semantically rational person is not to beg the question at all but to acknowledge the _sui generis_ character of the mental. For a criticism of Millikan’s approach along those lines, see the paper by John McDowell (unpublished). 

- [3] While proposing these distinctions, Millikan makes heavy use of David Kaplan’s ideas. Since I am not going to discuss all the details of her argument, I have decided, for the clarity of exposition, to put the niceties aside. 

- [4] In this passage the author speaks not of content _simpliciter_ but about _kontent_ (which is content as conceived by Kaplan). One can ignore here this subtlety. 

- [5] Millikan sees the elements of this strategy even in Frege’s semantics, and especially in his distinction between sense and reference ( _Sinn_ and _Bedeutung_ ). She writes: “Frege’s _Sinne_ (or more accurately but awkwardly, grasping of these) are his intermediaries for thought about the world. _Sinne_ are what stand between mind and world, making errors in thought possible. More telling, _Sinne_ are what move the mind: differences among _Sinne_ account for differences in movement if the mind is rational” (Millikan, 1991, p. 452). Again, McDowell (unpublished) �nds this construal of Frege’s semantics objectionable, on the grounds that it reduces normative semantic rationality to “mechanical” rationality and makes Frege’s views “nakedly psychologistic”. 

- [6] Of course, I mean here only similarity relevant to the purpose of the present considerations. In many other respects there are signi�cant dissimilarities between these two accounts of a priori knowledge, especially in the general picture of knowledge presupposed by them and in their respective assessments of prospects of attaining a priori knowledge. 

- [7] This point is also, to some extent, accommodated by Laurence BonJour in his recent detailed defence of a priori knowledge and justi�cation. He proposes to count a proposition as being justi�ed a priori “as long as no appeal to experience is needed for the proposition to be justi�ed _once it is understood_ , where it is allowed that experience may have been needed to achieve such an understanding” (BonJour, 1998, p. 10). However, unlike Burge, he does not agree that a priori knowledge and justi�cation _always_ depends in some way on experience. 

- [8] But perhaps we can make a distinction here and say that when this empirical knowledge is minimal, we come to know logical truths _simpliciter_ , and when it is rich and detailed, we are dealing with instances or particular examples of certain logical truths. 

- [9] Consequently, one can argue that there is something distinctive about our concepts which makes a priori justi�cation possible. For a development of this idea, see Peacocke (1993).

<!-- page: pdf=0014 printed=14 -->

- [10] That objection was raised by an anonymous referee, although the example used by him or her was different. 

- [11] Perhaps she would object to that approach on largely methodological grounds. See e.g. her pronouncements in Millikan (1994, p. 76). 

- [12] See, for instance, Wynn (1993). An ingenious philosophical theory, partially explaining those phenomena has been proposed by Colin McGinn (1993). 

- [13] As suggested by Paul A. Boghossian (1994, p. 33). 

- [14] McDowell (unpublished) considers that reading of Russell’s Principle as highly implausible. 

##### **References** 

BOGHOSSIAN, P.A. (1994). The transparency of mental content. _Philosophical Perspectives_ , _8_ , 33–50. 

BONJOUR, L. (1998). _In defense of pure reason: a rationalist account of a priori justi�cation_ . Cambridge: Cambridge University Press. 

BURGE, T. (1993). Content preservation. _Philosophical Review_ , _102_ , 457–488. 

DUMMETT, M. (1978). _Truth and other enigmas_ . London: Duckworth. 

KITCHER, P. (1980). A priori knowledge. _Philosophical Review_ , _89_ , 3–23. 

MCDOWELL, J. (unpublished). Naturalism and Cartesianism in the philosophy of mind. 

MCGINN, C. (1993). Logic, mind, and mathematics. In B. DAHLBOM (Ed.) _Dennett and his critics_ . Oxford: Blackwell. 

MILLIKAN, R.G. (1991). Perceptual content and Fregean myth, _Mind_ , _100_ , 439–459. 

MILLIKAN, R.G. (1993). _White Queen psychology and other essays for Alice_ . Cambridge, MA: MIT Press. 

MILLIKAN, R.G. (1994). On unclear and indistinct ideas, _Philosophical Perspectives_ , _8_ , 75–100. 

PEACOCKE, C. (1993). How are a priori truths possible? _European Journal of Philosophy_ , _1_ , 175–199. 

WYNN, K. (1993). Evidence against empiricist accounts of the origins of numerical knowledge. In A.I. 

GOLDMAN (Ed.) _Readings in philosophy and cognitive science_ . Cambridge, MA: MIT Press.
