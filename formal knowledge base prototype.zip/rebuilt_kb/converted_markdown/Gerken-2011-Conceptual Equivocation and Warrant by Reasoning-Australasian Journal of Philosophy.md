---
title: "Conceptual Equivocation and Warrant by Reasoning"
source_type: "paper"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Gerken-2011-Conceptual Equivocation and Warrant by Reasoning-Australasian Journal of Philosophy.pdf"
source_id: "gerken-2011-conceptual-equivocation-and-warrant-by-reasoning-australasian-journal-of-philosophy-099909ee310b"
source_sha256: "099909ee310bbf28c1e0a54fdccfdbed2e86d81cbc00a5d4048720cd404b13f8"
conversion_status: "extracted"
conversion_date: "2026-11-09T23:36:28+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/gerken-2011-conceptual-equivocation-and-warrant-by-reasoning-australasian-journal-of-philosophy-099909ee310b-7a19f5c00c.json"
---

# Conceptual Equivocation and Warrant by Reasoning

<!-- page: pdf=0001 printed=1 -->

## **Australasian Journal of Philosophy** 

**ISSN: 0004-8402 (Print) 1471-6828 (Online) Journal homepage: www.tandfonline.com/journals/rajp20** 


# **Conceptual Equivocation and Warrant by Reasoning** 

#### **Mikkel Gerken** 

**To cite this article:** Mikkel Gerken (2011) Conceptual Equivocation and Warrant by Reasoning, Australasian Journal of Philosophy, 89:3, 381-400, DOI: 10.1080/00048402.2010.488267 

**To link to this article:** <u>https://doi.org/10.1080/00048402.2010.488267</u> 


Published online: 04 Jun 2010. 


Submit your article to this journal 

Article views: 507 


View related articles 


Citing articles: 2 View citing articles

<!-- page: pdf=0002 printed=0 -->

### CONCEPTUAL EQUIVOCATION AND WARRANT BY REASONING 

#### Mikkel Gerken 

In this paper, I challenge a widely presupposed principle in the epistemology of inference. The principle, (Validity Requirement), is this: S’s (purportedly deductive) reasoning, R, from warranted premise-beliefs provides (conditional) warrant for S’s belief in its conclusion only if R is valid. 

I argue against (Validity Requirement) from two prominent assumptions in the philosophy of mind: that the cognitive competencies that constitute reasoning are fallible, and that the attitudes operative in reasoning are antiindividualistically individuated. Indeed, my discussion will amount to a defence of anti-individualism against a novel ‘slow-switch’ argument against it. 

This argument contra anti-individualism has it that given anti-individualism and certain auxiliary assumptions, A, a switched reasoner may, in certain slow-switch circumstances, C, reason invalidly by equivocating concepts. More specifically: 

- (Valid 0): Peter is in circumstances C, and auxiliary assumptions, A, hold. (Valid 1): If Peter is in circumstances C, and auxiliary assumptions A hold, then (if the attitudes operative in Peter’s reasoning R are antiindividualistically individuated, then R is not valid). 

(Valid 2): Peter’s reasoning, R, generates warrant for the conclusion-belief. (Valid 3): Peter’s reasoning, R, generates warrant for the conclusion-belief only if the reasoning, R, is valid. 

- (Valid 4): So, the attitudes operative in Peter’s reasoning R are not antiindividualistically individuated. 

The argument involves weaker premises than those of familiar slow-switch arguments against anti-individualism. In particular, it requires only that the reasoning be de facto valid. This assumption is much weaker than the requirement that the validity of the reasoning be ‘transparent’ to the reasoner. Indeed, (Valid 3) is simply an instance of (Validity Requirement). 

However, I argue that anti-individualism and (Valid 0)–(Valid 2) should be upheld at the expense of (Valid 3). In consequence, (Validity Requirement) stands in need of restriction. Thus, I argue for a surprising result in the epistemology of inference from widely accepted assumptions in the philosophy of mind.

<!-- page: pdf=0003 printed=1 -->

##### 1. Introduction 

In this paper, I investigate epistemic warrant of the sort that may be acquired by reasoning.<sup>1</sup> I do so by integrating this epistemological issue with philosophy of mind in two ways. First, I focus on the cognitive competencies, the exercise of which constitutes reasoning. Second, I assume that the attitudes that are operative in reasoning are anti-individualistically individuated. I proceed as follows: 

In x2, I articulate and motivate an influential principle, (Validity Requirement), according to which purportedly deductive reasoning must be valid to provide warrant. 

In x3, I articulate a novel slow-switch reductio of anti-individualism. Since it derives from the principle (Validity Requirement), I label it ‘The Validity Argument’. 

In x4, I argue, contra (Validity Requirement), that slow-switched agents may generate warrant by reasoning that exhibits the fallacy of equivocation. 

In x5, I defend my response against the objection that the equivocating reasoner is not warranted in the conclusion-belief but merely cognitively blameless. 

In x6, I conclude with a methodological moral. 

##### 2. The Traditional Conception of Warrant By Reasoning 

A broad traditional assumption—let us call it ‘(Environmental Independency)’—is that the warranting force of purportedly deductive reasoning is independent of the agent’s relations to the environment. Purportedly deductive reasoning, it is said, is distinctive in that the warrant it may provide depends only on the form of the reasoning and the warrant of its premise-beliefs. In this section, I articulate a more specific principle that aims to capture a central aspect of this traditional idea. 

##### 2.1 The Classical Biconditional: (Transmission) and (Validity Requirement) 

Consider the following biconditional—‘the classical biconditional’ or ‘(CB)’ for short: 

(CB) S’s (purportedly deductive) reasoning, R, from warranted premise-beliefs provides (conditional) warrant for S’s belief in its conclusion iff R is valid. 

The right-to-left direction of (CB) is often labelled ‘(Transmission)’ and has been subject to much criticism.<sup>2</sup> In contrast, the left-to-right direction of (CB) is rarely explicitly discussed and has yet to receive a name. So, let’s call it ‘(Validity Requirement)’. 

> 1I use ‘warrant’ broadly as the genus under which internalist and externalist species, ‘justification’ and ‘entitlement’, fall [Burge 2003]. Neither notion is factive. 

> 2See [Dretske 1970, 1971; Davies 2003; Wright 2000].

<!-- page: pdf=0004 printed=2 -->

I will argue that (Validity Requirement) requires restriction. Interestingly, (Validity Requirement) appears to now have the status that (Transmission) had before it was articulated and criticized: while the principle is widely relied upon, it has rarely been explicitly articulated or defended. Consequently, I shall clarify the above articulation of (Validity Requirement) and provide a central rationale for upholding it. 

(Validity Requirement) is restricted to purportedly deductive reasoning.<sup>3</sup> The term ‘purportedly’ does not indicate a higher-order representation. Rather, whether a line of reasoning is purportedly deductive is determined by the standards that are relevant for assessing the form of the reasoning. If a line of reasoning is to be assessed by considering whether it is truthpreservative in virtue of its form, the reasoning is purportedly deductive. Of course, whether a line of reasoning is subject to abductive or deductive standards depends to a large extent on the thinker’s psychology.<sup>4</sup> But it does not primarily depend on how the reasoner represents the reasoning. A line of reasoning may be purportedly deductive although the reasoner has no higher-order intention that the reasoning be deductive and no representation of it as deductive. Indeed, a thinker may engage in purportedly deductive reasoning without possessing the concept <u>deduction.</u><sup>5</sup> 

Furthermore, if a thinker misrepresents herself as reasoning deductively although she in fact reasons, say, abductively, she is not engaged in purportedly deductive reasoning. So, it is no objection to (Validity Requirement) to argue that a reasoner may misrepresent herself as reasoning deductively although she is in fact engaged in warrant-producing abductive reasoning. According to the notion of ‘purportedly’ in question, such reasoning is not purportedly deductive. 

Note, finally, that an invalid line of reasoning may be purportedly deductive. We may regard someone as reasoning invalidly precisely because the reasoning falls under the standard of truth-preservation in virtue of form and fails to meet that standard. 

The parenthetical qualification ‘(conditional)’ is included in (Validity Requirement) in order to account for the familiar fact that the warrant for the conclusion-belief of a line of reasoning is dependent on the warrant for the premise-beliefs. Furthermore, the qualification addresses Gilbert Harman’s point that logic alone does not normally establish whether a conclusion of some valid argument should be adopted: 

So-called deductive rules of inference are not plausibly construed as rules of deductive acceptance that tell us what conclusions we may accept, given that we already have certain antecedent beliefs. For example, although the deductive rule of modus ponens is sometimes stated like this ‘‘From P and If p, then Q, infer Q,’’ there is no plausible rule of acceptance saying that if we 

> 3Applied to inductive, abductive and heuristically-based reasoning, the principle is clearly false. 

> 4It has proven to be very hard to specify the nature of the psychological processes that constitute purportedly deductive reasoning. For example, the suggestion that S is engaged in purportedly deductive reasoning when S aims to follow deductive inference-rules raises (equally?) hard questions about the nature of rule-following. For the present purposes, we need not settle these questions. In the cases to be discussed, it may be stipulated that the reasoners are engaged in purportedly deductive reasoning. Thanks to Tyler Burge and Ram Neta for discussion of this issue. 

> 5I use underlining to mention concepts/thoughts and single quotation marks to mention words/sentences.

<!-- page: pdf=0005 printed=3 -->

believe both P and If P, then Q, we may always infer or accept Q. Perhaps we should stop believing P or If P, then Q rather than believe Q. 

[Harman 1973: 157] 

Harman’s point has gained some orthodoxy. Nevertheless, it has remained common to regard the warranting force of purportedly deductive reasoning as constituted solely by the form of the reasoning and the warrant for the premise-beliefs. Whether the conclusion should be adopted or the set of premises should be given up depends on the epistemic status of the conclusion-belief vis-a`-vis the premise-beliefs. 

Thus conceived, Harman’s point does not compromise the common conception according to which validity remains a necessary condition on the generation of warrant for a conclusion-belief by purportedly deductive reasoning. Kent Bach articulates, on behalf of the traditionalists, the common conception as follows: 

[according to the common conception] . . . to be rational is to be logical. Logic is where to look for an account of good reasoning since, after all, logic is the theory of validity. Ideally, then, reasoning should follow the pattern of a valid argument. 

[Bach 1984: 37]<sup>6</sup> 

Similarly, Warren Goldfarb begins his introduction to logic as follows: 

Logic is the study of principles of reasoning. It is concerned not with how people actually reason, but rather with how people ought to reason if they wish to ensure the truth of their results. That is, by ‘‘principles of logic’’ we mean those that yield correct reasoning. 

[Goldfarb 2003: xiii] 

This view expressed by Goldfarb does not strictly entail (Validity Requirement). But it nevertheless illustrates the close affinity of the rules of logic and those of epistemic reasoning. Interestingly, Paul Boghossian provides an even more outright dictum: ‘ . . . the norms of rationality are the norms of logic’ [Boghossian 1994: 42]. 

In contrast, (Validity Requirement) is a more modest principle. It expresses only the view that being a rational reasoner requires being logical. Although purportedly valid reasoning from warranted premises is no longer taken to be sufficient for inferentially warranted conclusion-beliefs, it is still widely presupposed that validity is necessary. 

##### 2.2 A Rationale for (Validity Requirement) 

As mentioned, (Validity Requirement) is relied on more often than it is defended. Consequently, I will provide a rationale for it before I criticize it.

<!-- page: pdf=0006 printed=4 -->

A general rationale for (Validity Requirement) begins with the basic idea that a belief is warranted only if it is connected to truth in a non-lucky manner.<sup>7</sup> A valid line of purportedly deductive reasoning is one way of providing a (conditional) contribution to such a truth-connection. But this way of connecting the conclusion-belief to truth appears to require that the reasoning be truth-preserving. Consider a true conclusion-belief which is generated by an invalid line of purportedly deductive reasoning from true warranted premise-beliefs. Despite the truth and warrant of the premisebeliefs, the fact that the conclusion-belief is true is epistemically lucky in the extreme. Even the non-factive truth-connection that is required for warrant does not allow for such a degree of epistemic luck. So, if a belief is generated by an invalid line of purportedly deductive reasoning, it is not warranted thereby. This claim is the contrapositive of (Validity Requirement). The idea which underlies this rationale may be expressed via an allegedly rhetorical question: If the (purportedly deductive) reasoning does not even preserve truth, then where is the truth-connection? 

The defender of (Validity Requirement) will answer that purportedly deductive invalid reasoning fails to provide any truth-connection—not even the sort required for warrant. So, it is concluded, by the platitudinous assumption that the truth-connection is required for warrant, that warrant by deductive reasoning requires that the reasoning be de facto valid. This epistemic rationale is principled in so far as it relies on general doctrines pertaining to the nature of warrant and validity. We may sloganize the rationale for (Validity Requirement) thus: 

No truth-preservation, no non-lucky truth-connection. No non-lucky truthconnection, no warrant.<sup>8</sup> 

The epistemic rationale sketched above is compatible with the idea that purportedly deductive reasoning’s distinctive contribution to warrant derives from its form. According to the rationale, it is because the valid reasoning is truth-preservative that the warrant for the premise-beliefs may be brought to bear on the epistemic status of the conclusion-belief. Of course, the premise-beliefs may be unwarranted or, as Harman noted, the conclusion may be wildly implausible. But these matters fall outside the scope of purportedly deductive reasoning’s contribution to warrant. Purportedly deductive reasoning connects premise-beliefs and the conclusion-belief on the basis of the formal relations between them rather than their particular content. So, the rationale fits the doctrine (Environmental Independency) rather nicely. The ultimate standard for reasoning is validity conceived as truth-preservation in virtue of form. Consequently, purportedly 

> 7It is a central goal of the theory of warrant to specify the relevant truth-connection in a manner that allows for warranted false beliefs. 

> 8I include the qualification ‘non-lucky’ in the slogan because some patterns of connection to truth may be epistemically lucky. To see this, consider a casino owner who, as part of a marketing stunt, rigs his roulette wheel to track the bets of a random guest, Luke. So, Luke’s guesses about a specific future contingent domain exhibit a pattern of connection to truth. But this truth-connection is lucky because the direction of fit is wrong. The world tracks Luke’s guesses, not vice versa. Thanks to an anonymous referee.

<!-- page: pdf=0007 printed=5 -->

deductive reasoning contributes to warrant only if it actually meets this standard of validity. 

Finally, (Validity Requirement) might be said to be indirectly motivated by appeal to the apparent absence of counter-examples to it. It might seem that there are no conceivable cases in which an agent is clearly warranted by an invalid line of purportedly deductive reasoning. So, the principle may be said to be abductively motivated in so far as it provides a unified explanation of all the cases which we have been able to conceive of.<sup>9</sup> 

##### 2.3 (Validity Requirement): Concluding Remarks 

It is not feasible to capture a grand epistemological tradition in a single principle. Yet, (Validity Requirement) captures a central tenet of the traditional idea that the warranting force of purportedly deductive reasoning is constitutively linked to validity. 

##### 3. A Novel Slow-Switch Reductio of Anti-Individualism 

In this section, I outline a novel argument against anti-individualism. The argument is based on a variety of a slow-switch thought experiment and (Validity Requirement). I will eventually argue that the lesson from the argument is the epistemological one that (Validity Requirement) requires restriction. But in this section, I present and motivate the argument. To do so, two working hypotheses must be articulated. 

##### 3.1 Two Working Hypotheses: Anti-Individualism and Well-Functioning Fallibility 

My first working hypothesis is that the attitudes operative in purportedly deductive reasoning are anti-individualistically individuated. That is, roughly, the attitudes are partly type-identified by certain patterns of relations holding between the attitude-bearing subject (and/or her species) and the wider environment. 

It will ease the subsequent discussion to illustrate anti-individualism via a Twin Earth thought experiment. Consider an agent, Ali, who regularly perceives aluminium in his environment on Earth. Assume that Ali has a physiologically and phenomenally internal twin, twin-Ali, who lives on a different planet, Twin Earth, which is causally isolated from Earth. Twin Earth differs from Earth in one respect. There is no aluminium on Twin Earth. Rather, there is an abundance of a distinct look-alike metal, twaluminium. Ali and twin-Ali are laymen with respect to metals and cannot discriminate between aluminium and twaluminium. They are internal or individualistic twins. 

> 9The methodology underlying this rationale may be questioned. I mention it since it is frequently invoked.

<!-- page: pdf=0008 printed=6 -->

The anti-individualist concludes from reflection on this thought experiment that Ali and twin-Ali possess non-univocal (or type-distinct) concepts since they stand in patterns of relations to different metals. So, importantly, according to anti-individualism, attitudes are partly individuated by factors (patterns of relations to the environment) that need not be available to the attitude-bearer. 

My second working hypothesis is that certain reasoning competencies are well-functioning fallible. Generally, a cognitive competence is well-functioning fallible if the optimal performance of it does not entail that it successfully fulfils its cognitive function. 

Perceptual competencies are paradigms of competencies that are well-functioning fallible. In certain epistemically abnormal circumstances, a perceptual competence is ‘tricked’ although it performs optimally. Although reasoning competencies are far less likely to be tricked in abnormal circumstances, it is psychologically possible that they sometimes are. More specifically, I assume that a reasoning-competence that I call ‘the univocality-competence’ is well-functioning fallible. 

The univocality-competence may be characterized as a competence that reliably redeploys only univocal concepts as middle terms in reasoning. It is possible to deploy two occurrences of the same concept in two successive thoughts without redeploying it. Assume, for illustration of this point, that Siri thinks the following two thoughts in succession: 

(Gold 1): The ring is made of gold. 

(Gold 2): Something is made of gold. 

Assume that Siri is, at every relevant level of specification, oblivious of the fact that the occurrence of the concept <u>gold</u> in (Gold 1) and the occurrence of <u>gold</u> in (Gold 2) are univocal. If so, her thinking does not amount to reasoning. Reasoning requires that the two occurrences of the concept operate as occurrences of the very same concept. To reason is, in part, to exercise a cognitive competence that governs this operation. This is the competence I label ‘the univocality-competence’. I suggest that optimal performance of the univocality-competence does not entail that two thought-components that are operating as univocal are in fact univocal. The univocality-competence, as ordinarily exercised, can go wrong although there is nothing wrong with it. Or so I hypothesize.<sup>10</sup> 

##### 3.2 Slow-Switching and Conceptual Equivocation 

Consider a so-called slow-switch case derived from Burge [1988] and Boghossian [1992, 1994]. Boghossian’s case involves memories about the Earthian tenor, Pavarotti, and his Twin Earthian counterpart,

<!-- page: pdf=0009 printed=7 -->

twin-Pavarotti. I shall consider a slow-switch case that involves natural kind concepts. 

An Earthling, Peter, comes to believe that some apples are red during his childhood on planet Earth. Later in life, Peter is unknowingly transported to Twin Earth. However, the apple-appearing fruits on Twin Earth are not apples. They are a different kind of fruit: twin-apples. After years on Twin Earth, during which Peter interacts with twin-apples and twinEarthians who speak about twin-apples, he acquires the new concept <u>apple</u><sup>te</sup> . Let us assume, however, that he retains his old Earthian concept <u>apple</u><sup><u>e</u></sup> . 

I represent the concepts by providing superscripts that serve as typemarkers. However, the type-markers are added solely for the convenience of the reader. It is stipulated that Peter is unaware of the environmental switch. So, arguably, Peter is not aware that he possesses two similar but nonunivocal concepts. Once he has acquired the <u>apple</u><sup>te</sup> concept, he comes to believe that all apples<sup>te</sup> are sweet. One day he recalls his previously held Earthian thought and connects it to his more recent Twin Earthian thought in equivocal reasoning: 

(Apple 1) Some apples<sup>e</sup> are red. 

(Apple 2) All apples<sup>te</sup> are sweet. 

(Apple 3) Something is both red and sweet. 

According to this take on the case, the two non-univocal concepts, <u>apple</u><sup>e</sup> and <u>apple</u><sup>te</sup> , operate, in Peter’s reasoning, as if they were univocal. If so, Peter reasons invalidly owing to a conceptual equivocation. 

Anti-individualism may be—and has been—taken to partly underwrite the view that Peter’s reasoning exhibits the fallacy of equivocation. First, the assumption that Peter has come to possess two type-distinct concepts may be partly motivated on anti-individualistic grounds. Patterns of relations have been holding between Peter and two distinct environments. Second, the assumption that Peter equivocates on the concepts <u>apple</u><sup>e</sup> and <u>apple</u><sup>te</sup> may also be explained, in part, by reference to anti-individualism. According to anti-individualism, concepts that do not differ in their individualistically specifiable features can be non-univocal (roughly, representationally type-distinct). This leaves open the psychological possibility that concepts operate as univocal although they are non-univocal. Thus, antiindividualism may contribute to an account according to which Peter’s univocality-competence exhibits well-functioning failure in the slow-switch case. 

However, anti-individualism does not by itself entail that Peter’s reasoning exhibits the fallacy of equivocation in a slow-switch scenario. This upshot requires a number of auxiliary hypotheses regarding the nature of reasoning, memory, attitude-individuation, concept-formation, etc. For example, anti-individualists may argue that Peter retains his Earthian concept rather than acquires a new one [Moya 2003]; that if there is a

<!-- page: pdf=0010 printed=8 -->

conceptual switch, it replaces the Earthian concept even in memorygenerated beliefs [Ludlow 1995b; Tye 1998]; that in the context of reasoning Peter’s memory works anaphorically so as to preserve univocality [Burge 1998; Schiffer 1992]; that a jade-like amalgam concept is formed [Heal 1998]; or that a tacit identity-belief is operative in the reasoning [Burge 2005], etc.<sup>11</sup> 

According to most of these ‘alternative’ interpretations, Peter’s reasoning is valid but unsound since Peter may be taken to argue from a false warranted premise-belief. If so, the epistemological assessment of Peter’s conclusion-belief is rather straightforward. If it is false, it is a false warranted belief. If it is true, it is arguably a true warranted belief that does not amount to knowledge. 

The alternative interpretations of Peter’s reasoning should not be dismissed as anti-individualistic kicking and screaming. Plausibly, each of them marks a psychological possibility. However, it may be argued that no single account is plausible for every specification of the slow-switch scenario.<sup>12</sup> In particular, it is plausible that Boghossian’s account according to which Peter’s reasoning exhibits the fallacy of equivocation also marks a psychological possibility. The central caveat is that anti-individualism does not by itself entail that Peter reasons invalidly. An account according to which he reasons invalidly requires a number of auxiliary assumptions about Peter’s psychology. 

This caveat is epistemically important and frequently overlooked. For the sake of the subsequent discussion, however, I grant that in some slow-switch circumstances, C, Peter’s reasoning exhibits the fallacy of equivocation given anti-individualism and a set of auxiliary psychological assumptions, A. Among the auxiliaries in A are, for example, a1: Peter acquires a novel concept, <u>apple</u><sup>te</sup> , a2: Peter retains the concept <u>apple</u><sup>e</sup> in memory, a3: Peter does not reason anaphorically on the occasion in question . . . an: No tacit identity belief <u>apples</u><sup>e</sup> <u>are apples</u><sup>te</sup> is operative in the reasoning. 

Let us stipulate that the relevant slow-switch circumstances, C, obtain and that the psychological possibility marked by A obtains. I will label this assumption ‘(Valid 0)’: 

(Valid 0): Peter is in circumstances C and auxiliary assumptions A hold. 

Given this assumption about Peter’s circumstances and psychology, the following premise may be upheld: 

> 11A referee notes an ingenious account according to which Peter’s concept apple is token-equivocal in both premises. By ‘token-equivocal’, the referee means that each token of apple has two semantic values simultaneously. So, the whole argument has two readings, each of which is deductively sound. However, there is a ‘Gettier’ premise-belief on each reading. This proposal appears to involve a commitment to a version of a view—often labelled ‘dialetheism’—according to which a non-indexical belief-token may be simultaneously true and false [Priest 2006]. Although the view has been motivated in other contexts, even proponents of the view recognize that it involves radical revisions of common-sense presuppositions. Clearly, arguing for or against the two-valued account is a major task. Likewise, developing and assessing an application of it in the present context is not feasible. So, while I acknowledge the competing account, I will simply state the case for an anti-individualist account that does not involve a commitment to a radically revisionist theory. Moreover, the positive account I will set forth contributes to a psychological explanation of Peter’s reasoning and preserves Peter’s epistemic rationality. 

> 12See Collins [2008] and Gerken [2007a: Chap. IV.iii.a–e] for arguments to this effect.

<!-- page: pdf=0011 printed=9 -->

- (Valid 1): If Peter is in circumstances C and auxiliary assumptions A hold, then (if the attitudes operative in Peter’s reasoning R are antiindividualistically individuated, then R is not valid). 

I have emphasized that conceptual equivocation does not invariably occur in slow-switch cases. This is epistemologically important. Since circumstances C mark a subset of the already abnormal slow-switch circumstances, (Valid 0) and (Valid 1) may be granted only given a proviso of epistemic abnormality. It is only in epistemically abnormal circumstances that a subject’s reasoning exhibits the fallacy of conceptual equivocation if attitudes are anti-individualistically individuated.<sup>13</sup> 

##### 3.3 The Validity Argument 

We are now, finally, in a position to formulate, on behalf of the individualist, a slow-switch-based argument against anti-individualism: 

##### <u>The Validity Argument:</u> 

- (Valid 0): Peter is in circumstances C and auxiliary assumptions A hold. 

- (Valid 1): If Peter is in circumstances C and auxiliary assumptions A hold, then (if the attitudes operative in Peter’s reasoning R are antiindividualistically individuated, then R is not valid). 

- (Valid 2): Peter’s reasoning R generates warrant for the conclusion-beliefs. 

- (Valid 3): Peter’s reasoning R generates warrant for the conclusion-beliefs only if the reasoning R is valid. 

- \ (Valid 4): The attitudes operative in Peter’s reasoning R are not antiindividualistically individuated. 

The Validity Argument has gone unnoticed in the extensive literature on slow-switching. This is remarkable since the premises of the Argument are weaker than those invoked by Boghossian in his slow-switch-based reductio of anti-individualism. Most notably, (Valid 3) is weaker than Boghossian’s key assumption that if Peter is rational, he can know a priori whether his reasoning R is valid. This assumption is based on a highly controversial transparency of difference principle [Boghossian 1994]. 

In contrast, (Valid 3) does not require that a reasoner can know anything (a priori or otherwise) about his reasoning or the states operative in it. It merely requires that the reasoning is de facto valid. So, (Valid 3) is not compromised by any of the forceful arguments against Boghossian’s transparency principle [Falvey and Owens 1994; Burge 1998; Brown 2004;

<!-- page: pdf=0012 printed=10 -->

Schroeter 2007]. It appears, then, that The Validity Argument is far more challenging to anti-individualism than Boghossian’s much-debated argument. 

Let us briefly consider the rationales for the premises of The Validity Argument. (Valid 0) is argued to be a psychological possibility that is stipulated to obtain. (Valid 1) is argued to mark a consequence of antiindividualism given (Valid 0). 

From a common-sense standpoint, (Valid 2) has some plausibility. Peter appears to be as rational as anyone; he is just unfortunate to be in cognitively inhospitable circumstances. However, this commonsensical judgment in favour of (Valid 2) stands in need of theoretical motivation. Interestingly, (Valid 2) may be motivated by radically distinct frameworks. For example, individualists may give rationales for (Valid 2) that require (Valid 3) to be true. In contrast, I shall develop an anti-individualistic rationale for upholding (Valid 2) that requires that (Valid 3) is false. In developing this rationale, I will argue that (Valid 2) is not merely plausible because Peter is cognitively blameless. 

Crucially, (Valid 3) is not motivated by reference to the slow-switch case. Rather, the premise is an instance of the widely presupposed principle (Validity Requirement). So, (Valid 3) inherits the general rationales for this principle outlined in x2.2 above.<sup>14</sup> 

In sum, The Validity Argument appeals to a commonly presupposed epistemological assumption, (Validity Requirement), rather than a commonly criticized principle of transparency. Yet the argument reaches a conclusion in the philosophy of mind: individualism. In response, I will argue that the two working hypotheses in the philosophy of mind provide strong grounds for revising the epistemological doctrine, (Validity Requirement). 

##### 4. Warrant Without Validity 

I shall consider three discernible but related reasons for upholding (Valid 2) and rejecting (Valid 3). First, this response may be motivated by reflection on the nature of reasoning competencies. Second, it may be motivated by a comparative Twin Earth thought experiment. Third, it may be motivated by comparing the case of Peter to more familiar Gettier-style cases. 

While each of the rationales may stand on its own, they form mutually reinforcing motivations for upholding (Valid 2) and rejecting (Valid 3). I will 

> 14 Because (Valid 3) is motivated only qua instance of (Validity Requirement), we should briefly reconsider the general rationales for (Validity Requirement) in the dialectical context of the present argument. The central rationale for (Validity Requirement) concerned how purportedly deductive reasoning may connect the conclusion-belief to truth. Recall the sloganized rationale for (Validity Requirement): No truthpreservation, no non-lucky truth-connection. No non-lucky truth-connection, no warrant. However, generally, a belief need only be generated or maintained by appropriately truth-conducive competencies to be regarded as warranted. So, it is viable to consider a weaker requirement on warrant by reasoning than the de facto validity requirement articulated by (Validity Requirement). The general rationale for (Validity Requirement) is inconclusive. Finally, the motivation of (Validity Requirement) by appeal to ‘the absence of counterexamples’ is entirely ineffective in the present context. What is at stake is precisely whether the case of Peter is a counterexample to (Validity Requirement).

<!-- page: pdf=0013 printed=11 -->

consider the rationales in turn and elicit connections between them as I go along. 

##### 4.1 Reasoning Competencies and Validity-Conduciveness 

Since reasoning requires the exercise of cognitive competencies, a competence-oriented approach is as appropriate in the theory of warrant by reasoning as elsewhere. According to a competence-oriented approach, a false belief that is generated by a highly truth-conducive cognitive competence may be warranted. In contrast, true belief that is generated by an unreliable cognitive competence is, ceteris paribus, not warranted. Thus, the epistemic status of a particular belief is not determined solely by considering whether it meets its representational objective, i.e. truth. Rather, it is the truth-conducive nature of the cognitive competence associated with the belief that is relevant for warrant. The truth-conduciveness of a cognitive competence may be partly characterized in terms of epistemically normal circumstances. Very roughly, a cognitive competence is truth-conducive when it yields (mainly) true beliefs when it is well-functioning in epistemically normal circumstances. 

Such a competence-oriented approach is compatible with the view that validity is at the heart of warrant by purportedly deductive reasoning. When such reasoning fulfils its central cognitive function, it is truth-preservative in virtue of its form. As mentioned, this idea may be taken as a rationale for (Validity Requirement). 

However, in hindsight, this rationale is misguided. First, it ignores that the attitudes operative in the reasoning are anti-individualistically individuated. Hence, the form that a line of reasoning has may plausibly depend on the relations that hold between the reasoner and the external reality that she often reasons about. Second, the rationale for (Validity Requirement) does not take into account the fact that the reasoning is constituted by the exercise of a fallible competence. My working hypothesis is that one aspect of the overall reasoning competence—namely the univocality-competence— is well-functioning fallible. Optimal performance of it does not entail that it fulfils its cognitive objective: univocality of the reasoning’s middle terms. The case of Peter suggests that the relations between the reasoner and the environment may change in a manner such that the basic constituents of the reasoning—the premise-beliefs—also change. In some such cases, the reasoning competence performs optimally and nevertheless produces a suboptimal outcome: the reasoning fails to fulfil its central cognitive objective, i.e. validity.<sup>15</sup> 

As mentioned, the distinctive contribution to warrant provided by the exercise of reasoning competencies is not truth itself. Rather, it is truthpreservation in virtue of form. A line of purportedly deductive reasoning successfully meets its central cognitive objective only if it is valid. 

> 15The qualification ‘central’ signifies that I remain silent on whether reasoning has other cognitive objectives than validity.

<!-- page: pdf=0014 printed=12 -->

Nevertheless, a line of reasoning should not be epistemically evaluated solely by reference to the particular outcome—i.e., de facto validity. Rather, it should be epistemically evaluated by reference to whether or not the overall reasoning competence is validity-conducive. 

Note that (Validity Requirement) is a de facto requirement. So, given that purportedly deductive reasoning’s contribution to warrant derives from validity-conduciveness rather than de facto validity, (Validity Requirement) is too strong. Hence, it fails to motivate (Valid 3). Thus, the present considerations support the anti-individualist response that consists in upholding (Valid 2) at the expense of (Valid 3). 

Thus far I have mainly been arguing at the level of principle. I will now substantiate the suggestion that Peter exercises a validity-conducive reasoning competence that fails to meet its cognitive objective although it performs well. As noted, the univocality-competence’s cognitive objective is that all and only univocal thought-components are operating as univocal. Roughly, since the univocality-competence fails to meet its cognitive objective, univocality of the middle terms of the reasoning, the reasoning itself fails to meet its central cognitive objective, validity. 

In Peter’s circumstances, C, epistemically abnormal circumstances have affected the thought-components that the univocality-competence is operating on. However, it is plausible that the circumstances have not otherwise affected the operation of the univocality-competence. If so, it is plausible to assume that the univocality-competence exhibits well-functioning failure. If so, the same thing may be said about Peter’s reasoning generally. If so, Peter’s reasoning should be taken to provide its ordinary contribution to warrant. Although it fails to meet its central cognitive objective, validity, it does so in a validity-conducive manner. The univocality-competence would have succeeded in epistemically normal circumstances. If so, the overall reasoning competence would have provided truth-preservation in virtue of form in epistemically normal circumstances. This suffices, ceteris paribus, for assuming that the reasoning provides its ordinary contribution to warrant.<sup>16</sup> 

Recall the assumption that if Peter is in circumstances C, then he is in epistemically abnormal circumstances [Gerken 2007a, 2009]. Crucially, one need not be warranted in believing that one is in normal circumstances. The point is crucial because it is general, that is, it holds both when one is in epistemically normal and when one is in epistemically abnormal circumstances.<sup>17</sup> If so, Peter may rightly ignore the possibility that he has been slow-switched even though this has in fact happened. 

Let us sum up the rationale from a competence-oriented approach. Peter is warranted in his conclusion-belief partly because his reasoning 

> 16The ‘ceteris paribus’ is a reminder that the premise-beliefs must be warranted, the reasoner must not have any indication that he is prone to a switch, the conclusion-belief must not be wildly implausible, etc. 17Compare with a lottery case: Even if Elsa’s ticket is in fact the winner, she is warranted in believing that she will lose the lottery. She is as epistemically unlucky as she is financially lucky. A similar point may be made about perceptual belief. Even if Ted is in fact in an illusion-circumstance or in an evil demon scenario, he may still be warranted in his perceptual belief. Likewise, even if Peter has in fact been slow-switched, he is epistemically rational in exercising his reasoning competencies as if he were not. Theorists who have it that Elsa and Ted are not warranted will not be impressed by the comparison. I am not here trying to impress theorists who defend such radical views.

<!-- page: pdf=0015 printed=13 -->

competencies are well-functioning. The fact that his reasoning fails to fulfil its central cognitive function of being valid is explained by the fact that it operates in epistemically abnormal circumstances that ‘trick’ one aspect of it: the univocality-competence. However, warrant is not attributed on the basis of de facto fulfilment of cognitive objectives. What matters for warrant is whether the relevant competencies perform in a manner such that they reliably fulfil their cognitive function in epistemically normal circumstances. But, if so, Peter’s reasoning appears to meet the mark required for warrant. This verdict may be augmented by comparing Peter to a twin in epistemically normal circumstances. 

##### 4.2 Enter Pedro 

Let us invoke a variation of the slow-switch methodology to evaluate Peter’s reasoning. Compare Peter to his unswitched twin, Pedro. Pedro has remained on Earth where he first came to believe that some apples are red and later that all apples are sweet. Pedro is mentally different from Peter only in that he has not acquired a new twin-concept. Much like Peter, Pedro connects his beliefs in reasoning and concludes that something is both red and sweet. 

Only the most sceptically minded theorist will deny that Pedro is warranted by the reasoning in his conclusion-belief. If we assume, for illustration, that Pedro’s premise-beliefs are true and warranted, his conclusion-belief arguably amounts to knowledge. Importantly, Pedro’s knowledge is not defeated by the fact that he can’t rule out the possibility that he has been slow-switched. Such a possibility is often said to be an ‘irrelevant alternative’—one which Pedro may ignore in his reasoning. The point may be expressed by saying that it is epistemically legitimate for Pedro to reason as if he is in normal circumstances. The central point is that given the normal circumstances, Pedro’s conclusion-belief amounts to knowledge. The view that Pedro does not know his conclusion-belief amounts to scepticism about knowledge by reasoning. 

Let us now turn back to our switched subject, Peter. I argued above that, from a competence-oriented perspective, Peter reasons in a validityconducive manner although his reasoning, considering only the outcome, is fallacious. This account may be augmented by comparing Peter and Pedro. If Pedro is epistemically rational in ignoring the possibility that he has been switched, so is Peter—since he has no indication that he has been switched. I here assume the general point that if one has no indication to the contrary, one may ignore the possibility that one is in epistemically abnormal circumstances—even if one is in such circumstances. 

Arguably, Pedro can simply ignore the slow-switch possibility because it is epistemically abnormal. But if the slow-switch scenario is epistemically abnormal, then it is epistemically abnormal—even when it obtains [Gerken 2009]. Since Pedro may ignore the slow-switch possibility, Peter may also

<!-- page: pdf=0016 printed=14 -->

ignore it—even though it is actual. It appears, then, that Peter is exercising his reasoning competencies as well as Pedro.<sup>18</sup> Peter is just epistemically unlucky to have been switched to a look-alike environment in a manner such that he has come to unknowingly possess two non-univocal, but similar, concepts. Had Pedro been switched, he would have been reasoning just like Peter reasons. Had Peter avoided the switch, he would have been reasoning just like Pedro reasons. The forms of their reasoning differ because of differences in factors—patterns of relations to the environment—that are not readily available to either of them. 

The comparison between Peter and Pedro suggests that they are equally well warranted in their respective conclusion-beliefs. Reflection on their respective epistemic circumstances may provide a self-standing rationale for upholding (Valid 2). However, this verdict may be augmented by comparing the comparison of Peter and Pedro to more familiar comparisons of agents. Specifically, it is illuminating to compare Peter and Pedro to subjects in Gettier-style cases and their counterparts in normal circumstances. 

##### 4.3 Enter Gettier 

The case-pair of Peter and Pedro is relevantly similar to the following two familiar case-pairs in which the male is in Gettier-style circumstances whereas the female is in epistemically normal circumstances. In Gettier’s original case, Mr Smith reasons from a warranted false premise-belief to a true conclusionbelief [Gettier 1963]. We may introduce, as contrast, Mrs Smith, who reasons from a similar equally warranted but true premise-belief to a true conclusionbelief. Consider a non-inferential Gettier-style case: Mr Doe generates a warranted perceptual belief that there is a sheep on the hill on the basis of seeing a sheep-shaped rock. However, there is a sheep hidden on the hill. Here Mr Doe’s warranted true perceptual belief does not amount to knowledge [Chisholm 1977]. In contrast, Mrs Doe generates a true perceptual belief that there is a sheep on the hill on the basis of a veridical perceptual representation of a sheep on the hill. Scepticism aside, she knows that there is a sheep on the hill. 

According to a fairly orthodox conception of Gettier-style cases, an infamous ‘fourth condition’ on knowledge is met in the cases of Pedro, Mrs Smith and Mrs Doe. The standard conception partly explains why they are regarded as knowing subjects.<sup>19</sup> However, this condition is not met in the 

> 18I assume that Peter and Pedro exercise type-identical competencies. This assumption is compatible with assuming that cognitive competencies are anti-individualistically individuated. Moreover, the fact that the mental states involved in the operation of a competence have been slow-switched does not entail that the competence itself has been slow-switched [Gerken 2007a]. Thanks to Luca Struble for discussion. These points bear on a worry brought to my attention by Nicholas Silins: If an evil demon makes S engage in fallacious reasoning, she will—on the proposed account—be warranted by the reasoning. Bad consequence! Fortunately, my account has no such consequence. For in a demon case, S’s reasoning does not exhibit well-functioning fallibility. Depending on the specification of the demon scenario, S’s reasoning exemplifies an (externally caused) cognitive malfunction or the exercise of a different, unreliable reasoning competence. But malfunctioning failure rarely provides warrant and unreliable competencies never do. So, S is not warranted in the demon case. 

> 19Of course, the ‘fairly orthodox’ conception is purely schematic. It does not amount to a theory of knowledge. Indeed, it does not entail that knowledge can be reductively analysed.

<!-- page: pdf=0017 printed=15 -->

case of Mr Smith and Mr Doe. Plausibly, this fourth condition is not met in the case of Peter either. 

Peter resembles Mr Smith and Mr Doe by doing everything right although he does not get the form of his reasoning right. However, he does not get it right solely because he is in abnormal circumstances that have affected the basic parameters that shape the form of his reasoning. Again, if Peter is in equivocation-inducing circumstances C, he is in epistemically abnormal circumstances [Gerken 2009]. It is a hallmark of Gettier-style circumstances that they are epistemically abnormal—at least with regard to the belief in question. Likewise, ordinary cases of warranted false belief may be partly accounted for in terms of abnormal circumstances. 

In the Equivocal Apple Argument, Peter’s conclusion-belief <u>Something is red and sweet</u> is true. Strawberries are sweet and red. But Peter’s reasoning does not concern strawberries. So, let us consider the reasoning about apples/twin-apples as the sole basis for the conclusion-belief. Clearly, Peter’s conclusion-belief cannot be regarded as knowledge on the basis of the reasoning. The connection between the warrant provided by the reasoning and the fact that the conclusion-belief is true is too lucky to constitute knowledge. But if the case is indeed a Gettier-style case, Peter’s warrant is not altered by this fact. Peter is in Gettier-style circumstances that defeat knowledge without affecting warrant. It is another hallmark of Gettier-style circumstances that they do not defeat or diminish the subject’s warrant. For if they did, Gettier-style cases would not provide counter-examples to the tripartite theory of knowledge [Gerken forthcoming]. 

Consequently, it is plausible that Peter and Pedro are equally warranted in believing their respective conclusion-beliefs. This is a stronger claim than (Valid 2), which requires only that Peter be warranted by the reasoning. However, if it is correct that Peter is in a Gettier-style circumstance, the stronger claim may be upheld. 

The central point, for the present purpose, is that Peter is plausibly in Gettier-style circumstances. If so, he is warranted in his conclusion-belief. If so, (Valid 2) is true and (Valid 3) is false. Hence, (Validity Requirement) stands in need of restriction. 

##### 4.5 Concluding Remark 

The Validity Argument should not be regarded as a reductio against antiindividualism. Rather, the assumption that attitudes are partly individuated by factors that are unavailable to the reasoner may contribute to epistemological insights. Anti-individualism may partly explain how the cognitive competencies that constitute reasoning may exhibit well-functioning fallibility in certain circumstances. Thus, a frequently presupposed principle in the epistemology of inference, (Validity Requirement), stands in need of restriction.<sup>20</sup> 

> 20The status of (Environmental Independency)—the thesis that the warranting force of purportedly deductive reasoning is independent of the agent’s relations to the environment – is less clear. Since Peter’s reasoning retains its usual epistemic force, the discussion above does not directly cast doubt upon the principle.

<!-- page: pdf=0018 printed=16 -->

##### 5. A Pre-emptive Clarification 

Before concluding, I will attempt to defuse an objection to my response to The Validity Argument. 

##### 5.1 The Charge of Deontologism 

It may be objected that the only way in which Peter is connected to truth is in terms of fulfilling his intellectual obligations in a blameless manner. However, while fulfilling one’s intellectual obligations is a nice thing, it does not suffice for genuine epistemic warrant. So, it may be objected, ironically, that the above defence of (Valid 2) exemplifies the fallacy of equivocating between epistemic warrant and mere cognitive blamelessness. So, it might be objected that Peter is, at best, warranted in some problematic deontological sense.<sup>21</sup> 

I stand guilty as charged in so far as the defence of (Valid 2) does indeed require the assumption that Peter is cognitively blameless. Cognitive blamelessness is plausibly a necessary condition on the warrant. However, I reject that cognitive blamelessness is sufficient for warrant. Sloganized: Warrant is more than mere relief from blamelessness. 

##### 5.2 Epistemic Deontologism Eschewed 

I will address the charge that Peter is not warranted but merely cognitively blameless by way of comparison with a case of a blameless reasoner who is not warranted by the reasoning. 

Case of Pete: Pete is born and raised in a community in which both experts and laymen are psychologically prone to the gambler’s fallacy and reason accordingly. This flaw is not merely cultural. Rather, the psychology of Pete and his peers is simply inferior to human psychology in this regard. To these people, rules or judgments that reflect the gambler’s fallacy appear to be obvious and self-evident. For example, everyone in the community would be extremely confident that if a die has not landed on a 6 for a long while, then the chances of its landing on a 6 have increased. This will simply appear to them to be a self-evident fact. Moreover, assume that the experts of the community have provided a prima facie theoretical 

However, a broader moral may be that the nature of the agent’s normal environment partly determines the warranting force of her purportedly deductive reasoning. So, perhaps other switching scenarios may compromise (Environmental Independency). If, for example, an agent is in an environment in which scientific paradigm shifts are common, the warranting force of her purportedly deductive reasoning might be limited. Moreover, some cognitive domains may induce a high risk of equivocation [Gerken 2009]. However, these issues require further consideration than I can give them here. 

> 21Jessica Brown addresses the slow-switch case by providing principles by reference to which ‘the antiindividualist can make sense of the distinction between those logical failings for which we blame agents and those for which we do not’ [Brown 2004: 192]. In contrast, Sanford Goldberg claims that Peter’s conclusionbelief lacks ‘anything approximating an externalist justification. At best, his conclusion-belief enjoys an appearance-grounded justification’ [Goldberg 2007: 193]. I believe both Brown’s deontological principles and Goldberg’s bifurcated conception of warrant by reasoning are misguided, but there is no space for a responsible discussion.

<!-- page: pdf=0019 printed=17 -->

justification for the corresponding rules of reasoning. Of course, this theoretical justification is misguided. But in Pete’s community, there is consensus that the experts have theoretically proven a piece of common knowledge. 

Whenever Pete plays dice, he forms beliefs regarding certain outcomes by reasoning with inference rules that reflect the gambler’s fallacy. Moreover, it is beyond Pete’s cognitive competencies to realize that his reasoning is flawed. Finally, assume that Pete has been lucky in the past. When he has reasoned according to the gambler’s fallacy, he has quite often generated true beliefs. 

There is a strong sense in which Pete is cognitively blameless for his conclusion-beliefs about probabilities. The combination of strong intuitions, layman and expert testimony and a decent track-record is forceful. Nevertheless, Pete’s conclusion-beliefs in question are not warranted by the reasoning. The rules that Pete uses in his reasoning are not truth-conducive. Indeed, Pete is a casino owner’s dream. If one of Pete’s conclusion-beliefs is true, the belief’s truth is too lucky for it to be warranted. 

The case of Pete is not an uncontroversial example of blameless reasoning that fails to contribute to warrant. But it is illustrative even if it is not perfectly analogous to the case of Peter with regard to degree of blamelessness.<sup>22</sup> Grant, for the sake of argument, that there is a difference in degree of blamelessness between Pete and Peter. According to my defence of (Valid 2), the difference in degree of blamelessness between the two agents is not what explains the difference in warrant for their respective conclusionbeliefs. On the contrary, the difference in warrant is explained by reference to the difference in truth-conduciveness of the two subjects’ respective reasoning competencies. 

While there may or may not be some asymmetry in terms of degree of blamelessness, there is clearly a very strong asymmetry between the truth-conduciveness of Peter’s reasoning and that of Pete’s reasoning. If we focus on the competencies that constitute the reasoning, rather than solely on the outcomes, there is something to be said for Peter’s reasoning which cannot be said for Pete’s reasoning. In the case of Peter, empirical abnormal circumstances affect the reasoning by affecting the attitudes that enter into it. The unfortunate outcome is not explained by a flaw intrinsic to the reasoning competencies. Had the empirical circumstances been normal, then Peter would have held true conclusion-beliefs. Nothing of this sort may be said in favour of Pete’s reasoning. 

So, the epistemically relevant difference between Pete and Peter is not merely, or even primarily, a difference in degree of blamelessness. The problem with Pete’s reasoning is not primarily that he—or someone with more powerful cognitive resources—could, in principle, figure out that the rules he uses are not truth-conducive. The primary problem is 

> 22Someone might argue that Pete is not blameless in a principled manner. After all, it could, in principle, be realized by first-person methods that the rules Pete reasons with are flawed—even if it is beyond Pete’s own cognitive means to do so. If so, there is a putative difference in degree of blamelessness between Pete and Peter. A theorist (not me!) might attempt to argue that the difference in warrant is to be explained by reference to this difference in degree of blamelessness. As will become clear, my point is entirely different.

<!-- page: pdf=0020 printed=18 -->

that Pete uses rules that are not, as a matter of objective fact, truthconducive. 

In contrast, Peter’s reasoning competencies are truth-conducive. So, although I assume that Peter is cognitively blameless, I am not merely playing a deontological ‘blame game’. The charge of epistemic deontologism has force only if all that there is to be said in favour of Peter’s reasoning is that he is cognitively blameless. But, in fact, this assumption has played a very minor role in my defence of (Valid 2). The core of the defence is that Peter exercises truth-conducive reasoning competencies in epistemically abnormal, inhospitable circumstances. 

##### 6. Conclusion 

The idea that epistemic warrant is determined by the truth-conduciveness of the relevant cognitive competence, rather than the de facto outcome of a particular exercise of it, is widely accepted. In the case of purportedly deductive reasoning, the truth-conduciveness derives, in part, from reasoning competences that reliably preserve truth in virtue of form. But reasoning competences are fallible. Consequently, I have argued that the validityconduciveness of the reasoning competencies in epistemically normal circumstances is central to warrant by purportedly deductive reasoning. Thus, validity remains a central epistemic standard and an essential cognitive function of purportedly deductive reasoning. But the commonly presupposed principle (Validity Requirement) according to which purportedly deductive reasoning must be de facto valid is too strong. 

The view that (Validity Requirement) requires restriction is a novel view in the epistemology of inference. Moreover, it may appear radical to many that one can generate warrant by purportedly deductive reasoning that is invalid. Yet I hope to have argued, from widely accepted assumptions in epistemology and the philosophy of mind, that this proposal deserves consideration. 

More generally, the discussion has highlighted a methodologically important fact about the epistemology of inference: the fact that reasoning is a distinctive mental activity that is constituted by the exercise of fallible competencies. Therefore, warrant by reasoning should be considered in relation to rather than in abstraction from the competencies that constitute the reasoning.<sup>23</sup> 

##### University of Copenhagen 

Received: November 2009 Revised: April 2010 

> 23I am very thankful to Tyler Burge who advised my UCLA dissertation from which the article is drawn [Gerken 2007a]. I also owe thanks to Paul Boghossian, Jessica Brown, Dylan Dodd, Erica Gielow, Sanford Goldberg, Andrew Hsu¨ , Krista Lawlor, Ram Neta, Sarah Sawyer, Nicholas Silins, Luca Struble and two referees for the AJP. Thanks also to the participants at a Danish Epistemology Network Workshop (University of Copenhagen, 2006), a Southern California Epistemology Workshop (UCLA 2007), the Arche´ Basic Knowledge III conference (St. Andrews, 2008), the XIXth Inter-University Workshop on Philosophy and Cognitive Science (Zaragoza, 2009). I owe special thanks to Julie Brummer. I benefited from a grant from The Danish Research Council for the Humanities. The paper is dedicated to Ane.

<!-- page: pdf=0021 printed=19 -->

##### References 

Bach, Kent 1984. Default Reasoning: Jumping to Conclusions and Knowing When to Think Twice, Pacific Philosophical Quarterly 65: 37–58. 

Boghossian, Paul 1992a. Externalism and Inference, Philosophical Issues 2: 11–28. Boghossian, Paul 1994. The Transparency of Mental Content, Philosophical Perspectives 8: 33–50. Brown, Jessica 2004. Anti-Individualism and Knowledge, Cambridge, MA: MIT Press. Burge, Tyler 1988. Individualism and Self-Knowledge, Journal of Philosophy 85/11: 649–63. Burge, Tyler 1998. Memory and Self-Knowledge, in Externalism and Self-Knowledge, Peter Ludlow and Norah Martin, eds, Stanford: CSLI Publications: 351–70. 

Burge, Tyler 2003. Perceptual Entitlement, Philosophy & Phenomenological Research 67/3: 503–48. Burge, Tyler 2005. Disjunctionism and Perceptual Psychology, Philosophical Topics 33/1: 1–78. Chisholm, Roderick 1977. Theory of Knowledge, 2<sup>nd</sup> edn, Englewood Cliffs, NJ: Prentice-Hall. Collins, John 2008. Content Externalism and Brute Logical Error, Canadian Journal of Philosophy 38/4: 549–74. 

Davies, Martin 2003. Externalism, Self-Knowledge and Transmission of Warrant, in Meaning, Basic SelfKnowledge, and Mind. Essays on Tyler Burge, Marı´a J. Fra´ polli and Esther Romero, eds, Stanford: CSLI Publications: 105–30. Dretske, Fred 1970. Epistemic Operators, Journal of Philosophy 67/24: 1007–23. 

Dretske, Fred 1971. Conclusive Reasons, Australasian Journal of Philosophy 49/1: 1–22. 

Falvey, Kevin and Joseph Owens 1994. Externalism, Self-Knowledge, and Skepticism, Philosophical Review 103/1: 107–37. 

Gerken, Mikkel 2007a. Epistemic Reasoning and the Mental, UCLA Dissertation. 

Gerken, Mikkel 2007b. A False Dilemma for Anti-Individualism, American Philosophical Quarterly 44/4: 329–42. 

Gerken, Mikkel 2009. Conceptual Equivocation and Epistemic Relevance, dialectica 63/2: 117–32. Gerken, Mikkel forthcoming. Warrant and Action, Synthese (online first) http://www.springerlink.com/ content/b062835p233908x7/. 

Gettier, Edmund 1963. Is Knowledge Justified True Belief? Analysis, 23/6: 121–3. 

Goldberg, Sanford 2007. Anti-Individualism, Content Preservation, and Discursive Justification, Nouˆs 41/2: 178–203. 

Goldfarb, Warren 2003. Deductive Logic, Indianapolis: Hackett Publishing Company, Inc. Harman, Gilbert 1973. Thought, Princeton: Princeton University Press. 

Heal, Jane 1998. Externalism and Memory, Proceedings of the Aristotelian Society 72/1: 95–110. 

Lawlor, Krista 2001. New Thoughts about Old Things: Cognitive Policies as the Ground of Singular Concepts, New York, N.Y.: Garland Publishing. 

Lawlor, Krista 2007. A Notational Worlds Approach to Confusion, Mind & Language 22/2: 150–72. Ludlow, Peter 1995a. Externalism, Self-Knowledge and the Prevalence of Slow Switching, Analysis 55/1: 45–9. 

Ludlow, Peter 1995b. Social Externalism, Self-Knowledge, and Memory, Analysis 55/3: 157–9. Millikan, Ruth 2000. On Clear and Confused Ideas, Cambridge: Cambridge University Press. 

Moya, Carlos 2003. Externalism, Inclusion and Knowledge of Content, in Meaning, Basic Self-Knowledge, and Mind. Essays on Tyler Burge, Marı´a J. Fra´ polli and Esther Romero, eds, Stanford: CSLI Publications: 165–86. 

Priest, Graham 2006. In Contradiction: A Study of the Transconsistent, 2<sup>nd</sup> edn, Oxford: Oxford University Press. 

Schiffer, Stephen 1992. Boghossian on Externalism and Inference, Philosophical Issues 2: 29–37. Schroeter, Laura 2007. The Illusion of Transparency, Australasian Journal of Philosophy 85/4: 597–618. Tye, Michael 1998. Externalism and Memory, Proceedings of the Aristotelian Society Supplementary Volume 72: 77–94. 

Wright, Crispin 2000. Cogency and Question-Begging: Some Reflections on McKinsey’s Paradox and Putnam’s Proof, Philosophical Issues 10: 140–63.
