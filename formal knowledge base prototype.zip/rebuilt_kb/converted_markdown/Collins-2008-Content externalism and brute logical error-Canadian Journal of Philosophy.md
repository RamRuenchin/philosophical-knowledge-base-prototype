---
title: "Content Externalism and Brute Logical Error"
source_type: "paper"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Collins-2008-Content externalism and brute logical error-Canadian Journal of Philosophy.pdf"
source_id: "collins-2008-content-externalism-and-brute-logical-error-canadian-journal-of-philosophy-024ee9a58825"
source_sha256: "024ee9a5882515913f405352b31d4f19e4fb7c44a45222d60792027036919ed3"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:51:54+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/collins-2008-content-externalism-and-brute-logical-error-canadian-journal-of-philosophy-024ee9a58825-7a19f5c00c.json"
authors:
  - "Herb Ratsch"
---

# Content Externalism and Brute Logical Error

<!-- page: pdf=0001 printed=549 -->

# _Content Externalism and Brute Logical Error_ 

JOHN M. COLLINS East Carolina University Greenville, NC 27858 USA 

## **I Introduction** 

Externalism with respect to content is the thesis that the contents of an individual’s mental states are fi xed, not just by the intrinsic physical characteristics of the individual, but also in part by the external circumstances of the individual. This idea can be illustrated by means of thought experiments involving pairs of ‘twins’ who are identical with respect to their intrinsic features yet who differ mentally because of differences in their environments. The thoughts of a thirsty earthling may turn to water. Suppose that an earthling has a molecule-for-molecule twin on a very distant planet, a planet identical to Earth except that wherever Earth has H2O, Twin Earth has XYZ, which is superfi cially indistinguishable from water. When the twin is thirsty, her thoughts will turn instead to _twater_ , as we may call it. Externalism about content is a metaphysical thesis, but it has epistemological implications. Many have argued that externalism is incompatible with a suitably rigorous thesis about the authoritative, introspective1 self-knowledge we seem 

> 1 The use here of ‘introspective’ is not intended to signal the endorsement of a perceptual model of inner access, nor any other very contentious view. I take it that there is some asymmetry between fi rst-person and third-person access to the men-

<!-- page: pdf=0002 printed=550 -->

to have with respect to our own thought contents. The earth individual’s introspective evidence underdetermines the thought content; if she were thinking a twater thought, her introspective experience would be 2 just the same . 

Externalists have argued in various ways that externalism and authoritative self-knowledge are compatible. Some opt for a reliabilist strategy; since whatever determines that a thought employs the concept _water_ instead of the concept _twater_ will also determine that the second-order thought _I am thinking that water is dripping_ involves the concept _water_ as well. The second-order thought is guaranteed to be correct, and thus is a knowledgeable self-attribution. (John Heil, 1988, is a notable example of this strategy.) Other compatibilists maintain that arguments for the incompatibility of externalism and authoritative selfknowledge depend on a confl ation of knowledge of content _simpliciter_ with discriminative or comparative knowledge of content (knowledge of sameness or difference of content). Lois Lane knows who the man of steel is, and she knows who the mild-mannered reporter is; she just does not know that they are one and the same. Some argue that it is the same with introspective knowledge. One can know that one is thinking about water without being able to discriminate this thought introspectively from all other thoughts that play a similar psychological role. (Falvey and Owens, 1994, takes this tack.) 

Some of those who defend the compatibility of externalism and authoritative self-knowledge take themselves to be defending the externalist thesis itself. Kevin Falvey and Joseph Owens say: 

[I]f this line of thought [the incompatibility of externalism and authoritative selfknowledge] is correct, then externalism is in serious trouble, for while philosophers in the Cartesian tradition have tended to exaggerate the certainty and scope of self-knowledge, it is diffi cult to deny the intuition that one’s knowledge of one’s own occurrent propositional mental states is frequently direct and authoritative… Any philosophy of mind that cannot accommodate and explain these intuitions must be mistaken. (Falvey and Owens 1994, 108) 

tal. I use ‘introspection’ to mean whatever direct and privileged (i.e. unavailable to anyone else) way one has of knowing of the existence and content of one’s own mental states. 

- 2 Actually, in some sense the twins’ introspective evidence is different, since one introspects a water thought, while the other introspects a twater thought. It might be more perspicacious to say that the subject would not be able to discriminate between water and twater thoughts, on the basis of the introspective evidence. Thanks to Mike Veber for making this point.

<!-- page: pdf=0003 printed=551 -->

Most externalists do not, however, believe that the plausibility of externalism depends on its being compatible with authoritative _discriminative_ self-knowledge of content. 

DASK: For any subject S and any of S’s mental state tokens M1 and M2, S can determine through introspection whether M1 and M2 have the same, or different, contents. 

Content externalism looks to be incompatible with DASK. Were one to be transported, unawares, to Twin Earth, where one encountered twater and developed the capacity to think about twater, one would have no way of telling by introspection that one is using a concept different from the old water concept. Here, difference of content is not transparent to the subject. Similarly, one could encounter tomatoes in two very different situations (Campbell’s tomato soup, say, and tomatoes eaten right from the vine, but pronounced ‘to-mah-toes’), and think _tomatoes (to-may-toes) are tasty_ and _tomatoes (to-mah-toes) are tasty_ , while supposing that these are two distinct thought contents, about two different kinds of food. Sameness of content is not transparent, either. 

## **II Externalism and Brute Logical Error** 

## _1. Brute Logical Error_ 

The validity of an inference typically depends on particular constituents of the inference having the same content. For instance, for an inference to be an instance of _modus ponens_ , the content of the antecedent of the conditional premise must be the same as the content of the other premise; the content of the consequent of the conditional must be the same as the content of the conclusion. If these contents differ, in a putative instance of _modus ponens_ , equivocation occurs and the inference is invalid. So since difference of content is not transparent, it appears that some equivocations in putative instances of _modus ponens_ will not be detectable as such via introspection even by the thinker who makes the inference. A fanciful example will illustrate the possibility. Suppose that Peter is a resident of Earth, and he believes that he took swimming lessons as a child in a pool fi lled with water. Peter is unwittingly transported to Twin Earth, and there he interacts with twater and forms thoughts about it. Suppose that he now has two concepts, water and twater, both of which he express with the word ‘water.’ He believes that twater is now condensing on his glass (though he uses the word ‘water’). From these two beliefs he infers that the same kind of thing he swam in as a child is now condensing on his glass. Peter’s inference is invalid, but he cannot know this by introspection of his thoughts, no

<!-- page: pdf=0004 printed=552 -->

matter how skilled at logic he is, and how carefully he introspectively scrutinizes his inference.3 

Externalism therefore seems to engender the possibility of brute error about the logical form of one’s own inferences, an area that many have supposed to be safe from skeptical challenges. Brute errors, as Tyler Burge puts it, are those which ‘do not result from any sort of carelessness, malfunction, or irrationality on our part’ (Burge, 1988, 657). So a brute logical error is a logical mistake that betokens no defect in one’s logical skills. If one whose logical skills are above reproach, and who takes great care to reason correctly, reasons invalidly, while insisting that one is not doing so, one is committing a brute logical error. One might argue that the error is one of introspection, rather than logic, since it is the false introspective judgments about sameness and difference of content that allow the invalid inferences. But in this sort of case, an error in reasoning — moving from all true premises to a false conclusion — does occur, even if the underlying cause of the error is an introspective error. Mistakes about sameness and difference of one’s own mental contents lead to mistakes about the logical properties of one’s thoughts. 

## _2. The Argument from Logical Norms_ 

Of course, it is possible to make errors about the logical form of one’s inferences, due to lack of logical skills, momentary confusion or carelessness. To detect equivocation in some cases may require quite a lot of refl ection.4 The possibility of brute logical error might be more trouble- 

- 3 There is a great deal of literature dealing with switching cases. For a sample, see Burge 1988, Boghossian 1989, Ted Warfi eld 1992 and 1997, and Peter Ludlow 1995 and 1997. More recently, an excellent paper by Sanford Goldberg (2007) explores the consequences of switching cases for the epistemology of reasoning. 

- 4 John Stuart Mill famously offered this defense of utilitarianism in chapter 4 of _Utilitarianism_ : 

The only proof capable of being given that an object is visible, is that people actually see it. The only proof that a sound is audible, is that people hear it: and so of the other sources of our experience. In like manner, I apprehend, the sole evidence it is possible to produce that anything is desirable, is that people actually desire it. (Mill 1979, 34) 

Although there are other defensible analyses of this paragraph, it looks like Mill is unwittingly equivocating between two different senses of ‘desirable.’ Something is desirable, in one sense, if it is capable of being desired, and desirable in another sense if it is worthy of being desired. Mill intends to convince us that happiness is desirable, in the latter sense, but the analogy with visibility and audibility is relevant only to the former sense.

<!-- page: pdf=0005 printed=553 -->

some. One of the norms of logic and rationality is that one avoids simple logical errors. If the most logically astute and careful of reasoners cannot observe these norms, perhaps the norms of logic and rationality need to be refashioned. Alternatively, rather than formulating new norms, one could reject the theory of content that threatens our conception of what it is to be a rational agent. 

Although Paul Boghossian has not explicitly argued against externalism on these grounds, he suggests that such an argument has some merit (1992, 26-8, and 1994, 45-9). Let’s call this argument against externalism the _Argument from Logical Norms_ : 

1. If Content Externalism is correct, then DASK is false. 

2. If DASK is false, brute logical error is possible. 

3. If brute logical error is possible, the norms of logic and rationality must be re-fashioned. 

4. It is not the case that the norms of logic and rationality must be re-fashioned. 

5. Content Externalism is incorrect. 

If a wholesale reworking of the norms of logic and rationality can be avoided, just by adopting an internalist theory of content that does not engender brute logical error, then this is one reason to consider doing so. If DASK is abandoned, says Boghossian: 

[W]e must either jettison the notion of rationality and with it the practice of psychological explanation that [DASK] underwrites, or we must show that these notions can be refashioned so as not to yield absurd results. (1994, 40) 

How does DASK underwrite the apparatus of folk psychology? Boghossian cites examples of folk psychological principles that seem to presuppose that the subjects governed by these principles have authoritative discriminative self-knowledge. Take, for two examples, 

- (1) If S occurrently believes p and intends to F if p, and if S has no independent reason for not F’ing, then S will intend to F or, at the very least, will be disposed to intend to F. 

- (2) If S intends to F if and only if p, but does not believe that p, but merely q instead (where p and q are logically independent propositions), then S will not intend to F. (1994, 33)

<!-- page: pdf=0006 printed=554 -->

Principle (1) will have counterexamples if sameness of content is not transparent. Imagine a subject who believes that tomatoes (to-maytoes) are on the menu, and who intends, if tomatoes (to-mah-toes) are on the menu, to order them. Such a subject may not order the tomatoes from the menu. Principle (2) will have counterexamples if difference of content is not transparent. Imagine a subject who intends to call the plumber if and only if water is dripping from the pipes, but who does not believe that water is dripping from the pipers. Instead, she believes that twater is dripping from the pipes. Yet, she calls the plumber. Principles (1) and (2) seem to be fairly typical folk psychological principles, so it looks like the general practice of folk psychology presupposes DASK, or something much like it. Here, however, I will put aside the issue whether our practice of psychological explanation assumes DASK, and I will concentrate on whether externalism’s rejection of DASK forces on us the possibility of brute logical error. Much of what is said about the latter will have some bearing on the former, however. 

The externalist may resist the Argument from Logical Norms in several different ways. She could challenge the third premise, and insist that the norms of logic and rationality are _ceteris paribus_ laws, and that occasional exceptions to the laws do not necessitate that they be jettisoned. She could also reject the third premise, while insisting that the logically irreproachable will abide by those norms. The traveler Peter, who equivocates in his water/twater inferences, is _ipso facto_ illogical, and is culpable for it, the stipulation of his logical acumen notwithstanding. To take this approach would be to accept the existence of logical or rational luck, the susceptibility of deserved criticism or praise of one’s logicality and rationality, to lucky or unlucky outcomes.5 Yet a third strategy would be to argue that even if accepting externalism requires considerable reworking of logical and rational norms, externalism is otherwise so compelling that it is worth the effort of refashioning these norms. Fourth, one could argue that even a proponent of an internalist or narrow theory of content will be forced to deny DASK (and admit that there are counterexamples to folk psychological principles like (1) and (2)). (Falvey and Owens 1994, argue for this.) And lastly, one could argue that even if counterexamples to DASK can be found by considering bizarre possibilities, such as that of the switcher between Earth and Twin Earth, there is no reason to think that _we_ fail to have such discriminative self-knowledge, since there is no reason to think that we are being so switched. (Such a strategy would adapt Ted Warfi eld’s arguments for the compatibility of externalism and self- 

> 5 See Sorensen 1998 for a defense of the notion of logical luck.

<!-- page: pdf=0007 printed=555 -->

knowledge (Warfi eld 1992, Warfi eld 1997) to the compatibility of externalism and discriminative self-knowledge.) 

## **III  Attempts to Block the Argument From Logical Norms** 

Each of these responses deserves lengthy consideration, but here I want to concentrate on premise two of the argument from logical norms. Does externalism, in virtue of undermining DASK, really allow for the possibility of brute logical error? I will consider three ways of trying to block the brute logical error consequences, and I will argue that each fails. The fi rst is to deny that it would really be possible for a subject to think two distinct contents, but to nevertheless suppose that they are the same. That is, one could not think both water- and twater-thoughts, unless one knew they had different contents. This is to deny the possibility that two concepts could be _twin concepts_ for a person, i.e. concepts one possesses but between which one cannot discriminate by introspection. The second strategy is to concede that twin concepts might be possible, but to maintain that in an act of inference, some intention or device ensures that multiple instances of a term have the same content throughout. For example, later occurrences of the term might have their contents determined by the fi rst, somewhat like anaphoric dependence of pronouns on their binding or governing term. The last strategy is to insist that these invalid inferences are really enthymemes. When the tacit premise is made explicit, we see that it is belief of this (false) premise (say, that water is identical with twater), rather than the reasoning itself, that is the culprit. The inference is valid, but unsound, in virtue of the tacit false premise, according to this view. 

## _1. The Possibility of Twin Concepts_ 

I will not dwell for terribly long on the question whether it is possible for an unwitting traveler from one physical environment, or one linguistic community, to another, to have distinct concepts between which she is unable to discern by introspection, and which she does not realize even are distinct concepts (which I am calling twin concepts). Some philosophers have argued that this would not occur. One view is that the contents of all the water-thoughts would fl ip, and become twater-thoughts, sometime after the Twin Earth arrival. (This view is defended in Tye, 1998, 79-85.) Another view is that the initial water-concept would broaden to become a disjunctive water-or-twater concept. Whichever is the case, there would be no twin concepts, and thus there would be no risk of slipping insensibly from one to the other, mid-inference.

<!-- page: pdf=0008 printed=556 -->

I do not think it matters too much if one of these views is correct. Notice that if so, it would still be possible for one to falsely judge that two of her thought tokens have different contents (as in the toe-mayto/toe-mah-to case, or Saul Kripke’s famous London/Londres and Paderewski examples (Kripke 1979)), since such cases do not depend on the possibility of twin concepts. (Of course, some philosophers, like Brian Loar (Loar, 1987), Gabriel Segal (Segal, 2000) or William Taschek (Taschek, 1995a, 1995b, and 1998), would deny that in these cases the two tokens have the same contents. This, however, is because they reject content externalism. We are concerned with what is the case, if externalism is correct.) 

So it will be possible for an individual to be unable to recognize by introspection the validity of a given inference, even if twin concepts are not possible. It might be that being unable to see the validity of certain inferences is a less serious problem than is thinking an invalid inference to be valid.6 Everything else being equal, it is likely that there is greater epistemological cost in acquiring false beliefs than there is in failing to acquire true beliefs. But the failure to introspect sameness of content, which leads one not to make certain valid inferences, will sometimes prevent one from _eliminating_ false beliefs from one’s belief set. If Peter believes that tomatoes (‘to-mah-toes’) are good for your health, and he believes that tomatoes (‘to-may-toes’) are tasty, he should abandon his belief that no food that tastes good is good for you. But he won’t if he doesn’t realize that his utterances of ‘to-mah-to’ and ‘to-may-to’ have the same content. And there seems to be no greater epistemological cost in acquiring new false beliefs than in failing to eliminate old false beliefs — it is, after all, the _holding_ of the false beliefs that is costly. So the epistemological damage to externalism will be done even if twin concepts are not possible. 

Jessica Brown points out, though, that a Fregean externalist, who individuates contents by potential differences of attitude, may deny that content externalism is incompatible with authoritative self-knowledge of _sameness_ of content (Brown, 2004, 165-6). (That is, per Brown’s usage of the phrase, the Fregean externalist may maintain that when a subject judges that two of her mental states have different contents, she must be right.) If a subject is disposed to have different attitudes towards two sentences that differ only with respect to which of two synonyms they 

> 6 You might say that we have perfect logical duties not to reason invalidly (to adopt Kantian terminology), and only imperfect logical obligations to make valid inferences. To reason invalidly is to violate the norms of logic, but to fail to carry out a valid inference typically is not, as it would be impossible to make all possible valid inferences anyhow.

<!-- page: pdf=0009 printed=557 -->

contain, then those two synonyms (or merely _putative_ synonyms?) have different contents (different senses) for that subject, on this view. Since content externalism claims merely that external circumstances are part of what fi xes the contents of an individual’s mental states, it is compatible with the claim that potential differences in attitude also are factors that may individuate contents. Thus, although the terms ‘cilantro’ and ‘coriander’ are both causally related to the same herb, if a subject is inclined to assent to a content expressed by a sentence involving the former, but is inclined to dissent from a sentence otherwise identical but involving the latter, then the contents are different (for that subject). For the Fregean externalist, then, the inference from _cilantro is an herb available in Germany_ and _coriander is an herb available in France_ to _there is an herb available in both Germany and France_ would be invalid for some individuals (and _mutatis mutandis_ for Kripke’s ‘Paderewski’ and ‘London’/’Londres’ examples).7 Brown grants that even so, the switching subject will be prone to mistake in judging that all her uses of, say, ‘water,’ will have the same content. 

One of the principal advantages of content externalism over individualistic conceptions of content, though, is that content externalism allows for greater interpersonal sameness of content. If a subject says ‘tomatoes are tasty,’ where ‘tomatoes’ is pronounced toe-may-toes, and says ‘tomatoes are not tasty’ (toe-mah-toes), then I, who understands that the single word ‘tomatoes’ can be pronounced two different ways and believes that tomatoes are tasty, should be able to, with a single univocal belief, agree with the fi rst assertion and deny the second. But this will not be possible if ‘tomatoes’ has different contents for that subject in those two sentences. So it is not clear that reconciliation between content externalism and this sort of Fregeanism is well motivated. 

At any rate, I will briefl y review, and argue against, the reasons for thinking twin concepts are not possible. I described a case where the subject uses the water-concept in his thought about his (watery) past, believing that he swam in water as a child, and switches to the 

> 7 Some Fregean externalists reject this, however. Joseph Owens, a self-professed Fregean content externalist, has argued that even a Fregean should accept, due to content externalist considerations, that a subject cannot necessarily know via introspection whether two of his mental states have the same or different contents. Suppose a linguistically competent subject assents to one sentence and dissents from another, where the two sentences differ only in that a term from the fi rst sentence is replaced by its synonym in the second sentence. According to Owens, the subject ought to be regarded as believing both a proposition and, simultaneously, its negation. (His example involves the synonyms ‘cilantro’ and ‘coriander.’) Owens denies, however, the Millian view that co-referential names, such as ‘Hesperus’ and ‘Phosphorus,’ are interchangeable _salva veritate_ . See Owens 1989 and 1995.

<!-- page: pdf=0010 printed=558 -->

twater-concept in his thought about his current (twatery) environs, believing that twater is now condensing on his glass, and constructs an argument with these two thoughts as premises, thus unwittingly equivocating. Michael Tye argues that in such a case, the subject will be employing just the twater-concept throughout, even in the memory-based premise (Tye, 1998, 79-85). He says (about a similar example) that the subject is _comparing_ his current relations to twater with his old relations to twater. (The subject, after all, would be happy to replace the second occurrence of ‘water’ by the pronoun ‘it.’) If the fi rst premise of the inference is _that I swam in water as a child_ , rather than _that I swam in twater as a child_ , no such comparison would have been made. So he concludes that memories are laid down without fi xed contents, but rather with ‘contents [that] can fl oat free of their settings that gave rise to them and change with suitable changes in the external setting’8 (1998, 81). So the relevant external circumstance for determining the content of a long held belief about the past is the current external circumstance, not the one operative when the belief was fi rst formed, according to Tye. 

But this is unpersuasive. We can make perfect sense of the subject’s taking himself to be comparing his past relations with a particular substance to his present relations to it, even though he is not in fact doing that. He systematically mistakes water for twater, after all. If someone replaced my computer printer last night with a look-alike, today I might take myself to be comparing the whirring noise it makes while printing with the noise it made yesterday. I could not actually be doing so, but my taking myself to be doing this is quite comprehensible. I see no good grounds for an externalist to accept the view that the new concept must somehow displace the old one. Tye’s argument against the possibility of twin concepts just presupposes DASK (as noted in Brown, 2004, 171-2). 

Jane Heal (1998) argues for the thesis that the concept would broaden after the switch. She notes that on Hilary Putnam’s infl uential account of a natural kind term like ‘water,’ prior to anyone knowing water’s microstructure, paradigmatic instances of water are identifi ed (the stuff in this river, in that ocean, etc.). For something to be water then is for it to 

- 8 Memory is ordinarily taken to be factive. One cannot remember that which did not happen; if it is not the case that _p_ then at best one can seem to remember that _p_ . If one’s water concept has been replaced by a twater concept, then one cannot remember one’s experiences with water. But neither can one remember the childhood experiences of twater, since one had no such experiences. It might, therefore, be better to describe these mental states as mismemories, as Tye acknowledges (1998, 80). See also Brueckner (1997).

<!-- page: pdf=0011 printed=559 -->

bear the same-liquid relation (same microstructure, or same essence) to the demonstrated stereotypes. The presupposition of this enterprise is that the stereotypes one’s linguistic group has demonstrated are all, or at least most or mostly, of the same kind. But the presupposition seems to be false in Peter’s case, since instances of both water and twater will be exemplars for his term ‘water.’ Of course, all the ones he could point to now will be examples of twater, but these exemplars must be _remembered_ (one is not always looking at an exemplar) too, and since much of Peter’s remembered life is on earth, a signifi cant number of his exemplars for ‘water’ would be water. Since the exemplars broaden to include twater as well as water, so too does the concept broaden in one way or another. The relevant external factors then for determining the content of a thought about the past, but which occurs now, are both the past (water) and current (twater) external factors. 

This is not exactly canonical, ‘Meaning of “Meaning”’ Putnam, though. For instance, in the case of jade, where the stereotypes are two different kinds of minerals (jade is the disjunction of jadeite and nephrite), Putnam believed that the concept jade is something like a Fregean descriptive content, rather than a disjunctive one. He argues that when the empirical presupposition of the ostensive defi nition of water — that the liquid he points to is the same kind of liquid as most of the stuff speakers in the linguistic community call ‘water’ — is false, ‘fallback’ conditions are activated, and the ostensive defi nition is not intended to be accepted (Putnam, 1975, 225). In such a case, on Putnam’s view, the result would not be a successful ostensive defi nition of ‘water’ such that the extension of ‘water’ is broadened to include more than one kind of liquid. 

But we need not rest on Putnam’s authority. There is some reason to suppose that the switcher’s ‘water’ concept would not broaden. When a term acquires a meaning through a baptism, or dubbing, whether the baptism employs an indexical, as with Putnam’s ostensive defi nitions, or a defi nite description, the baptism _fi xes_ the content. Content-fi xing is not an ongoing process that is always contingent upon what new exemplars might be tapped, or what new defi nite descriptions might be thought to be apt. If a baptism fi xes a name as the name of a particular child (‘“Peter” is hereby the name of _this_ child’ or ‘“Peter” is hereby the name of the child born on May 31 to Michael and Melinda’), it is irrelevant to the content of the name that in the future one may identify Peter as _that_ person, or as the unique such-and-such. Reference-fi xing is not a revolving process. At any rate (as noted by Brown, 2004, 172-4), one who accepts such a causal theory of content, as most externalists would, would be unlikely to accept Heal’s view that a subject’s contents would evolve along with the appearance of new exemplars that the subject would regard as standard setting.

<!-- page: pdf=0012 printed=560 -->

What can be said in favor of the view that a switcher would, at some point, have twin concepts? Burge’s notion of the preservative role of memory is of help here. Burge’s view is that one function of memory is to preserve propositions that are believed (or doubted, etc.), along with the justifi cation one had for believing them in the fi rst place, for future use in, for example, reasoning. When memory preserves a propositional attitude, says Burge: 

The memory need not set out to identify an aluminum rather than a twaluminum thought, trying to fi nd one by working through the obstacles set by the switches. Preservative memory normally retains the content and the attitude commitments of earlier thinkings, through causal connections to past thinkings. That is one of its functions — maintaining and preserving a point of view over time. It need not take a past thought as an object of investigation, in need of discrimination from other thoughts. Memory need not use the form ‘Yesterday I was thinking a ______ type of thought,’ where the memory attempts to _identify_ the thought content as an object. Again, if it did, the individual might perhaps err by using a thought appropriate to the second environment in making an attribution to a thought event in the fi rst environment. (1998, 357, emphasis is Burge’s) 

Years ago, on Earth, Peter formed a belief about water, and now he remembers it on Twin Earth. On this view, the memory is a water memory, even though Peter has picked up the concept of twater. It is not that Peter is able to discriminate between water and twater thoughts and know which one he had originally. Rather, memory links the mental event from years ago to the mental event occurring now, allowing the former to fi x the content of the latter by preserving it (along with its justifi cational force) for later employment. (This would not entail that even the switcher’s new beliefs about the distant past would employ the old, rather than the new, concept, as in these cases there is no old belief to be preserved.)9 

- 9 If Burge is right, it solves a problem about a priori justifi cation or knowledge, and memory. If one knows _a priori_ the truth of a mathematical proposition, in virtue of having proved it oneself, does one still know it a priori a few minutes later, when one is relying on one’s memory of having proved it? That one’s memory is reliable is not known _a priori_ , after all. Indeed, any instance of _a priori_ reasoning must take place over time, and thus relies on memory. (Even grasping a proposition seems to require a bit of memory.) On Burge’s view, reliable memory is a background condition for successful reasoning, but it does not contribute justifi cational support for the conclusion. Rather, it preserves the content and the justifi cational support one already has for the content, which themselves justify the conclusion of the inference. Not only does this allow _a priori_ justifi cation to be preserved through memory, but it also prevents an infi nite regress of justifi cation. If I need, for my mathematical conclusion, a justifi ed premise about my memory, then by the time it

<!-- page: pdf=0013 printed=561 -->

This is hardly decisive, of course. It might be that even if Burge is correct in broad outline, what memory preserves is something other than externalistically individuated wide contents, but which in most cases if preserved will also preserve wide contents. Or it might be that memory preserves wide content, but it does so only defeasibly, and that one of the defeating conditions for wide content preservation (besides genuine forgetfulness, or other cognitive malfunction) is that the subject has switched environments and linguistic communities, like Peter has. But if we agree with Burge that memory does play this preservative role, we have at least some reason to reject the Tye or Heal view of memory, according to which memory contents typically depend on the current environment of the remembering subject, rather than (solely) on the environment that was operative when the remembered event actually occurred. The original thoughts involving the water-concept will instead have been preserved, so when the subject encounters twater and forms the twater concept, she will have twin concepts. Not only does Burge’s view have the virtue of solving the problems that Burge says it does (see note 9), but it also allows the post-switch memories on Twin Earth of water to be genuine memories. If they represent the switcher as having swum in twater in the past, they are merely apparent memories. 

Let us tentatively accept the twin concept hypothesis, then, and see whether the externalist can block the consequence that in certain situations a subject will be unable to detect by introspection that a sequence of her thoughts constitutes an invalid argument. The two strategies I will consider, again, are that there is some sort of anaphor-like device or background intention in reasoning that guarantees the concepts don’t shift mid-inference, or the enthymeme strategy, according to which there must be another premise, implicit and false, which is the real culprit in the inference, rather than invalid reasoning. 

## _2. ‘Anaphoric’ Content Links_ 

First let’s consider the former of these strategies. Is there some kind of mental anaphora, or a standing intention to use words univocally, or some other device that wards off equivocation? When one reasons as Peter does, uttering the sentences ‘I swam in water as a child; now there is water condensing on the outside of my glass; thus the kind 

takes to grasp the new argument, I will need a brand new justifi ed premise about memory, and so forth, if I am to be justifi ed ( _a priori_ or _a posteriori_ ) in believing the conclusion. Burge articulates this in greater detail in Burge 1993. See also Burge 1997.

<!-- page: pdf=0014 printed=562 -->

of stuff I once swam in is now condensing on my glass,’ one likely would be willing to rephrase the two premises as ‘I swam in water as a child and some of _it_ is now condensing on my glass.’ (As Stephen Schiffer suggested about a similar example, in his reply to Boghossian 1992, (Schiffer, 1992, 35), one would be happy to rephrase the premises as ‘Water is what I swam in as a child and now is condensing on my glass.’) If the pronoun ‘it’ is bound by the occurrence of ‘water’ in the fi rst premise, then there is no chance that the pronoun refers to something else. If the ‘inferential intention’ somehow ties all the later uses of a term to the content of the fi rst use of the term in the inference, then there will be no possibility of the sort of mid-inference concept shift we have been considering. 

Well, the fact that Peter would happily enough rephrase his inference substituting ‘it’ for ‘water’ doesn’t show that anything he’s done has guaranteed that the occurrences of the word ‘water’ all co-refer. It just refl ects the fact that he thinks they all do — and _of course_ he thinks that, or else he wouldn’t make the inference. That does not guarantee that the switch of concepts has not happened. And even if Peter stated the argument with pronouns substituted for latter occurrences of ‘water’ in the fi rst place, that still would not guarantee that he had not equivocated. There are some occurrences of pronouns that are bound by an antecedent that determines their contents. But some pronouns secure their reference independently, by a demonstration. And the so the demonstrated referent might differ from the referent of the earlier term. Alternatively, the sentences Peter employs might not accurately capture the nature of his reasoning. 

But suppose there is a background intention that ensures that during a piece of reasoning, all the occurrences of a given term have the same content (though this would have to be qualifi ed to admit homonyms, or intentional equivocation, in the inference), in something like the way that variables and some pronouns are bound by antecedents. There is the risk that a defense of this view could prove too much. It seems very likely that there is such a thing as unintentional equivocation that is due to inattention. If the mere intention to avoid equivocation precludes the possibility of unintentional equivocation, which presumably would be operative in any inference, such careless equivocation would be impossible. The view would have to be qualifi ed in some way in order to account for this. However, putting this objection aside, we can show by _reductio ad absurdum_ that it cannot always be the case that a switcher’s premises are linked in such a way as to avoid equivocation. 

In an inference, one typically puts together independent pieces of information or propositions, and draws a conclusion from them. These propositions start life, as it were, not linked to each other anaphorically, or any by any other dependence relation. I have a belief about some-

<!-- page: pdf=0015 printed=563 -->

thing that happened to me years ago, and I have a belief about something in my current environment, and I put them together and infer something. If the contents of my beliefs are independent of each other in the fi rst place, but when they are put together in an inference something _happens_ to them, so that their contents are guaranteed to match in the relevant ways, this thing that happens to them seems to be _inference_ (even if it is unconscious). If, from my original beliefs _that I swam in water as a child_ and _that now twater is condensing on my glass_ , somehow I end up with an inference where the premises are anaphorically linked, like _water is such that I swam in it as a child; and now it is condensing on my glass_ , this transition would be the result of an (invalid) inference, a putative instance of the ‘ λ ’-transformation rule of abstraction.10 From < _a_ is F> and < _a_ is G>, it can be inferred validly that < _a_ is an individual such that it is F and G>, where ‘a’ and ‘it’ must co-refer. But if one does so infer, then this resulting quasi-anaphoric linkage is not already present in the premises, and is not required to be already present in order for the inference to occur. Rather, it is the end result of this particular (stage of) inference. 

If Peter believes that he swam in water, and he also believes that there is now twater condensing on his glass, but when he puts these beliefs together in an argument as premises, Peter ends up with linked-content premises that both involve the water-concept, or both involve the twater-concept, then this transition (from original beliefs to a new set of premises scotch-guarded against equivocation) is where the equivocation happens. Peter transitions from <I swam in water> and <now there is twater condensing on my glass>, to <water is something such that I swam in it and it is now condensing on my glass>. This seems to him like an application of the ‘ λ ’-transformation rule of abstraction, but it is not. It is equivocation, and it is invalid. So if twin concepts are possible, and the real genesis of the inference is these propositions whose contents are determined independently of each other, then even if some sort of inferential intention transforms the contents of the premises so that equivocation is ruled out thenceforth, the equivocation would be occurring after all, in that transformation. So even on the assumption that the inferential intention precludes unintentional equivocation (at 

> 10 The argument form < _a_ is F and _a_ is G; therefore _a_ is something that is both F and G> is an application of Alonzo Church’s ‘ λ ’-transformation rule of abstraction, which permits the inference from <Fa> to <( λ x)[Fx](a)>, i.e. to <a is an individual such that it F’s>. The inference from the latter to the former is also valid, by ‘ λ ’- concretion. The two sentences are logically equivalent, but their contents differ. For an insightful discussion of the ‘ λ ’-transformation rule of abstraction and belief contents, see Nathan Salmon (1989), particularly 244-5 and 261-3.

<!-- page: pdf=0016 printed=564 -->

least at one stage of the inference), provided that the concepts of water and of twater can be twin concepts for a subject, we fi nd that such unintentional equivocation must take place anyhow, at an earlier stage of the inference. 

Burge’s view (1998), another variation on the anaphor strategy, is that someone in Peter’s situation would not reason invalidly, even if he has twin concepts, because of the preservative role that memory plays. (Recall that preservative memory was earlier marshaled in favor of the possibility of twin concepts; Burge will now use it against the view that these twin concepts will engender invalid inferences.) Burge says that in characterizing Peter’s situation as we have done, and attributing to him invalid reasoning, we 

overlook the centrality of preservative memory in reasoning… Insofar as we think intuitively that [Peter] is not making a mistake in reasoning, it is natural, and in most cases I think correct, to take [him] to be holding constant, through preservative memory within the argument, the concept used in the fi rst premise in [his] thinking the second premise. (1998, 366-7) 

Peter thinks a thought involving the water concept. In constructing an argument, Peter holds the water concept for re-use in the second premise. Peter perceives twater, and has beliefs about it, but ‘the exigencies of reasoning take precedence’ (367), with the result that he falsely applies the water concept in the current environment.11 It may well be that this sometimes happens. But sometimes surely this does not happen. One simply notices that one has one belief, notices that one has another belief, arrived at independently, and sees them as combinable by _modus ponens_ or some other rule, and combines them in that way. The second premise is not constructed on the spot by retaining elements from the fi rst premise for re-use. It is easy to fi nd examples of this from one’s own life. 

Brown (2004, 178-9) argues that if it were indeed the case that once a switcher began an inference with a twater premise, she could no lon- 

- 11 Brown (2004, 178) criticizes Burge on this point, arguing that if this were so then the content of an inference might depend, implausibly, on the order in which the premises were thought. If a reasoning subject began with a twater thought, then memory would preserve that twater concept for employment again in the later premises, even though the subject possesses the water concept. But if the subject started off with a water thought, then it is the water concept that would be preserved throughout the inference. Brown regards it as ‘intuitively plausible’ (2004, 178) that the thoughts a subject entertains are independent of the order in which they are thought. One might grant that we have such intuitions but explain them away as the result of lacking a full appreciation of the role of preservative memory in inference.

<!-- page: pdf=0017 printed=565 -->

ger employ her water thoughts in the inference, a standard motivation for saying that the switcher has both concepts — this allows her to remember her past experiences of water — would be lost. Yes, she would still have water thoughts, _but only as long as they were not combined with other beliefs in theoretical or practical reasoning_ . Such a switcher can recall water, but she can only recall it ‘neat’ (as Brown wonderfully puts it). I might add that a similar problem arises for ‘neat’ thoughts about the present environment. If one starts an inference with a memory-based water thought, and Burge is right about the centrality to inference of preservative memory, then although one will still be able to have thoughts about the twater in one’s current environs, one will be unable to employ those thoughts in the inference. Girding the Twin Earth thought experiments is the intuition that if one switched to Twin Earth, one would eventually be able to think and talk about twater, and to use those thoughts, presumably in conjunction with the thoughts one already has, in reasoning. 

Of course the preservative role of memory plays a role in inference, preserving a particular content, or one’s justifi cation for believing the content, through a period of time, but it need not play the role that Burge claims it does here, of allowing later premises to be constructed from the preserved constituents of earlier premises. And if Burge were right, once again it would prove too much. Equivocation due to carelessness and the like does occur, so the ‘exigencies of reasoning’ and the preservative function of memory must not be such as to prevent it ever from happening. 

One might wonder if it is even epistemically justifi ed to try to ward off equivocation by tying all the occurrences of a term together by preservative memory. I think it is not. There are of course all sorts of iron clad strategies for avoiding invalid inferences. For instance, one could simply refuse to make inferences, or one could accept contradictions, so that everything one might infer would follow validly from one’s premises. But these strategies are contraindicated, considering our epistemic goals of acquiring true beliefs and avoiding false ones. The same can be said for this anti-equivocation strategy. One who did try to avoid equivocation by holding constituents of one’s premises for re-use in later premises would not thereby avoid inferring the false conclusion. The remedy is a nostrum — it avoids the logical error of reasoning from true premises to a false conclusion, by turning one of the true premises into a false one. This would be a technical improvement, at best. (Goldberg, 1999, makes a similar point.)

<!-- page: pdf=0018 printed=566 -->

## _3. The Enthymeme Strategy_ 

So I do not think that any variation of the anaphor strategy will vindicate Peter’s reasoning. Let us consider the last strategy. Perhaps Peter’s reasoning as characterized is enthymematic. All we need to do is to make explicit the tacit missing premise (perhaps, _that water is twater_ ), and then the culprit is not Peter’s reasoning, but the false identity premise, belief of which betokens no irrationality. If this is right, Peter does not commit a brute, logical error. 

What is an enthymeme? I’ll take it to be an incompletely stated valid argument (invalid as stated), in which the missing premise is, or at least seems, suffi ciently obvious, in the context, to ‘go without saying.’ Irving Copi thought that the suppressed premise must be an obvious _truth_ and easily supplied, and that if it meets these conditions ‘in all fairness’ it ought to be included in an appraisal of the argument (1973, 132). In assessing the validity of an argument, the truth of the premises is irrelevant, so presumably the reason Copi thought the tacit premise must be an obvious truth is that this would be strong evidence that the reasoning subject relied on the premise, despite not making this explicit. But in some cases there will be reason to believe that a premise that is in fact false would seem suffi ciently obvious to the reasoning subject that the subject might not explicitly state the premise, despite depending on it in the inference. So I submit that suppressed premise need not be true. 

Since Peter’s inference is unsound, and all his explicit premises are true, any candidate for the suppressed premise that would validate his reasoning must be false. If supplying a suppressed premise is to validate Peter’s reasoning, then I think three conditions must be met. (1) Peter must believe the premise; (2) the premise must actually fi gure in Peter’s reasoning, even if only tacitly; and (3) belief of the premise, in itself or in conjunction with the other premises, must not constitute any logical defi ciency. We need to include the last condition, or else we could validate the reasoning of someone who affi rms the consequent by attributing to them belief in a premise like ‘(Q & (P > Q)) > P),’ which itself betokens a lack of logical acumen. The necessity of the other two criteria should be self-evident, although it may be diffi cult to say exactly what it is for a premise to be tacitly relied upon. 

Let us fi rst consider the premise _that water is twater_ (which Peter perhaps would express, somewhat oddly, as ‘Water is water.’). Although this premise is false (although the sentence could be used to express trivial truths, as well), belief of it is not a logical error. Does Peter believe that water is twater? At fi rst blush, it seems that he does. He confuses the two substances with each other, and in fact thinks they are just one substance. Tye (1998), however, argues that he does not. He gives

<!-- page: pdf=0019 printed=567 -->

two reasons. One is that if Peter believes water is twater, then whatever he believes of twater (that there is twater in his current environment, for example) he will then also believe of water. But Tye takes it to be self-evident that Peter, after he’s been a while on Twin Earth, will not believe that water is in his current environment. Peter will believe that twater is in his environment. Therefore he does not believe that water is twater (1998, 83). 

Tye’s argument can be resisted in two ways. Tye assumes that if a subject believes that <a = b> and that <a is F>, then the subject must believe that <b is F>. This may well be the case, but it is not self-evident. It might be that although a subject believes that <a = b>, she sometimes believes that <a is F> without believing that <b is F>, in virtue of the causal connections she bears to her environment at the time the belief is formed. Peter might believe that water is twater, and yet believe something of twater that he does not believe of water (or vice versa). Peter’s belief that long ago he once swam in water was caused by contact with water, and sustained by memory of that water incident. There was no such contact with twater in his youth, and no memories of twater incidents from his youth, so plausibly he lacks the belief that long ago he once swam in twater. But this does not show that were he to (somehow) entertain the proposition that water is twater, that he would withhold assent from it, or dissent from it. The proposition should seem like a triviality to him, expressible as it is by the sentence ‘water is water,’ and thus seems to be something he’d believe. 

Suppose, though, that Tye’s assumption, that if the switcher believes that water is twater, then whatever she believes of water she also will believe of twater, is correct. Suppose also that the switcher _does_ believe that water is twater. Therefore it follows that after the switcher has acquired the concept of twater, and has formed the belief that twater is in her environment, she also retains the concept of water and believes that water is in her environment. It is hardly self-evident that this is an unacceptable conclusion for the content externalist. If an externalist insisted that a switcher to Twin Earth could not believe that there was water in her current environment, but agreed that the switcher could still remember the water from Earth, this would likely be because the externalist would reject Tye’s assumption that if a switcher believes that water is twater, that she must believe exactly the same things about water that she believes about twater. 

The other reason Tye gives as to why the switcher could not believe that water is twater is this: the switcher, while on Twin Earth, could entertain a Putnamian thought experiment of his own ‘in reverse with respect to Earth.’ He could imagine a planet just like his own, with stuff just like his own ‘water’ that fi lls the oceans and rivers, but which has a different molecular structure. Says Tye:

<!-- page: pdf=0020 printed=568 -->

[He] would surely deny that there is any twater on that planet, while simultaneously granting that water is found there. How could [he] do that, if [he] believed that water is twater? (1998, 84) 

The reasoning is specious. First of all, the strategy of arguing that a subject must not believe that water is twater if he also believes that water is not twater might not fare well in these circumstances. If sameness of content is not transparent, then a subject might encounter the same proposition under two different guises, believe it under one guise and disbelieve it under the other (as with the Paderewski, London/Londres examples). But even worse, in the situation as described, the switcher would not, by entertaining the Putnamian thought experiment ‘in reverse’ thereby come to have any beliefs about Earth, or water, i.e., about the place he used to live and the liquid he used to drink. Neither could one acquire the twater-concept early (before the switch) by hearing about Putnam’s Twin Earth thought experiment. 

Anyone reading this paper has entertained the Twin Earth thought experiment, but none of us has thereby acquired a new natural kind concept, or even a concept that purports to be of a natural kind. Twater is neither a natural kind, nor even a _possible_ natural kind. It is merely a fi ction that is used to illustrate a philosophical point, and to stand in for any of an infi nite number of possible substances that satisfy the requirements of the Twin Earth stories. 

Suppose you have a good friend named Joe, but actually, unbeknownst to you, ‘Joe’ is two identical twins, Joe and Moe, who get their kicks pretending to be a single person. You are acquainted with each of these guys, and you have de re beliefs about each of them, although you think you have just the one friend, not two. Do you believe that Joe is Moe (although you wouldn’t identify either as Moe)? Maybe you do, and maybe you do not. But the case can hardly be decided in the negative simply by pointing out that you could do a thought experiment in which you imagine your friend Joe has an identical twin, whom we can call ‘Moe,’ and so forth, and that in such a case you would say that Joe and this hypothetical ‘Moe’ do not share personal identity. The belief that in this hypothetical case Joe is not Moe is not the negation of the belief about Joe and the actual identical twin Moe, the belief that Joe is Moe. The hypothetical thought experiment ‘Moe’ is no real or even possible person; it is a mere fi ction. 

Now the mere fact that someone systematically confuses one thing for another does not entail that she believes they are identical. A prospector may never be able to tell the difference between gold and fool’s gold (iron pyrites), but she does not believe that they are one and the same. For such a prospector, gold and fool’s gold are still discernible in some ways, if not perceptually discernible. The prospector knows

<!-- page: pdf=0021 printed=569 -->

the gold is valuable, but that fool’s gold is not, and so forth. But Peter mistakes water for twater, and although he is aware of each, he is not aware that there is any difference between them, or even that they are not numerically identical. So I think it is not unreasonable to say that he believes that water is twater. It helps explain why he reasons as he does. Two of the conditions for the argument being an enthymeme therefore plausibly have been met. But does this premise really fi gure in his reasoning? If the argument, without the premise, were valid, as Peter supposes it is, then the suppressed premise would be completely superfl uous. Press Peter on the status of the suppressed premise, and, if he really has training in logic, he would insist that the premise was superfl uous for the validity of the inference, and that it was not a constituent of his inference. This premise, after all, although its content is _that water is twater_ , is expressed by the sentence ‘water is water.’ 

If a mathematician thought that she had proved something, and she insisted that she had not relied on Cantor’s Theorem, and the proof as explicitly stated was invalid, we could not validate her reasoning by attributing to her tacit reliance on Cantor’s Theorem. We ought to be reluctant to attribute to someone reliance on a premise when she explicitly denies that she is using it at all. It may be possible that a reasoning subject could tacitly rely on a premise that she thinks she is not relying on, perhaps in cases like Peter’s, in which case the subject’s reasoning would be valid, but she would be mistaken about what form her argument takes. (There are questions about how such a subject would manage to think the right, validity-securing, content by uttering ‘water is water,’ rather than thinking a tautological content.) 

But I think there is good reason to suppose that Peter is not using that premise in the argument. In reasoning, we trade on the identity of things we perceive and think about. You see a dog follow the fl ight of a thrown stick, you blink, and then you see the dog chase the stick. You conclude that the dog chased the stick after following its fl ight. Here, you’re presupposing that the dog you saw before the blink is the dog you saw after the blink. But in drawing the conclusion you do not rely on a judgment, as a premise of the inference, that _this_ dog is _that_ dog. You simply trade on this identity in the inference, as you are entitled to do if your perceptual faculties are functioning more or less correctly, and the demonstrata are relatively stable and perceptually re-identifi - able objects.12 (See John Campbell, 1994, chapter 3, for a detailed de- 

> 12 As Brown (2004, 180-81) notes, if any argument involving a singular term like ‘water’ depended on a tacit identity premise such as, as it would be stated in English, ‘water is water,’ an infi nite regress will ensue. The argument would still rely on the fact that the occurrences of ‘water’ in the identity premise express the same con-

<!-- page: pdf=0022 printed=570 -->

fense of this view.) But in Peter’s case, the environment did not cooperate, and the presupposition that water (or _this stuff_ ) and twater (or _that stuff_ ) are identical just happens to be false. 

The same thing will have to be said about any other halfway plausible candidates for the suppressed premise, such as some meta-linguistic premise about how one uses the word ‘water.’ These are presuppositions of the reasoning, background conditions that must be met in order for the inference to be valid, rather than premises of the reasoning. We were trying to fi nd a false premise, in order to make Peter’s reasoning logically unimpeachable. Would fi nding a false presupposition do the same thing? 

Burge thinks so. He concedes there may be cases in which the subject does not tie the contents of his premises together, ‘anaphorically’ by the use of preservative memory, as I have argued. Let me quote him: 

Insofar as the reasoner’s intentions in reasoning are not dominant in requiring ‘anaphorically’ that the same concept be used throughout the reasoning, and insofar as we think that there is a gap between the premises that the reasoner has not made explicit, it would seem obvious that the reasoner tacitly and mistakenly presupposes that the concepts apply to the same objects. This presupposition is not present in cases of equivocation that occasion invalid reasoning. In such cases the individual overlooks the difference between concepts expressed by the same term, but has no tendency to treat the concepts as interchangeable in general beliefs, and no tendency to apply them to the same objects. So to fully capture the reasoner’s cognitive state in a case where the reasoner does presuppose (mistakenly) that the concepts apply to the same objects, one would have to supply for the reasoner the mistaken presupposition… Again, there is no mistake in reasoning, only a mistake in presupposition. (Burge, 1998, 368) 

I think that a lot of what Burge says here is right. We should distinguish between the sort of equivocation that occurs when someone realizes that a term expresses two different concepts, but he overlooks this fact in an inference (as with the Mill example in note 4), and what is happening with Peter, who doesn’t realize that his term does express two concepts. The former is correctable by refl ection, and the latter is not, so if we are constructing epistemic blaming policies, there is a strong case 

cept as the other ‘water’ occurrences in the inference do, so another identity premise would seem to be required, and so on. I take it to be clear, though, that it is not the case that _any_ argument whose validity depends on multiple occurrences of a term having the same content needs an identity premise for that validity. The view being considered here is that when an argument (without the identity premise) is invalid, because different occurrences of a given singular term have different contents, the argument can be made valid by supplying the tacit identity premise. The view is wrong, I think, but not because of the threat of any infi nite regress.

<!-- page: pdf=0023 printed=571 -->

for treating Peter differently from how we treat the ordinary equivocator. Recognizing that the fl aw in Peter’s reasoning is very different from the sort that is correctable by refl ection seems to fall under the heading of ‘more fully capturing Peter’s cognitive state.’ 

But Burge is wrong that if the problem in Peter’s inference is his mistaken presupposition that his term expresses the same concept throughout the inference, then Peter has made no mistake in reasoning. This mistaken presupposition _just is_ an error about the logical form of his inference. Of course, Peter knows what logical form an inference must have if it is to avoid equivocation, so he does have logical acumen. But he is unable to tell through introspection whether his own inference exemplifi es that logical form. Unless we elevate all the presuppositions of an inference to the status of premises in that inference, which we should not do13, we must say that the reasoning is invalid. Attributing to the subject the mistaken presupposition does not validate the reasoning, but rather it makes it clear why the refl ective and logically adroit subject could produce such invalid reasoning. 

## **IV  Conclusions** 

So I conclude that the most plausible view is that externalism does entail the possibility of brute logical error, or more particularly brute error as to the logical form of one’s own inferences. The three types of strategies for blocking this consequence are (1) to argue that even if a switcher would lack authoritative discriminative self-knowledge, since she would not know that her current twater thought is different from her past water thought, she would at no time be able to think both water and twater thoughts, (2) to argue that when one makes an inference something links the contents so as to make unintentional equivocation between, say, the water and twater concepts impossible, and (3) to argue that to better represent the switcher’s reasoning we should attribute to her belief in a tacit identity premise, like _that water is twater_ , which validates her reasoning. I have argued that all of these strategies fail. 

The externalist may respond that this result should not be regarded as constituting an objection to externalism, since externalism gives us good reason to reject (at least in part) the conception of rationality and folk psychological explanation underwritten by the thesis that we have authoritative discriminatory self-knowledge. The question is how this is to be done. Boghossian suggests some answers that he rejects as un- 

> 13 And Burge would be the fi rst to admit that we should not. This is one of his central points in Burge 1993.

<!-- page: pdf=0024 printed=572 -->

helpful (1994, 48-9). In order to deal with the problem cases in which, no matter how rational she might be, the subject just cannot see that two mental state tokens have different contents (or have the same content), one cannot simply absolve everyone who cannot see that she is violating the norms of logic, as such an inability is precisely what makes someone irrational, in ordinary cases, Boghossian rightly says. Nor can one absolve those for whom the nature of the logical misstep is not accessible to introspection, for if externalism is true the logical properties of one’s thoughts are in general not accessible to introspection. 

Brown (2004, 190-91) suggests a sensible way to sort out the logical errors for which one deserves blame from those for which one does not. One who believes a contradiction, or fails to see the validity of a simple inference (as with the Paderewski or the to-may-to/to-mah-to examples), is not to be blamed for the logical error if she would deny that she was using the relevant term univocally. One who asserts that Paderewski is a musician and Paderewski is not a musician but who explains herself by saying ‘But they are two different Paderewskis!’ makes a logical error, but is not culpable for it. Similarly, one who equivocates on the word ‘water’ in an inference, in one premise using it to express the concept water and in the other using it to express the concept twater, is blameless for the logical error if she indeed believes that water is twater, or insists that she takes ‘water’ to have the same meaning each time it occurs in her inference. Rational agents cannot be expected to conform to the norms of logic merely on the basis of what introspection tells them. All that can be expected of rational agents is that if they are given the logical properties of a sequence of thoughts, they can tell whether that sequence is valid or not. 

It is beyond the scope of this paper to determine whether this reply is adequate. An account of rationality according to which one is never justifi ed except after empirical investigation in taking one’s thought content constituents to bear particular sameness or difference relations to each other would seem to be terribly impoverished. On the other hand, the _aims_ of rationality and logicality are clearly _external_ : truth, validity, and consistency (among others). Perhaps the externalist can argue that, fanciful counterfactual situations notwithstanding, our environments are stable enough to support an entitlement (albeit a defeasible one) to introspective judgments of sameness and difference of content. I am sanguine about the prospects for such an argument, but I do not believe it has yet been given.14 

_Received: August 2006_ 

14 I thank Anthony Brueckner, C. Anthony Anderson, Francis Dauer, Sanford Gold-

<!-- page: pdf=0025 printed=573 -->

## **References** 

Boghossian, P. 1989. ‘Content and Self-Knowledge.’ _Philosophical Topics_ **17** : 5-26. 

- ______. 1992. ‘Externalism and Inference.’ _Philosophical Issues_ **2** (Rationality in Epistemology): 11-28. 

- ______. 1994. ‘The Transparency of Mental Content.’ _Philosophical Perspectives_ **8** (Logic and Language): 33-50. 

Brown, J. 2004. _Anti-Individualism and Knowledge_ . Cambridge, MA: MIT Press. 

- Brueckner, A. 1997. ‘Externalism and Memory.’ _Pacifi c Philosophical Quarterly_ **78** : 1-12. 

- Burge, T. 1988. ‘Individualism and Self-Knowledge.’ _Journal of Philosophy_ **85** : 649-63. 

- ______. 1993. ‘Content Preservation.’ _The Philosophical Review_ **102** : 457-88. 

- ______. 1997. ‘Interlocution, Perception and Memory.’ _Philosophical Studies_ **86** : 21-47. 

- ______. 1998. ‘Memory and Self-Knowledge.’ In _Externalism and Self-Knowledge_ , P. Ludlow and N. Martin, eds. Stanford, CA: CSLI Publications. 351-370. 

- Campbell, J. 1994. _Past, Space and Self_ . Cambridge, MA: MIT Press. 

- Copi, I. 1973. _Symbolic Logic, 4th Edition_ . New York, NY: Macmillan. 

- Falvey, K., and Owens, J. 1994. ‘Externalism, Self-Knowledge and Skepticism.’ _Philosophical Review_ **103** : 107-37. 

- Goldberg, S. 1999. ‘The Relevance of Discriminatory Knowledge of Content.’ _Pacifi c Philosophical Quarterly_ **80** : 136-56. 

- ______. 2007. ‘Anti-Individualism, Content Preservation, and Discursive Justifi cation.’ _Nous_ **41** : 178-203. 

- Heal, J. 1998. ‘Externalism and Memory II.’ _Proceedings of the Aristotelian Society_ , 

   - Supplementary Volume **72** : 95-109. 

- Heil, J. 1988 ‘Privileged Access.’ _Mind_ **97** : 238-51. 

- Kripke, S. 1979. ‘A Puzzle about Belief.’ In _Meaning and Use_ , A Margalit, ed. Dordrecht: Reidel. 239-83. 

- Loar, B. 1987. ‘Social Content and Psychological Content.’ In _Contents of Thoughts_ , R. Grimm and D. Merrill, eds. Tucson: University of Arizona Press. 99-110. 

- Ludlow, P. 1995. ‘Externalism, Self-Knowledge, and the Prevalence of Slow Switching.’ _Analysis_ **55** : 45-9. 

______. 1997. ‘On the Relevance of Slow Switching.’ _Analysis_ **57** : 285-6. 

berg, William Larkin, Michael Veber, Richard Greene, Dennis Arjo, audiences at the University of California at Santa Barbara, John Carroll University, East Carolina University, and the 2004 Pacifi c Division meeting of the American Philosophical Association, anonymous referees from this journal, and especially Nathan Salmon and Kevin Falvey, for helpful comments on earlier drafts of this article.

<!-- page: pdf=0026 printed=574 -->

Mill, J.S. 1979. _Utilitarianism_ . Indianapolis: Hackett Publishing Co. 

Owens, J. 1989. ‘Contradictory Belief and Cognitive Access.’ _Midwest Studies in Philosophy_ **14** (Contemporary Perspectives in the Philosophy of Language II): 289-316. 

- ______. 1995. ‘Pierre and the Fundamental Assumption.’ _Mind and Language_ **10** : 250-73. 

- Putnam, H. 1975. ‘The Meaning of ‘‘Meaning.’’’ Reprinted in H. Putnam, _Mind, Language and Reality: Philosophical Papers: Volume 2_ . Cambridge: Cambridge University Press. 215-71. 

- Salmon, N. 1989. ‘Illogical Belief.’ _Philosophical Perspectives_ **3** (Philosophy of Mind and Action Theory): 243-85. 

- Schiffer, S. 1992. ‘Boghossian on Externalism and Inference.’ _Philosophical Issues_ **2** (Rationality in Epistemology): 29-37. 

Segal, G. 2000. _A Slim Book about Narrow Content_ . Cambridge, MA: MIT Press. 

- Sorensen, R. 1998. ‘Logical Luck.’ _The Philosophical Quarterly_ **48** : 319-34. 

Taschek, W. 1995a. ‘Belief, Substitution, and Logical Structure.’ _Nous_ **29** : 71-95. 

- ______. 1995b. ‘On Belief Content and That-Clauses.’ _Mind and Language_ **10** : 274-98. 

- ______. 1998. ‘On Ascribing Beliefs: Content in Context.’ _Journal of Philosophy_ **95** : 323-53. 

- Tye, M. 1998. ‘Externalism and Memory I.’ _Proceedings of the Aristotelian Society_ Supplementary Volume **72** : 77-94. 

- Warfi eld, T. 1992. ‘Privileged Self-Knowledge and Externalism are Compatible.’ _Analysis_ **52** : 232-7. 

- ______. 1997. ‘Externalism, Self-Knowledge, and the Irrelevance of Slow Switching.’ _Analysis_ **57** : 282-4.
