---
title: "Reply to Otero's “Boghossian's Inference Argument against Content Externalism Reversed”"
source_type: "paper"
source_format: "pdf"
source_path: "D:\\Codex Working Folder\\2026-08-09\\obsidian-update-20260809-011416\\s044\\Boghossian-2014-Reply-to-Otero.pdf"
source_id: "boghossian-2014-reply-to-otero-9c43206ecf71"
source_sha256: "9c43206ecf71459d6f73d3a77f2307bf8397fa6daa8af9a34d02ec3f6590284f"
conversion_status: "extracted"
conversion_date: "2026-08-09T01:15:30+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "D:\\Codex Working Folder\\2026-08-09\\obsidian-update-20260809-011416\\s044\\literature-to-markdown\\artifacts\\manifests\\boghossian-2014-reply-to-otero-9c43206ecf71-761a2d4a58.json"
---

# Reply to Otero's “Boghossian's Inference Argument against Content Externalism Reversed”

<!-- page: pdf=0001 printed=1 -->

Philosophy and Phenomenological Research Vol. LXXXIX No. 1, July 2014 doi: 10.1111/phpr.12098 © 2014 Philosophy and Phenomenological Research, LLC 

PAUL BOGHOSSIAN

New York University

In my (1992, 1994), I argued that introspective accessibility of facts about sameness and difference of the concepts exercised in our thoughts plays a pivotal role in our most basic conceptions of rational agency and rational explanation. 

In particular, I argued that any theory of concepts that allows for such failures of (epistemic) transparency faces a serious difficulty: it seems committed to mis-describing the conditions under which agents are rational. (More neutrally, any such theory blurs the distinction between an agent’s mishandling the information she has, versus her merely failing to have information.) 

I also argued that standard externalist accounts of concepts, both of the natural and social varieties, allowed for such cases, illustrating this not only through Kripke’s Pierre (1979) but also through my example of Switched Peter. 

In his critical discussion of my 1994, Manuel Perez Otero (2012) argues for two main claims. His central thesis, he says, 

is that the problematic situation Boghossian describes represents an important challenge for any theory of content, not just for externalism. (2) 

A secondary claim is that, to the extent to which cases like Switched Peter bear on the internalism/externalism debate in the theory of content, 

it is the externalist side that comes up on top. I hope to show that the repertoire of solutions that the externalists can call on is more promising than the set of solutions that the internalists can invoke. (2)

<!-- page: pdf=0002 printed=2 -->

He ends with tentatively suggesting a diagnosis of why the secondary claim is true: 

The debate favours externalism because the example analysed by Boghossian involves the use of a singular term, and with respect to singular terms, our externalist intuitions (as highlighted by Putnam and Burge in their thought experiments about Twin Earth) are even stronger than they are with respect to natural kind terms. (3) 

In this short piece, I will briefly reply to these three claims. 

Let me start with the third of Otero’s claims, that by focusing on an inference involving an equivocation in the use of a proper name, ‘Pavarotti’, I unwittingly presented an argument that further bolsters externalist views. 

It’s puzzling to me that Otero says that I focused exclusively on the treatment of proper names in the case of Switched Peter. In my (1994), I was especially concerned to emphasize that the failures of transparency applied just as much to general terms like ‘water’ as they did to singular terms like ‘Pavarotti.’ 

Indeed, I was much more interested in the general terms than I was in the singular terms. Naming and Necessity had persuaded many philosophers that names had to be treated as mere tags. As a result most philosophers took Millianism, and a consequent failure of transparency about names, to be inevitable. 

In my (1994), I pointed out that de re beliefs, which are obviously externalistically individuated, and for which, as a result, transparency failure is immediate, are already excluded from assessments of a subject’s rationality. Since one might easily believe of one and the same visually presented apple both that it is wholesome and that it is not wholesome, without being guilty of any failure of rationality, we don’t take ‘contradictory’ de re beliefs to impugn a person’s rationality. 

If my problem-generating example had involved only names, an externalist would have an easy and conservative way out of the problem: treat beliefs involving names in the way that we already treat de re beliefs, by selectively excluding them from assessments of rationality and rational explanation. Such a maneuver may not be cost-free, but it’s in the running. After all, proper names are not needed for most of science. 

Of course, such a strategy of selective exclusion could not be extended to general terms as well, for fear of leaving nothing for assessments of rationality to be about. 

That’s why I took it to be important to show that general terms, which have a descriptive meaning in addition to an extension or reference, would also fail to be transparent, if those descriptive meanings were individuated externalistically. For that would show that one could not deal with the problem of transparency failure simply by the selective exclusion strategy.

<!-- page: pdf=0003 printed=3 -->

At any rate, I don’t really understand how Otero proposes to show that the internalist will have a harder time than the externalist in vindicating Peter’s rationality. Peter reasons to himself in a way that he would express as follows: 

Whoever floats on water gets wet Pavarotti once floated on water So, Pavarotti once got wet 

On certain externalist assumptions, that Otero does not dispute, the externalistically individuated thoughts that Peter is giving voice to here involve a fallacy of equivocation: the second premise involves the concept water whereas the first involves twater. 

However, there is clearly a narrow, ‘syntactic,’ way of individuating the thoughts involved, along with a correspondingly narrow, syntactic notion of validity, according to which the inference is valid. 

And if that narrow notion is the one we employed in our theory of rationality, we could easily explain why Peter is rational in being prepared to make these inferences. 

I don’t say that this sort of approach is problem-free, of course. But it is highly unobvious to me, to say the least, that it is more problematic than the solutions that are available to the externalist—namely, the Anaphorically-based treatment of Peter’s inference, (Burge, 1998) or the Logical Luck strategy (Sorensen, 1998 or Faria, 2009). 

We can certainly agree with Otero that the problem of transparency is a challenge to any theory of concepts and not just to externalist ones. Beyond that, though, his more specific claims seem to me doubtful.<sup>1</sup> 

## References

Boghossian, Paul 1992. “Externalism and Inference”. Philsophical Issues, 2. 11–28. 

1994. “The Transparency of Mental Content”. Philosophical Perspectives, 8. 33–50. 

Burge, Tyler 1998. “Memory and Self-Knowledge”. In P. Ludlow and N. Martin (eds.), Externalism and Self-Knowledge, Stanford: CSLI. 

Faria, Paulo 2009. “Unsafe Reasoning: A Survey”. Dois Pontos, 6. 185–201. Kripke, Saul 1979. “A Puzzle About Belief”. In A. Margalit (ed.) Meaning and Use. Dordrecht: Reidel. 

Sorensen, Roy 1998. “Logical Luck”. Philosophical Quarterly, 48. 310–334. 

> 1 Thanks to Gregory Bochner for helpful comments on a draft of this reply.
