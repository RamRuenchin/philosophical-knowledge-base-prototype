---
title: "A new argument for the incompatibility of content externalism with justification internalism"
source_type: "paper"
source_format: "pdf"
source_path: "D:\\Local Knowledge Base\\2.Raw\\papers\\Morvarid-2021-A New Argument for the Incompatibility of Content Externalism with Justification Internalism-Synthese.pdf"
source_id: "morvarid-2021-a-new-argument-for-the-incompatibility-of-content-externalism-with-justification-i-b14d17e03987"
source_sha256: "b14d17e039872d9cc90424eec36646a4d605a87570fba01aae4068fd04de7ac8"
conversion_status: "extracted"
conversion_date: "2026-08-09T15:17:30+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "\\\\?\\D:\\Codex Working Folder\\2026-08-09\\obsidian-update-20260809-011416\\s204\\literature-to-markdown\\artifacts\\manifests\\morvarid-2021-a-new-argument-for-the-incompatibility-of-content-externalism-with-justification-i-b14d17e03987-761a2d4a58.json"
authors:
  - "Mahmoud Morvarid"
---

# A new argument for the incompatibility of content externalism with justification internalism

<!-- page: pdf=0001 printed=2333 -->

# **A new argument for the incompatibility of content externalism with justification internalism** 


### **Mahmoud Morvarid**<sup>**1**</sup> 

Received: 28 May 2018 / Accepted: 10 April 2019 / Published online: 17 April 2019 © Springer Nature B.V. 2019 

### **Abstract** 

Several lines of reasoning have been proposed to show the incompatibility of content externalism with justification internalism. In this paper I examine two such lines of reasoning, which both rely on the general idea that since content externalism is incompatible with certain aspects of the alleged privileged character of self-knowledge, it would tend to undermine justification internalism as well. I shall argue that both lines of reasoning, as they stand, lack plausibility, though the core idea of the second line can be reconstructed into a new argument which shows considerable promise. In particular, relying upon the reliability constraint on knowledge, I shall argue that the so-called ‘two-concept’ version of content externalism is incompatible with ‘the transparency of sameness of content’, and thereby would also undermine justification internalism. 

**Keywords** Content externalism · Justification internalism · Privileged selfknowledge · Transparency of sameness of content · Transparency of difference of content 

The phrase ‘internalism versus externalism’ is used to refer to two completely different debates in contemporary philosophy. In philosophy of mind, the debate concerns whether the mental content one possesses supervenes on one’s intrinsic properties (content internalism), or not (content externalism). In epistemology, on the other hand, the debate between internalists and externalists can be loosely characterized as concerning whether the justificatory status of a subject is entirely determined by factors to which she can acquire ‘special access’ (justification internalism), or not (justification externalism). 

Even from the early days in which Putnam (1975) and Burge (1979) put forward their influential arguments for content externalism, many philosophers have felt that 

> * Mahmoud Morvarid morvarid@ipm.ir 

> 1 School of Analytic Philosophy, Institute for Research in Fundamental Sciences (IPM), Niavaran, P.O. Box 19395-5746, Tehran, Iran

<!-- page: pdf=0002 printed=2334 -->

content externalism might have substantive epistemological implications. In the last 3 decades, for example, a huge literature has appeared as to whether content externalism is compatible with the privileged access thesis, namely the intuitive idea that one can know the content of one’s current thoughts in an a priori manner.<sup>1</sup> Another issue which has been raised, but received much less attention, is the possible relationship between the internalism/externalism debate in the philosophy of mind and in epistemology. In particular, several lines of reasoning have been proposed for the claim that content externalism may be in tension with (at least some versions of) justification internalism.<sup>2</sup> Among these arguments, presumably, the most promising ones are those which appeal to the assumption that content externalism tends to undermine (some aspects of) the privileged character of self-knowledge. In this paper I examine two such lines of reasoning, finding them, as they stand, lacking in plausibility. The core idea of the second line of reasoning, however, can be reconstructed into a new argument which enjoys considerable merit, or so shall I argue. 

## **1  Preliminaries** 

According to content externalism, the thought content one possesses is partly individuated by one’s physical and social environment. The standard thought experiments used to motivate this idea are those in which two subjects are supposed to be intrinsically the same, while, due to their different physical or social environments, they have different thought contents. For example, consider Putnam’s twin earth, a planet exactly similar to earth, except for the fact that the watery stuff twin earthians call ‘water’ and has all superficial properties of water, has the atomic structure XYZ rather than  H2O. Intuitively, when a subject on earth, Oscar, and his duplicate on twin earth, Toscar, both sincerely utter the sentence ‘water is wet’, they express different thought contents, whereas their relevant intrinsic properties remain the same. 

On the other side, we have justification internalism, which can be roughly characterized as the idea that a subject’s justificatory status depends exclusively on factors to which she can acquire ‘special access’.<sup>3</sup> This rather vague characterization takes different shapes in more precise formulations of the idea. According to the so-called ‘supervenience on the accessible’, the justificatory status of one’s beliefs supervenes on those facts to which one has ‘special access’. There are several possibilities as 

> 1 For collections of papers on this issue, see, e.g., Ludlow and Martin (1998), Wright et al. (1998), Nuccetelli (2003) and Goldberg (2015). 

> 2 See, e.g., Boghossian (1989), BonJour (1992/2010), Vahid (2003a), Brown (2007) and Williamson (2007); also cf. Chase (2001), Brueckner (2002), Conee (2007), Madison (2009) and Tillman (2012). Pritchard and Kallestrup (2004) and Gerken (2008) are germane too. 

> 3 Notice that this characterization concerns only one of two wide branches of justification internalism, which is sometimes called ‘accessibilism’. According to the other branch, usually called ‘mentalism’, the justificatory status of a subject is completely determined by her occurent and dispositional mental states (see, e.g., Conee and Feldman 2001; Wedgwood 2002). In this paper, I only consider accessibilism, leaving the question of whether mentalism is incompatible with content externalism for a separate examination. For this question and related issues, see, e.g., Conee and Feldman (2004, p. 82), Conee (2007) and Tillman (2012).

<!-- page: pdf=0003 printed=2335 -->

to how the notion of special access can be interpreted. For example, it might be construed as having direct or non-inferential knowledge of a fact. We concentrate, however, on a more common understanding of the relevant notion, which takes it as the notion of _reflective_ accessibility: 

**Supervenience on the accessible (SA)** : whether a subject is justified in believing that _p_ supervenes on facts which she is in a position to know by reflection alone.<sup>4</sup> 

Another approach to formulating justification internalism has it, very roughly, that for a subject to be justified in believing that _p_ she ought to be in a position to acquire special access to ‘the justification-conferring factor’ (or ‘the J-factor’) for that belief.<sup>5</sup> I take it that a J-factor for a given belief is a factor whose conjunction with the special access requirement is sufficient to render the belief justified (it is notable that in the related literature, the term ‘J-factor’ and its cognates are sometimes used rather differently, that is, they are used to mean a factor which contributes, even only partially, to the justification of a justified belief. At any rate, nothing substantial hinges on this terminological difference). Of course, sometimes a belief enjoys a positive justificatory status from two independently adequate grounds, as when the subject possesses perceptual as well as testimonial evidence for believing that it is raining. In such cases, it seems utterly implausible to take special access to the both J-factors as a necessary condition for justification. Thus, the present formulation for justification internalism is best understood as requiring that for a subject to be justified in holding a belief, she must be in a position to acquire special access to at least one of the J-factors for that belief. Here again, although the notion of special access could be understood in several ways, we focus on the notion of reflective accessibility: 

**J-factor accessibility (JFA)** : A subject is justified in believing that _p_ only if she is in a position to know, by reflection alone, that at least one of the J-factors for her belief that _p_ holds<sup>6</sup> 

> 4 See, e.g., Brown (2007). Pryor (2001) calls such a view ‘simple internalism’, and Conee and Feldman (2001) call a rather similar idea ‘accessiblism’. Following Pryor (2001, p. 104), by ‘reflection’ I mean ‘a priori reasoning, introspective awareness of one’s own mental states, and one’s memory of knowledge acquired in those ways’. 

> 5 Alston (1986), BonJour (2003, p. 24) and Bergmann (2006, p. 9), among others, characterize justification internalism more or less in this way. See also Goldman (1999) and Audi (2001). 

6 As just remarked, by a J-factor I mean a factor which is sufficient, when conjoined with the special access requirement, to render a belief justified, not a factor which only partially contributes to the justification of a belief. Thus, when I characterize JFA as requiring that the subject should have reflective access to “at least one of the J-factors for her belief”, I do not mean that the internalist requirement will be satisfied, according to JFA, when she has reflective access to only one of the factors which partially contributes to the justification of her belief. Of course, being justified in such a circumstance is what justification externalism claims. Rather, the proposed characterization of JFA is simply intended to highlight the natural idea (from the viewpoint of justification internalism) that if there are two independently sufficient grounds for justification, then having reflective access to only one of those grounds will satisfy the internalist requirement. I thank an anonymous referee for pressing me to clarify this.

<!-- page: pdf=0004 printed=2336 -->

A last formulation of justification internalism says that a subject always has special access to her justifcatory status. Following Pryor (2001) and Brown (2007) we may call this ‘Access Internalism’: 

**Access internalism (AI)** : A subject is always in a position to acquire reflective knowledge regarding her justificatory status.<sup>7</sup> 

The relationship between SA, JFA, and AI raises interesting questions which I shall not go into here. For the sake of simplicity, however, I will mainly be concerned with JFA, as the relevant discussion will typically be repeatable, _mutatis mutandis_ , in the case of AI and SA as well.<sup>8</sup> 

As pointed out, several lines of arguments have been proposed to the effect that content externalism may be in tension with justification internalism. The most promising arguments of this sort, I think, are those which appeal to the idea that since content externalism may undermine (certain aspects of) the privileged character of self-knowledge, it may threaten (some versions of) justification internalism as well. To get a better grip on what is going on in this kind of reasoning, let us distinguish between two different theses regarding our (alleged) authoritative self-knowledge: 

**Privileged Access (PA)** : if a subject at time _t_ entertains a thought or a thought constituent then, at _t_ , she can know the content of her thought or her thought constituent by reflection alone. 

**Transparency of Sameness of Content (TSC)** : if a subject at time _t_ entertains two thoughts, or thought constituents, with the same content then, at _t_ , she can know that they have the same content by reflection alone.<sup>9</sup> 

The above two theses are both alleged to be threatened by (certain versions of) content externalism. In particular, there is a controversy over the compatibility of content externalism with PA, which I shall not rehearse here.<sup>10</sup> 

Parallel to these two theses, two lines of reasoning have been proposed for the incompatibility of content externalism and justification internalism. The first line, advanced by BonJour (1992/2010), Vahid (2003a) and Brown (2007), endeavors to show that if content externalism is assumed to undermine PA then it would by the same token threaten justification internalism as well. I shall argue that this line of reasoning, as it stands, lacks plausibility, even if we grant its assumption that content externalism is incompatible with PA. One might try, of course, to improve the first line of reasoning by adding a new twist to it, but the improved argument, I shall 

> 7 Sosa (1999) calls this view ‘Chisholmian internalism’, and it is defended by Chisholm (1977, ch. 6) and Bonjour 1985 (chs. 1–2). 

> 8 Moreover, it seems that given some plausible assumptions, JFA and SA are equivalent to each other. Furthermore, it is natural to hold that AI entails SA, though it is not clear whether SA implies AI. See, e.g., Sosa (1999, p. 148), Pryor (2001, pp. 105–106) and Brown (2007, p. 16). 

> 9 There is also another thesis in the vicinity, namely ‘the transparency of difference of content’ (TDC), to which we will return in Sect. 4. 

> 10 For some sources on the possible bearings of content externalism upon PA see footnote 1. For the incompatibility of (certain versions of) content externalism with TSC, see the references will be cited in footnotes 24 and 30.

<!-- page: pdf=0005 printed=2337 -->

argue, either collapses to the second line of reasoning (explained below), or else fails to reach its objective except by appealing to controversial assumptions in philosophy of mind and epistemology. 

The second line of reasoning, set out succinctly by Brown (2007), draws on the idea that content externalism (at least in some versions) is incompatible with TSC, and because of this it may also tend to undermine justification internalism. I shall argue that Brown’s implementation of the idea cannot even get off the ground, though the main core of the idea may be reconstructed into a cogent argument which, if not conclusive, does pose a considerable threat to justification internalism. 

Here is how the remaining parts of the paper unfold. In Sect. 2, I delineate the first line of reasoning just mentioned in the form of a _reductio ad absurdum_ against 3, the joint assumption of content externalism and justification internalism. In Sect. I argue that this line of reasoning either collapses eventually to the second line, or else must make controversial assumptions. A new argument for the incompatibility 4, where of content externalism and justification internalism is constructed in Sect. the prospects of the above-mentioned second line of reasoning are explored. Finally, Sect. 5 concludes the paper. 

## **2  The privileged access argument explained** 

In recent decades, several arguments have been proposed to the effect that content externalism is incompatible with PA. For example, in the well-known ‘slow switching’ argument, it is supposed that a subject, say Oscar, is unwittingly switched back and forth between earth and twin earth, and stays long enough in each planet to acquire the relevant concept, that is, the concept of water on earth and that of twater on twin earth. Then it is argued that when he in on earth thinking that water is wet, he cannot know that he is thinking that water is wet in an a priori manner. For he cannot introspectively discriminate between the actual situation in which he is thinking that water is wet, and the relevant counterfactual situation where he is on twin earth thinking that tawter is wet. This kind of reasoning relies on the idea that having relevant discrimination abilities is a necessary condition for knowledge: 

**Discrimination Constraint on Knowledge (DCK)** : S knows that _p_ only if she can discriminate between the actual situation and all relevant counterfactual situations in which _p_ is not true.<sup>11</sup> 

Or consider the McKinsey-style argument according to which the joint assumption of content externalism and PA would result in the unacceptable consequence 

> 11 For the slow switching argument, see, e.g., Boghossian (1989) and Brown (2004). For criticism, see, e.g., Falvey and Owens (1994), McLaughlin and Tye (1998b), Vahid (2003b), Goldberg (2006) and Morvarid (2015), just to mention a few.

<!-- page: pdf=0006 printed=2338 -->

that a subject can acquire a priori knowledge about some substantive facts in her environment.<sup>12</sup> 

There is a vast literature on whether these arguments succeed, which I shall not go through here. In the present and the next sections, I simply assume for the sake of argument that content externalism _does_ undermine PA. My goal in these two sections is rather to investigate the following question: assuming that content externalism undermines PA, could it also thereby threaten justification internalism as formulated by JFA? As already remarked, some philosophers opt for a positive answer. Here is BonJour: 

The adoption of an externalist account of mental content would seem to support an externalist account of justification in the following way: if part or all of the content of a belief is inaccessible to the believer, then both the justifying status of other beliefs in relation to that content and the status of that content as justifying further beliefs will be similarly inaccessible, thus contradicting the internalist requirements for justification. (BonJour (1992, p. 136) and (2010, p. 368)) 

And Brown argues in a similar vein: 

If slow switches undermine IKC [i.e., PA in my notation] and ordinary humans frequently undergo such switches, then ordinary humans lack introspective knowledge of at least some of their thought contents. On this worse case scenario, semantic externalism undermines epistemic internalism. If one can know some of one’s thought contents only by inference from observation of one’s behavior or environment, then one lacks special access to one’s thoughts in either of the ways epistemic internalists understand that notion (as direct knowledge or reflective knowledge). If one lacks special access to at least some of one’s thought contents, one lacks special access to some of the factors which determine whether some of one’s beliefs are justified and SA is false. (Brown (2007, pp. 20–21)). 

Let us develop these remarks into a more tractable argument for the incompatibility of content externalism and JFA, which may be called ‘the privileged access argument’.<sup>13</sup> Suppose that a subject, Oscar, has been unknowingly and slowly switched back and forth between earth and twin earth (this supposition is required only when the incompatibility between content externalism and PA is to be substantiated by the slow switching argument. Otherwise, we no longer need to depict a switching scenario). Suppose, further, that he is now on earth seeing a glass of water in normal 

> 12 For different versions of McKinsey-style arguments, see, e.g., McKinsey (1991), Brown (1995) and Boghossian (1997). For criticism, see, e.g., Brueckner (1992), McLaughlin and Tye (1998a, b), Wright (2000), Goldberg (2003), Brown (2004) and Pryor (2007). 

> 13 The name is due to Vahid (2003a), who proposes an essentially similar argument, though his framing of the argument differs considerably from mine (see Vahid 2003a, pp. 102–104). Notice, moreover, that although Brown’s above-quoted passage concerns SA, her argument can be easily applied in the case of JFA as well. In particular, her talk of ‘the factors which determine whether some of one’s beliefs are justified’ indicates that her line of reasoning is applicable, even more suitably, to JFA.

<!-- page: pdf=0007 printed=2339 -->

conditions, and naturally comes to believe that there is some water in the glass (let us call this proposition _p_ ). From his belief that _p_ , then, Oscar competently infers _p_ or _q_ , for an arbitrary proposition _q_ . It seems intuitive that Oscar’s belief that _p_ as well as his belief that _p_ or _q_ are both justified. He has acquired his belief that _p_ on the basis of a clear perceptual experience, where no undermining evidence is available. As for his belief that _p_ or _q_ , it is attained by way of exercising a robust logical skill, under the forceful intellectual appearance that, let us suppose, _p_ logically entails _p_ or _q_ .<sup>14</sup> Now, the argument can be presented as a _reductio ad absurdum_ . Suppose, for the sake of reductio, that both content externalism and JFA are true. Then we have: 

(P1) Oscar is justified in believing that _p_ or _q_ . 

(P2) Oscar is not in a position to know, by reflection alone, that he believes that _p_ . 

(P3) If Oscar is not in a position to reflectively know that he believes that _p_ then he would not be justified in believing that _p_ or _q_ . 

(P4) Oscar is not justified in believing that _p_ or _q_ (from P2 and P3). 

But P4 contradicts P1, which means that the reductio assumption must be false, that is: 

(P5) Content externalism is incompatible with JFA. 

Some of the above steps need further clarification. P2 follows from our assumption that content externalism is incompatible with PA. P3 is seemingly a direct implication of JFA: given the setup of the scenario, the following condition is the only J-factor for Oscar’s belief that _p_ or _q_ : 

(J):  (j1) Oscar justifiably believes that _p_ , and  (j2) his belief that _p_ logically entails his other belief that _p_ or _q_ . 

But according to JFA, if Oscar is not in a position to acquire introspective knowledge that  j1 holds, which means that J is not introspectively accessible either, then he will not be justified in believing that _p_ or _q_ .<sup>15</sup> 

14 Notice that the discrimination constraint on knowledge, DCK, cannot prevent these two beliefs from _not_ being justified, as DCK is merely a constraint on knowledge, and on justification. 

15 One may complain that the privileged access argument is problematic as it is not clear which notion of justification appears in P1 and other premises. If it is an internalist notion, then content externalism cannot be freely presupposed by P2. For, it is the very (alleged) conclusion of the argument that justification internalism is incompatible with content externalism. On the other hand, if the relevant premises are to use an externalist notion of justification then P3 would be clearly unwarranted. It seems, however, that an advocate of the privileged access argument will not be moved by this objection, as she can plausibly assume that there is an intuitive single notion of justification which is the subject matter of many epistemological disputes (otherwise these disputes would turn out to be verbal), and it is that very notion which appears in all the relevant premises of the privileged access argument. The argument is intended, therefore, to show that given content externalism, that notion is not conditioned by the reflective accessibility constraint. In fact, the argument can be viewed as somehow analogous to a typical line of reasoning against justification internalism, according to which justification internalism, due to its alleged accessibility constraint, would imply that some intuitively justified beliefs are unjustified. Likewise, here Oscar’s belief that _p_ or _q_ is intuitively justified. But, justification internalism entails, when conjoined with content externalism, that such a belief cannot be justified under the same intuitive notion of justification. I thank an anonymous referee of this journal for pressing me on this issue.

<!-- page: pdf=0008 printed=2340 -->

The above argument is concerned with a belief that enjoys inferential justification, where (a part of) its J-factor is another justified belief with externally determined content. Naturally, a parallel line of argument can be applied to any case of (intuitively) justified belief where a part of its J-factor is a mental state with wide content, regardless of whether that mental state is another belief, a perceptual appearance, a memory state, or an intuition. For example, concerning Oscar’s belief that there is some water in the glass ( _p_ ) in the aforementioned scenario, the reductio argument against the conjoined assumption of content externalism and JFA runs as follows: 

(Q1) Oscar is justified in believing that _p_ . 

(Q2) Oscar is not in a position to know, by reflection alone, that it perceptually appears to him that _p_ . 

(Q3) If Oscar is not in a position to reflectively know that it perceptually appears to him that _p_ then he would not be justified in believing that _p_ . 

(Q4) Oscar is not justified in believing that _p_ (from Q2 and Q3). 

But Q4 contradicts Q1 and thus the reductio assumption must be false, that is: 

(Q5) Content externalism is incompatible with JFA. 

Steps Q1–Q5 are completely parallel to P1–P5. As to Q2 in particular, whatever argument is proposed for the claim that content externalism undermines our privileged access to the content of our thoughts can be naturally extended to the content of our experiences. 

To summarize, the core idea of the argument is that the conjoined assumptions of JFA and content externalism would result in an awkward consequence that a switching subject cannot be justified in any of her (first-order non-trivial) water-beliefs. This is the case if the incompatibility of content externalism and PA is to be substantiated by the slow switching argument. Alternatively, if the incompatibility (between content externalism and PA) is supported by a version of the McKinsey argument, then the conjunction of JFA and content externalism would have a much more dramatic result: no one can be justified in holding any (first-order non-trivial) belief with wide content. 

In the next section, however, I argue that the privileged access argument, as it stands, does not succeed, even if content externalism is assumed to undermine PA. 

## **3  The privileged access argument criticized** 

An obvious problem with the privileged access argument is that its basic assumption, namely the incompatibility of content externalism and PA, is highly controversial, and in fact has been rejected by many content externalists. Even if we ignore this problem and simply grant that content externalism _does_ undermine PA, the privileged access argument as it stands suffers from another defect, which I explain in what follows. 

To begin with, notice that sometimes a subject acquires two justificatory sources for a given belief. As pointed out, in such cases JFA _only_ requires that for the subject

<!-- page: pdf=0009 printed=2341 -->

to be justified in holding the belief she ought to be in a position to acquire special access to at least one of the J-factors. It seems that we are confronted with a similar situation in the privileged access argument. According to the argument, Oscar is justified in believing that _p_ or _q_ , while given the assumption that content externalism is incompatible with PA, he is not in a position to acquire a priori knowledge that condition J obtains. Given JFA, therefore, J cannot render Oscar’s belief that _p_ or _q_ justified (even though on our terminology, J _is_ still a J-factor for Oscar’s target belief, as it would confer justification to that belief were Oscar in a position to acquire reflective knowledge that it holds). I grant all this. The gist of my criticism, however, is roughly that there _is_ a second J-factor for Oscar’s belief that _p_ or _q_ , to which he _might_ be in a position to acquire a priori access. Consequently, Oscar’s target belief might still be justified, even if we suppose that both content externalism and JFA are true. In short, to substantiate P3 it must be shown that Oscar cannot have a priori access to that second J-factor either, which is not an easy task at all (similar remarks are applicable in the case of argument Q1–Q5 as well). 

To explain the idea, let us first suppose that both content externalism and JFA are true. Notice, then, that given psychological realism, when Oscar occurently believes that _p_ and that _p_ or _q_ , there are two particular belief tokens present in his mind. Let us call these tokens _b_ 1 and _b_ 2 respectively. Now, consider the following conjunctive condition: 

(H):  (h1) _b_ 1 is a belief in Oscar’s mind,  (h2) _b_ 1 is justified,  (h3) _b_ 2 is a belief in Oscar’s mind, and  (h4) _b_ 1’s content logically entails _b_ 2’s content. 

It seems that H, just like J, is a J-factor for Oscar’s belief that _p_ or _q_ (or alternatively, for belief token _b_ 2): H is sufficient, when conjoined with its being reflectively accessible, to render Oscar’s target belief justified. To see this more clearly, notice that the J-factors for a given justified belief can be typically read off from the relevant epistemic principles which govern the justificatory status of that belief. Now, the following seems to be a plausible epistemic principle: 

Necessarily, if H obtains and Oscar is in a position to know, by reflection alone, that H obtains, then Oscar’s belief _b_ 2 would be justified. 

This principle highlights the intuitive idea that for _b_ 2 to be a justified belief, it is sufficient that Oscar be in a position to acquire a priori knowledge that he possesses a belief whose content (whatever it is) logically entails _b_ 2’s content, even if he could not know the content of these beliefs in an a priori manner. This reinforces the idea that H is a J-factor for Oscar’s belief _b_ 2. 

Now the crucial question is whether Oscar is in a position to reflectively know that H obtains. To begin with, consider the first part of H:  (h1) _b_ 1 is a belief in Oscar’s mind. To explore whether Oscar can acquire reflective knowledge that  h1 obtains, we should examine two more specific questions. First, does Oscar, in the first place, possess requisite resources to come to believe that  h1 obtains? Second, given the positive answer to the first question, does such a belief constitute an instance of a priori knowledge, being immune from threats that content externalism may pose to the first-person authority?

<!-- page: pdf=0010 printed=2342 -->

Regarding the first question, it seems plausible to claim that whenever a subject has a conscious mental state token, she is typically in a position to introspectively demonstrate that mental state token, and thereby come to produce singular beliefs about it.<sup>16</sup> Accordingly, in our scenario, Oscar can introspectively refer to _b_ 1 and thereby make various reflective second-order judgments of the following forms (we can safely suppose that _b_ 1 is a conscious state to which he pays full attention): (1) ‘I have _that_ particular mental state’; (2) ‘ _that_ particular mental state is a propositional attitude’; (3) ‘ _that_ particular mental state is an instance of belief present in my mind’; (4) ‘ _that_ particular mental state is an instance of belief with the content _there is some water in the glass_ ’, and the like. All these beliefs are singular with respect to _b_ 1. So Oscar is in a position to introspectively believe that  h1 obtains—it is the third judgment just mentioned above. Moreover, all these second-order beliefs enjoy substantial introspective justification, just like any other belief based upon introspection under normal conditions. 

The second question, as already noted, is whether Oscar’s belief that  h1 obtains (i.e., that _b_ 1 is a belief in Oscar’s mind) constitutes an instance of a priori knowledge, provided that content externalism, as we have assumed, undermines PA. Clearly enough, the standard arguments proposed for the incompatibility of content externalism and PA are typically concerned only with those first-person secondorder judgments which ascribe (wide) content to the subject, such as judgment (4) mentioned above. In other words, these arguments, _as typically articulated_ , can only show (if successful at all) that the subject cannot acquire a priori knowledge about _the content_ of her thoughts. Other kinds of second-order beliefs in which no specific content is ascribed to the subject, including Oscar’s belief that  h1 obtains, would fall outside the scope of these arguments.<sup>17</sup> 

This is particularly clear in the case of the McKinsey argument. According to this line of argumentation, the joint assumptions of content externalism and PA lead to the implausible consequence that one can have a priori knowledge of some important facts about one’s environment. It is clear, however, that such a consequence would follow only if we grant to the subject a priori knowledge of his though _contents_ . The mere supposition that Oscar can know a priori that _b_ 1 is a belief in his mind does not entail, in combination with content externalism, the unacceptable consequence that he can attain a priori knowledge of some substantial facts about 

> 16 Although the idea of introspective demonstration has been usually employed in the case of phenomenal states, as in, e.g., Gertler (2001) and Perry (2001), it can be naturally extended, as Hofmann (2009) indicates, to the case of occurent intentional states as well. 

> 17 A clarification might be helpful here. When I say that Oscar’s second-order belief that _b1_ is a belief in his mind does not ascribe any specific content to the subject, I do not mean that _b1_ lacks any specific content. Of course, _b1 does_ have a specific content, namely: _there is some water in the glass_ ( _p_ ). Nor do I claim that Oscar’s ability to reflectively demonstrate _b1_ is not by mediation of its content. Arguably, our reflective access to our occurent intentional states _is_ normally through their contents. My claim, rather, is that when we look at the content of the envisaged second-order belief, namely: _b1 is a belief in Oscar’s mind_ , we see no content ascribed to _b1_ . In other words, the content of _b1_ (namely: _there is some water in the glass_ ) does not appear in the content of this second-order belief. The same is true of Oscar’s other second-order beliefs to the effect that other parts of H obtain. I thank an anonymous referee for pressing me to clarify this.

<!-- page: pdf=0011 printed=2343 -->

his surroundings. Thus, the McKinsey-style argument cannot pose any threat to the claim that Oscar can acquire a priori knowledge that _b_ 1 is a belief in his mind. 

The issue is more complicated with respect to the slow switching argument. Although the _letter_ of the standard slow switching argument does not affect secondorder beliefs ascribing no specific content to the subject, it _might_ be the case that a comparable line of argument could be constructed to show that content externalism would also prevent these second-order beliefs, including Oscar’s belief that  h1 obtains, from being instances of a priori knowledge. As you will remember, this argument is based on the following principle: 

**(DCK)** : S knows that _p_ only if she can discriminate between the actual situation and all relevant counterfactual situations in which _p_ is not true. 

It seems that given DCK and _content essentialism_ (namely, the view that mental states have their contents essentially), content externalism would not only undermine Oscar’s a priori knowledge of his thought contents, but also his ability to acquire a priori knowledge that _b_ 1 is a belief in his mind. According to our scenario, which we have supposed to be actually the case, Oscar has been unwittingly switched back and forth between earth and twin earth, and he is now on earth and believes that there is some water in the glass. Further, while he introspectively demonstrates that belief, he comes to acquire a second-order belief to the effect that _that_ mental state ( _b_ 1) is a belief in his mind. Now, consider a relevant counterfactual situation, W, which is exactly the same as the actual world, except for the fact that in W, Oscar is now on twin earth and believes that there is some twater in the glass. Being intrinsically the same as the actual world, Oscar introspectively refers, in W, to that particular belief token which he would express by saying “there is some water in the glass” (call it _b_ 1 _*_ ), and comes to believe that _b_ 1 _*_ is a belief in his mind. According to content externalism, _b_ 1 and _b_ 1 _*_ have different contents, namely: _that there is some water in the glass_ , and _that there is some twater in the glass_ , respectively. 

Now, provided that discrimination ability is a constraint on knowledge (as stated by DCK), the epistemic status of Oscar’s actual second-order belief that _b_ 1 is a belief in his mind turns on whether beliefs have their contents essentially or not. Given content essentialism, since none of Oscar’s belief tokens in W has the content _there is some water in the glass_ , none of them could be identical with _b_ 1, and consequently his target belief (to the effect that _b_ 1 is a belief in his mind) is no longer true with respect to W. Therefore, in the actual situation, he cannot know a priori that _b_ 1 is a belief in his mind, as he cannot reflectively discriminate between the actual situation and a relevant counterfactual situation, namely W, where it is not the case that _b_ 1 is a belief in his mind. On the other hand, if we reject content essentialism then it is quite natural to take _b_ 1 to be identical with _b_ 1 _*_ . Thus, W is a counterfactual situation in which Oscar’s target belief (to the effect that _b_ 1 is a belief in his mind) remains true, and therefore is not a knowledge-undermining situation. 

The upshot is that only under the joint assumptions of DCK and content essentialism could content externalism undermine Oscar’s capability to know, in an a priori manner, that _b_ 1 is a belief in his mind. Notice, however, that these assumptions are both controversial. For example, some have argued that DCK is too strong to be

<!-- page: pdf=0012 printed=2344 -->

a plausible constraint on knowledge.<sup>18</sup> As to content essentialism, it has been also disputed on the ground that it is incompatible with the conjunction of content externalism and token physicalism.<sup>19</sup> It goes far beyond the scope of the present paper to go through these issues here. What I want to insist, rather, is that the question as to whether Oscar is in a position to acquire a priori knowledge that _b_ 1 is a belief in his mind does not have a simple yes/no answer, but hinges upon controversial issues in epistemology and philosophy of mind.<sup>20</sup> 

So far we have been concentrating on  h1, exploring whether its obtaining can be reflectively known by Oscar. What about other parts of H, i.e.,  h2,  h3 and  h4? All previous remarks also apply to the case of  h3 (that is: _b_ 2 is a belief in Oscar’s mind), which I won’t repeat. Is Oscar in a position to know a priori that  h2 obtains, that is, that _b_ 1 is justified? It might be argued that Oscar, being an ordinary non-philosopher person, is not expected to be in a position to acquire a priori knowledge that _b_ 1 is justified. The internalist constraint on justification, therefore, amounts to a kind of unwelcome ‘hyper-intellectualization’.<sup>21</sup> But notice that whatever the merits of this challenge against justification internalism might be, it is not a difficulty posed by content externalism. Regardless of whether content externalism is true or not, justification internalists have to provide a plausible answer to the hyper-intellectualization objection. Since our objective is just to explore the possible bearings of content externalism on justification internalism, we can bypass this kind of worry and simply assume, for the sake of our purpose, that Oscar _is_ in a position to have a priori knowledge that _b_ 1 is justified. 

Let us finally turn to the question as to whether Oscar can acquire a priori knowledge that  h4 obtains, that is that _b_ 1’s content logically entails _b_ 2’s content. For the sake of discussion, let us take it for granted that Oscar _is_ in a position to know, by reflection alone, that other parts of H, namely  h2,  h3, and  h4, obtain. Admittedly, Oscar’s failure to know the contents of _b_ 1 and _b_ 2 in an a priori manner does not preclude, by itself, his ability to acquire reflective knowledge about the logical relations between these contents. It is very natural to assume that Oscar can know, by reflection alone, that his belief _b_ 2 has a disjunctive content. No argument has so far been proposed to the effect that content externalism might undermine our a priori 

> 18 See, e.g., Burge (1988), Goldberg (2006) and Morvarid (2015). But also see Vahid (2003b) and Brown (2004). 

> 19 See, e.g., Gibbons (1993) and Frances (2007). But also see Burge (1986, 1993). 

> 20 Because of space limitations, I do not consider here the so-called ‘illusion version’ of content externalism, according to which in no-reference cases, such as cases where an empty natural kind term is involved, the subject suffers from an illusion of entertaining a thought (see, e.g., Evans 1982; McDowell 1977, 1986). It seems that unlike other versions of content externalism, there is a good argument [namely, ‘the illusion argument’ as it is called by Brown (2004)] for the incompatibility of the illusion view with PA (see Brown 2004; Morvarid 2013). Moreover, and directly relevant to our present concern, I think that the illusion argument can be reconstructed to show that given the illusion view, in some switching scenarios Oscar is not in a position to acquire a priori knowledge that _b_ 1 is a belief in his mind, even if both DCK and content essentialism are rejected. I hope elsewhere to explore the bearings of the illusion view on the externalism/internalism debate in epistemology. 

21 For different versions of the hyper-intellectualization objection, see, e.g., Goldman (1999) and Burge (2003).

<!-- page: pdf=0013 printed=2345 -->

access to the logical form of our thought contents. Now, if Oscar is also in a position to know that _b_ 1’s content is the same as one of the two constituents of _b_ 2’s content, then he could come to know that the former content logically entails the latter, even if he fails to know what these two contents are. But this issue brings us directly to the question whether content externalism would undermine the transparency of the sameness of content (TSC), the topic to be explored in the next section. If, because of content externalism, Oscar is deprived of a priori knowledge about the sameness of his thought contents, then he would fail to know by reflection alone that _b_ 1’s content logically entails _b_ 2’s content, regardless of whether content externalism undermines PA or not. In other words, Oscar’s failure, if any, to know the logical relationships between _b_ 1 and _b_ 2 does not stem from content externalism being incompatible with PA, but from its incompatibility with TSC.<sup>22</sup> 

To sum up, the privileged access argument does not get off the ground unless it can be shown that given content externalism, H is not reflectively accessible for Oscar. But, even if content externalism is assumed to undermine PA, it cannot threaten reflective knowability of H unless one of the two following conditions holds: either (1) both DCK and content essentialism are true, or (2) content externalism turns out to undermine TSC. Nevertheless, whether the first condition obtains, as pointed out, is highly controversial. As to the second condition, notice that although it might be the case that content externalism undermines TSC, this would constitute a different line of reasoning for the incompatibility of content externalism and justification internalism, regardless of whether content externalism is compatible with PA. We will explore the prospects for such a line of reasoning in the following section. 

## **4  The transparency argument** 

So far, we have examined the prospects of a line of reasoning for the incompatibility of content externalism and justification internalism, which draws upon the assumption that content externalism tends to undermines PA. Although I have not called 

> 22 Oscar’s example is a case in which one of his beliefs follows from another one in virtue of their logical forms. As an anonymous referee has pointed out, there are also cases where the inferential relationship between two beliefs is not due to their logical form, as when Oscar infers from his belief that water is liquid in the normal temperature the belief that water is not solid in the normal temperature. Let us call these two beliefs _d1_ and _d2_ , respectively. Here, again, we can plausibly assume that if the subject is in a position to know the sameness of his thought constituents in an a priori manner then he will have a priori access to the fact that the content of _d1_ entails that of _d2_ , even if he is not in a position to reflectively know, because of the incompatibility of content externalism with PA, what these contents are. For, given that Oscar has grasped, even only partially, the concepts _liquid_ and _solid_ , he is in a position to reflectively know that a thought of the form ‘x is not solid’ can be validly inferred form a thought of the form ‘x is liquid’. Thus, if he can know a priori that the two tokenings of the concept _water_ in _d1_ and _d2_ has the same content, then he would be in a position to acquire a priori knowledge that the content of _d1_ entails that of _d2_ . Therefore, again, his a priori access to the inferential relationship between _d1_ and _d2_ hinges upon the transparency of the sameness of content (TSC). I thank an anonymous referee for raising this issue.

<!-- page: pdf=0014 printed=2346 -->

this assumption into question, many philosophers (and in fact most content externalists) are inclined to reject it. Nevertheless, it is uncontroversial that at least some versions of content externalism _are_ incompatible with the transparency of sameness of contents: 

(TSC): If a subject at time _t_ entertains two thoughts, or thought constituents, with the same content then, at _t_ , she can know that they have the same content by reflection alone. 

Thus it is tempting to explore possible bearings that the failure of TSC might have upon justification internalism. To begin with, consider the so-called ‘non-Fregean externalism’ according to which the contents of our thought constituents are solely individuated by their referents, while no content-individuating role is given to ‘modes of presentation’ or ‘Fregean senses’. It is obvious how such a version of content externalism is at odds with TSC. Take, for example, a subject who is unaware that Samuel Clemens is identical with Mark Twain, and has two thoughts which she would express by saying ‘Samuel Clemens is a nice person’ and ‘Mark Twain is a nice person’. On non-Fregean externalism, these two thoughts have the same content, though the subject cannot know their sameness without empirical investigation.<sup>23</sup> 

Now, Brown (2007) argues that through its undermining TSC, non-Fregean externalism also tends to challenge justification internalism as formulated by AI. Drawing upon an example from Falvey and Owens (1994), she consider a subject, Rudolph, who partially understands the terms ‘coriander’ and ‘cilantro’, yet is ignorant that they name the same herb. Given non-Fregean externalism, therefore, these two terms express the same concept, but Rudolph is not in a position to know this in an a priori manner. Brown’s argument, then, runs as follows (brackets are mine; the letters therein indicate the relevant beliefs): 

Suppose that Rudolph has the belief he would express by saying ‘Coriander was known to the ancient Romans’  [R1]. Further, suppose that Rudolph also has the beliefs he would express by saying ‘Cilantro was brought to Europe after Columbus’s expedition to the Americas’  [R2] and ‘Columbus’s expedition occurred after the fall of ancient Rome’ [RConsider, for example, a victim of slow]. On the semantic externalist account under consideration, Rudolph expresses the same concept by his use of ‘cilantro’ and ‘coriander.’ So, Rudolph’s further beliefs undermine his first belief. However, given that Rudolph needs to use empirical information to know that he expresses the 

> 23 See, e.g., Owens (1989), Boghossian (1992), Boghossian (1994), Falvey and Owens (1994), Brown (2004, 2007) and Gerken (2013). As Brown (2004), pp. 165–166) points out, the ‘Mark Twain’–‘Samuel Clemens’ example and the like cannot show that ‘Fregean externalism’ is incompatible with TSC. For, whenever the subject is unaware that ‘Mark Twain’ and ‘Samuel Clemens’ are co-referential, she can take different doxastic attitudes toward sentences containing these terms, which means, given Fregean externalism, that she would express different senses by those sentences. Thus, the thought contents she expresses by saying ‘Samuel Clemens is a nice person’ and ‘Mark Twain is a nice person’ will have _different_ contents.

<!-- page: pdf=0015 printed=2347 -->

same concept by ‘cilantro’ and ‘coriander’, it seems that he cannot know by reflection that these further beliefs undermine his first belief. So, Rudolph’s inability to know introspectively that he expresses the same concept by ‘cilantro’ and ‘coriander’ undermines his ability to know by reflection the justificational status of the belief he expresses by ‘Coriander was known to the ancient Romans.’ (Brown 2007, p. 22) 

The idea can be explained in the following way. To make the case more vivid, let us suppose that Rudolf is highly justified in holding beliefs  R2 and  R3. Given this, Rudolf would also be justified in holding a belief which he would express by saying ‘Cilantro was not known to the ancient Romans’ (let us call this latter belief  R4). After all, Rudolf can derive  R4, through a valid inference from his two other justified beliefs  R2 and  R3 (when conjoined with some other evident truisms). Now, Brown’s reasoning, seemingly, is that according to Non-Fregean externalism, ‘cilantro’ and ‘coriander’ express the same concept, and thus  R1 and  R4 have logically contradictory contents. Accordingly, the argument proceeds, to the extent that  R4 gains positive justificatory status from  R2 and  R3, the justificatory status of  R1 will be reduced. But, since Rudolf is not in a position to know, by reflection alone, that ‘coriander’ and ‘cilantro’ express the same concept, he cannot know, in an a priori manner, that R1 and  R4 have logically contradictory contents, nor that such a justificatory diminution takes place. Thus, the justificatory status of Rudolf’s belief  R1 is not reflectively accessible for him, contrary to what AI requires. 

I think, however, that Brown’s argument suffers from an obvious defect: it relies on the presupposition that acquiring a justification for believing that _p_ will automatically reduce the justification one possesses for believing that not- _p_ . But this presupposition is precisely what Non-Fregean externalists are willing (and in fact, obliged) to deny. As an example, consider Lois Lane who is unaware that Superman is identical with Clark Kent, while holding two beliefs which she would express by saying ‘Superman is courageous’ and ‘Clark Kent is not courageous’. It is highly intuitive that she can be simultaneously justified in holding the both beliefs, even though according to Non-Fregean externalism, these two beliefs have contradictory contents.<sup>24</sup> We can put the point more generally: in so far as the subject is ignorant that the two beliefs she holds have contradictory contents, and her ignorance is merely a matter of factual ignorance and not a defect of rationality, the justification she has for one of her beliefs will not affect the justificatory status of the other one. The same is true of Rudolf’s case. Granted, his two beliefs  R2 and  R3 conjointly justify him in holding  R4, but this need not diminish the justificatory status of his other belief  R1, even though according to Non-Fregean externalism  R4 and  R1 have contradictory contents. It does not follow, therefore, that  R1 undergoes a justification diminution which is not reflectively accessible for Rudolf.<sup>25</sup> 

> 24 This mirrors, in fact, the view typically held by the advocates of non-Fregean externalism: a perfectly rational agent may hold contradictory beliefs, in so far as she is unaware that they are contradictory (see, e.g., Owens 1989; Campbell 1987; Brown 2004). 

> 25 Brown (2007, pp. 22–23) also proposes a related line of argument for a rather different claim that given the ‘two-concept’ construal of switching cases, content externalism undermines TSC, and thereby it would also tend to threaten justification internalism as formulated by AI. This line of reasoning, again,

<!-- page: pdf=0016 printed=2348 -->

So far, we have seen that Brown’s argument, to the effect that (the non-Fregean version of) content externalism may threaten justification internalism through its undermining of TSC, fails. It seems, however, that the main idea can be constructed into a much more successful argument, which is applicable to both Fregean and nonFregean externalism. First of all, notice that given some assumptions to be mentioned below, both the Fregean and non-Fregean versions of content externalism can undermine, as many have pointed out, so-called ‘transparency of difference of content’: 

**(TDC)** : if a subject at time _t_ entertains two thoughts, or thought constituents, _t_ with different contents then, at , she can know that they have different contents by reflection alone. 

Consider, for example, a victim of slow switching, Oscar, who has been unknowingly switched back and forth between earth and twin earth. According to ‘the two-concept’ construal of switching cases, after the switch Oscar preserves the preswitch concept while acquiring the post-switch one by interacting with the new environment. Thus, when recollecting a memory from earth, he employs the concept of water, while the thoughts caused and sustained by experiences of XYZ contain the concept of twater. Accordingly, Oscar may entertain, simultaneously, two thoughts (or two thought constituents) with different contents, while he is not in a position to know their difference without empirical information.<sup>26</sup> 

This much is pretty well known. What is typically unvoiced, and has a direct bearing upon our present concern, however, is that given the two-concept interpretation, content externalism would undermine not only TDC, but also TSC, regardless of whether content externalism is combined with the idea of Fregean senses. To see this, suppose that our switching subject, Oscar, is now on twin earth entertaining two thoughts, one of which involves the concept of water and the other that of twater. As we have seen, although the two thought constituents which he would express by the term ‘water’ have different contents, Oscar is not in a position to know, by reflection alone, that they have different contents. Now, exercising his introspective abilities, Oscar wants to figure out whether these two thought constituents have the same content or not. Given that Oscar is entirely ignorant that he has been a victim of switching, he would naturally come to believe, erroneously, that they have the same contents. After all, his situation is phenomenologically the same as when no switching takes place. He then makes several mistaken second-order judgments of a similar sort: in many cases he judges of two thought constituents that they have the same contents, although they don’t. Now, suppose that in one case Oscar considers two thought constituents with the same content, and consequently his judgment to the effect that they have the same content comes out true this time. Intuitively, 

> hinges upon a dubious presupposition that a logical entailment can transmit epistemic justification even if the subject is (rationally) doubtful whether that logical entailment holds. 

> 26 See, e.g., Boghossian (1992), Boghossian (1994), Falvey and Owens (1994), Goldberg (1999), Brown (2004, 2007) and Gerken (2013).

<!-- page: pdf=0017 printed=2349 -->

although Oscar’s second-order belief in this latter case is true, it cannot constitute an instance of knowledge. The reason is that Oscar tends to, and in fact did, produce various false second-order beliefs in a series of ‘relevant’ situations. 

Oscar’s epistemic status here is completely analogous to that of Henry in Goldman’s well-known fake barn scenario. When confronted with a real barn, Henry’s true belief that he perceives a barn does not constitute an instance of knowledge, as there are relevant situations in which he will produce false beliefs. Likewise, in our switching scenario, Oscar’s liability to produce various false second-order beliefs in relevant cases would prevent his true belief (to the effect that the two given thought constituents have the same content) from being an instance of knowledge. The fake barn scenario and other similar ones are usually invoked to motivate a reliability constraint on knowledge.<sup>27</sup> Applying this diagnosis to Oscar’s case, we can say that the belief-forming process responsible for producing Oscar’s introspective beliefs about the sameness of content is not reliable in the switching environment, and thus its products fail to qualify as knowledge.<sup>28</sup> 

We can conclude, therefore, that given the two-concept view, content externalism (whether Fregean or not) would undermine TSC.<sup>29</sup> Relying upon this contention, we can construct a much more satisfactory argument for the incompatibility of content externalism and justification internalism, which can be called ‘the transparency argument’. To do this, let us return to the switching scenario depicted in Sects. 2 and 3: our switching subject, Oscar, is now in one of his earth phases, looking at a glass of water in front of him, and comes to believe that there is some water in the glass ( _p_ ). Exercising his perfect logical ability, Oscar arrives at a further belief that _p_ or _q_ . As pointed out, it seems intuitive that these two beliefs (which I have called _b_ 1 and _b_ 2, respectively) are both justified. Oscar’s belief that _p_ is based upon a forceful perceptual appearance, while no undermining evidence is available for him. And his belief that _p_ or _q_ is acquired through a very simple and competent inference from his justified belief that _p_ , and thus should be treated as justified as well.<sup>30</sup> 

> 27 See, e.g., McGinn (1984), Goldman (1986) and Brown (2007). 

> 28 One might also appeal to DCK to show that Oscar’s true beliefs to the effect that his two ‘water’thoughts have the same content do not constitute instances of knowledge. Remember, nevertheless, that unlike the reliability constraint on knowledge, DCK has been usually rejected on the ground that it poses too strong a condition on knowledge. 

> 29 As far as I know, the only writers who have come close to, but failed to explicitly express, the idea that the two-concept view undermines not only TDC but also TSC are Goldberg (1999) and Brown (2007). It is noteworthy, however, that while my case concerns a subject, Oscar, who truly believes (but fails to know) that he possesses two thought constituents with the same content, Goldberg’s and Brown’s scenario describes a subject who is doubtful, in the first place, whether her two thought constituents have the same content or not. And precisely because of this aspect of their case, it fails to provide a counterexample to JFA or AI (see footnote 24). 

30 To be clear, I am not appealing here to general principles as to when perceptual appearances can bestow justification upon perceptual beliefs, and when justification can transmit through a logical inference. Rather, I am merely relying on my extensional intuitions to the effect that given the setup of the scenario, Oscar’s belief that _p_ as well as his belief that _p_ or _q_ are both justified. Thus, I need not take any specific position regarding, for example, how perceptual appearances should be individuated, whether a BIV can enjoy the same perceptual appearances with the same justificatory roles as ours, etc. I thank an anonymous referee for pressing me to clarify this.

<!-- page: pdf=0018 printed=2350 -->

Now, as we have seen, there are two J-factors for Oscar’s belief that _p_ or _q_ , and therefore JFA requires that Oscar should be in a position to have a priori access to at least one of them: 

(J):  (j1) Oscar justifiably believes that _p_ , and  (j2) his belief that _p_ logically entails his other belief that _p_ or _q_ . 

(H):  (h1) _b_ 1 is a belief in Oscar’s mind,  (h2) _b_ 1 is justified,  (h3) _b_ 2 is a belief in Oscar’s mind, and  (h4) _b_ 1’s content logically entails _b_ 2’s content. 

Nevertheless, as I have just explained, the two-concept version of content externalism implies that Oscar fails to know, in a priori manner, that the two tokenings of the water concept which appear in his two beliefs _b_ 1 and _b_ 2 have the same content. Accordingly, Oscar is not in a position to acquire reflective knowledge that his belief in _p_ logically entails his other belief in _p_ or _q_ , nor that _b_ 1’s content logically entails _b_ 2’s content. The upshot is that neither of the two J-factors for Oscar’s belief that _p_ or _q_ is reflectively accessible, contrary to what JFA requires. This way, we eventually arrive at the conclusion that given the two-concept view, content externalism can undermine justification internalism as formulated by JFA. A similar argument can easily be constructed for the incompatibility of content externalism and AI, although I shall not go through this. 

The transparency argument has considerable advantages over other lines of reasoning which seek to reach a rather similar conclusion by appealing to the main idea that content externalism may undermine some aspects of authoritative self-knowledge. In particular, contrary to the privileged access argument discussed in Sects. 2 and 3, it does not rely on the assumption that content externalism undermines PA, a view rejected by most advocates of content externalism. And, unlike Brown’s argument discussed in the present section, the transparency argument does not suppose that the justificatory status of a belief may be reduced by logical relations it bears to other beliefs, even if the subject is inculpably ignorant about those relations. Of course, the transparency argument rests on its own assumption, namely, the twoconcept construal of the switching scenario, but this assumption has been espoused by many philosophers.<sup>31</sup> Anyway, I am not in a position to argue for the two-concept view, but remain content with a conditional claim: if the two-concept interpretation of the switching scenarios is adopted then content externalism would undermine justification internalism. 

## **5  Conclusion** 

It has been proposed that content externalism may tend to threaten justification internalism thorough its undermining of some aspects of our (purported) privileged selfknowledge. I examined two lines of reasoning that follow this general trend. The 

> 31 See, e.g., Boghossian (1992), Falvey and Owens (1994), Ludlow (1995), Gibbons (1996), Burge (1998) and Goldberg (1999). But also see Tye (1998) and Heal (1998).

<!-- page: pdf=0019 printed=2351 -->

first line proposes that since content externalism is incompatible with PA, it may undermine justification internalism as well. I have argued that even if we grant the highly controversial assumption that content externalism undermines PA, the first line of reasoning would either collapse to the second line, or else must presuppose further controversial assumptions in epistemology and philosophy of mind. 

Appealing to the much more plausible assumption that at least some versions of content externalism are incompatible with TSC, the second line of reasoning endeavors to show that those versions may also undermine justification internalism. Although the arguments so far proposed which follow this line of reasoning fail, I still think that it has considerable promise. In particular, relying upon the reliability constraint on knowledge, I argued that the two-concept version of content externalism is incompatible with TSC and thereby will undermine justification internalism.<sup>32</sup> 

## **References** 

Alston, W. (1986). Internalism and externalism in epistemology. _Philosophical Topics, 14,_ 179–221. Audi, R. (2001). An internalist theory of normative grounds. _Philosophical Topics, 29,_ 19–46. Bergmann, M. (2006). _Justification without awareness_ . Oxford: Clarendon Press. Boghossian, P. (1989). Content and self-knowledge. _Philosophical Topics, 17,_ 5–26. Boghossian, P. (1992). Externalism and inference. _Philosophical Issues, 2,_ 11–28. 

Boghossian, P. (1994). The transparency of mental content. _Philosophical Perspectives, 8,_ 33–50. Boghossian, P. (1997). What the externalist can know a priori. _Proceedings of the Aristotelian Society, 97,_ 161–175. 

BonJour, L. (1985). _The structure of empirical knowledge_ . Cambridge, MA: Harvard University Press. BonJour, L. (1992/2010). Externalism/internalism. In J. Dancy & E. Sosa (Eds.), (1992). _A companion to epistemology_ (pp. 132–136). Oxford: Blackwell. (Reprinted in J. Dancy, E. Sosa & M. Steup (Eds.), (2010). _A companion to epistemology (Second Edition)_ (pp. 364–368). Oxford: Blackwell). 

BonJour, L. (2003). A version of internalist foundationalism. In L. BonJour & E. Susa (Eds.), _Epistemic justification_ (pp. 3–96). Malden, MA: Blackwell. Brown, J. (1995). The incompatibility of anti-individualism and privileged access. _Analysis, 55_ (3), 149–156. 

Brown, J. (2004). _Anti-individualism and knowledge_ . Cambridge, MA: MIT Press. 

Brown, J. (2007). Externalism in mind and epistemology. In S. Goldberg (Ed.), _Internalism and externalism in semantics and epistemology_ (pp. 13–34). Oxford: Oxford University Press. 

Brueckner, A. (1992). What an individualist knows a priori. _Analysis, 52,_ 111–118. Brueckner, A. (2002). The consistency of content-externalism and justification-internalism. _Australasian Journal of Philosophy, 80_ (4), 512–515. 

Burge, T. (1979). Individualism and the mental. _Midwest Studies in Philosophy, 4,_ 73–121. Burge, T. (1986). Individualism and psychology. _Philosophical Review, 95,_ 3–45. Burge, T. (1988). Individualism and self-knowledge. _Journal of Philosophy, 85,_ 649–663. Burge, T. (1993). Mind–body causation and explanatory practice. In J. Heil & A. R. Mele (Eds.), _Mental causation_ (pp. 97–120). Oxford: Clarendon Press. 

Burge, T. (1998). Memory and self-knowledge. In P. Ludlow & N. Martin (Eds.), _Externalism and selfknowledge_ (pp. 351–370). Stanford: CSLI Publications. 

Burge, T. (2003). Perceptual entitlement. _Philosophy and Phenomenological Research, 67_ (3), 503–548. Campbell, J. (1987). Is Sense Transparent? _Proceedings of the Aristotelian Society_ , _61_ , 273–292. Chase, J. (2001). Is externalism about content consistent with internalism about justification? _Australian Journal of Philosophy, 79_ (2), 227–246. 

32 I would like to thank Hashem Morvarid, Seyed Mousavian, Amir Saemi, Sajed Tayebi, Hamid Vahid, Mohsen Zamani and an anonymous reviewer for helpful comments on earlier drafts of this paper.

<!-- page: pdf=0020 printed=2352 -->

Chisholm, R. (1977). _The theory of knowledge_ . Eaglewood Cliffs, NJ: Prentice Hall. 

Conee, E. (2007). Externally enhanced internalism. In S. Goldberg (Ed.), _Internalism and externalism in semantics and epistemology_ (pp. 51–67). Oxford: Oxford University Press. 

Conee, E. & Feldman, R. (2001). Internalism defended. (Reprinted in E. Conee & R. Feldman, _Evidentialism: Essays in epistemology_ (pp. 53–80)). New York: Oxford University Press. 

Conee, E., & R. Feldman (2004). _Evidentialism: Essays in Epistemology_ . New York: Oxford University Press. 

Evans, G. (1982). _The varieties of reference_ . Oxford: Oxford University Press. Falvey, K., & Owens, J. (1994). Externalism, self-knowledge, and scepticism. _Philosophical Review, 103,_ 107–137. 

Frances, B. (2007). Externalism, physicalism, statues, and hunks. _Philosophical Studies, 133,_ 199–232. Gerken, M. (2008). Is internalism about knowledge consistent with content externalism? _Philosophia, 36,_ 87–96. 

Gerken, M. (2013). _Epistemic reasoning and the mental_ . New York: Palgrave Macmillan. Gertler, B. (2001). Introspecting phenomenal states. _Philosophy and Phenomenological Research, 63,_ 305–328. Gibbons, J. (1993). Identity without supervenience. _Philosophical Studies, 70,_ 59–80. Gibbons, J. (1996). Externalism and knowledge of content. _Philosophical Review, 105,_ 287–310. Goldberg, S. (1999). The relevance of discriminatory knowledge of content. _Pacific Philosophical Quarterly, 80,_ 136–156. Goldberg, S. (2003). On our alleged a priori knowledge that water exists. _Analysis, 63_ (1), 38–41. Goldberg, S. (2006). Brown on self-knowledge and discriminability. _Pacific Philosophical Quarterly, 87,_ 301–314. Goldberg, S. (Ed.). (2015). _Externalism, self-knowledge, and skepticism_ . Cambridge: Cambridge University Press. Goldman, A. (1986). _Epistemology and cognition_ . Cambridge, MA: Harvard University Press. Goldman, A. (1999). Internalism exposed. _The Journal of Philosophy, 96_ (6), 271–293. Heal, J. (1998). Externalism and memory. _Proceedings of the Aristotelian Society, 72,_ 95–110. Hofmann, F. (2009). Introspective self-knowledge of experience and evidence. _Erkenntnis, 71,_ 19–34. Ludlow, P. (1995). Social externalism, self-knowledge and memory. _Analysis, 55_ (3), 157–159. Ludlow, P., & Martin, N. (Eds.). (1998). _Externalism and self-knowledge_ . Stanford: CSLI Publications. Madison, B. (2009). On the compatibility of epistemic internalism and content externalism. _Acta Analytica, 24,_ 173–183. 

McDowell, J. (1977). On the sense and reference of a proper name. _Mind, 86,_ 159–185. McDowell, J. (1986). Singular thought and the extent of inner space. In J. McDowell & P. Pettit (Eds.), _Subject, thought, and context_ (pp. 137–168). Oxford: Oxford University Press. McGinn, C. (1984). The concept of knowledge. _Midwest Studies in Philosophy, 9_ (1), 529–554. McKinsey, M. (1991). Anti-individualism and privileged access. _Analysis, 51,_ 9–16. McLaughlin, B., & Tye, M. (1998a). Externalism, twin earth, and self-knowledge. In C. Wright, B. Smith, & C. Macdonald (Eds.), _Knowing our own minds_ (pp. 285–320). Oxford: Clarendon Press. McLaughlin, B., & Tye, M. (1998b). Is content-externalism compatible with the privileged access? _Philosophical Review, 107,_ 349–380. 

Morvarid, M. (2013). Reference failure, illusion of thought and self-knowledge. _Dialectica, 67_ (3), 303–323. 

Morvarid, M. (2015). The epistemological bases of the slow switching argument. _European Journal of Philosophy, 23,_ 17–38. 

Nuccetelli, S. (Ed.). (2003). _New essays on semantic externalism and self-knowledge_ . Cambridge, MA: MIT Press. 

Owens, J. (1989). Contradictory belief and cognitive access. In P. French, T. Uehling, & H. Wettstein (Eds.), _Midwest studies (14), contemporary perspectives in the philosophy of language II_ . Notre Dame: University of Notre Dame Press. 

Perry, J. (2001). _Knowledge, possibility, and consciousness_ . Cambridge, MA: MIT Press. Pritchard, D., & Kallestrup, J. (2004). An argument for the inconsistency of content externalism and epistemic internalism. _Philosophia, 31,_ 345–354. 

Pryor, J. (2001). Highlights of recent epistemology. _British Journal for the Philosophy of Science, 52,_ 95–124. 

Pryor, J. (2007). What’s wrong with McKinsey-style reasoning? In S. Goldberg (Ed.), _Internalism and externalism in semantics and epistemology_ (pp. 177–200). Oxford: Oxford University Press.

<!-- page: pdf=0021 printed=2353 -->

Putnam, H. (1975). The meaning of ‘meaning’. In K. Gunderson (Ed.), _Mind, language, and reality: Philosophical papers_ (Vol. 2, pp. 215–271). Cambridge: Cambridge University Press. 

- Sosa, E. (1999). Scepticism and the internal/external divide. In J. Greco & E. Sosa (Eds.), _The Blackwell guide to epistemology_ (pp. 145–157). Oxford: Blackwell. 

- Tillman, C. (2012). Reconciling justificatory internalism and content externalism. _Synthese, 187,_ 419–440. 

- Tye, M. (1998). Externalism and memory. _Proceedings of the Aristotelian Society, 72,_ 77–94. 

- Vahid, H. (2003a). Content externalism and the internalism/externalism debate in justification theory. _European Journal of Philosophy, 11_ (1), 89–107. 

- Vahid, H. (2003b). Externalism, slow-switching, and privileged self-knowledge. _Philosophy and Phenomenological Research, 66_ (2), 370–388. 

- Wedgwood, R. (2002). Internalism explained. _Philosophy and Phenomenological Research, 66,_ 349–369. 

- Williamson, T. (2007). On being justified in one’s head. In M. Timmons, J. Greco, & A. Mele (Eds.), _Rationality and the good_ (pp. 106–122). Oxford: Oxford University Press. 

- Wright, C. (2000). Cogency and question-begging: Some reflections on McKinsey’s paradox, and Putnam’s proof. _Philosophical Issues, 10,_ 140–163. 

- Wright, C., Smith, B., & Macdonald, C. (Eds.). (1998). _Knowing our own minds_ . Oxford: Clarendon Press. 

**Publisher’s Note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.
