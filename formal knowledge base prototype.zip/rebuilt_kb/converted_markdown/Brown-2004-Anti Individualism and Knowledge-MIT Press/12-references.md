---
title: "References"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 365
locator_end: 372
---

# References

<!-- page: pdf=0365 printed=none -->

## **References** 

Anderson, Anthony, and Owens, Joseph (eds.). 1990. _Propositional Attitudes: The Role of Content in Logic, Language and Mind_ . CSLI Press: Palo Alto. 

Armstrong, David. 1973. _Belief, Truth, and Knowledge_ . Cambridge University Press: London. 

Barber, Alex (ed.). 2003. _Epistemology of Language_ . Oxford University Press: Oxford. 

Beebee, Helen. 2001. “Transfer of Warrant, Begging the Question, and Semantic Externalism.” _Philosophical Quarterly_ 51: 356–374. 

Boghossian, Paul. 1989. “Content and Self-Knowledge.” _Philosophical Topics_ 17: 5–26. 

———. 1992. “Externalism and Inference.” _Philosophical Issues_ 2: 1–28. 

———. 1994. “The Opaqueness of Mental Content.” _Philosophical Perspectives_ 8: 33–50. 

———. 1997. “What the Externalist Can Know A Priori.” _Proceedings of the Aristotelian Society_ 97: 161–175. 

Boghossian, Paul, and Peacocke, Christopher (eds.). 2000. _New Essays on the A Priori._ Oxford University Press: Oxford. 

Brewer, Bill. 1999. _Perception and Reason_ . Oxford University Press: Oxford. 

———. 2000. “Externalism and A Priori Knowledge of Empirical Facts.” In Boghossian and Peacocke (2000), 415–432. 

Brown, Jessica. 1995. “The Incompatibility of Anti-Individualism and Privileged Access.” _Analysis_ 53: 149–156.

<!-- page: pdf=0366 printed=none -->

References 

———.  1998. “Recognitional Capacities and Natural Kind Terms.” _Mind_ 107: 275–303. 

———.  1999. “Boghossian and Privileged Access.” _Analysis_ 59: 52–58. 

———. 2000a. “Against Temporal Externalism.” _Analysis_ 60: 178–188. 

———.  2000b. “Critical Reasoning, Understanding, and Self-Knowledge.” _Philosophy and Phenomenological Research_ 61: 659–677. 

———. 2000c. “Reliabilism, Knowledge, and Mental Content.” _Proceedings of the Aristotelian Society_ 100: 115–135. 

———. 2001. “Anti-Individualism and Agnosticism.” _Analysis_ 61: 213–224. ———. 2003. “Externalism and the Fregean Tradition.” In Barber (2003). Brueckner, Anthony. 1992a. “Semantic Answers to Scepticism.” _Pacific Philosophical Quarterly_ 73: 200–219. 

———. 1992b. “What an Individualist Knows _A Priori._ ” _Analysis_ 52: 111– 118. 

———. 2002. “Anti-Individualism and Analyticity.” _Analysis_ 62: 87–91. Burge, Tyler. 1976. “Belief and Synonymy.” _Journal of Philosophy_ 75: 119–138. 

———. 1979. “Individualism and the Mental.” _Midwest Studies in Philosophy_ 4: 73–121. 

———. 1982. “Other Bodies.” In _Thought and Object: Essays on Intentionality,_ ed. A. Woodfield, 97–120. Oxford University Press: Oxford. 

———. 1986a. “Individualism and Psychology.” _Philosophical Review_ 95: 3–45. 

———. 1986b. “Intellectual Norms and the Foundations of Normativity.” _Journal of Philosophy_ 83: 697–720. 

———. 1988. “Individualism and Self-Knowledge.” _Journal of Philosophy_ 85: 649–663. 

———. 1993. “Content Preservation.” _Philosophical Review_ 102: 457–488. 

———. 1996. “Our Entitlement to Self-Knowledge.” _Proceedings of the Aristotelian Society_ 96: 91–116. 

———. 1998. “Memory and Self-Knowledge.” In Martin and Ludlow (1998), 351–371.

<!-- page: pdf=0367 printed=none -->

329 

Campbell, John. 1987. “Is Sense Transparent?” _Proceedings of the Aristotelian Society_ 61: 273–292. 

———. 1994. _Past, Space, and Self._ MIT Press: Cambridge, Mass. 

Carnap, Rudolf. 1946. _Meaning and Necessity._ University of Chicago Press: Chicago. 

Church, Alonzo. 1954. “Intensional Isomorphism and Identity of Belief.” _Philosophical Studies_ 5: 65–73. 

Churchland, Paul. 1970. “The Logical Character of Action Explanations.” _Philosophical Review_ 79: 214–236. 

Crimmins, Mark, and Perry, John. 1989. “The Prince and the Phonebooth.” _Journal of Philosophy_ 86: 685–711. 

Dancy, Jonathan. 1985. _Introduction to Contemporary Epistemology_ . Blackwell: Oxford. 

Davidson, Donald. 1969. “On Saying That.” In Davidson, _Essays on Truth and Interpretation_ , 93–108. Oxford University Press: Oxford. 

———. 1987. “Knowing One’s Own Mind.” _Proceedings of the American Philosophical Association_ , 441–458 _._ 

Davies, Martin. 1998. “Externalism, Architecturalism, and Epistemic Warrant.” In Wright, Smith, and Macdonald (1998), 321–361. 

———. 2000. “Externalism and A Priori Knowledge.” In Boghossian and Peacocke (2000), 384–432. 

Davies, Martin, and Humberstone, Lloyd. 1980. “Two Notions of Necessity.” _Philosophical Studies_ 38: 1–30. 

DeRose, Keith. 1995. “Solving the Sceptical Problem.” _Philosophical Review_ 104: 1–52. 

———. 2000. “How Do We Know We’re Not Brains in a Vat?” _Spindel Supplement to the Southern Journal of Philosophy_ 37: 121–138. 

DeRose, Keith and Warfield, Ted (eds.). 1999. _Scepticism._ Oxford University Press: Oxford. 

Devitt, Michael. 1980. _Designation_ . Columbia University Press: New York. 

Dretske, Fred. 1970. “Epistemic Operators.” _Journal of Philosophy_ 67: 1007–1023. Reprinted in his _Perception, Knowledge, and Belief_ , 30–47. Cambridge University Press: Cambridge.

<!-- page: pdf=0368 printed=none -->

———. 1981. _Knowledge and the Flow of Information_ . MIT Press: Cambridge, Mass. 

Dummett, Michael. 1973. _Frege._ Duckworth: London. 

Dupré, John. 1981. “Natural Kinds and Biological Taxa.” _Philosophical Review_ 90: 66–90. 

Evans, Gareth. 1982. _The Varieties of Reference._ Oxford University Press: Oxford. 

Falvey, Kevin. 2000. “The Compatibility of Anti-Individualism and Privileged Access.” _Analysis_ 60: 137–142. 

Falvey, Kevin, and Owens, Joseph. 1994. “Externalism, Self-Knowledge, and Scepticism.” _Philosophical Review_ 103: 107–137. 

Fodor, Jerry. 1987. _Psychosemantics_ . MIT Press: Cambridge, Mass. 

———. 1992. _A Theory of Content_ . MIT Press: Cambridge, Mass. 

Frances, Bryan. 1999. “Contradictory Belief and Epistemic Closure.” _Mind and Language_ 14: 203–226. 

Frege, Gottlob. 1892. “On Sense and Reference.” In _Philosophical Writings: Translations_ , eds. P. Geach and M. Black. Blackwell: Oxford. 

———. 1980. _Philosophical and Mathematical Correspondence_ , ed. by Gabriel et al., abridged for the English edition by McGuiness, and trans. by Kaal. Blackwell: Oxford. 

Gallois, Andre, and O’Leary-Hawthorne, John. 1996. “Externalism and Scepticism.” _Philosophical Studies_ 81: 1–26. 

Gibbons, John. 1996. “Externalism and Knowledge of Content.” _Philosophical Review_ 105: 287–310. 

Goldberg, Sandford. 1999. “The Relevance of Discriminatory Knowledge of Content.” _Pacific Philosophical Quarterly_ 80: 136–156. 

Goldman, Alvin. 1967. “A Causal Theory of Knowing.” _Journal of Philosophy_ 64: 355–372. 

———. 1976. “Discrimination and Perceptual Knowledge.” _Journal of Philosophy_ 73: 771–791. 

———. 1979. “What Is Justified Belief?” In _Justification and Knowledge_ , ed. George Pappas. Reidel: Dordrecht.

<!-- page: pdf=0369 printed=none -->

331 

———. 1986. _Epistemology and Cognition._ Harvard University Press: Cambridge, Mass. 

Heal, Jane. 1998. “Externalism and Memory.” _Proceedings of the Aristotelian Society_ 72: 95–110. 

Heil, John. 1988. “Privileged Access.” _Mind_ 386: 238–251. 

Jackson, Frank. 1987. _Conditionals_ . Blackwell: Oxford. 

Jackson, Frank, and Pettit, Philip. 1993. “Some Content Is Narrow.” In J. Heil and A. Mele, _Mental Causation_ , 259–282. Oxford University Press: Oxford. 

Kahneman, Daniel. 1982. _Judgement under Uncertainty_ . Cambridge University Press: Cambridge. 

Kaplan, David. 1989. “Demonstratives.” In _Themes from Kaplan_ , eds. J. Almog, J. Perry, and H. Wettstein. Oxford University Press: Oxford. 

Kimbrough, Scott. 1998. “Anti-Individualism and Fregeanism.” _Philosophical Quarterly_ 48: 470–482. 

Kripke, Saul. 1980. _Naming and Necessity_ . Blackwell: Oxford. 

———. 1979. “A Puzzle about Belief.” In Margalit, ed., _Meaning and Use_ , 239–283. Reidel: Dordrecht. 

Langton, Rae, and Lewis, David. 1998. “Defining ‘Intrinsic.’” _Philosophy and Phenomenological Research_ 58: 333–346. 

Lewis, David. 1996. “Elusive Knowledge.” _Australasian Journal of Philosophy_ 74: 549–567. 

Ludlow, Peter. 1995a. “Externalism, Self-Knowledge, and the Prevalence of Slow Switching.” _Analysis_ 55: 45–49. 

———. 1995b. “Social Externalism, Self-Knowledge, and Memory.” _Analysis_ 55: 157–159. 

———. 1996. “Externalism and Memory: A Problem.” _Acta Analytica_ 14. Reprinted in Ludlow and Martin (1998), 311–318. 

Ludlow, Peter, and Martin, Norah (eds.). 1998. _Externalism and SelfKnowledge_ . CSLI Publications: Stanford. 

Mates, Benson. 1952. “Synonymity.” In Linsky, ed., _Semantics and the Philosophy of Language_ , 111–138. University of Illinois Press: Urbana.

<!-- page: pdf=0370 printed=none -->

McDowell, John. 1977. “On the Sense and Reference of a Proper Name.” _Mind_ 86: 159–185. 

———. 1986. “Singular Thought and the Extent of Inner Space.” In _Subject, Thought, and Context,_ eds. J. McDowell and P. Pettit, 137–168. Oxford University Press: Oxford. 

McGinn, Colin. 1984. “The Concept of Knowledge.” _Midwest Studies in Philosophy_ 9. Page references from _Knowledge and Reality_ , C. McGinn, 7–35. Oxford University Press: Oxford. 

McKinsey, Michael. 1991. “Anti-Individualism and Privileged Access.” _Analysis_ 51: 9–16. 

———. 1997. “Accepting the Consequences of Anti-Individualism.” _Analysis_ 54: 124–128. 

McLaughlin, Brian. 2000. “Self-Knowledge, Externalism, and Scepticism.” _Proceedings of the Aristotelian Society_ 74: 93–117. 

———. 2003. “McKinsey’s Challenge, Warrant Transmission and Skepticism.” In S. Nuccetelli (ed.), _New Essays on Semantic Externalism and Self-Knowledge_ . MIT Press: Cambridge, Mass. 

McLaughlin, Brian, and Tye, Michael. 1998. “Content Externalism and Privileged Access.” _Philosophical Review_ 107: 349–380. 

Merricks, Trenton. 1995. “Warrant Entails Truth.” _Philosophy and Phenomenological Research_ 55: 841–855. 

Millikan, Ruth. 1993. _White Queen Psychology and Other Essays for Alice_ . MIT Press: Cambridge, Mass. 

Nozick, Robert. 1981. _Philosophical Explanations._ Oxford University Press: Oxford. 

Owens, Joseph. 1989. “Contradictory Belief and Cognitive Access.” In _Midwest Studies: vol. 14, Contemporary Perspectives in the Philosophy of Language II_ , eds. P. French, T. Uehling, and H. Wettstein. University of Notre Dame Press: Notre Dame. 

———. 1990. “Cognitive Access and Semantic Puzzles.” In Anderson and Owens (1990), 147–174. 

———. 1992. “Psychophysical Supervenience: Its Epistemological Foundation.” _Synthese_ 90: 89–117. 

Peacocke, Christopher. 1983. _Sense and Content._ Oxford University Press: Oxford.

<!-- page: pdf=0371 printed=none -->

———. 1996. “Entitlement, Self-Knowledge, and Conceptual Redeployment.” _Proceedings of the Aristotelian Society_ 96: 117–158. 

———. 1998. _Being Known_ . Oxford University Press: Oxford. 

Perry, John. 1979. “The Essential Indexical.” _Noûs_ 13: 3–21. 

Plantinga, Alvin. 1993. _Warrant: The Current Debate_ . Oxford University Press: Oxford. 

Platts, Mark. 1983. “Explanatory Kinds.” _British Journal for the Philosophy of Science_ 34: 133–148. 

Pritchard, Duncan. 2002. “McKinsey Paradoxes, Radical Scepticism, and Transmission of Knowledge across Known Entailments.” _Synthese_ 130: 279–302. 

Pryor, James. 2000. “The Sceptic and the Dogmatist.” _Noûs_ 34: 517–549. 

———. Forthcoming. “Is Moore’s Argument an Example of Transmission Failure?” 

Putnam, Hilary. 1975a. “The Meaning of ‘Meaning’.” In _Language, Mind, and Knowledge,_ vol. 2 of _Minnesota Studies in the Philosophy of Science,_ ed. K. Gunderson, University of Minnesota Press: Minneapolis. Reprinted in Putnam (1975d), 215–271. 

———. 1975b. “Explanation and Reference.” Reprinted in Putnam (1975d), 196–214. 

———. 1975c. “Is Semantics Possible?” Reprinted in Putnam (1975d), 139–152. 

———. 1975d. _Mind, Language, and Reality_ . Cambridge University Press: Cambridge. 

Salmon, Nathan. 1986. _Frege’s Puzzle._ MIT Press/Bradford Books: Cambridge, Mass. 

Sawyer, Sarah. 1998. “Privileged Access to the World.” _Australasian Journal of Philosophy_ 76: 523–533. 

———. 1999. “An Externalist Account of Introspective Knowledge.” _Pacific Philosophical Quarterly_ 80: 358–378. 

Segal, Gabriel. 2000. _A Slim Book about Narrow Content_ . MIT Press: Cambridge, Mass. 

———. 2003. “Ignorance of Meaning.” In Barber (2003).

<!-- page: pdf=0372 printed=none -->

Soames, Scott. 1987. “Direct Reference, Propositional Attitudes, and Semantic Content.” _Philosophical Topics_ 15: 47–87. 

Stoneham, Tom. 1999. “Boghossian on Empty Natural Kind Concepts.” _Proceedings of the Aristotelian Society_ 99: 119–122. 

Stroud, Barry. 1984. _The Significance of Philosophical Scepticism_ . Oxford University Press: New York. 

Tversky, Amos, and Kahneman, Daniel. 1983. “Extensional versus Intuitive Reasoning: The Conjunction Fallacy in Probability Judgement.” _Psychological Review_ 90: 293–315. 

Tye, Michael. 1998. “Externalism and Memory.” _Proceedings of the Aristotelian Society_ 72: 77–94. 

Warfield, Ted. 1994. “Knowing the World and Knowing Our Minds.” _Philosophy and Phenomenological Research_ 55: 525–545. 

———. 1997. “Externalism, Self-Knowledge, and the Irrelevance of Slow Switching.” _Analysis_ 57: 282–284. 

———. 1998. “A Priori Knowledge of the World: Knowing the World by Knowing Our Minds.” _Philosophical Studies_ 92: 127–147 _._ 

Wason, Peter, and Johnson-Laird, Philip. 1972. _The Psychology of Reasoning_ . Harvard University Press: Cambidge, Mass. 

Wright, Crispin. 2000. “Cogency and Question-Begging: Some Reflections on McKinsey’s Paradox, and Putnam’s Proof.” _Philosophical Issues_ 10: 140–163. 

———. 2002. “Anti-Sceptics Simple and Subtle: Moore and McDowell.” _Philosophy and Phenomenological Research_ 65: 330–348. 

———. 2003. “Some Reflections on the Acquisition of Warrant by Inference.” In Nuccetelli (2003), 57–78. 

Wright, Crispin, Smith, Barry C., and Macdonald, Cynthia. 1998. _Knowing Our Own Minds_ . Oxford University Press: Oxford. 

Zemach, Eddy. 1976. “Putnam’s Theory on the Reference of Substance Terms.” _Journal of Philosophy_ 73: 116–127.
