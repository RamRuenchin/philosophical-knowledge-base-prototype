---
title: "Front Matter and Contents"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 1
locator_end: 8
---

# Front Matter and Contents

<!-- page: pdf=0001 printed=none -->

Anti-Individualism and
Knowledge
This is a portion of the eBook at
doi:10.7551/mitpress/1294.001.0001
Downloaded from direct.​mit.​edu/​books/​monograph/​chapter-pdf/​2430930/​f010002_9780262269346.​pdf by Kings College London user on 08 Nove

<!-- page: pdf=0002 printed=none -->

**Contemporary Philosophical Monographs** Peter Ludlow, editor 

1. _A Slim Book about Narrow Content_ Gabriel M. A. Segal (2000) 

2. _Complex Demonstratives_ Jeffrey C. King (2001) 

3. _Words without Meaning_ Christopher Gauker (2003) 

4. _Anti-Individualism and Knowledge_ Jessica Brown (2004)

<!-- page: pdf=0003 printed=none -->

Anti-Individualism and
Knowledge
A Bradford Book
The MIT Press
Cambridge, Massachusetts
London, England
Jessica Brown
This is a portion of the eBook at
doi:10.7551/mitpress/1294.001.0001
Downloaded from direct.​mit.​edu/​books/​monograph/​chapter-pdf/​2430930/​f010002_9780262269346.​pdf by Kings College London user on 08 Nove

<!-- page: pdf=0004 printed=none -->

© 2004 Massachusetts Institute of Technology 

All rights reserved. No part of this book may be reproduced in any form by any electronic or mechanical means (including photocopying, recording, or information storage and retrieval) without permission in writing from the publisher. 

This book was set in Palatino by SNP Best-set Typesetter Ltd., Hong Kong, and was printed and bound in the United States of America. 

Library of Congress Cataloging-in-Publication Data 

Brown, Jessica. Anti-individualism and knowledge / Jessica Brown. p. cm.—(Contemporary philosophical monographs ; 4) “A Bradford book.” Includes bibliographical references (p. ) and index. ISBN 0-262-02558-2 (hc. : alk. paper)—ISBN 0-262-52421-X (pbk. : alk. paper) 1. Knowledge, Theory of. 2. Individualism. I. Title. II. Series. BD161.B765 2004 121¢.3—dc21 

2003054115 

10 9 8 7 6 5 4 3 2 1

<!-- page: pdf=0005 printed=none -->

## **Contents** 

Preface ix 

- **1 Anti-Individualism** 1 1 Content and the Environment 2 2 Natural Kind Anti-Individualism 9 3 Singular Anti-Individualism 13 4 Illusions of Thought 15 5 Social Anti-Individualism 17 6 Fregean and Non-Fregean Anti-Individualism 20 7 A Priori and Empirical 22 8 Outline of the Book 25 

**2 Knowledge and Discrimination** 33 

- 1 Privileged Access 33 2 The Discrimination Argument 37 3 Discrimination and Reliability 45 4 Knowledge and Reliability 59 5 Other Compatibilist Responses—Falvey and Owens, and McLaughlin and Tye 64 

- 6 Conclusion 71 

**3 Thought and Discriminative Abilities—Evans** 75 1 Introduction 75

<!-- page: pdf=0006 printed=none -->

Contents 

- 2 Evans’s Account of Singular Thought 77 

- 3 Evans and the Discrimination Argument 83 

- 4 Perceptual Demonstrative Thoughts 86 

- 5 Possible Compatibilist Responses 90 

- 6 Recognition-based Thoughts 96 

- 7 Comparison of Evans’s Account and the Modified Account 106 

- 8 Conclusion 110 

- **4 The Illusion Argument** 113 1 Introduction 113 

- 2 Relevance and Reliability 117 

- 3 Two Notions of Reliability 119 

- 4 Local or Global Reliability? 124 

- 5 The Illusion Argument Reconsidered 129 

- 6 Conclusion of the Illusion Argument 133 7 The Illusion and Discrimination Arguments 135 8 Social Anti-Individualism and Twin Situations 138 9 Natural Kind Anti-Individualism and Twin Situations 142 

- 10 Singular Anti-Individualism and Twin Situations 145 

- 11 No-Reference Situations 147 

- 12 The Relevance Strategy and Alternatives 152 

- 13 Conclusion of Chapters 2 through 4 155 

- **5 Anti-Individualism and Reasoning** 157 

- 1 Introduction 157 

- 2 Transparency of Sameness of Content 161 3 Transparency of Difference of Content 166 4 Slow Switch and Conceptual Change 170 5 Two Concepts and Inference 176

<!-- page: pdf=0007 printed=none -->

Contents 

vii 

- 6 Rationality and A Priority 182 

- 7 Conclusion 191 

- **6 Anti-Individualism and Fregean Sense** 193 

- 1 Introduction 193 

- 2 The Contrast between Fregean and Non-Fregean Anti-Individualism 197 

- 3 Fregean Anti-Individualism and Transparency of Sameness 204 

- 4 Fregean Anti-Individualism and Transparency of Difference 210 

- 5 Fregean Anti-Individualism 225 

### **7 The Reductio Argument: Transmission of** 

- **Warrant** 233 

- 1 Introduction 233 

- 2 Closure and Transmission 239 

- 3 Wright and Conditional Warrant 244 

- 4 Begging the Question 258 

- 5 Warrant and Ruling Out Alternatives 259 

- 6 Conclusion 269 

### **8 The Reductio Argument: Entailments between** 

- **Thought and the World** 271 

- 1 Introduction 271 

- 2 Natural Kind Anti-Individualism 274 

- 3 Singular Anti-Individualism 289 

- 4 Social Anti-Individualism 294 

- 5 Combined Views 300 6 Conclusion 301 

Appendix to Chapter 8: Comparison with Davies and Wright 303

<!-- page: pdf=0008 printed=none -->

9 Conclusion
309
Notes
313
References
327
Index
335
viii
Contents
This is a portion of the eBook at
doi:10.7551/mitpress/1294.001.0001
Downloaded from direct.​mit.​edu/​books/​monograph/​chapter-pdf/​2430930/​f010002_9780262269346.​pdf by Kings College London user on 08 Nove
