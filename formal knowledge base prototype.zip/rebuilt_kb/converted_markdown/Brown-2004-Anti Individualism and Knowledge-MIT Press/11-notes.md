---
title: "Notes"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 349
locator_end: 362
---

# Notes

<!-- page: pdf=0349 printed=none -->

## **Notes** 

### **Chapter 1** 

1. Functionalism can also be developed as an anti-individualist view. 

2. For simplicity, I am ignoring impure intrinsic properties that can be possessed independently of the existence of other objects and events but are not shared by duplicates (Langton and Lewis 1998). To deal with this issue, one could reformulate the definitions of individualism and antiindividualism, replacing the notion of an intrinsic property with the notion of a property shared between duplicates. 

3. That a subject’s thought contents are individuated partly by her environment does not strictly entail that her thought contents fail to supervene on her intrinsic properties. Jackson and Pettit (1993) argue that a property of an object, _x_ , that is individuated relationally might still supervene on microstructural properties of _x_ , e.g., the property of being water-soluble. 

4. These arguments and the resulting nondescriptive model of reference in language and thought can be found, inter alia, in Perry (1979), Kripke (1980), Evans (1982), Peacocke (1983), McDowell (1986), Salmon (1986), Soames (1987), and, Kaplan (1989). 

### **Chapter 2** 

1. Her thought contents may not change immediately after the switch, for, at that point, the dominant influence on her thoughts is plausibly still the Earth environment. Nevertheless, anti-individualists agree that, after a

<!-- page: pdf=0350 printed=none -->

suitable period of time, her new relationship with Twin Earth starts to affect her thought contents. 

2. This view may be supported by arguing that after the switch, the subject is related mainly to the Twin Earth environment (e.g., Burge 1988; Falvey and Owens 1994; Gibbons 1996; Tye 1998). On an alternative view, after the switch, she is related to both Earth and Twin Earth environments and so either has an “amalgam” concept that applies to both water and twater, or suffers an illusion of thought (see Heal 1998; Sawyer 1999). For further discussion, see chap. 5. 

3. For exceptions, see Warfield (1997) and Sawyer (1999). Sawyer suggests that one has a recognition-based thought about an object or kind only if there is no duplicate in the environment. I agree (see Brown 1998 and chaps. 3 and 4 here), but this point does not extend straightforwardly to show that duplicate thoughts are not relevant for other types of externally individuated thoughts, such as perceptual demonstrative or socially individuated thoughts. In addition, in some cases a twin thought is relevant, such as in a slow switch. Sawyer treats slow switch cases as akin to cases in which a subject mistakes a motley collection of natural kinds for a single natural kind. She argues that, after a switch, a subject would not have a twin thought, say, about twater, but rather a thought involving a descriptive concept that applies to both water and twater. But this does not answer the discrimination argument, since, as indicated, it can use any alternative situation in which the subject lacks the thought she has in the actual situation including one in which she instead has a descriptive concept. 

4. The self-verifying nature of cogito thoughts cannot be used to explain our knowledge of our past thoughts. A subject’s belief that she thinks that _p_ makes it the case that she now thinks that _p_ , but not that she thinks that _p_ at any other time. 

5. Compatibilists do not argue that a subject can have a priori knowledge of the contents of her past thoughts. Nevertheless, Sally’s mistake supports the claim that she cannot distinguish a priori between the two situations. 

6. Whether Sally can correctly report her thought contents depends on the correct account of thought content. Plausibly, after the switch, the meaning of ‘water’ on Sally’s lips is determined by the conventions of the Twin Earth community in which ‘water’ refers only to twater. But some anti-individualists hold that, after the switch, those of Sally’s thoughts that were based on Earth memories involve the concept water. Others argue that, after the switch, with ‘water’ Sally expresses a concept that applies to both water and twater.

<!-- page: pdf=0351 printed=none -->

7. Note that this view does not undermine my description of the challenge posed by the discrimination argument: how can a subject know a priori that she thinks that _p_ when there is a relevant alternative situation, in which she lacks the thought that _p_ , that she cannot a priori distinguish from the actual situation? Even if a subject retains her old concept after a slow switch, where _p_ is suitably chosen, she no longer thinks that _p_ after the switch. E.g., let _p_ be the thought _S_ expresses on Earth with ‘Water is wet’, namely, the thought that water is wet. The content _S_ expresses with ‘Water is wet’ does not only depend on memory but is caused and sustained by current interactions. Thus, after the switch to Twin Earth, even if _S_ retains the concept of water, she no longer expresses the thought that water is wet with ‘Water is wet’. Depending on the anti-individualist view under consideration, she would either have a twin thought, have an amalgam thought, or suffer an illusion of thought. 

8. Sally’s explication may provide evidence that, before and after the switch, she uses ‘water’ to express different concepts. E.g., her verbal reports may attribute different contents to her water and twater thoughts, and she might explain ‘water’ by saying it refers to a natural kind common to lakes and rivers around here. Neither of these points provides evidence that she notices any difference between water and twater thoughts. 

9. Here, and throughout this chapter, I concentrate on what Goldman calls a “local reliability” condition for knowledge. This seems appropriate given that compatibilists focus implicitly on this condition; they argue that, even if Sally were in a relevant alternative situation in which she lacks the thought she actually has, she would no longer self-attribute that thought. Goldman holds that knowledge also requires that the belief be produced by a “globally reliable” process, one that tends to produce a high ratio of true beliefs. This distinct reliability condition is relevant to the illusion argument, and I discuss it in chap. 4 (see sec. 3 especially). 

10. Burge similarly argues that we (in his view mistakenly) suppose that a subject can know that _p_ only if she can rule out various alternatives because, were one of those alternatives actual, she would be liable to error (1988, p. 659). But he provides no argument for his diagnosis and against the rival hypothesis that we make this supposition because we take it that knowledge that _p_ requires the ability to distinguish the actual state of affairs in which _p_ from relevant alternative states of affairs. 

11. McLaughlin and Tye do not aim to show that anti-individualism is compatible with such discriminative abilities, but this issue is crucial to the discrimination argument as I have set it up.

<!-- page: pdf=0352 printed=none -->

### **Chapter 3** 

1. A subject may locate the object egocentrically, rather than allocentrically. 

2. Here Evans stresses the idea that the subject would not be disposed to regard an object outside the area of search as the relevant object. Elsewhere, Evans says “any disposition he has to pick out something outside the area of search does not count, and he is disposed to identify just one thing within it” (1982, p. 280). I have concentrated on the first idea, as it seems to go better with Evans’s idea of the area of search as the area within which the subject estimates the object to be. On this definition of the area of search, it is not obvious that a disposition to consider an object outside the area of search would not count for the estimated area of search might be incorrect. See sec. 6. 

3. In chap. 4, I question whether such alternative situations are usually relevant. 

4. I am assuming that a subject may have the same perceptual demonstrative thought at different times. If this were not the case and Sally were to know this, then she would correctly judge that her two perceptual demonstrative thoughts have different contents even if she mistakenly thinks that they concern the same object. However, perceptual demonstrative thoughts are plausibly connected with perceptual tracking of objects over (short) periods of time so that one can have the same perceptual demonstrative thought at different times; this is so even on a Fregean view (Campbell 1987). 

5. Sally’s inability to pass this test cannot be explained away by saying that there is a period in which it is indeterminate what thought she is thinking. Sometimes indeterminacy may make judgments of change more difficult. E.g., as someone loses weight, there may be a period in which it is indeterminate whether she has become thin, although at a later stage she is determinately thin. However, unlike this thinness example, Sally’s problem is not plausibly captured by saying that she has access to the change but is not sure how to classify it. Rather, it seems, she lacks access to the change altogether. 

6. Evans’s notions of discrimination by perception and by recognitional capacity do not help here. We have already seen that Sally lacks a recognition-based ability to distinguish the actual situation and the relevant alternative situation in which she thinks a twin thought. Perception of an object enables one to distinguish it from all others since it enables one to locate the object and discover its type. It is implausible to suppose that a subject exploits location in distinguishing types of thought.

<!-- page: pdf=0353 printed=none -->

7. Like the earlier indexical suggestion, this suggestion is compatible with a wide range of anti-individualist views, whether or not they accept Evans’s requirement for thought. 

8. Notice that this is so whether or not knowledge that _p_ requires the ability to distinguish the actual situation from relevant alternative situations or merely requires that there is no relevant alternative situation in which the subject falsely believes that _p_ . 

### **Chapter 4** 

##### 1. Introduced in chap. 1, sec. 4. 

2. Some prefer to use “reliability” for the statistical or dispositional property I later describe as “global reliability.” However, the use of “reliabilist” to characterize Nozick’s and Goldman’s accounts is widespread and reflects the fact that a belief meeting the relevant conditions could not easily have been false. 

3. This conclusion would not be affected if a local reliabilist accepted two further conditions Goldman places on knowledge—(1) his nonundermining condition: that the subject neither believe that the process is unreliable nor be in a mental state from which reliable processes would lead her so to conclude; and (2) that the belief be produced by a reliable process that was itself acquired by a reliable method for acquiring belief-forming processes (Goldman 1986, pp. 52–54). In particular, Sally may be ignorant of the fact that she is liable to suffer illusions of hearing wasps; and this fact does not undermine the reliability of the belief-forming process if we take reliability to be local reliability. 

4. By contrast, the distinction between local and global reliability makes no difference to whether Sally’s a priori knowledge of her actual thoughts is undermined by the possible situation in which she is hearing, and thinking about, a different wasp _w*_ . If Sally were hearing _w*_ , then she would neither self-ascribe the thought that that wasp ( _w_ ) is near nor suffer an illusion of thought. 

5. Someone might suggest that illusions of thought are normally so infrequent that even if global reliability is required for knowledge, illusions of thought present no problem for this condition. I ultimately agree with this line of thought (sec. 11), but it is interesting to see whether a defense of privileged access needs to rely on this point about frequency. If it does, the fact that some subjects—like Sally—frequently suffer illusions of thought may threaten their privileged access to their thoughts. In secs.

<!-- page: pdf=0354 printed=none -->

4–5, I examine whether a compatibilist could respond to the illusion argument in a different way, by arguing either that knowledge does not require global reliability or that illusions of thought are not relevant to global reliability. 

6. Nozick’s alternative formulation (if _p_ weren’t true, then _S_ would not believe that _p_ ) does not help since we have no satisfactory theory of the truth value of conditionals with impossible antecedents. 

7. The case cannot obviously be dealt with by using Goldman’s nonundermining condition and his condition that the belief result from a process that was itself acquired by a reliable method for acquiring belief-forming processes. I may have no evidence that forming beliefs on the basis of my informant’s testimony is unreliable; and this process may have been produced by a reliable method for acquiring belief-forming processes. 

8. The barn example is not likely to be solved by Goldman’s other conditions for knowledge. E.g., Laura may have no evidence that she is disposed to mistake fakes for barns. In addition, the process that produced Laura’s belief may itself have been produced by a reliable process for acquiring belief-forming processes. 

9. Someone may argue that Laura’s case instead motivates a modification of local reliabilism. Consider the two perceptual demonstrative propositions that that object ( _b_ ) is a barn, and that that object ( _f_ ) is a barn. Calling such pairs of object-dependent propositions _counterparts_ , the objector may suggest the following modified view: the true belief that _p_ is knowledge iff it is produced by a method that is reliable with respect to _p_ and its counterparts. However, this response ignores the argument for global reliabilism from knowledge of necessary truths, and it is inadequate if the illusion version of anti-individualism is correct. Consider _S_ who regularly hallucinates barns but is in an environment in which there are only real barns. At _t_ , she sees the barn, _b_ , and thinks that that object ( _b_ ) is a barn. This belief is not knowledge given her frequent hallucinations. But the modified local reliabilist account cannot agree; all it requires for knowledge is reliability with respect to the believed proposition and its counterparts. On the illusion version of anti-individualism, when _S_ hallucinates a barn she does not believe a relevant counterpart proposition but rather suffers an illusion of thought. It is hard to see how the objector could deal with the barnhallucinator without thereby conceding that the illusion version of antiindividualism may threaten privileged access. For example, she could say that _S_ knows that that object ( _b_ ) is a barn only if there is no nearby situation in which _S_ would suffer an illusion of thought. But, if that is right, then the illusion version of anti-individualism may threaten privileged access,

<!-- page: pdf=0355 printed=none -->

for subjects can suffer illusions of thought at both first- and second-order levels. 

10. Not always: the two typings considered in the last paragraph do not obviously affect the range of propositions relevant to global reliability, but rather affect the range of circumstances relevant to reliability. 

11. Most compatibilists accept the relevance of alternative situations. However, Sawyer (1999) argues that if a subject is thinking a recognitionbased thought about an object or kind, then the possibility of thinking a twin thought is not relevant. However, this claim does not easily extend to other types of externally individuated thoughts. In addition, the discrimination argument can exploit not only twin situations but also no-reference situations. Warfield (1997) suggests that real-world slow switches are infrequent. 

12. It is logically possible that a subject could apply a term only to instances of a natural kind for which she lacks a recognitional capacity, e.g., if by accident she never comes across instances of a duplicate that she would mistake for the relevant kind. However, the more usual explanation is that she can recognize the relevant natural kind. Further, where she lacks such a capacity and applies a term to instances of one kind only by accident, this undermines the idea that she has a concept of that kind. 

13. For Campbell (1987), the ability to perceptually track is crucial to our making the seems/is distinction. 

14. Although the discussion considers the paradigm examples of externally individuated thoughts, it does not cover all possible examples, e.g., memory-based demonstrative thoughts. 

### **Chapter 5** 

1. It should be clear from this example, and throughout the discussion, that I am focusing on validity as a property of thoughts, rather than as a property of sentences. 

2. Is transparency further undermined by the illusion version of antiindividualism, according to which someone who takes herself to have two thoughts with the same content may in fact be suffering one or more illusions of thought? Such cases are not direct counterexamples to either transparency of sameness or transparency of difference of content, for they do not involve a subject having two thoughts with the same (or different) content and being unable to realize this a priori. Further, if such cases are

<!-- page: pdf=0356 printed=none -->

rare, they do not prevent a subject from grasping a priori that she has two thoughts with the same content when she does. Compare: if perceptual illusion is rare, it does not prevent one from knowing that one is perceiving when one is. 

3. Chapter 6 considers a different argument due to Frances for the incompatibility of anti-individualism and transparency of difference of content. Since this argument does not show that a subject may make an invalid inference it is less relevant to the discussion of reasoning in this chapter. 

4. Many of Owens’s other arguments depend on the truth of antiindividualism, including his arguments from belief ascription (1989) and his Pierre and Bugsy Wabbit arguments (1990). Owens’s (1992) Rudolf case aims to show that regardless of the truth of anti-individualism, without empirical information a subject cannot tell whether or not two of his earlier thoughts involve the same concept. However, this example does not threaten transparency since that concerns a subject’s epistemic access only to her current thoughts, not her past thoughts. 

5. Could a Fregean individualist challenge the claim that all of Burge et al. express the same thoughts by (i) and (ii) on the basis that although Kripke and Church assent to (i) and (ii), Burge and Mates assent to (i) but dissent to (ii)? Recall that Fregeans hold that content is partly individuated by difference of attitude. So, it might be suggested that although Church and Kripke express the same attitude by (i) and (ii), Burge and Mates do not. However, this argument rests on a mistake about the Fregean test for difference of content. The Fregean test for difference of content applies only to extensional contexts, not intensional ones. 

6. In fact this claim does not follow logically from the failure of transparency. Even if a subject cannot always grasp a priori that two of her thoughts are contradictory, it does not follow that she can never grasp a priori that two of her thoughts are contradictory. 

7. By contrast, Millikan (1993) argues that the processing of empty and equivocal thoughts, and failures of transparency, are so frequent that the standard principles are not true even considered as generalizations. 

### **Chapter 6** 

1. Even on the descriptive understanding, the claim is compatible with her thought being individuated by some environmental factor other than _x_ . So anti-individualists, whether Fregean or not, can accept that subjects sometimes think of objects via a description (see chap. 1, sec. 1). The point is

<!-- page: pdf=0357 printed=none -->

only that if a subject thinks of a particular object, _x_ , by description, then her thought is not individuated by _x_ . 

2. Salmon, Owens, and Millikan reject transparency of sameness of content and argue that a subject may have contradictory beliefs without anything being wrong with her faculty of reasoning (Salmon 1986, appendix A; Owens 1989, 1990; Millikan 1993, p. 289). Millikan further concludes that a rational subject may fail to make simple valid inferences (ibid.). 

3. Dummett (1973) makes a related claim about the Fregean argument for sense formulated at the level of language: “[t]he underlying assumption [of the Fregean argument from informative identity statements to the notion of sense] is the compelling principle that, if someone knows the senses of two words, and the two words have the same sense, he must know that they have the same sense: hence, if the sense of a name consists merely in its reference, anyone who understands two names having the same reference must know that they have the same referent” (p. 95). 

4. The case may undermine the different principle that if a subject has two thoughts or thought constituents with the same content at the same time, then she can know (cf. realize) a priori that they have the same content. Suppose that _S_ correctly thinks that two perceptual demonstrative thoughts involve the same sense. It might be argued that her belief is not a priori knowledge since she cannot rule out a priori the possibility that she is mistaken because, say, between her thinking these two thoughts, there has been an unnoticed switch in the object perceived. Whether this argument succeeds depends on which error possibilities one needs to rule out to have knowledge. However, the classic Fregean argument for sense does not require the stronger principle concerning knowledge. That argument involves the idea that, in simple cases, a rational subject would not have contradictory beliefs or fail to make valid inferences. But this requires only the weaker transparency principle in the text. 

5. If, instead, Eve believes that she has lost track of the original apple, she might think of it as the apple that caused certain memories. Thinking of apple _a_ by this description enables Eve to meet Evans’s discrimination requirement. However, this thought is conceptually more complex than Evans takes perceptual demonstrative thoughts to be. Further, if Eve thinks she has lost track, she would not be inclined to put the two thoughts together in inference. 

6. Both social and natural kind anti-individualism accept that a subject can have the concept of a natural kind while being ignorant of its chemical composition. Further, both views accept that a subject can have the concepts expressed by two terms even if she is ignorant that they have different

<!-- page: pdf=0358 printed=none -->

extensions. E.g., in Burge’s arthritis thought experiment, a subject has the concepts expressed by ‘arthritis’ and ‘rheumatoid ailment of the joints and thighs’ although thinking mistakenly that they have the same extension. And a subject may have such causal relations that a natural kind antiindividualist would accept that she has the concepts of two distinct natural kinds even though she is unsure if the relevant terms name the same natural kind. E.g., she may think that she may have encountered two different forms of the same underlying natural kind just as, say, diamond and graphite are instances of the element carbon. 

7. Even if someone disputed this conclusion, the Fregean response establishes that Clara can realize the difference in content only either by gaining empirical information or by acquiring Fregean theory via philosophical argument. In neither case is the difference of content readily available a priori. But, even this minimal conclusion establishes tension between Fregean sense and anti-individualism. The classic arguments for sense assume that a rational subject would not have simple contradictory beliefs and would not fail to make simple valid inferences. That requires that sameness of content is readily available a priori. But why hold that sameness of content is so available if difference is not? 

8. Given that Clara is uncertain about whether the terms name the same element, she does not actually make an invalid inference. 

9. This might not be so if the relevant principles were formulated using the notion of knowledge instead of realization. See note 4. 

10. The Fregean cannot motivate transparency of sameness of content or the accompanying conception of rationality by appeal to the notion of sense, for this would be circular: transparency of sameness of content and the accompanying conception of rationality are key assumptions of the classic Fregean arguments for sense. 

### **Chapter 7** 

1. Many anti-individualists hold that if one had always been envatted then one would lack any contentful thoughts and/or experiences. 

2. I have formulated transmission and closure slightly differently from Wright, who says “[c]losure [of warrant], unrestricted, says that whenever there is warrant for the premises of a valid argument, there is warrant for the conclusion too. Transmission, unrestricted, says more: roughly, that to acquire a warrant for the premises of a valid argument and to recognise its validity is to acquire—perhaps for the first time—a warrant to accept the

<!-- page: pdf=0359 printed=none -->

conclusion” (Wright 2000, p. 141). My formulation is designed to apply with minimal change to both warrant and knowledge. It is implausible to claim that if a subject has warrant for, or knowledge of, the premises of a valid argument, then she has warrant for, or knowledge of, the conclusion. She might not believe the conclusion of the argument or realize that the argument is valid, and, even if she does, she might believe the conclusion on completely different grounds. Some of the same problems affect the standard definition of closure for knowledge: if _S_ knows that _p_ and _S_ knows that if _p_ then _q_ , then she knows that _q_ . 

3. Davies and Wright concentrate on a failure of transmission of warrant. But to solve the reductio they need to deny that knowledge transmits across the reductio. 

4. Wright expresses this by saying that the arguments are “questionbegging.” I am following Jackson’s different usage in which an argument is question-begging iff someone who doubts the conclusion would have background beliefs relative to which the evidence for the premises is no evidence. 

5. Wright (2002) revises condition (ii) to read: “that C depicts a situation of a general kind incompatible with the reliable operation of the cognitive capacities involved in generating the warrant for A.” This revision does not affect my discussion. 

6. Pritchard (2002) makes the different objection to Wright’s analysis, that the water argument is not analogous to Moore’s argument since the presuppositions for having warrant for the first premises of these two arguments are different, and it is only in the case of Moore’s argument that there is no possible evidence for the relevant presupposition. However, neither Wright nor Davies claims that the arguments are analogous in these respects. McLaughlin (2003) poses a more serious challenge to Wright, claiming that Wright’s template for a failure of transmission has the result that warrant fails to transmit across any valid argument from A and if A then B, to B, where A has a noninferential nonlogically conclusive warrant. 

7. This is so even if the relevant warrant is taken to be nonevidential. Merely lacking evidence against a possibility, _q_ , does not entail that one has nonevidential warrant for not- _q_ . 

8. In this passage, by “reliability,” I mean what I earlier called “global reliability” (chap. 4). 

9. Wright’s conditional analysis would also be rejected by some internalists. Pryor (2000) argues that, for some propositions, having an experience

<!-- page: pdf=0360 printed=none -->

as of _p_ provides a justification for _p_ that does not presuppose or rest on one’s justification for anything else. On this basis, Pryor (forthcoming) rejects Wright’s conditional analysis of the BIV argument, although he accepts this view of the zebra argument. 

10. “Externalism about [a natural kind] concept may involve all or only some of a variety of claims: for instance that the concept is _rigidly associated_ with its actual extension, that it is _identified_ by its extension, that it _cannot so much as exist_ without a (non-empty) extension. The last is what is germane to the second premise of the McKinsey paradox” (Wright 2000, p. 145). Wright argues that the reductio argument meets his template, taking A = “I believe that water is wet”; B = “I, or my speech community, have had such and such encounters with water”; and C = “the seeming thought which I attempt to token by ‘I believe that water is wet’ is contentdefective owing to the reference failure of the purported natural kind term, ‘water’, in my language” (p. 156). 

11. See also Wright (2000), p. 157. Wright claims that, on his view of the reductio, one’s warrant for the premise (W1) I think that water is wet depends on antecedent entitlement to discount the possibility (C) that one is instead suffering an illusion of thought. This entitlement in turn depends on one’s having “antecedent reason to think that [one’s] tokenings of ‘water’ comply with appropriate externalist constraints,” namely that oneself or one’s community has had such-and-such encounters with water. But, Wright says, “if such an antecedent reason for discounting C had to be empirically acquired, this line of thought would after all involve dismissal of the groundlessness of self-knowledge in the relevant kind of case.” In other words, if one could have only empirical warrant for supposing that oneself or one’s community has had contact with water, then one could not have a priori knowledge of one’s thought contents. He goes on to defend the idea that there is an a priori entitlement against the possibility of illusions of thought. 

12. For any valid argument, doubt about the conclusion may lead someone to doubt the premises, but such a doubt does not necessarily involve having background beliefs relative to which the evidence for the premises is no evidence. Thus, Davies’s account does not threaten transmission across all valid arguments. 

13. By contrast, the experience of seeing a striped horselike animal combined with one’s warrant for thinking that if the animal is a zebra then it is not an elephant does rule out the relevant alternatives to the claim that the animal is not an elephant. Thus, Davies’s account does not threaten a failure of transmission across all valid arguments.

<!-- page: pdf=0361 printed=none -->

14. By contrast, McLaughlin (2003) challenges Davies’s analysis by objecting to the limitation principles. 

15. Since Davies provides no independent account of the notion of a relevant alternative, it is reasonable to assume that he is using the extant epistemological notion. If he is not, then it is not clear how to interpret the notion. 

16. Davies might try to avoid this objection by restricting his account of warrant to true beliefs. So restricted, the account of warrant is radically incomplete and has the counterintuitive consequence that different accounts of warrant apply to true and false beliefs. In any case, even with this restriction, Davies’s account would still have counterintuitive consequences in Gettier cases. 

17. On Goldman’s more recent account, “ _S_ ’s believing _p_ at _t_ is justified iff a) _S_ ’s believing _p_ at _t_ is permitted by a right system of J-rules; and b) this permission is not undermined by _S_ ’s cognitive state at _t”_ (Goldman 1986, p. 63). Condition (a) is explained in reliabilist terms. Note that (McE1) and (McE3) meet Goldman’s nonundermining condition, (b). 

18. Some accounts of warrant might accept these consequences. Plantinga (1993) elucidates justification as a deontological notion associated with the concept of duty. By contrast, he defines warrant as that which makes the difference between true belief and knowledge. Thus, a belief cannot be both warranted and true and yet fail to be knowledge. So, Gettier cases cannot involve true warranted beliefs that fail to be knowledge. Merricks (1995) argues that, on Plantinga’s conception, warrant entails truth. However, Plantinga’s conception of warrant is highly controversial. So, if Davies were to support his account with Plantinga’s views, it would not provide a compatibilist response to the reductio acceptable to a wide range of theorists with different approaches to warrant. 

### **Chapter 8** 

1. Boghossian (1997) distinguishes atomic and compositional concepts (p. 165). 

2. See Nozick (1981) and, for similar conditions, Dretske (1970, 1981) and Goldman (1976, 1986). In chapter 4, following McGinn and Goldman, I called such conditions “local reliability” conditions for knowledge. 

3. Each view also endorses the different principle that if a chemically indifferent subject _S_ intends _t_ to name a natural kind and it does so, then it

<!-- page: pdf=0362 printed=none -->

expresses a nondescriptive concept of that kind. But this principle is of no use in defending (R2). 

4. McLaughlin and Tye (1998) and Stoneham (1999) deny that Putnamian anti-individualism about natural kinds entails the illusion view. Even if this is correct, Boghossian’s argument might still apply to the illusion view. Brown (1998) objects to Boghossian’s argument that if natural kind and social anti-individualism are both true, then a subject cannot know a priori that she intends _t_ to express an atomic concept of a natural kind. However, this objection is not relevant at this point when we are considering only natural kind anti-individualism. 

5. Nor is this merely the result of an overly restrictive definition. E.g., it seems no part of folk psychology to suppose that a subject can know a priori the type of her thought and, in particular, whether it is descriptive or not. 

6. Interestingly, Davies’s and Wright’s accounts have the consequence that warrant, and thus knowledge, fails to transmit from (T1) and (T2) to (T3). 

7. Someone might argue that Sally’s belief in (T3) meets the Nozickean condition when relativized to methods: _S_ knows _p_ via _M_ only if _S_ truly believes _p_ via _M_ and, if _p_ were false and _S_ were to use _M_ to arrive at a belief whether _p_ , _S_ wouldn’t believe that _p_ via _M_ (Nozick 1981, p. 179). If the relevant method were inferring whether one is suffering an illusion of thought from having an actual thought, then the method seems inapplicable when one is suffering an illusion. So, formed via this method, one’s belief that one is not suffering an illusion of thought meets the Nozickean condition. However, it is not clear what justifies the selection of this method rather than the method of inferring whether one is suffering an illusion of thought on the basis of having an apparent thought. Nozick’s understanding of the notion of method favors the latter specification, for he says “any method experientially the same, the same ‘from the inside’ will count as the same method” (p. 185). Notice that if Nozick’s principle for the individuation of methods is rejected then one does have a method for producing the belief that one is not a BIV that meets the relevant condition, namely inference from visual perception (as opposed to inference from visual experience). 

8. Social anti-individualists are also committed to the following entailment: if _S_ has a concept _c_ and misunderstands that concept, then _S_ is, or used to be, part of a community with the concept _c_ . However, since a subject cannot have a priori knowledge that she misunderstands a concept, knowledge of this entailment is of no use in the reductio. 

9. A similar objection applies to McLaughlin and Tye’s example involving the concept of the a priori (1998, p. 317).
