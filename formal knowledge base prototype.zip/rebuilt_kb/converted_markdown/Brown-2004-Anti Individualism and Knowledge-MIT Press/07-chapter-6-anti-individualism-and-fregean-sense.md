---
title: "Chapter 6: Anti-Individualism and Fregean Sense"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 221
locator_end: 259
---

# Chapter 6: Anti-Individualism and Fregean Sense

<!-- page: pdf=0221 printed=none -->

**6** 

**Anti-Individualism and Fregean Sense** 

### **1 Introduction** 

So far I have been assuming that it is possible to combine anti-individualism and the Fregean notion of sense, and thus that one can distinguish Fregean from non-Fregean versions of anti-individualism. Indeed, a number of prominent anti-individualists have accepted the notion of sense, for example, Evans, Campbell, McDowell, and Peacocke. Fregeans argue that we need the notion of sense to provide an adequate psychological understanding of agents. In particular, they argue that the notion of sense is needed to explain informative identity judgments, inferences, and belief ascriptions, and to avoid attributing contradictory beliefs to subjects. Fregean anti-individualists hope to take advantage of the Fregean explanations of these phenomena while also endorsing anti-individualism. Thus, the question of whether anti-individualism is compatible with Fregean sense is crucial for our psychological understanding of agents. 

Some have argued that anti-individualism and Fregean sense are incompatible because they assume that whenever a subject thinks of something via a sense, or mode of

<!-- page: pdf=0222 printed=none -->

presentation, she thinks of it via some description (see, e.g., Kripke 1980; Salmon 1986). For example, suppose that a subject is looking at a vase and thinks the perceptual demonstrative thought that that vase is pretty. A Fregean would argue that she thinks of the vase via a certain sense or mode of presentation. Suppose that this amounted to her thinking of the vase via a description, such as the vase that I am now looking at. In that case, the content of her thought is independent of the particular vase she is looking at. She would have the same thought in a counterfactual situation in which she sees a different vase, or merely suffers an illusion of seeing such a vase. Thus, on the descriptive understanding of sense, the claim that a subject thinks of _x_ via a certain sense is incompatible with the anti-individualist claim that her thought is individuated partly by _x_ .<sup>1</sup> 

Those who have attempted to combine anti-individualism and the notion of sense have rejected the descriptive model of sense. They have developed instead the notion of an object-dependent sense, a way of thinking about an object that would not be available to be thought in the absence of that object (see, e.g., Evans 1982; Peacocke 1983; McDowell 1986; Campbell 1994). If the subject in our example were to think of the vase via such an object-dependent sense, then she would not have the same thought in a counterfactual situation in which she sees a different vase, or merely suffers an illusion of seeing such a vase: in such a counterfactual situation, the object-dependent sense that she uses in the actual situation would not be available. Thus, this different understanding of sense avoids the problems faced by the attempt to combine the descriptive understanding of the notion of sense with anti-individualism. However, in this chapter, I present a new reason for thinking that even the

<!-- page: pdf=0223 printed=none -->

Anti-Individualism and Fregean Sense 

object-dependent notion of sense may be in tension with anti-individualism. 

The argument turns on issues raised in the last chapter concerning transparency of content. Let me briefly summarize the conclusions established there. We saw that many varieties of anti-individualism undermine transparency, although Fregean and non-Fregean versions of antiindividualism affect transparency differently. The following two principles were central to the argument: 

**Transparency of sameness of content** : For any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content then, at _t_ , _S_ can realize a priori that they have the same content. 

**Transparency of difference of content** : For any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents then, at _t_ , _S_ can realize a priori that they have different contents. 

We saw that non-Fregean anti-individualism is incompatible with transparency of sameness of content, and that Fregean anti-individualism is compatible with transparency of sameness of content. By contrast, it turned out that many varieties of anti-individualism, whether Fregean or nonFregean, are incompatible with transparency of difference of content. If sameness and/or difference of content is not transparent, then a subject may make mistakes about the logical properties of her thoughts, mistakes that she cannot correct without empirical information. In the last chapter, I rejected the suggestion that since anti-individualism undermines transparency, it undermines the idea that we are rational subjects. I rejected the claim that it is part of the concept

<!-- page: pdf=0224 printed=none -->

of a rational subject that, at least in simple cases, she can always grasp the logical relations between her thoughts a priori and so would not have simple contradictory beliefs, would not make simple invalid inferences, or would not fail to make simple valid inferences. In this chapter, I will leave aside the controversial issue of the nature of rationality, which, as we will see, is in dispute between Fregeans and non-Fregeans. However, the argument does use the results of the last chapter concerning transparency. 

Here, I argue that the classic Fregean arguments for sense rely on the assumption of the transparency of sameness of content and a certain conception of rationality. That the Fregean arguments rely on transparency of sameness of content does not directly make it difficult to combine antiindividualism and Fregean sense. As we saw in the last chapter, although non-Fregean anti-individualism is incompatible with transparency of sameness of content, Fregean anti-individualism is compatible with transparency of sameness of content. However, I argue via a more indirect route that the Fregean argument’s reliance on the assumptions of transparency of sameness of content and on a related conception of rationality makes it hard to combine Fregean sense and anti-individualism. The indirect route uses the notion of the transparency of difference of content. In the last chapter, we saw that many varieties of both Fregean and non-Fregean anti-individualism are incompatible with transparency of difference of content. I argue that it is hard to motivate the key assumptions of the Fregean argument for sense—transparency of sameness of content and the relevant conception of rationality—if one rejects transparency of difference of content. Thus, I conclude that there is a tension between anti-individualism and Fregean sense.

<!-- page: pdf=0225 printed=none -->

Anti-Individualism and Fregean Sense 

Section 2 begins the discussion by showing how the classic Fregean arguments for sense rely on the assumptions of transparency of sameness of content and a certain conception of rationality. 

### **2 The Contrast between Fregean and Non-Fregean Anti-Individualism** 

Given that non-Fregean anti-individualists reject Fregean sense, they hold that the semantic value of the singular component of a thought is exhausted by its referent, if any. By contrast, Fregeans argue that there is a component of thought content not accounted for by non-Fregean antiindividualism, namely, sense. Recall that sense is individuated by potential difference of attitude: 

If it is possible rationally to believe that _p_ and not believe that _q_ , then the contents _p_ and _q_ are distinct. 

Consider the standard example of a subject, call her Celeste, who unwittingly has two terms for the planet Venus—‘Phosphorus’ and ‘Hesperus’. She applies the term ‘Phosphorus’ to a bright star visible in the morning; she applies ‘Hesperus’ to a bright star visible in the evening. Fregeans argue that non-Fregean anti-individualism cannot accommodate various features of Celeste’s cognitive life. As we will see, the Fregean argument depends partly on a conception of rationality that we rejected in the last chapter. However, I won’t rely on that rejection here. Rather I will argue that, whether or not the Fregean conception of rationality is correct, it cannot be well motivated for someone who also accepts anti-individualism. 

Consider the identity judgments Celeste would express by:

<!-- page: pdf=0226 printed=none -->

- (1) Phosphorus is Phosphorus. 

- (2) Phosphorus is Hesperus. 

The Fregean argues that, given that Celeste thinks that ‘Hesperus’ and ‘Phosphorus’ refer to distinct stars, Celeste would find the identity judgment expressed by (2) informative and that expressed by (1) uninformative. Certainly, if Celeste came to accept (2), this would be an important empirical discovery that would enable her to bring together a host of information about Phosphorus and Hesperus, which she previously kept separate. On the non-Fregean view, the thought constituents corresponding to ‘Phosphorus’ and ‘Hesperus’ have the same content and thus so do the thoughts corresponding to (1) and (2), for ‘Hesperus’ and ‘Phosphorus’ have the same referent. But, the Fregean asks, how can (1) and (2) differ in informativeness if they have precisely the same content? (Frege 1892, 1980; p. 80). 

Second, the Fregean points out that, before discovering that Hesperus is Phosphorus, Celeste would fail to put Hesperus and Phosphorus thoughts together in inference. For example, suppose that Celeste has the attitudes she would express by: 

(3) Hesperus is clearly visible in the evening. 

(4) It is crucially important to make as many observations as possible of Phosphorus. 

Celeste would fail to draw the conclusion she would express by: 

(5) It is crucially important to make as many observations as possible of Hesperus in the evening. 

and she might fail to make any observations of Hesperus in the evening. On the non-Fregean view, the thought

<!-- page: pdf=0227 printed=none -->

constituents corresponding to ‘Hesperus’ and ‘Phosphorus’ have the same content, and the inference is a simple valid one. But, given that Celeste is a rational subject, how could she fail to make such a simple inference? 

Third, Celeste would sincerely assent to the following sentences, providing strong evidence that she believes the corresponding thought contents: 

(6) Phosphorus rises in the morning. 

(7) It is not the case that Hesperus rises in the morning. 

This suggests that the non-Fregean is committed to saying that Celeste believes a proposition and believes its negation. But, the Fregean argues that this is deeply implausible, given that Celeste is supposedly rational and a rational person would not have simple contradictory beliefs. 

A last problem for the non-Fregean anti-individualist is that Celeste’s behavior may appear to provide evidence for the view that she believes the proposition she would express by ‘Phosphorus rises in the morning’ and that she does not believe the proposition she would express by ‘Hesperus rises in the morning’. Indeed, this is intuitively how we would describe her psychological state. On the non-Fregean view, these sentences express the same proposition so how can Celeste, being rational, believe the proposition expressed by the one sentence but not the proposition expressed by the other? 

The Fregean concludes that non-Fregean antiindividualism cannot accommodate the facts about Celeste. Instead, she argues that the thought constituents Celeste expresses with ‘Hesperus’ and ‘Phosphorus’ differ in sense and thus content. The Fregean uses this difference in content to explain how Celeste can find the identity judgment ‘Hesperus is Phosphorus’ informative, and why she fails

<!-- page: pdf=0228 printed=none -->

to put Hesperus and Phosphorus thoughts together in inference. Further, she can avoid the conclusion that Celeste has beliefs with contradictory contents, for on her view, the beliefs Celeste expresses with (6) and (7) do not contradict each other since they involve different ways of thinking of Venus. Last, the Fregean can accommodate the intuition that Celeste believes that Phosphorus rises in the morning but does not believe that Hesperus rises in the morning. Since the Fregean holds that different senses are associated with ‘Hesperus’ and ‘Phosphorus’, on her view, Celeste, while remaining rational, may believe that Phosphorus rises in the morning but not believe the different proposition that Hesperus rises in the morning. 

The Fregean arguments for sense rely on two key assumptions: a certain conception of rationality and the transparency of sameness of content. We can see this by seeing how the non-Fregean can counter the Fregean arguments by rejecting both assumptions. Consider the argument that the non-Fregean cannot explain why Celeste, a rational person, fails to inferentially combine ‘Hesperus’ and ‘Phosphorus’ thoughts. Suppose that sameness of content is not transparent and thus that a subject may have two thoughts, or thought constituents, with the same content at a single time, yet believe mistakenly that they have different contents and be unable to correct her view without using empirical information. This would provide an alternative explanation of Celeste’s failure of inference that is compatible with the non-Fregean view that the thought constituents corresponding to ‘Hesperus’ and ‘Phosphorus’ have the same content. On this rival explanation, Celeste fails to make the simple valid inference (3)–(5) since she does not realize that the relevant thought constituents have the same content and thus that the inference is valid. Further, she can come to the

<!-- page: pdf=0229 printed=none -->

Anti-Individualism and Fregean Sense 201 

correct view only by using empirical information. On this view, her failure to make the simple valid inference (3)–(5) does not impugn her rationality, for even a rational subject would fail to make a valid inference that she does not realize is valid.<sup>2</sup> 

Next, consider the argument that non-Fregean antiindividualism has the implausible result that Celeste, a rational subject, has beliefs with contradictory contents. The non-Fregean would respond by saying that this result would not be implausible if sameness of content were not transparent. In that case, a subject could have two thoughts, or thought constituents, with the same content at a single time, yet believe mistakenly that they have different contents and be unable to correct her view without using empirical information. As a result, she may easily end up with contradictory beliefs that she cannot see are contradictory without empirical information. Such contradictory beliefs would not impugn her rationality. 

The idea that subjects may mistakenly suppose that two thought constituents have different contents also undermines the Fregean argument from informative identity judgments.<sup>3</sup> On the non-Fregean view that the thought constituents associated with ‘Hesperus’ and ‘Phosphorus’ have the same content, the relevant identity judgments cannot differ in their semantic information. However, the nonFregean anti-individualist may attempt to explain away our intuition of a difference in informativeness. She may argue that, given the set up, Celeste would suppose mistakenly that ‘Hesperus’ and ‘Phosphorus’ express thought constituents that have different referents and contents. Further, Celeste could come to realize that the thought constituents have the same referent and content only by gaining empirical information. So, the judgment Celeste expresses with

<!-- page: pdf=0230 printed=none -->

‘Hesperus is Phosphorus’ has an important cognitive effect for Celeste—it leads her to bring together the information she previously associated separately with ‘Hesperus’ and ‘Phosphorus’. These are the facts, the non-Fregean antiindividualist alleges, that the Fregean mistakenly takes as evidence that the thought constituents associated with ‘Hesperus’ and ‘Phosphorus’ differ in semantic informativeness and thus content (see, e.g., Millikan 1993, p. 335). 

The claim that sameness of content cannot always be grasped a priori does not enable the non-Fregean antiindividualist to answer the last of the Fregean arguments, from opacity of attitude ascriptions. Recall that Celeste’s behavior provides evidence that she believes the proposition she would express by ‘Phosphorus rises in the morning’, and that she does not believe the proposition which she would express by ‘Hesperus rises in the morning’. On the non-Fregean view, the same thought is expressed by the two sentences. But, it is surely inconsistent to claim that a subject believes and does not believe one and the same proposition. One cannot overcome this problem by arguing that sameness of content cannot always be grasped a priori. Instead, non-Fregean anti-individualists have employed a number of other strategies, arguing that belief ascriptions claim implicitly or suggest pragmatically that a subject believes a certain proposition under a certain guise (Salmon 1986; Crimmins and Perry 1989); or that they implicitly involve reference to a sentence in the language (Carnap 1946; Davidson 1969). I will not examine the details of these responses here. My aim is not to determine which of the Fregean and non-Fregean explanations of the phenomena is preferable, but rather to examine whether the Fregean explanation is compatible with anti-individualism.

<!-- page: pdf=0231 printed=none -->

Anti-Individualism and Fregean Sense 

We can summarize the contrast between the Fregean and non-Fregean approaches as follows. The Fregean explains the facts about informativeness, inferential transitions, and apparently contradictory belief by arguing that the thought constituents corresponding to ‘Hesperus’ and ‘Phosphorus’ have different contents. Further, the Fregean’s argument that non-Fregeans cannot account for these phenomena relies on two key assumptions: the transparency of sameness of content and a connected conception of rationality. According to transparency of sameness of content, for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content then, at _t_ , _S_ can realize a priori that they have the same content. As a result, at least in simple cases, a rational subject can grasp those relations that turn on sameness of content, such as contradiction and validity, without using empirical information. Thus, a rational subject would not hold simple contradictory beliefs, or fail to make simple valid inferences. 

As we have seen, the non-Fregean may counter the Fregean arguments by rejecting transparency of sameness of content. Instead of explaining facts about informativeness, inferential transitions, and putative contradictory beliefs by appeal to differences of content, she explains them by arguing that subjects cannot always realize a priori that two thoughts or thoughts constituents have the same content. Thus, on this view, a rational subject may have simple contradictory beliefs and fail to make simple valid inferences, for she is not always able to grasp simple instances of contradiction and validity without using empirical information. 

It seems, then, that the debate between the Fregean and the non-Fregean turns on whether sameness of content is

<!-- page: pdf=0232 printed=none -->

transparent and on the correct conception of rationality. The Fregean position is well motivated only if the assumptions of transparency of sameness of content and the related Fregean conception of rationality are well motivated. In the rest of the chapter, I examine whether these assumptions can be well motivated for someone who also accepts anti-individualism. 

### **3 Fregean Anti-Individualism and Transparency of Sameness** 

In the last chapter, we saw that it is commonplace to argue that anti-individualism is incompatible with transparency of sameness of content. If these positions were incompatible, then anti-individualism would be directly in tension with Fregean sense, given that transparency of sameness of content is a key assumption behind the classic arguments for sense. However, in the last chapter, we also saw that the standard incompatibilist argument applies only to nonFregean anti-individualism. Let us briefly remind ourselves of why this is so. 

According to the standard argument, since a subject may be ignorant of the environmental facts that, according to antiindividualism, partly individuate her thoughts, she may be unable to know that two thoughts have the same content without empirical information. In Falvey and Owens (1994), Rudolf is acquainted with the terms ‘coriander’ and ‘cilantro’, although he is ignorant of the fact that they name the same herb. He assents to both ‘Cilantro should be used sparingly’ and ‘Coriander should be used sparingly’. Falvey and Owens argue that an anti-individualist should accept that these two thoughts have the same content, for ‘coriander’ and ‘cilantro’ have the same extension. However,

<!-- page: pdf=0233 printed=none -->

Anti-Individualism and Fregean Sense 205 

Rudolf cannot realize a priori that these thoughts have the same content, for he thinks that the terms name different herbs. They conclude that anti-individualism is incompatible with the transparency of sameness of content (pp. 110–111). 

A Fregean anti-individualist would agree that content depends on contextual matters of which the subject may be ignorant. However, in any case in which a subject unwittingly has two terms that in fact refer to the same object or kind, the subject could take different attitudes to sentences involving the terms. In the cilantro/coriander case, Rudolf may dissent from ‘Coriander is a herb characteristic of Mexican cuisine’ while assenting to ‘Cilantro is a herb characteristic of Mexican cuisine’. Now the notion of sense is partly individuated by potential difference of attitude: if it is possible rationally to believe that _p_ and not believe that _q_ , then _p_ and _q_ have different contents. Thus, the Fregean antiindividualist would argue that although the concepts the subject associates with the two terms have the same extension, they differ in sense and hence content. Thus, the Fregean anti-individualist would deny that the example shows that sameness of content is not transparent, that is, that a subject may have two thoughts with the same content at the same time and yet be unable to realize a priori that they have the same content; on her view, Rudolf associates different thoughts with the sentences ‘Cilantro should be used sparingly’ and ‘Coriander should be used sparingly’. It seems, then, that the standard argument for the incompatibility of anti-individualism and transparency of sameness of content does not apply to Fregean anti-individualism. 

Nevertheless, it is useful to consider the views of a prominent Fregean anti-individualist, John Campbell, who seems

<!-- page: pdf=0234 printed=none -->

to provide a different argument for the incompatibility of Fregean anti-individualism and transparency of sameness of content. Campbell (1987) argues that Fregean antiindividualism is incompatible with what he calls “transparency of sense.” Since, for the Fregean anti-individualist, sense is one component of thought content, Campbell’s conclusion might be taken to suggest that Fregean antiindividualism is incompatible with transparency of sameness of content. 

Campbell combines anti-individualism and the notion of object-dependent sense, a way of thinking of an object that would not be available if one lacks a suitable relation to the relevant object. Campbell argues that sometimes a particular sense is made available to a subject in virtue of the fact that she perceptually tracks the object across time or across different sensory modalities. Such a sense enables the subject to think of the object in the same way across different times and sensory modalities. However, since a subject may think mistakenly that she has successfully tracked an object when she has not, she may suppose mistakenly that she is thinking of one object via a single sense although she is not. Thus Campbell concludes that his Fregean antiindividualist view is incompatible with transparency of sense. 

Consider a subject who attempts to think the inference she would express with 

- (1) That glass is _F_ . 

- (2) That glass is _G_ . 

- (3) So, there is something that is both _F_ and _G_ . 

Suppose that the subject takes herself to be looking at a single glass over a period of time and thinking about it via

<!-- page: pdf=0235 printed=none -->

Anti-Individualism and Fregean Sense 207 

a single sense. Campbell argues that if it is the same glass that is being thought about in the two premises, then they involve the same sense and the subject is correct. Now suppose instead that a clever switch takes place during the inference so that, unbeknownst to the subject, she is looking at different glasses when she attempts to think the relevant premises. In that case, Campbell argues, the premises do not involve the same sense and the subject is mistaken in thinking that they do involve the same sense. To realize her mistake she would need to use empirical information about the switch. Campbell concludes that the case shows that sense is not transparent (1987, pp. 281–290). 

However, contrary to first appearances, the case is no counterexample to the principle of the transparency of sameness of content: for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content then, at _t_ , _S_ can realize a priori that they have the same content.<sup>4</sup> Campbell’s case is not one in which a subject in fact has two thought constituents with the same content, yet mistakenly thinks that they have different contents. Rather, the case shows that whether a subject is having two thought constituents with the same sense and content depends on matters outside the subject, and so a subject may think that she is having two thought constituents with the same sense and content, when she is not. As a result, a subject is reliable, but not infallible, about whether she is having two thoughts involving the same sense and content (Campbell 1987, p. 279). 

There are two possible views about a case where a subject mistakenly thinks she is having two thought constituents with the same sense and content. On one view, apparently favored by Campbell, the subject suffers an illusion of thought: although it seems to her as if she is thinking the

<!-- page: pdf=0236 printed=none -->

premises of an inference, she is not (ibid. p. 285). On a second view, the subject thinks two thoughts, but each concerns a different object. On this view, the case would constitute a counterexample to the distinct principle of the transparency of difference of content: for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents then, at _t_ , _S_ can realize a priori that they have different contents. 

Rather than objecting to transparency of sameness of content, Campbell argues that if two thoughts involve the same sense, then the subject knows that they are the same immediately: “[I]f, for example, one does succeed in keeping track of a particular wasp over time, or from sensory modality to sensory modality, and makes the judgements, ‘that wasp is _F_ ’, and ‘that wasp is _G_ ’, then one must know immediately that it is the same thing that is in question” (p. 285). Further, Campbell seems to endorse the idea that the validity of an inference should be obvious to a subject, not something that the subject can discover only by gaining empirical information about her environment: “[T]he form of a valid argument must do more than merely secure that if the premises are true, so too is the conclusion. The form of a formally valid argument . . . must furthermore make it possible for one who grasps it to move from premises to conclusion in a series of steps, each of whose correctness is individually obvious” (p. 277). Admittedly, Campbell accepts that a subject can suppose mistakenly that she is thinking a valid inference when she is not, such as in the switching example. However, he seems to hold that when a subject is in fact thinking a valid inference, this must be obvious to her. 

Given the dependence of sameness of sense on environmental factors, a subject who is in fact thinking about just

<!-- page: pdf=0237 printed=none -->

Anti-Individualism and Fregean Sense 

209 

one object through an inference may wonder whether the premises concern the same object and thus whether the inference is valid. However, once the subject has raised this question, the subject could rationally take conflicting attitudes to the objects of the two premises. Thus, standard Fregean criteria for the individuation of sense show that she is thinking of the object by different senses in the two premises (Campbell 1987, pp. 284–285). Thus, Campbell argues, such a case would not be one in which a subject has two thought constituents with the same content but cannot realize a priori that they have the same content, nor one in which she makes a valid inference but cannot realize a priori that it is valid. Rather, it is a case in which she has two thought constituents with different contents, but wonders whether they have the same referent. Thus, such a doubt does not directly threaten transparency of sameness of content. (These comments reflect the Fregean rejection of the view that the inference “ _Fa_ , _Gb_ , so something is _F_ and _G_ ” is valid iff _a_ and _b_ are coreferential. Instead, Fregeans hold that the inference is valid iff _a_ and _b_ have the same sense as well as reference [see, e.g., Campbell 1987, p. 277]. For instance, Fregeans deny that there is a valid inference from the beliefs that Phosphorus rises in the morning and Hesperus rises in the evening to the conclusion that something rises in the morning and the evening. This Fregean understanding of validity is required if the validity of an inference is to be obvious to one who grasps it.) 

In conclusion, one potential threat to the coherence of Fregean anti-individualism has been removed—the claim that, qua Fregean, it must endorse transparency of sameness of content but that, qua anti-individualist, it must reject it. The standard argument that non-Fregean antiindividualism is incompatible with transparency of

<!-- page: pdf=0238 printed=none -->

sameness of content does not apply to Fregean antiindividualism. And, Campbell’s argument that his Fregean anti-individualist view is incompatible with transparency of sense does not undermine transparency of sameness of content. However, I will argue that the coherence of Fregean anti-individualism is threatened in a different way: Fregean anti-individualism is incompatible with transparency of difference of content (sec. 4), but this makes it hard to motivate the key assumptions behind the Fregean argument for sense, namely, transparency of sameness of content and the related conception of rationality (sec. 5). 

### **4 Fregean Anti-Individualism and Transparency of Difference** 

The last chapter established the conclusion that antiindividualist positions that accept the two-concept view of slow switch cases are incompatible with transparency of difference of content. Since I aim to use this result to show that there is a tension in Fregean anti-individualism, it is important to show in detail how the conclusion of the last chapter applies to Fregean anti-individualism and to attempt to broaden the range of anti-individualist views to which this conclusion applies. After summarizing the slow switch argument from the last chapter, I show how it applies to the kind of position characteristic of modern Fregean antiindividualism, Fregean anti-individualism about singular thought. I then use an argument due to Bryan Frances to show that transparency of difference of content is threatened not only by the two-concept version of anti-individualism but by any version. (Frances’s argument that antiindividualism is incompatible with transparency of difference of content does not show that anti-individualism leads the subject to make mistakes in reasoning and so was

<!-- page: pdf=0239 printed=none -->

Anti-Individualism and Fregean Sense 

not mentioned in the discussion of anti-individualism and reasoning in chapter 5.) 

In the last chapter, I argued that the two-concept version of anti-individualism undermines transparency of difference of content. The argument concerned a subject Sally, who, as a result of a slow switch, acquires two different concepts—aluminum and twaluminum—which she expresses with the single term ‘aluminum’. The concept aluminum figures in beliefs based on memories of events on Earth, such as the belief she expresses with ‘Aluminum is mined in Australia’. By contrast, the concept twaluminum figures in beliefs acquired on Twin Earth, through interactions with Twin Earth speakers and twaluminum itself, such as the belief she would express with ‘Aluminum is mined in the Soviet Union’. Since Sally is ignorant of the switch, she is ignorant of the fact that she expresses two distinct concepts with the term ‘aluminum’. She could come to realize that she does so only by gaining empirical information about the switch. Thus, on the two-concept reading, the case is a counterexample to the transparency of difference of content: for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents then, at _t_ , _S_ can realize a priori that they have different contents. Further, I argued that since Sally is ignorant of the fact that she expresses two distinct concepts with ‘aluminum’ she might make simple invalid inferences, say, from the beliefs she expresses with ‘Aluminum is mined in Australia’ and ‘Aluminum is mined in the Soviet Union’ to the conclusion that a single substance is mined in both Australia and the Soviet Union. To know that the inference is invalid, she needs empirical information about the switch. 

Not all anti-individualists accept the two-concept view. However, the two-concept view may be defended on the widely held anti-individualist view that a subject’s thought

<!-- page: pdf=0240 printed=none -->

contents depend on historical relations, and by appeal to the function of memory (Burge 1998). Further, I rejected two ways of arguing that even if Sally expresses two distinct concepts with ‘aluminum’, this does not lead her to make invalid inferences: (1) Burge’s view that even if she has distinct concepts, they cannot both figure in a single inference; and (2) the view that the relevant inference involves a (false) identity premise (Aluminum is aluminum) so that it is unsound rather than invalid. It seems, then, that any antiindividualist who accepts the two-concept view should reject transparency of difference of content and accept that a subject may make simple invalid inferences. 

For the purposes of this chapter, it is important to note that the Fregean cannot use the notion of sense to avoid this conclusion. In particular, a Fregean cannot reply to the slow switch argument concerning transparency of difference of content in a way analogous to the way she replied to the argument concerning transparency of sameness. Faced with a putative example of a subject who has two thought constituents with the same referent and content but who fails to realize that they have the same content, the Fregean argues that the two constituents differ in sense and thus content. Thus, according to the Fregean, the example is not a counterexample to transparency of sameness of content. However, the Fregean cannot respond in an analogous way to a putative example in which a subject has two thought constituents with different referents and contents although the subject fails to realize this. The notion of sense may introduce further differences between the contents of the two thought constituents but cannot be used to argue that those constituents have the same content. 

Given our concern in this chapter with the viability of Fregean anti-individualism, it is important to apply the slow

<!-- page: pdf=0241 printed=none -->

Anti-Individualism and Fregean Sense 

switch argument to the type of view characteristic of modern Fregean anti-individualism, namely, Fregean antiindividualism about singular thoughts. Someone might wonder whether the slow switch argument applies to thoughts about individuals rather than thoughts about kinds, as in the aluminum example. In particular, she might wonder if the argument applies to those modern Fregean anti-individualist views, e.g., the views of Evans and Campbell, which endorse tougher requirements on thought than non-Fregean anti-individualist views. So, I will spend some time applying the slow switch argument to the Fregean anti-individualist view that when a subject thinks demonstratively about an object, the content of the demonstrative component of her thought is individuated by the object thought about and an object-dependent sense. 

Suppose that a subject, Eve, takes herself to be looking at a particular apple and attempts to think the inference she would express with: 

- (1) That apple is green. 

- (2) That apple is from New Zealand. 

- (3) Something is green and from New Zealand. 

Consider a possible situation in which, between Eve’s thinking of the first and second premises, someone substitutes a different but indistinguishable apple. Thus, when she attempts to think the thought she would express with (1), she is looking at apple _a_ , whereas when she attempts to think the thought she would express with (2), she is looking at a different apple, _b_ . The case would constitute a counterexample to the transparency of difference of content if, by (1) and (2), Eve expresses thoughts whose demonstrative components have different referents and contents. Since Eve

<!-- page: pdf=0242 printed=none -->

is unaware of the switch, she would not realize that the demonstrative components differ in content, and she could realize this only by using empirical information about the switch. Further, on the two-concept view of the case, it is hard to deny that Eve would be disposed to make simple invalid inferences, say from (1) and (2) to (3). Recall, in the last chapter, our rejection of the two main ways of arguing that the two-concept view need not lead a subject to make simple invalid inferences. So, the key question is whether one should accept the two-concept view of the Eve case. 

It may seem easy to support the two-concept view merely by pointing out that Eve is looking at different apples when she attempts to think the thoughts she would express with (1) and (2). However, the issue is less straightforward on some developed Fregean accounts that connect perceptual demonstrative thought with the ability to track objects over time and across sensory modalities. For instance, Evans and Campbell hold that if a subject perceptually tracks an object over a time period then she may think of it via the same sense over this period. However, they argue that, if she loses track of the object, then she fails to have a perceptual demonstrative thought and instead suffers an illusion of thought. On this view, it may be argued that since Eve loses track of the apples during the switch, she fails to think a thought corresponding to either (1) or (2). If that is right, then the case is not a counterexample to the transparency of difference of content: for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents, then, at _t_ , _S_ can realize a priori that they have different contents. On the view suggested instead of having two thoughts with different contents, she suffers an illusion of thought. Further, on this view, Eve does not make a

<!-- page: pdf=0243 printed=none -->

Anti-Individualism and Fregean Sense 215 

simple invalid inference, but rather suffers an illusion of making an inference. 

We could overcome this first problem for the two-concept view by modifying the Eve case. Even if the ability to think demonstrative thoughts is connected to the ability to keep track of objects, this surely cannot amount to the requirement that for a subject to think demonstratively about an object at a time, she must not lose track of it at any later time. This seems far too demanding. Instead, Fregeans should and do allow that a subject can think about an object if she keeps track of it over a substantial period of time, even if she later loses track of it (see, e.g., Evans 1982, pp. 195–196). So, we could overcome the tracking objection by modifying the case so that Eve tracks apple _a_ for a sufficient period to have thoughts about it before the switch, after which she tracks apple _b_ for a sufficient length of time to have thoughts about it. With this view in place, we could appeal to memory links to argue that, after the switch, Eve has the ability to think about both apple _a_ and apple _b_ . For example, Eve’s thought that that apple is green is based on her memory of seeing apple _a_ and is about _a_ ; by contrast, her thought that that apple is from New Zealand is based on her current perception of apple _b_ and is about apple _b_ . So, the view that demonstratives are connected with our abilities to track objects over time is compatible with the two-concept view. 

There is another strand to Evans’s thought, which would lead him to deny that even in the modified case Eve can think demonstratively both about apple _a_ and apple _b_ . As we saw in chapter 3, Evans argues that a subject can think about an object only if she can distinguish it from every other object. In the case of a spatiotemporal object, this requires that to think of an object, a subject must know

<!-- page: pdf=0244 printed=none -->

where the object is located, or know what it is for an object so located to be the relevant object: “[A]n adequate Idea of an object involves either the conception of it as the occupant of such-and-such a position (at such-and-such a time), or knowledge of what it is for an object so identified to be the relevant object . . .” (1982, p. 149). Consider Eve in the modified case after the apples have been switched. It seems that she can meet Evans’s discrimination requirement for thinking about apple _b_ , since she can, for instance, pick out apple _b_ . However, she no longer knows where apple _a_ is located. In addition, it seems that she does not know what it is for an apple located at a certain place and time to be _a_ . After all, she is ignorant of the switch and falsely supposes that she has been seeing just one apple over the entire period.<sup>5</sup> So, Evans would deny that she can think demonstratively about apple _a_ and apple _b_ . Thus, he would deny that the case is a counterexample to the transparency of difference of content. 

However, Evans’s discrimination requirement has not been widely accepted by anti-individualists. It is rejected by those, such as causal theorists and teleofunctionalists, who argue that the content of a thought is fixed by past historical factors, not the subject’s current state and dispositions. Evans’s requirement has also been rejected by many of those who hope to combine anti-individualism and the Fregean tradition (e.g., Peacocke 1983, p. 171; Brewer 1999, pp. 251–252). Thus, at best, Evans’s argument shows only that transparency of difference of content is compatible with a narrow class of anti-individualist views, namely, those that endorse Evans’s discrimination requirement. 

In conclusion, the slow switch case can be applied to both non-Fregean and Fregean versions of anti-individualism that accept the two-concept view. Fregeans cannot reject the slow switch argument for the incompatibility of

<!-- page: pdf=0245 printed=none -->

Anti-Individualism and Fregean Sense 

217 

anti-individualism and transparency of difference of content in the same way they responded to the argument for the incompatibility of anti-individualism and transparency of sameness of content. Further, we have applied the slow switch argument to the paradigm case to which Fregean anti-individualists apply their view, the case of perceptual demonstrative thoughts. We have seen how one can defend the two-concept view even if perceptual demonstrative thoughts are connected to perceptual tracking. Admittedly Evans would reject the two-concept view because of his discrimination requirement for thought. But this restrictive requirement would be rejected by many anti-individualists, including Fregean anti-individualists. Thus, it seems that many Fregean anti-individualists should reject transparency of difference of content and accept that a subject may make simple invalid inferences. 

In section 5 I argue that there is a tension between the rejection of the transparency of difference of content and the key assumptions of the argument for Fregean sense, namely, transparency of sameness of content and the related conception of rationality. This tension is more problematic the wider the class of anti-individualist views that are incompatible with transparency of difference of content. So, it is worthwhile examining Frances’s argument for the incompatibility of anti-individualism and transparency of difference of content, which is intended to apply to any anti-individualist view and not just to the two-concept version. 

### **_4.1 Frances’s Einsteinium/Fermium Case_** 

In Frances’s example, a subject, say, Clara, is acquainted with the terms ‘Einsteinium’ and ‘Fermium’ and knows that

<!-- page: pdf=0246 printed=none -->

each names an element. She is ignorant that they name distinct elements and ignorant of their chemical composition. However, she has such causal and/or deferential relations that an anti-individualist would accept that she has beliefs involving the concepts of these elements.<sup>6</sup> For example, Clara believes that Einsteinium is an element and that Fermium is an element. However, she wonders whether her two beliefs have the same content, since she is unsure whether ‘Einsteinium’ and ‘Fermium’ name the same element. After all, many elements high in the periodic table have had several names. Given that Clara’s beliefs refer to different elements, they in fact have different contents. But, Clara can know that they have different referents only empirically by gaining knowledge either about the relevant natural kinds, or about linguistic practice. Thus, Clara can realize that the two beliefs have different contents only empirically, and transparency of difference of content is false. As Frances puts it: 

[T]he beliefs are distinct according to any plausible view of belief, at least in part since the elements are distinct, but there is nothing in [her] experiential history that provides [her] with the conceptual resources necessary to discriminate between the Einsteinium and Fermium thoughts; introspective reflection is inadequate here. Thus, it is false that if thought _A_ is not identical with thought _B_ , then I can know by reflection alone that thought _A_ is not identical with thought _B_ . (1999, pp. 216–217) 

Frances’s argument has wider application than the slow switch argument for the incompatibility of antiindividualism and transparency of difference of content. As we have seen, the slow switch argument applies only to anti-individualist positions that accept the two-concept view of slow switch cases. Frances’s argument has no such limitation. Given the way it is set up, Frances’s case ensures

<!-- page: pdf=0247 printed=none -->

Anti-Individualism and Fregean Sense 

219 

that the concepts Clara expresses by ‘Einsteinium’ and ‘Fermium’ have separate causal and deferential connections. Given Clara’s uncertainty about whether ‘Einsteinium’ and ‘Fermium’ refer to the same element, she would regard her Einsteinium beliefs as being correctly explicated by how the experts explain ‘Einsteinium’, and her Fermium beliefs as being correctly explicated by how the experts explain ‘Fermium’. Since these terms refer to different elements, the experts would explicate them differently. Further, her uncertainty about whether the elements are identical prevents her from putting Einsteinium and Fermium beliefs together in inference and thus helps preserve their distinct causal histories. The distinct causal and deferential relations of her Einsteinium and Fermium beliefs undermines the suggestion, which may be made in the slow switch case, that the subject has only one concept, not two. 

For instance, consider Heal’s view, which may be used to argue against the two-concept interpretation of the slow switch case. On Heal’s view, the concept expressed by a term in the mouth of a speaker at a time is determined by the samples and/or experts she would then regard as authoritative. We have seen that Frances’s subject would regard her Einsteinium beliefs as being correctly explicated by how the experts explain ‘Einsteinium’, and her Fermium beliefs as being correctly explicated by how the experts explain ‘Fermium’. Since the experts would explicate ‘Einsteinium’ and ‘Fermium’ differently, even Heal should agree that the subject expresses different concepts with ‘Einsteinium’ and ‘Fermium’. It seems, then, that unlike the slow-switch argument, Frances’s argument applies to any version of anti-individualism according to which content is individuated partly by the natural kinds present in the environment and/or by linguistic practices.

<!-- page: pdf=0248 printed=none -->

Given the broader scope of Frances’s argument, if it could be applied to Fregean anti-individualism it would show that all versions of this view are incompatible with transparency of difference of content, not just the two-concept version. However, someone might think that Frances’s case depends implicitly on a non-Fregean view. We need to rule out this worry to show that Frances’s argument applies to Fregean anti-individualism. 

At the core of Frances’s argument is the claim that Clara may think that the concepts she expresses with ‘Einsteinium’ and ‘Fermium’ have the same referent and therefore the same content. This chain of thought is coherent only if Clara implicitly takes a non-Fregean approach to content. Clara need not have heard of the Fregean and non-Fregean positions or the philosophical arguments for them. Nevertheless, the relevant train of thought would not be coherently available if she took the Fregean position according to which two concepts may have different contents even if they have the same referent. On this Fregean view, one cannot justify the claim that two concepts have the same content merely by noting that they have the same referent. As a result, one might wonder whether Frances’s argument can be non-question-beggingly applied to Fregean antiindividualism. Clearly, Frances’s argument would beg the question against the Fregean view if it relied on the truth of the non-Fregean view. However, it relies only on a subject’s accepting the non-Fregean view, whether or not it is true. Suppose that the Fregean view were correct and that the concepts Clara expresses with ‘Einsteinium’ and ‘Fermium’ differ in both sense and reference. This is compatible with Clara’s accepting the non-Fregean view and thinking that the concepts may have the same content since they may have the same referent.

<!-- page: pdf=0249 printed=none -->

Anti-Individualism and Fregean Sense 

221 

The Fregean may challenge Frances’s argument in a different way by arguing that, on the Fregean view, Clara may realize that the concepts she expresses with ‘Einsteinium’ and ‘Fermium’ have different contents without using empirical information. On the Fregean view, the concepts Clara expresses by ‘Einsteinium’ and ‘Fermium’ differ in both sense and reference. Clara can find out that the terms differ in reference only empirically. But, perhaps, she can realize a priori that they differ in sense. If the Fregean is right in supposing that content is determined by reference and sense, then this view is presumably established by philosophical arguments. Clara could use those arguments to gain a priori knowledge of the existence of sense and that it is partly individuated by potential difference of attitude. Since it is part of the case that Clara is unsure about whether ‘Einsteinium’ and ‘Fermium’ name the same element, she could potentially take different attitudes to thoughts she would express with these terms. For example, she might assent to ‘Einsteinium is rare’ but fail to assent to ‘Fermium is rare’. Clara can know a priori that she is unsure whether the relevant thoughts are about the same element and thus that she may rationally take different attitudes to thoughts about Einsteinium and Fermium. She may put these facts together with Fregean theory to gain a priori knowledge that the relevant concepts differ in content since they differ in sense. 

The core idea of this Fregean response is that Clara can know a priori that the concepts differ in content by acquiring a priori knowledge of Fregean theory via philosophical argument. However, this response fails to take proper account of the fact that many subjects are ignorant of Fregean theory and even some of those who know Fregean arguments remain unconvinced by them. It is implausible

<!-- page: pdf=0250 printed=none -->

to claim that if Frances’s subject is ignorant of, or unconvinced by, Fregean arguments, then she can realize a priori that the relevant concepts have different content, since if she were to acquire Fregean theory she could do so. Let us consider some different examples. Suppose that I am faced with a problem that can be solved only by using trigonometry but I am ignorant of that theory. It is surely counterintuitive to say that I can now solve the problem in virtue of the fact that if I were to learn trigonometry I could do so. Rather, before I learn the theory, I cannot solve the problem. Or, consider a mathematician considering a problem that can be solved only by using differential calculus at a time before its discovery. It is counterintuitive to say that she can solve the problem since if she were to develop the theory of differential calculus she could do so. Rather, before she learns of differential calculus, she cannot solve the problem. I conclude that one cannot defend the claim that Clara can realize a priori that the concepts she expresses with ‘Einsteinium’ and ‘Fermium’ have different contents in virtue of the fact that if she acquired Fregean theory she could do so.<sup>7</sup> 

It seems, then, that Frances’s argument is applicable to both Fregean and non-Fregean anti-individualism. The argument does not depend on the truth of the non-Fregean view, but only on the possibility that a subject implicitly accepts this view. Further, the Fregean cannot adequately reply to the argument by claiming that, if the subject were to acquire Fregean theory by philosophical argument, she could use it to gain a priori knowledge of the difference in content. To strengthen the case that Frances’s argument applies to Fregean anti-individualism, it is useful to apply it to the view typically defended by modern Fregean antiindividualists, namely, Fregean anti-individualism about perceptual demonstrative thoughts (earlier, we applied the

<!-- page: pdf=0251 printed=none -->

Anti-Individualism and Fregean Sense 223 

slow switch argument to Fregean auti-individualism about perceptual demonstrative thoughts). To see just how wide an application the argument has, consider Evans’s Fregean anti-individualist position. Evans places tougher requirements on having a thought than nearly any other antiindividualist, including Fregean anti-individualists. Thus, if Frances’s example can be applied to Evans’s position, it should be applicable to most, if not all, versions of singular anti-individualism. 

Evans argues that a subject can think about an object only if she can distinguish that object from all other objects. In the case of a spatiotemporal object, this requires that to think of an object, a subject must know where the object is located, or know what is for an object so located to be the relevant object (1982, p. 149). Perceiving an object normally allows a subject to think about it, since it usually allows a subject to discover what type of thing it is and to locate it. 

Suppose that Sally is in a concert hall listening to a live performance. The large symphony orchestra on stage includes four clarinetists. As Sally watches one of the clarinetists, she thinks the thought she would express with ‘That clarinetist is beautiful’. While still watching the player, Sally hears a lovely clarinet solo, and judges on the basis of the sound the thought she would express with ‘That clarinetist is musical’. Sally then wonders whether the two demonstrative thought constituents have the same content, since she wonders whether the clarinetist she hears is identical with the clarinetist she is watching. In fact, the two clarinetists are distinct. As in Frances’s original example, the fact that Sally is unsure about whether the two thought constituents have the same referent prevents her from putting the relevant beliefs together in inference and thus helps to preserve their distinct causal histories. Thus, a causal

<!-- page: pdf=0252 printed=none -->

theorist about content should accept that the two thought constituents differ in content. 

Further, the example meets even Evans’s tough conditions for thought. Each of the perceptual relations in which the subject stands suffices for her to identify the type of object in question (a clarinetist) and where the object is. For it to be a live issue for Sally whether the heard and seen clarinetists are one and the same, we must suppose that she has not yet located both of them. However, on Evans’s view, that is compatible with her having demonstrative thoughts about each one; having a perceptual demonstrative thought about an object requires only that one is able to locate it, not that one already has (1982, p. 172). Thus, Sally has two thoughts, which differ in content. However, she may wonder whether they have the same content since she thinks they may have the same referent. She could come to know that they differ in content only by acquiring empirical information that they differ in reference. For example, she might watch the seen clarinetist to see whether her hands move in the appropriate way for the sounds she is hearing. (We saw above that the Fregean cannot argue that a subject can realize a priori that the thoughts differ in content by using knowledge of philosophical arguments for the existence and nature of sense.) Thus, Evans’s antiindividualist account of singular thought is incompatible with the transparency of difference of content. 

This discussion of Frances’s argument shows that any version of anti-individualism, whether Fregean or not, is incompatible with transparency of difference of content. As a result, any version of anti-individualism should accept that even a rational subject may be unable to grasp certain simple logical relations between her thoughts without using empirical information. In the slow switch example, Sally

<!-- page: pdf=0253 printed=none -->

Anti-Individualism and Fregean Sense 

225 

cannot realize a priori that she has two distinct concepts that she expresses with the term ‘aluminum’. As a result, she would be disposed to make simple invalid inferences. For example, she might combine the beliefs she would express with ‘Aluminum is mined in Australia’ and ‘Aluminum is mined in the Soviet Union’ to conclude invalidly that some substance is mined in both Australia and the Soviet Union. Since she cannot realize a priori that she expresses two distinct concepts with ‘aluminum’, she cannot realize a priori that the inference is invalid. 

Frances’s example establishes a similar conclusion.<sup>8</sup> Consider the beliefs Sally would express with ‘That clarinetist is beautiful’ and ‘That clarinetist is musical’. Since the two demonstrative thought constituents refer to different clarinetists, they have different contents. However, Sally is unsure about whether the thought constituents have different referents and contents, and cannot realize a priori that they have different contents. As a result, she would be unsure whether these two beliefs can be combined together in a valid inference, say, to the conclusion that some clarinetist is beautiful and musical. To realize that the inference is invalid she needs to realize that the demonstratives have different contents. But, she cannot realize a priori that they have different contents. It seems, then, that any version of anti-individualism must reject transparency of difference of content and hold that a subject cannot always grasp a priori that a simple invalid inference is invalid. 

### **5 Fregean Anti-Individualism** 

We are now in a position to consider whether the notion of sense is compatible with anti-individualism. In the last section, I argued in detail that any version of anti-

<!-- page: pdf=0254 printed=none -->

individualism, whether Fregean or not, is incompatible with transparency of difference of content, the claim that for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents, then, at _t_ , _S_ can realize a priori that they have different contents. As a result, any version of anti-individualism should accept that a rational subject cannot always realize a priori that a simple invalid inference is invalid. In addition, the slow switch case involves a subject making a simple invalid inference. 

Earlier in the chapter (sec. 2), we examined the classic arguments for Fregean sense and saw that they depend on two key assumptions: transparency of sameness of content and a certain connected view of a rational subject. According to the transparency of sameness of content, for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content, then, at _t_ , _S_ can realize a priori that they have the same content. According to the accompanying conception of rationality, at least in simple cases, a rational subject can always realize a priori that an inference is valid, or that a pair of beliefs is contradictory, and would not hold contradictory beliefs or fail to make simple valid inferences. 

These results may make us wonder if it is coherent to combine Fregean sense and anti-individualism as the Fregean anti-individualist tries to do. _Qua_ Fregean, the Fregean anti-individualist assumes transparency of sameness of content; _qua_ anti-individualist, she denies transparency of difference of content. It seems curiously asymmetric for a single position to affirm transparency of sameness of content but deny transparency of difference of content. Furthermore, _qua_ Fregean, the Fregean antiindividualist insists that a rational subject can always grasp a priori simple instances of validity and contradiction,

<!-- page: pdf=0255 printed=none -->

Anti-Individualism and Fregean Sense 

227 

but _qua_ anti-individualist she accepts that a rational subject cannot always grasp a priori simple instances of invalidity. What could motivate the view that a rational subject can grasp a priori simple instances of some logical properties but not others? Last, _qua_ Fregean, the Fregean anti-individualist insists that a rational subject would make simple valid inferences and would not have contradictory beliefs but, _qua_ anti-individualist, allows that a rational subject may make simple invalid inferences. What could motivate the view that a rational subject could make only one of these sorts of simple logical mistake? 

Someone might wonder whether the claims made by Fregean anti-individualism are logically compatible. If they were incompatible, then this would provide a quick route to the conclusion I am defending, that there is a tension in combining anti-individualism and Fregean sense. Consider the combination of affirming transparency of sameness of content but denying transparency of difference of content. Transparency of sameness of content and transparency of difference of content make claims about different kinds of case: transparency of sameness of content makes a claim about cases where a subject has two thoughts with the same content; transparency of difference of content makes a claim about cases where a subject has two thoughts with different contents. Given this distinction, it is not straightforwardly incompatible to hold transparency of sameness of content but deny transparency of difference of content.<sup>9</sup> Assume transparency of difference of content is false, and thus that a subject may have two thoughts with different contents at a single time, although she cannot realize this a priori. It does not follow that transparency of sameness of content is false, and that a subject may have two thoughts with the same content at a single time, while being unable to realize

<!-- page: pdf=0256 printed=none -->

this a priori. An analogy may help. Suppose that _S_ is red/green color-blind and cannot distinguish red and green, although she is ignorant of her condition. It follows that, in some cases where _S_ looks at two samples, each of a different color, she falsely believes that they are the same. It does not follow that there are any cases where she looks at two samples of the same color and judges falsely that they are different colors. 

Similarly, it is not inconsistent to hold that a rational subject can always grasp a priori simple cases of validity and contradiction, but cannot always grasp a priori simple instances of invalidity. Since these claims concern different types of case they are not directly incompatible. Suppose that a subject supposes that a simple inference is valid when it is invalid, and that she cannot correct this mistake except empirically. It does not follow that there is a simple valid inference that she mistakenly supposes to be invalid where she can correct her mistake only empirically. Even if a subject sometimes thinks mistakenly that an invalid inference is valid, it does not follow that she ever thinks that a valid inference is invalid. 

However, even if the commitments of the Fregean notion of sense and anti-individualism are not logically incompatible, they seem to be in tension. Since transparency of sameness of content and the accompanying notion of rationality are key assumptions of the classic Fregean arguments for sense, those arguments are well motivated only to the extent that these assumptions are. But it is hard to see how these assumptions could be well motivated for an antiindividualist. How could one motivate transparency of sameness of content if one denies transparency of difference of content? Why should someone suppose that sameness

<!-- page: pdf=0257 printed=none -->

Anti-Individualism and Fregean Sense 

of content is always graspable a priori even if difference of content is not? 

The Fregean anti-individualist insists that a rational subject can always grasp a priori simple instances of validity and contradiction. In the last chapter, I rejected this conception of a rational subject on grounds independent of the debate between individualism and anti-individualism. I am setting aside that objection here. Rather, I suggest that whether or not the Fregean conception of rationality is correct, it is hard to motivate if one also accepts antiindividualism: _qua_ Fregean, the Fregean anti-individualist insists that a rational subject can always grasp a priori simple instances of validity and contradiction, but _qua_ antiindividualist she accepts that a rational subject cannot always grasp a priori simple instances of invalidity. But what could motivate the view that it is part of the concept of a rational subject that she can grasp a priori simple instances of some logical properties if one accepts that she cannot grasp a priori equally simple instances of other logical properties? What could motivate the idea that a rational agent can always grasp simple instances of, say, validity, but not equally simple instances of invalidity? To put it slightly differently: _qua_ Fregean, the Fregean anti-individualist insists that a rational subject would make simple valid inferences and would not have contradictory beliefs but, _qua_ antiindividualist, she allows that a rational subject may make simple invalid inferences. But what could motivate the claim that it is part of the concept of a rational agent that she cannot make certain kinds of simple logical mistake, if one already allows that she can make other equally simple logical mistakes? What could motivate the view that a rational subject cannot have simple contradictory beliefs, if one

<!-- page: pdf=0258 printed=none -->

already accepts that she may make equally simple invalid inferences?<sup>10</sup> 

It seems, then, that Fregean sense and anti-individualism are in tension. The standard arguments for Fregean sense rely on assumptions about transparency and rationality that are hard to motivate if one also accepts anti-individualism. Notice that these problems do not arise for non-Fregean anti-individualism. As we have seen, the non-Fregean takes a symmetric attitude to transparency, denying both transparency of sameness and transparency of difference of content. As a result, the non-Fregean holds that a rational subject may be unable to grasp a priori simple instances of contradiction, validity, and invalidity. Further, non-Fregeans accept that a rational subject may make simple logical mistakes of a variety of kinds including making invalid inferences, forming contradictory beliefs, and failing to make valid inferences. 

This completes the discussion in this chapter and the last chapter of how anti-individualism affects a subject’s ability to reason. We have seen that all varieties of antiindividualism undermine transparency, although Fregean and non-Fregean versions of anti-individualism affect transparency differently. Fregean anti-individualism is compatible with transparency of sameness of content, whereas non-Fregean anti-individualism is not. Both Fregean and non-Fregean anti-individualism are incompatible with transparency of difference of content. Thus, antiindividualism of any sort has the result that a subject cannot always grasp a priori some of the simple logical relations between her thoughts. Some have taken this to show that anti-individualism undermines the idea that we are rational subjects. In the last chapter, I defended anti-individualism against this objection by arguing against the conception of

<!-- page: pdf=0259 printed=none -->

Anti-Individualism and Fregean Sense 

231 

a rational subject as one who can always grasp a priori simple instances of logical relations between her thoughts. In this chapter, I have set aside this conclusion about rationality and argued on independent grounds that there is a tension between Fregean sense and anti-individualism. If we cannot combine anti-individualism with the Fregean approach to psychological explanation, then we face a stark choice between anti-individualism and the Fregean explanation of key psychological data; those who are persuaded by the Fregean arguments for sense should reject anti-individualism.
