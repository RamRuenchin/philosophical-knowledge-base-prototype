---
title: "Chapter 7: The Reductio Argument: Transmission of Warrant"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 263
locator_end: 300
---

# Chapter 7: The Reductio Argument: Transmission of Warrant

<!-- page: pdf=0263 printed=none -->

**7** 

**The Reductio Argument: Transmission of Warrant** 

### **1 Introduction** 

Here, we return to the question of whether anti-individualism is compatible with privileged access, the view that a subject can have a priori knowledge of her thought contents. Unlike her knowledge of others’ thoughts, a subject’s knowledge of her own thoughts is typically not based on behavioral evidence. Further, although empirical investigation is used to form beliefs about the world, for example, whether Edinburgh is north of Glasgow, once a belief is formed one can know that one has a certain belief without further empirical investigation. Certainly, knowledge of one’s thoughts does not depend on empirical investigation into those aspects of one’s environment that anti-individualists claim partly individuate one’s thoughts, such as the chemical composition of substances, and the practices of one’s linguistic community. (Of course, a subject’s knowledge of her own conscious thoughts is based on those thoughts. However, throughout the book I have been following a well-established use of “a priori” on which knowledge may be a priori even though based on conscious thoughts. By contrast, knowledge based on perceptual

<!-- page: pdf=0264 printed=none -->

experience of the external world is empirical [see chap. 1, sec. 7.]) 

In the first part of the book we examined but rejected one problem for compatibility, the problem of how one can have privileged access to thought contents that are externally individuated. To put it in more detail, how can one have privileged access to one’s thoughts if what thoughts one has, and indeed whether one has a thought at all, depends on environmental facts of which one may be ignorant? Following Davies (1998), we may call this the _achievement problem_ . By contrast, this chapter and the next focus on what Davies calls the _consequence problem_ , the problem of what consequences follow from the joint assumptions of antiindividualism and privileged access. The achievement and consequence problems are distinct. Even if, as suggested in chapter 4, the achievement problem can be solved, the consequence problem might raise a further problem for compatibility. Conversely, even if the consequence problem presents no objection to compatibilism, the achievement problem might do so. Here I examine only the consequence problem and leave the achievement problem aside. 

To illustrate the consequence problem, consider natural kind anti-individualism. Suppose that Sally is an adult Earth subject who has interacted with water but is ignorant of its chemical composition. Natural kind anti-individualists claim that despite her ignorance Sally has the concept of water and has various beliefs involving that concept, such as that water is wet, that her environment contains water, and so on. Further, in virtue of their empirical grounding, many of these beliefs are also cases of empirical knowledge; for instance, she knows empirically that her environment contains water. According to the assumption of privileged access, a subject can have a priori knowledge of her thought

<!-- page: pdf=0265 printed=none -->

contents. Thus, Sally can have a priori knowledge that she thinks that water is wet. According to anti-individualism, whether a subject has certain concepts depends partly on her environment. Some have argued that it follows from anti-individualism that a subject who is ignorant of the chemical composition of water can have the concept of water only if she is in a certain kind of environment. As we will see in the next chapter, there has been some debate about precisely what entailments from thought to the environment anti-individualism is committed to. But, for simplicity, assume that Sally can have the concept of water only if water exists in her environment (or has existed; I will leave this qualification implicit in what follows). 

It has been further argued that, since anti-individualism is a philosophical theory established using philosophical arguments, a subject could use those arguments to gain a priori knowledge of anti-individualism and its consequences. If that is right, then Sally can know a priori that if she thinks that water is wet, then her environment contains water. But, then, Sally could combine this knowledge with her a priori knowledge of her thought content to gain a priori knowledge that her environment contains water. Thus, the assumptions of privileged access and antiindividualism seem to show that Sally can have a priori knowledge of the nature of her environment, that it contains water. 

We have already seen that Sally has empirical knowledge that her environment contains water. But it seems strange indeed that she could also have an a priori route to knowledge of this fact. Surely, a subject can know that her environment contains a particular natural kind only by empirical investigation. For example, surely one could know whether a certain country contains reserves of natural

<!-- page: pdf=0266 printed=none -->

gas only by empirical investigation. If it is indeed absurd that Sally could have a priori knowledge that her environment contains water, then the above line of reasoning constitutes a reductio of the joint assumptions of antiindividualism and privileged access (McKinsey 1991; Brown 1995; Boghossian 1997; Davies 1998, 2000; Wright 2000). We can formulate the main steps of the argument as follows: 

(R1) Sally can know a priori that she thinks that water is wet. _(From the assumption of privileged access.)_ 

(R2) Sally can know a priori that if she thinks that water is wet, then her environment contains water. _(From the assumption of anti-individualism.)_ 

(R3) Sally can know a priori that her environment contains water. _(From (R1) and (R2).)_ 

(R4) But (R3) is absurd. 

(R5) So, anti-individualism and privileged access are incompatible. _(From (R1)–(R4).)_ 

Although I have stated the argument using the notion of a priori knowledge, it could be formulated independently of this notion: if it is both the case that anti-individualism is true and a subject can have introspective knowledge of her thought contents, then a subject could gain knowledge of substantive facts about the world merely by reflection on her thought contents and thinking through the philosophical arguments for anti-individualism. But, surely, it’s implausible that a subject could have knowledge, say, that her environment contains a certain natural kind just by reflection on her thoughts and a bit of philosophy or, as Davies puts it, merely by “armchair reflection” (Davies 2000, p. 386). Those who prefer not to term a subject’s knowledge of her own

<!-- page: pdf=0267 printed=none -->

thoughts “a priori” should rephrase the following discussion as suggested. 

Someone might challenge (R1) arguing that it is undermined by the anti-individualism underlying (R2). In particular, they may say, how can Sally know a priori that she thinks that water is wet when, by (R2), her having this thought requires the empirical fact that her environment contains water? This worry is misguided in two ways. First, (R1) follows from one of the assumptions of the argument, the assumption of privileged access. Second, the worry seems to be merely a restatement of the achievement problem: how can a subject have privileged access to the contents of thoughts that are externally individuated? But, we have already seen that the achievement problem is irrelevant to the consequence problem, which merely considers what consequences would follow if anti-individualism and privileged access were both true. It is silent about whether the achievement problem has been solved: it merely asks us to assume both privileged access and anti-individualism for the purposes of reductio. In any case, note that doubt about the cotenability of (R1) and (R2) cannot be used as a way of defending the compatibility of anti-individualism and privileged access. 

Someone might question whether (R2) follows from the assumption of anti-individualism. First, she might question whether anti-individualism supports any entailment between thought and the environment that is suitable for the argument. I will examine this response in the next chapter. Second, even if anti-individualism does support such an entailment, she might question whether it’s knowable a priori. After all, not all subjects have heard of antiindividualism, let alone know the philosophical arguments for this position. However, some subjects do have such

<!-- page: pdf=0268 printed=none -->

knowledge, and let us suppose that Sally is one of them. It would be problematic if a subject with knowledge of the philosophical arguments for anti-individualism could use them to gain a priori knowledge of her environment even if a subject ignorant of those arguments could not do so. 

Another main line of response has been to deny (R4) and argue that it is not absurd to suppose that Sally can have a priori knowledge that her environment contains water. This line of thought is often supported by pointing out that Sally already has empirical knowledge that her environment contains water (see, e.g., Sawyer 1998, p. 532; Brewer 1999, p. 267; DeRose 2000). If it is not absurd that Sally could come to have a priori knowledge of her environment, then it is not an objection to compatibilism that it has this consequence. Rather, it might be an advantage. If Sally can know a priori that her environment contains water, it seems that she can also know a priori that there is an external world. Thus, on this alternative view, compatibilism would provide an answer to skeptics who claim that we cannot have knowledge of the nature and existence of the external world (Warfield, 1994 1998; Sawyer 1998). 

However, the suggestion that it is not absurd to suppose that subjects can have a priori knowledge of substantive facts about the environment is unconvincing. Consider the point that compatibilism would enable a subject to gain a priori knowledge only of propositions of which she already has empirical knowledge. As Davies points out, it was part of the set up of the argument that Sally already knows that her environment contains water on empirical grounds. Despite this, it seems problematic to suppose that, in addition, Sally has an a priori route to this same claim. Compare the case of natural gas: even if someone has empirical knowledge that a certain country has reserves of natural gas, it seems problematic to suppose that she also has an a priori

<!-- page: pdf=0269 printed=none -->

route to knowledge of this fact. Thus, in what follows, I take it that it is indeed absurd to suppose that Sally can have a priori knowledge that her environment contains water. 

The discussion in this chapter concentrates on a fourth line of response offered by Davies and Wright. They agree that it is absurd to suppose that Sally can have a priori knowledge of her environment, but, they argue, the joint assumptions of anti-individualism and privileged access do not have this result. They claim that (R3) does not follow from (R1) and (R2), arguing that even if a subject has a priori knowledge of her thought contents and that her having those thought contents requires certain facts about her environment, this does not enable her to gain a priori knowledge of her environment. 

In the following sections, I situate Davies’s and Wright’s view by contrasting it with the denial of the closure of knowledge. I then present and criticize several reasons for claiming that warrant and so knowledge fail to transmit across the inference relevant to the reductio. Although my discussion of Wright and Davies treats the Sally argument as a threat to compatibilism, it is also relevant to the rival view that the argument shows that anti-individualism and privileged access can together provide a response to skepticism: both ways of taking the argument assume that Sally can gain a priori knowledge of the world by combining her a priori knowledge of her thought contents and her a priori knowledge that her having those thought contents entails certain facts about her environment. 

### **2 Closure and Transmission** 

As we have seen, Davies and Wright challenge the reductio by arguing that even if a subject has a priori knowledge that she thinks that water is wet and that her thinking that water

<!-- page: pdf=0270 printed=none -->

is wet entails that her environment contains water, this does not enable her to gain a priori knowledge that her environment contains water. It is useful to present Davies’s and Wright’s view by focusing on the following simpler argument, which I will call the _water argument_ : 

(W1) I think that water is wet. 

(W2) If I think that water is wet, then my environment contains water. 

(W3) My environment contains water. 

In effect, Davies and Wright argue that even if Sally has a priori knowledge of (W1) and (W2) she cannot thereby gain a priori knowledge of (W3). Davies’s and Wright’s view may seem counterintuitive. The inference from (W1) to (W3) is a simple valid inference of the form: _p_ , if _p_ then _q_ , _q_ . But surely one can gain knowledge by thinking through a valid argument. Davies and Wright accept that one can often gain knowledge by thinking through a valid argument. However, they claim that this is not always the case. 

Nozick and Dretske famously argued that one cannot always use a valid argument to gain knowledge of its conclusion. Consider the following inference: 

(BIV1) I see a table in front of me. 

(BIV2) If I see a table in front of me, then it’s not the case that I have just become a BIV.<sup>1</sup> 

(BIV3) It’s not the case that I have just become a BIV. 

Suppose that a subject is in ordinary circumstances and seems to see a table in front of her. We would ordinarily suppose that her experience gives her warrant and knowl-

<!-- page: pdf=0271 printed=none -->

edge of (BIV1). Further, it seems that she can know (BIV2) merely by some minimal conceptual analysis. However, Nozick (1981) argues that even if a subject knows (BIV1) and (BIV2) she does not know (BIV3). On his account of knowledge, _S_ knows that _p_ only if, were _p_ false, she would not believe that _p_ . However, if the subject had just become a BIV, then she would still believe that she has not just become a BIV. Thus, Nozick denies the closure of knowledge, the claim that whenever a subject knows the premises of a valid argument and believes in its conclusion on the basis of her recognition of its validity, her belief in the conclusion constitutes knowledge.<sup>2</sup> Dretske (1970) similarly argues that the following inference is a counterexample to the closure of knowledge: 

(Z1) The animal in the pen is a zebra. 

(Z2) If the animal in the pen is a zebra, then it is not a disguised mule. 

(Z3) The animal in the pen is not a disguised mule. 

However, the denial of closure cannot be used to support the Davies/Wright response to the reductio argument. It is implausible to claim that even if Sally has knowledge of (W1) and (W2), she lacks knowledge of (W3). According to the anti-individualist view that is the target of the reductio, Sally has the concept of water in virtue of her past interactions with water; she has drunk it, showered in it, swum in it, and so on. These seem just the right kind of interactions to give her empirical knowledge that water exists. Thus, if Sally has had the kind of empirical interactions required for her to have the concept water and thus entertain the premises (W1) and (W2), she has empirical knowledge of (W3), that her environment contains water. Relatedly, Sally’s

<!-- page: pdf=0272 printed=none -->

belief that her environment contains water does meet Nozick’s necessary condition for knowledge. Given the antiindividualist view that is the target of the reductio, if Sally’s environment did not contain water, then she would lack the concept of water and thus would not believe that her environment contains water. 

Davies and Wright defend a more limited claim than Nozick and Dretske. Roughly, instead of arguing that there are cases in which someone knows the premises of an argument but fails to know its conclusion, they argue that there are cases in which someone knows the premises but fails to know the conclusion in one particular way—by inference from the premises. More precisely, they argue that the water argument is a counterexample to the transmission of knowledge, the claim that whenever a subject knows the premises of a valid argument and believes its conclusion on the basis of her recognition of its validity, her belief in the conclusion thereby constitutes knowledge.<sup>3</sup> The main difference between closure and transmission is that the closure principle makes no claim about what makes the subject’s belief in the conclusion knowledge, whereas the transmission principle claims that her belief in the conclusion constitutes knowledge in virtue of the fact that it is inferred from the known premises of an inference that is known to be valid. If knowledge fails to transmit across the water argument, then one cannot gain a priori knowledge that one’s environment contains water by inference from one’s a priori knowledge of one’s thoughts and one’s a priori knowledge of entailments from one’s thoughts to the environment. Thus, even if anti-individualism and privileged access were both true, they would not have the absurd result that one can gain a priori knowledge of one’s environment merely by reflection on one’s thoughts and philosophy.

<!-- page: pdf=0273 printed=none -->

Given the difference between closure and transmission, failure of transmission of knowledge does not entail failure of closure of knowledge. Even if knowledge fails to transmit from the premises of a valid argument to its conclusion, it may be that anyone who has knowledge of the premises would independently have knowledge of the conclusion. For example, even if the water argument is a counterexample to the transmission of knowledge, it is not a counterexample to closure. However, if there are counterexamples to the closure of knowledge, they are also counterexamples to transmission: if a subject fails to know the conclusion of a valid argument on any basis, then she fails to know it on the basis of inference from its premises. 

Davies and Wright argue that the water argument is one example of a wider class of arguments in which knowledge fails to transmit, including the zebra and BIV arguments, as well as Moore’s “proof” of the external world. They argue that knowledge fails to transmit across these arguments since warrant is a necessary condition for knowledge, and these arguments are counterexamples to the transmission of warrant, the claim that whenever a subject has warrant for the premises of a valid argument and believes its conclusion on the basis of her recognition of its validity, she thereby acquires warrant for its conclusion. 

From now on, I will focus on whether the relevant arguments are counterexamples to the transmission of warrant. From Davies’s and Wright’s work, we can distinguish three reasons for a failure of transmission of warrant: that the arguments are circular, that anyone sane who doubts the conclusion would have background beliefs relative to which the alleged evidence for the premises would be no evidence, and that warrant for the premises fails to rule out the relevant alternatives to the conclusion. Davies and Wright place

<!-- page: pdf=0274 printed=none -->

different emphasis on these ideas: Wright stresses the first idea whereas Davies stresses the latter two ideas. My presentation reflects this difference of emphasis. However, it should not be taken to suggest that there is no commonality between their views; indeed one can find each of these three ideas in both Davies’s and Wright’s work. 

### **3 Wright and Conditional Warrant** 

Wright argues that warrant fails to transmit across the water, BIV, and zebra arguments since these arguments are implicitly circular.<sup>4</sup> One simple example of a circular argument is one whose premises contain its conclusion. Such an argument could not move one to rational conviction of its conclusion. Rather, only someone who is already rationally persuaded of the conclusion would be rationally persuaded of the premises. Thus, warrant fails to transmit across such arguments: warrant for the premises cannot provide one with a warrant to accept the conclusion (Wright 2000, pp. 140–141). 

The water argument is not explicitly circular. However, Wright argues that it fits a certain template and that any argument fitting this template is implicitly circular. More specifically, he claims that, for any argument meeting his template, having warrant for its first premise is conditional on having prior and independent warrant for its conclusion. Thus, one cannot acquire warrant for the conclusion from one’s warrant for the premises. Rather, one must already have independent warrant for the conclusion in order to have warrant for the premises, and the inference is a counterexample to the transmission of warrant. An argument fits the template if it is of form [A, (if A then B), B] and meets the following conditions:

<!-- page: pdf=0275 printed=none -->

(i) A entails B. 

(ii) There is a proposition C incompatible with A. 

(iii) My warrant for A consists in my being in a state that is subjectively indistinguishable from a state in which C would be true. 

(iv) C would be true if B were false. (Wright 2000, p. 155)<sup>5</sup> 

Suppose that (iii) holds, that is, my warrant for the premise A consists in my being in a state subjectively indistinguishable from a state in which the incompatible C would be true. Given this, Wright argues that my warrant for A entitles me to move beyond the disjunction (A or C) only if I have prior and independent entitlement to discount C. Further, he holds that since (iv) C would be true if B were false, it follows that I have warrant for A only if I have prior and independent entitlement to B (ibid.). Thus, warrant for premise A is conditional on prior and independent entitlement for the conclusion B. Wright concludes that, for any argument that meets his template, warrant for the premise A is conditional on prior and independent warrant for the conclusion, B. Thus, any such argument is characterized by a failure of transmission of warrant. 

We may illustrate Wright’s view with the zebra argument: 

(Z1) The animal in the pen is a zebra. 

(Z2) If the animal in the pen is a zebra, then it is not a cleverly disguised mule. 

(Z3) The animal in the pen is not a cleverly disguised mule. 

This fits Wright’s template with A = ‘The animal in the pen is a zebra’; B = ‘The animal in the pen is not a cleverly

<!-- page: pdf=0276 printed=none -->

= disguised mule’; and C ‘The animal in the pen is a mule cleverly disguised to look like a zebra’. In particular, my warrant for A, ‘The animal in the pen is a zebra’, consists in my perception as of a striped horselike animal. This warrant is not only compatible with A but also with C, ‘The animal in the pen is a mule cleverly disguised to look like a zebra’. How, then, does my evidence entitle me to the claim that the animal in the pen is a zebra, rather than the more tentative disjunction (the animal in the pen is a zebra or a mule cleverly disguised to look like a zebra)? Wright argues that I am entitled to the claim that the animal is a zebra only if I am already entitled to discount the possibility that the animal is a cleverly disguised mule. But, the claim that the animal is a cleverly disguised mule is just the negation of the conclusion, B, ‘The animal in the pen is not a cleverly disguised mule’. So, my having warrant for A depends on my having prior and independent warrant for the conclusion, B (Wright 2000, pp. 155–156). 

I will now argue that Wright’s defense of a failure of transmission of warrant across the zebra, BIV, and water arguments faces several serious objections. As we have seen, at the heart of Wright’s case is his claim that, for any argument meeting his template, warrant for the first premise is conditional on prior and independent warrant for the conclusion. From now on, for brevity, I will use the expression _conditional analysis_ to refer to this claim of Wright’s. In the following sections, I argue that (1) many would reject Wright’s conditional analysis; (2) his analysis invites skepticism about whether we have warrant for ordinary claims; and (3) his solution to the reductio is no less problematic than the original puzzle it was designed to solve.<sup>6</sup>

<!-- page: pdf=0277 printed=none -->

### **_3.1 Challenging the Conditional Analysis_** 

To investigate Wright’s conditional analysis, let us focus on the zebra argument. According to Wright, one’s evidence as of seeing a striped horselike animal warrants the claim that the animal in the pen is a zebra (Z1) only if one has prior and independent warrant that the animal in the pen is not a disguised mule (Z3). We may start to examine Wright’s claim by first exploring our ordinary commonsense view of the warranting power of the experience as of seeing a striped horselike animal. Ordinarily, such experience would be taken as warranting (Z1) even though it does not rule out the possibility that the animal is instead a disguised mule and even if one lacks any positive evidence against that skeptical possibility. 

Of course, things would be different if one had positive reason to believe that the animal is a disguised mule, for example, if the local press had reported that the cash-starved zoo has been passing off fakes to an unsuspecting public. In that case, one’s perceptual experience as of a striped horselike animal would no longer warrant the claim that it is a zebra. It would regain its warranting power only if one acquired evidence against the skeptical possibility. But in the ordinary case, in which one has no reason to believe that the animal is a disguised mule, one’s perceptual evidence is taken to warrant the claim that the animal is a zebra even though one lacks any positive evidence against the skeptical possibility. That this is so is crucial to defending our epistemic situation against the skeptic. After all, one’s perceptual experience, say, of seeing a table, does not rule out the skeptical alternative that one has just become a BIV being stimulated to have nonveridical experiences. And the BIV hypothesis is designed so that one has no evidence

<!-- page: pdf=0278 printed=none -->

against it. So, if having warrant for claims about the external world required having evidence against the BIV hypothesis, then our experience would not warrant any claims about the external world. 

It seems, then, that according to our ordinary, commonsense view of the zebra case, unless there is positive reason for the disguised mule possibility, one’s evidence warrants (Z1) even if one has no positive evidence against the disguised mule possibility. That one has no evidence against the disguised mule possibility does not amount to the claim that one has positive warrant for the claim that what one is seeing is not a disguised mule. In general, one’s lacking evidence that not- _q_ does not entail that one has positive warrant that not- _q_ .<sup>7</sup> It seems, then, that our ordinary understanding of the zebra case provides a more minimal rival view to Wright’s. On this minimal view, one’s perceptual experience warrants the claim that the animal is a zebra even though one has no positive warrant against the possibility that it is a disguised mule. By contrast, on Wright’s view, one’s warrant for (Z1), the animal is a zebra, is conditional on one’s having prior and independent warrant for (Z3), the animal is not a disguised mule. If the more minimal view were correct, then Wright would not have shown that warrant fails to transmit across the zebra argument, for this more minimal view does not support the conditional analysis central to Wright’s argument for a failure of transmission of warrant. 

Can Wright rule out the more minimal analysis? Recall that Wright supported the conditional analysis of the zebra, BIV, and water arguments by claiming that they fit a certain template: they are arguments of the form “A, (if A then B), B,” where (i) A entails B; (ii) there is a proposition C incompatible with A; (iii) the subject’s warrant for A consists in a

<!-- page: pdf=0279 printed=none -->

state subjectively indistinguishable from one in which the incompatible proposition C would be the case; and (iv) C would be true if B were false. Given condition (iii), Wright argues that one has warrant for A only if one has prior and independent warrant against C: 

The key question is what, in the circumstances, can justify me in accepting A? Why not just reserve judgement and stay with the more tentative disjunction, “A or C”—for it is all the same which disjunct is true as far as what is subjectively apparent to me is concerned. The answer has to be, it would seem: because I am somehow additionally entitled to discount the other disjunct, C. . . . (Wright 2000, p. 155) 

Wright’s argument here seems to reflect an internalist epistemology that many would reject. Wright draws no distinction between possible substitutes for C in terms of how remote they are from the actual situation. For Wright, if the subject’s warrant for A consists in a state subjectively indistinguishable from one in which an incompatible proposition C would be true, then, no matter how bizarre C is, it raises the question of how one is entitled to move past the disjunction (A or C) to A. Wright argues that one is entitled to do so only if one has prior and independent entitlement to discount C. However, externalists argue that a subject’s epistemic position with respect to a proposition _p_ is undermined by only some of the alternatives to _p_ , those that are “relevant” or “nearby” (Goldman 1976, 1986; Nozick 1981). In addition, externalists reject the idea that a subject’s epistemological position with respect to a proposition depends exclusively on how things are subjectively for the subject. Instead, they insist that a subject may have warrant for, and knowledge of, one of two disjuncts in virtue of her external relations to that disjunct, even when the difference between the two disjuncts makes no subjective difference to her.

<!-- page: pdf=0280 printed=none -->

Thus, the concern that drives Wright to his conditional analysis need not be shared by externalists for whom epistemic entitlement is partly a matter of the subject’s relations to her environment. 

We can illustrate this by reference to Goldman’s reliabilist account of warrant, according to which a subject’s belief that _p_ is warranted only if produced by a reliable process, that is, one that tends to produce true beliefs and to inhibit false ones.<sup>8</sup> Consider the BIV argument. Wright’s analysis has the result that one has warrant for (BIV1), I am seeing a table, only if one has prior and independent warrant for (BIV3), It’s not the case that I have just become a BIV. This is because one’s warrant for (BIV1) consists in an experiential state that is subjectively indistinguishable from a state in which one has instead just become a BIV. However, Goldman would reject this conditional analysis. First, he would hold that whether I have warrant for (BIV1) depends on whether that belief was produced by a reliable process, independently of whether other beliefs such as (BIV3) are produced by such processes. Second, although Goldman holds that I have warrant for beliefs about what I see, he should reject the claim that I have prior and independent warrant for the belief that I have not just become a BIV. Perception provides one with a reliable process for producing beliefs about what one is seeing and thus, for Goldman, warrant for such beliefs. The most obvious reliable process for producing the belief that I have not just become a BIV is by inference from other beliefs, for example, by the inference from (BIV1) to (BIV3). However, this process cannot provide prior and independent warrant for the belief that I have not just become a BIV. Further, it seems that I have no evidence that I have not just become a BIV for, by hypothesis, everything would seem the same to me had that happened.

<!-- page: pdf=0281 printed=none -->

It seems, then, that I lack a reliable process for producing the belief that I have not just become a BIV that could provide prior and independent warrant for that belief. Thus, Goldman should reject the conditional analysis of the BIV arguments and similar arguments. (Goldman would accept the different claim that warrant for the first premise of the BIV argument depends on the truth of the conclusion, (BIV3). If (BIV3) were false, and I had just become a BIV, then forming beliefs about the external world on the basis of apparent perceptual experiences would no longer be a reliable belief-forming process. However, the view that warrant for the premises of an argument is conditional on the truth of the conclusion does not support a limitation on the transmission of warrant (see sec. 3.3)). 

In conclusion, it seems that many would reject Wright’s conditional analysis of arguments fitting his template. An alternative more minimal view is that one’s evidence warrants the premises of these arguments although it fails to rule out the possibility that the conclusion is false and one has no other positive warrant for the conclusion. Wright’s own argument for the conditional analysis seems to rest on an internalist epistemology that would be rejected by epistemological externalism.<sup>9</sup> This is particularly relevant to the reductio since it seems likely that many anti-individualists who hold that thought partly depends on the world would also adopt externalist epistemologies according to which one’s epistemic state depends partly on the world. 

### **_3.2 The Conditional Analysis and Skepticism_** 

In this section I argue that Wright’s conditional analysis raises a certain skeptical threat. According to Wright’s analysis, one’s warrant for the first premise of the zebra and BIV

<!-- page: pdf=0282 printed=none -->

arguments is conditional on one’s having prior and independent warrant for the conclusion. For example, one has warrant for (Z1), The animal in the pen is a zebra, only if one has prior and independent warrant for (Z3), The animal in the pen is not a disguised mule. Similarly, one has warrant for (BIV1), I am seeing a table, only if one has prior and independent warrant for (BIV3), I have not just become a BIV. Thus, the conditional analysis makes warrant for ordinary claims, such as that’s a zebra, depend on whether one has warrant against skeptical hypotheses, such as that’s not a disguised mule. But it may be doubted whether one has prior and independent warrant against such skeptical possibilities. If one lacks such warrant, then, on the conditional analysis, one also lacks warrant for the relevant ordinary claims. 

There are two ways in which one could have warrant against a skeptical hypothesis. First, one could have evidence against it. But we often take it that we have warrant for some ordinary claim even though we lack evidence against the relevant skeptical hypothesis. For example, experience as of a striped horselike animal is normally taken to warrant the claim that the animal in the pen is a zebra even if one has no evidence that it is not a disguised mule, e.g., one has not closely examined its hide, or taken evidence from an expert zoologist. Similarly, we ordinarily take ourselves to have warrant for such claims as that one is seeing a table even though one has no evidence against the skeptical hypothesis that one has just become a BIV. Indeed, if it were a requirement for having warrant for such claims that one has evidence against the BIV hypothesis, then we would lack warrant for any claims about the external world, for the BIV hypothesis is carefully designed to be consistent with

<!-- page: pdf=0283 printed=none -->

any possible evidence. So, one cannot have evidence that one is not a BIV. 

Second, it might be suggested that one could have warrant against a skeptical hypothesis without having evidence against it. For example, although there can be no empirical evidence against the BIV hypothesis, one might have a “standing” entitlement against it. However, it is not clear how one can have an entitlement against some hypothesis despite lacking any evidence against it. The situation does not seem obviously altered if, as in the BIV case, there could not possibly be any evidence against the hypothesis. Why not conclude that the nonavailability of such evidence shows that one cannot have warrant against the hypothesis, rather than suppose that this gives one a special kind of positive warrant against it—a standing entitlement? Even if we were to grant that one can have a standing entitlement against the BIV hypothesis, it seems implausible that one can have a standing entitlement against skeptical hypotheses for which empirical evidence is potentially available, for example, the hypothesis that the animals in the cage are disguised mules. Where empirical evidence is potentially available against some hypothesis, surely we can have warrant to discount the hypothesis only by gaining suitable evidence. 

It seems, then, that Wright’s analysis threatens warrant for, and knowledge of, ordinary claims. Take a proposition, _O_ , that we ordinarily take to be warranted on the basis of certain experiences. Skeptics attempt to undermine one’s warrant for, and knowledge of, _O_ by constructing a skeptical hypothesis, _SK_ , incompatible with _O_ , such that if _SK_ were true, one would be in a state subjectively indistinguishable from the state one is actually in. Wright argues

<!-- page: pdf=0284 printed=none -->

that in such a case one’s experience warrants _O_ only if one has a prior and independent reason to discount _SK_ . But it’s hard to see how one could have a warrant against _SK_ on the basis of no evidence. Some skeptical hypotheses are designed so that there is no possible evidence against them. Further, even if evidence against _SK_ is potentially available, we typically suppose that a subject can have warrant for _O_ without conducting the empirical investigations that might yield evidence against _SK_ . Thus, the conditional analysis threatens our warrant for, and knowledge of, ordinary propositions. 

### **_3.3 A Priori Entitlement_** 

So far I have argued that Wright’s conditional analysis of a failure of transmission of warrant would be rejected by many and raises skeptical worries. A third concern is whether the analysis provides a satisfactory solution to the reductio. Wright attempts to defend compatibilism by showing that the joint assumptions of privileged access and anti-individualism do not have the absurd result that a subject can have a priori knowledge of substantive facts about the world. On Wright’s view, even if a subject has a priori knowledge of the premises (W1), I think that water is wet, and (W2), If I think that water is wet, then my environment contains water, she cannot thereby gain a priori knowledge of the conclusion (W3), My environment contains water. As we have seen, Wright argues that warrant fails to transmit across an argument where warrant for one of the premises depends on prior and independent warrant for the conclusion. Applied to the water argument, his view is that warrant for the premise (W1), I think that water is wet, is conditional on prior and independent warrant for the

<!-- page: pdf=0285 printed=none -->

conclusion (W3), My environment contains water. Thus, at the heart of Wright’s response to the reductio are two claims: (1) a subject can have a priori knowledge of (W1); but (2) her warrant for (W1) is conditional on having prior and independent warrant for (W3). This raises the question of what kind of warrant the reductio subject has for (W3) on which her a priori warrant for (W1) is conditional. 

Suppose that the only prior warrant the reductio subject has for the conclusion (W3) were empirical. This might raise the worry that her warrant for the premise (W1) would also be empirical, for, on Wright’s view, her warrant for (W1) is conditional on her prior and independent warrant for (W3). But if this is correct, then the conditional analysis can be used to defend compatibilism only if the reductio subject has prior and independent a priori warrant for (W3), My environment contains water. This line of thinking is apparently endorsed by Wright himself, who says “[I]f one has a priori warrant for both premises of the McKinsey [i.e., the water] argument, it is courtesy of an a priori entitlement to discount the possibility of illusions of content, and hence to discount any scenario that would generate such an illusion” (2000, p. 217). Note that according to the kind of antiindividualism to which Wright thinks the reductio is suitably targeted, if one’s environment does not contain water, then one would suffer an illusion of thought.<sup>10</sup> So, in this quote, Wright is claiming that one has an a priori entitlement to discount the possibility that one’s environment does not contain water, or, alternatively, one has a positive entitlement for the claim that one’s environment does contain water.<sup>11</sup> But if Wright’s own analysis has the consequence that a subject has a priori warrant for the claim that her environment contains water, then it is not clear how it can be a satisfactory solution to the reductio. The reductio was

<!-- page: pdf=0286 printed=none -->

originally problematic precisely because it seemed to show that the combination of privileged access and anti-individualism has the consequence that subjects can have a priori knowledge of substantive facts about the world, say, that one’s environment contains water. 

Someone might try to show that Wright’s analysis is not committed to the view that subjects can have a priori warrant for substantive claims about the world by pointing out that a priori warrant and knowledge may be conditional on propositions that can be known only empirically. For example, a subject _S_ may derive a priori warrant for and knowledge of a mathematical proposition _p_ by deducing it validly from a priori known premises. However, her having this a priori warrant may depend on certain conditions that can be known to obtain only empirically, say, that it is not the case that, through some brain deterioration, she has lost her mathematical ability. 

However, this line of thought cannot be used to defend Wright’s view. Wright does not claim that one’s a priori warrant for the premise (W1), I think that water is wet, depends on the truth of the conclusion (W3), My environment contains water. Rather, he claims that one’s a priori warrant for the premise (W1) depends on one’s having prior and independent warrant for the conclusion (W3). Further, this seems to be an essential part of his view. It seems plausible that warrant fails to transmit across an argument where warrant for one of the premises is conditional on having prior and independent warrant for the conclusion. By contrast, on the view that warrant for one of the premises is conditional merely on the truth of the conclusion, having warrant for the premises requires neither that one believe the conclusion, nor that one have warrant for it. So, there seems no reason to suppose that warrant would fail to trans-

<!-- page: pdf=0287 printed=none -->

mit across an argument in which warrant for the premises is conditional on merely the truth of the conclusion. 

Suppose, then, that Wright is committed to the claim that the reductio subject has a priori warrant for (W3), My environment contains water. Wright might point out that, on his view, a subject cannot have this a priori warrant for (W3) by inference from (W1) and (W2), for he argues that this inference is a counterexample to the transmission of warrant. But, this seems no defense. What initially seemed problematic was the idea that the reductio subject can have a priori knowledge of substantive facts about the world, not merely that she can acquire this knowledge in one particular way. Similarly, it seems problematic to suppose that the reductio subject can have a priori warrant for substantive claims about the world, not merely that she can acquire this warrant in one particular way. If that is right, then the “solution” Wright offers to the reductio is just as problematic as the original problem the reductio posed. 

This section ends my discussion of Wright’s view that warrant fails to transmit across the relevant arguments. I have argued that his conditional analysis of these arguments would be rejected by many, especially externalist epistemologists; that it raises a skeptical threat; and that it fails to produce a satisfactory solution to the reductio. 

Davies’s papers on the reductio suggest several distinguishable reasons for thinking that warrant fails to transmit across the water, zebra, and BIV arguments (though the reasons are not distinguished by him). At times Davies suggests that warrant fails to transmit since the conclusion is already assumed in the premises. For example, Davies (1998) suggests that warrant fails to transmit from the premises of the relevant arguments to their conclusions since warrant cannot be transmitted from within an

<!-- page: pdf=0288 printed=none -->

epistemic project to its presuppositions or assumptions (see, e.g., p. 154). This idea is similar to Wright’s circular analysis. Since I have examined Wright’s view in detail, I won’t discuss it further. Davies suggests two other reasons why warrant may fail to transmit across the relevant arguments: that they beg the question and that warrant for the premises fails to rule out relevant alternatives to the conclusion. I discuss these ideas in the next two sections. 

### **4 Begging the Question** 

Davies (1998, 2000) argues that warrant fails to transmit across the zebra, BIV, and water arguments because they beg the question in Jackson’s sense, that is, “anyone—or anyone sane—who doubted the conclusion would have background beliefs relative to which the evidence for the premises would be no evidence” (Jackson 1987, p. 111).<sup>12</sup> Consider the BIV argument. Suppose someone doubts (BIV3), It’s not the case that I have just become a BIV, and she thinks that she may have just become a BIV. In that case, she would not take her perceptual experience as of seeing a table as warranting (BIV1), I am seeing a table. So, even if she has the perceptual experience as of seeing a table and she has evidence for (BIV2), If I am seeing a table, then it’s not the case that I have just become a BIV, this would not give her warrant for the conclusion, (BIV3). Thus, it may be suggested that warrant fails to transmit across the BIV argument. 

However, this line of thought fails to show that questionbegging arguments instantiate a failure of transmission of warrant. Someone who doubts (BIV3) and thinks she may have just become a BIV might have perceptual experiences as of seeing a table. But, for such a subject, these experiences would not warrant the claim that she is seeing a table,

<!-- page: pdf=0289 printed=none -->

although they would normally be taken to do so. Thus, in virtue of her doubt about the conclusion, (BIV3), she no longer has warrant for the premise, (BIV1). Thus, this subject is not someone who has a warrant for the premises of the BIV argument that fails to transmit to the conclusion; rather, she lacks warrant for the premises. This is compatible with saying that if someone were to have warrant for the premises, she could thereby acquire warrant for the conclusion, that is, that warrant transmits across the argument (Beebee 2001, pp. 358–359). 

### **5 Warrant and Ruling Out Alternatives** 

Davies (2000) emphasizes a different reason for a failure of transmission of warrant, namely, that one’s warrant for the premises of these arguments fails to rule out the salient or relevant alternatives to the conclusion. Consider the zebra argument. Davies says that it is a relevant alternative to the conclusion (Z3), The animal in the cage is not a disguised mule, that it is a disguised mule. But one’s evidence for the premises, namely one’s experience as of seeing a striped horselike animal and one’s warrant for the conditional claim, does not rule out the possibility that it is a disguised mule.<sup>13</sup> 

Notice that this relevant alternatives analysis is distinct from either of the two other analyses considered so far. The idea that warrant for the premises fails to rule out relevant alternatives to the conclusion is different from the idea that the arguments beg the question, that is, someone who doubts the conclusion of the argument would have background beliefs relative to which the apparent evidence for the premises would be no evidence. Further, the relevant alternatives analysis is different from Wright’s circular

<!-- page: pdf=0290 printed=none -->

analysis according to which warrant for one of the premises is conditional on prior and independent warrant for the conclusion. It may be that the premises of an argument fail to rule out the salient alternatives to its conclusion, even though it is not circular. 

For instance, consider the zebra argument. In section 3, I rejected Wright’s suggestion that one’s warrant for (Z1), The animal is a zebra, is conditional on one’s having prior and independent warrant for (Z3), The animal is a disguised mule. Even if this is right, one’s evidence for (Z1) and (Z2) fails to rule out the relevant alternative to the conclusion (that the animal is a disguised mule). Further, an argument could be circular even though it is not the case that the evidence for the premises fails to rule out the relevant alternatives to the conclusion. For example, suppose that one has a warrant for _p_ that rules out the relevant alternatives to _p_ . Despite this, the argument _p_ therefore _p_ is still circular. Given the distinctness of Davies’s analysis of the relevant arguments, it is unaffected by the previous discussion and requires separate examination. 

Davies’s argument for a limitation on the transmission of warrant is offered in his discussion of the goal argument: 

(G1) A goal has been scored. 

(G2) If a goal has been scored, then a football match is in progress and this is not just a movie scene. 

(G3) This is not just a movie scene. 

Suppose that walking into a stadium, it seems to _S_ that a football match is in progress. As she watches, a player kicks the ball between the posts, the crowd roars, and the referee makes signals appropriate to a goal being scored. Thus, _S_ has warrant for (G1). Further, reflection on the relevant

<!-- page: pdf=0291 printed=none -->

261 

concepts provides _S_ with warrant for (G2). And suppose that _S_ knows that the inference from (G1) and (G2) to (G3) is valid. Despite this, Davies argues that _S_ cannot gain warrant for the conclusion (G3) by inference from the premises for, he says, the evidence for the premises fails to rule out the most salient alternative to the conclusion: 

The evidence, even taken together with the considerations that support the conditional premise, does nothing to rule out the most obviously salient alternative hypothesis, namely that it is a movie scene which I am watching. That evidence would be of no help in resolving doubt and it does not confer knowledge. My epistemic warrants for the premises do not add up to an epistemic warrant for the conclusion. (2000, p. 400. See also Wright 2000, p. 154) 

Having argued that warrant fails to transmit across the goal argument, Davies applies the same idea to the zebra and BIV arguments and Moore’s proof of the external world. He then formulates two general principles limiting the transmission of warrant. The first of these is designed to limit the transmission of warrant across the goal, zebra, BIV, and Moore arguments. The second one is designed to apply specifically to the water argument. I won’t discuss these limitation principles here since Davies’s discussion of them provides no further argument for the idea that warrant fails to transmit across the arguments in question (2000, pp. 394–395 and secs. 6.1, 8.1, 8.2). Rather, the first limitation principle is designed to reflect the already argued for conclusion that warrant fails to transmit across the goal, zebra, BIV, and Moore arguments. The second limitation principle transposes the first limitation principle into a form that can be applied to the water argument. Further, Davies himself accepts that the limitation principles are likely to be open to counterexamples and need further refinement (ibid., p. 601).<sup>14</sup>

<!-- page: pdf=0292 printed=none -->

As we have seen, Davies claims that warrant fails to transmit from the premises to the conclusion of the goal argument since the warrant for the premises fails to rule out the salient alternatives to the conclusion. Thus, Davies seems to be committed implicitly to a general principle about warrant, namely that evidence warrants a proposition _p_ by ruling out alternatives to it. Indeed, he endorses this view explicitly: “[I]n short, the evidence rules out various ways in which the hypothesis that a goal has been scored could have been false, and it is for this reason that the evidence provides a resource for resolving doubt. It is also by ruling out alternatives that the evidence confers knowledge. This is how evidence constitutes an epistemic warrant” (2000, pp. 399–400). But, on pain of skepticism, we should not accept that evidence warrants a proposition _p_ only if it rules out all the possible alternatives to it. On that view, perceptual experience would fail to warrant beliefs about the world, such as there is a table in front of me, since it fails to rule out the possibility that one has just become a BIV. However, one could avoid this skeptical consequence by holding that a putative warrant warrants a proposition _p_ only if it rules out a subset of the alternatives to it, those that are relevant, for the BIV possibility is not normally relevant (see Dretske 1970, 1981 and Nozick 1981). This relevant alternatives conception of warrant would block the transmission of warrant in the relevant arguments. Consider the conclusion of the goal argument again: (G3) This is not just a movie scene. A relevant alternative to (G3) is that this is a movie scene. But, the evidence for (G1), namely the behavior of players, referee, ball, and crowd, does not rule out the possibility that this is a movie scene. Similarly, this conception of warrant would show that warrant fails to transmit across the BIV and zebra arguments. (The idea that a putative warrant war-

<!-- page: pdf=0293 printed=none -->

rants a proposition only if it rules out the relevant alternatives to that proposition is consistent with Davies’s remarks about why warrant fails to transmit across the goal argument—see the quoted passage on p. 261.) 

We have seen that central to Davies’s defense of a limitation on the transmission of warrant is the idea that a putative warrant warrants a proposition _p_ by ruling out the relevant alternatives to it. However, I will argue that this conception of warrant has controversial consequences that would be rejected by a number of accounts of warrant or justification, both internalist and externalist (Davies treats the terms “warrant” and “justification” interchangeably throughout his paper). 

Consider the following Gettier case (Dancy 1985, p. 25). Julie is watching television at the time advertised for the Wimbledon men’s finals and sees McEnroe beat Connors. She forms the belief that 

(McE1) I have just seen McEnroe win this year’s 

Further, Julie knows that 

(McE2) If I have just seen McEnroe win this year’s Wimbledon final, then McEnroe is this year’s Wimbledon champion. 

And so she infers 

(McE3) McEnroe is this year’s Wimbledon champion. 

In fact, owing to technical difficulties, the BBC is unable to transmit the current final and is showing last year’s final in which McEnroe beat Connors. Thus Julie’s belief (McE1) is false. As it happens, though, in the real final McEnroe _has_

<!-- page: pdf=0294 printed=none -->

just beaten Connors, so Julie’s belief (McE3) is true. Intuitively, her belief (McE3) is also justified or warranted, though not a case of knowledge. However, this would not be so on the view that evidence warrants or justifies a proposition by ruling out relevant alternatives. To see this, consider existing relevant alternative accounts of knowledge. Such accounts deal with Gettier cases by arguing that the subject’s accidentally true belief is not a case of knowledge since it fails to meet the relevant alternative condition for knowledge (see, e.g., Goldman 1986, pp. 54–55; Lewis 1996, pp. 228–229). 

For example, on Goldman’s account, “a true belief that _p_ fails to be knowledge if there are any relevant alternative situations in which the proposition _p_ would be false, but the process used would cause _S_ to believe _p_ anyway” (1986, p. 46). Goldman would argue that Julie’s belief (McE3) is not knowledge since it is a relevant alternative that McEnroe is not this year’s Wimbledon champion and the broadcast is a repeat. But, in this relevant alternative situation, use of the same process of belief-formation would lead Julie to falsely believe (McE3), McEnroe is this year’s Wimbledon champion. Davies uses the established epistemological notion of a relevant alternative in his account of warrant. So, on his account, too, it is a relevant alternative to (McE3) that McEnroe is not this year’s Wimbledon champion and that the broadcast is a repeat.<sup>15</sup> But, of course, Julie’s evidence for (McE1) and (McE2) fails to rule out this alternative to (McE3). So, on Davies’s view that evidence warrants a proposition by ruling out relevant alternatives, Julie lacks warrant for (McE3). 

A second problem for the view that evidence warrants a proposition by ruling out relevant alternatives is that it is

<!-- page: pdf=0295 printed=none -->

incompatible with the intuitive view that a false belief may be warranted or justified. Indeed, the possibility of a false but warranted or justified belief is used to generate many Gettier cases. In the Wimbledon example, Julie intuitively has a warranted but false belief in (McE1), I have just seen McEnroe win this year’s Wimbledon final, from which she justifiably infers the true belief (McE3). However, given the set up, it seems a relevant alternative to (McE1) that Julie has not just seen McEnroe win this year’s Wimbledon because the broadcast is a repeat. Surely, the nature of the actual situation should be included among the relevant alternatives to a believed proposition (see, e.g., Lewis’s rule of actuality [1996, p. 225]). But, clearly, Julie’s evidence for (McE1) does not rule out the possibility that she has not seen McEnroe win this year’s Wimbledon and that the broadcast is a repeat. 

More generally, suppose that _S_ believes that _p_ where actually not- _p_ . Given that not- _p_ is part of the way the world actually is, it is a relevant alternative to the believed proposition _p_ . But _S_ ’s evidence does not rule out not- _p_ , but is rather compatible with it. So, on the view that evidence warrants or justifies _p_ only if it rules out the relevant alternatives to _p_ , a false belief cannot be warranted or justified.<sup>16</sup> (Notice that I am using the Gettier case not as a direct objection to Davies’s limitation on the transmission of warrant, but rather as an objection to the account of warrant on which that limitation is based. I have argued that it is plausible that Julie has warrant for (McE1) and (McE3), but that Davies’s account cannot allow this. I have not argued that the case constitutes a counterexample to his limitation on the transmission of warrant. Indeed, it would be hard to do so. If I am right, then Davies must reject the claim that Julie has warrant for

<!-- page: pdf=0296 printed=none -->

(McE1), and so, on his view, the question of transmission of warrant across the inference to (McE3) cannot arise.) 

The notions of justification and warrant are currently the subject of much controversy. However, it is interesting that a variety of accounts of justification or warrant, both internalist and externalist, would allow that a false belief can be warranted/justified, and that Gettier cases involve true and warranted/justified beliefs. In broad terms, on an internalist account, whether a subject’s belief is warranted/justified depends on the obtaining of certain conditions that are internally accessible to the subject. Consider Julie’s belief (McE1), that she has just seen McEnroe win this year’s Wimbledon. Although Julie’s belief is false, this isn’t a matter of her belief failing to meet certain conditions that are accessible to Julie. From the inside, her epistemic position seems just as good as it would be if, counterfactually, the broadcast were live, rather than a repeat. The problem is not with those conditions internally accessible to Julie, but with facts external to her. It seems, then, that an internalist account should treat Julie’s belief in (McE1) as having the same degree of warrant/justification as it would have if, in fact, the broadcast were live, and her belief true. But, to avoid the skeptical conclusion that Julie’s belief is not warranted/justified even in the counterfactual situation in which the broadcast is live and her belief true, the internalist should accept that Julie’s belief in (McE1) is warranted/justified even though it is false. 

A similar analysis suggests that internalists would accept that Julie has a warranted or justified belief in (McE3), that McEnroe is this year’s Wimbledon champion. When considered solely internally, Julie’s epistemic position with respect to (McE3) is good: she forms her belief in (McE3) on the basis of a known entailment from another belief that,

<!-- page: pdf=0297 printed=none -->

from an internal perspective, is justified. Again, the problem is not that her belief fails to meet some internally accessible condition, but rather the way it links up with the world. Thus, the internalist should treat Julie’s belief in (McE3) as having the same degree of warrant/justification as it would have in the more congenial situation in which her belief in (McE3) is arrived at by a justified inference from a belief that is both justified and true. To avoid saying that Julie’s belief in (McE3) is not warranted/justified in this more congenial counterfactual situation, the internalist should accept that it is warranted/justified in the Gettier case. 

As we saw earlier, it may be argued that compatibilist anti-individualists are likely to endorse an externalist approach to epistemology rather than an internalist one (sec. 3.1). However, as I will now argue, Davies’s claims about warrant would be rejected even by some externalist accounts of warrant. For example, according to Goldman’s externalist account, a belief is warranted/justified if it was caused by a reliable process, that is, one that tends to produce true beliefs rather than false beliefs (Goldman 1979, 1986). (By “reliability” here, I mean what I earlier called “global reliability” [chap. 4].) This basic idea can be applied directly to beliefs that are produced by processes whose inputs are not beliefs, such as perception. However, a slight reformulation is needed to deal with processes, like inference, whose inputs and outputs are beliefs. Goldman argues that a belief that is produced by such a “belief-dependent” process is justified if and only if the process is conditionally reliable, that is, tends to produce true rather than false beliefs, when its input beliefs are true. Clearly, a false belief could be caused by a process that is either reliable or conditionally reliable. So, on this view, a belief may be warranted/justified and false. Further, it

<!-- page: pdf=0298 printed=none -->

seems that Goldman would agree that Gettier cases involve a subject’s having a true and warranted/justified belief. Consider Julie’s belief (McE3), that McEnroe is the champion. This belief is produced by a conditionally reliable process, that of inferring one belief by known entailment from another.<sup>17</sup> 

So far, I have argued that Davies’s account of warrant has controversial consequences that would be rejected by many accounts of warrant, both internalist and externalist.<sup>18</sup> It is not surprising that Davies’s account has these controversial consequences, for, as we will see, his account effectively imports into warrant what are normally regarded as conditions for knowledge. It is plausible that knowledge that _p_ requires what Goldman calls local reliability, reliability with respect to the specific proposition _p_ . For example, Nozick (1981) argues that the true belief that _p_ is knowledge if and only if (1) if it were false that _p_ , then the subject would not believe that _p_ ; and (2) if it were true that _p_ , then the subject would still believe that _p_ . On Goldman’s account, “a true belief that _p_ fails to be knowledge if there are any relevant alternative situations in which the proposition _p_ would be false, but the process used would cause _S_ to believe _p_ anyway” (1986, p. 46). As we have seen, Davies argues that a putative warrant _w_ justifies or warrants _p_ only if _w_ rules out the relevant alternatives to _p_ . In effect, this amounts to a local reliability condition for justification/warrant: the claim that _w_ warrants the belief that _p_ only if it rules out relevant alternative situations in which _p_ is false. Thus, it is not surprising that Davies’s account has counterintuitive consequences. 

For example, the local reliability condition for knowledge is standardly used to obtain the intuitively desirable result

<!-- page: pdf=0299 printed=none -->

that Gettier cases are not cases of knowledge. Consider Julie’s belief (McE3), that McEnroe is the champion. Given the set up, it is a relevant alternative to (McE3) that McEnroe is not the champion and the broadcast is a repeat. But, if that alternative were actual, then Julie would still believe (McE3) on the basis of the repeat. Thus, an account of knowledge incorporating the local reliability condition has the result that Julie’s belief in (McE3) is not knowledge. However, if one also builds the local reliability condition into one’s account of warrant, this delivers the counterintuitive result that Julie’s belief in (McE3) is not warranted either. 

### **6 Conclusion** 

In this chapter we’ve considered one of the main responses to the reductio argument. The reductio threatens compatibilism since it seems to show that if anti-individualism and privileged access were both true, then a subject could gain a priori knowledge of substantive claims about the nature of her environment. Davies and Wright respond by arguing that warrant fails to transmit from the premises to the conclusion of the relevant inference, and thus, even if anti-individualism and privileged access were both true, a subject couldn’t use her a priori knowledge of her thoughts and of philosophy to gain by inference a priori knowledge of her environment. 

We have examined and rejected several reasons for supposing that warrant fails to transmit across the relevant inference and related arguments: that the arguments are circular, that they beg the question in Jackson’s sense, and that the warrant for the premises fails to rule out relevant alternatives to the conclusion. I conclude that the threat posed

<!-- page: pdf=0300 printed=none -->

270 

Chapter 7 

to compatibilism by the reductio cannot be answered by limiting the transmission of warrant. Nevertheless, there may be other ways to counter this threat. In the next chapter, I consider whether any version of anti-individualism supports the claim, crucial to the success of the reductio, that a subject can have a priori knowledge of entailments between thought and the world.
