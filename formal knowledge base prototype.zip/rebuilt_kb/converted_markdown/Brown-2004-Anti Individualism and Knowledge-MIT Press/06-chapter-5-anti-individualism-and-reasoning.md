---
title: "Chapter 5: Anti-Individualism and Reasoning"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 183
locator_end: 218
---

# Chapter 5: Anti-Individualism and Reasoning

<!-- page: pdf=0183 printed=none -->

**5** 

## **Anti-Individualism and Reasoning** 

### **1 Introduction** 

In this chapter, I investigate the objection that antiindividualism undermines a subject’s ability to reason. The objection is grounded in the claim that anti-individualism undermines a subject’s ability to grasp a priori whether two thoughts, or thought constituents, have the same or different content. According to anti-individualism, a subject’s thought contents are individuated partly by the environment. Thus, whether two thoughts have the same or different content depends on environmental factors of which the subject may be ignorant. This suggests that a subject may need to investigate the environment in order to realize whether two thoughts have the same, or different, content; further, without such information, she may make mistakes about whether two thoughts have the same or different content. 

Sameness and difference of content are crucial for reasoning. If a subject makes mistakes about sameness and difference of content, she may make mistakes about the logical properties of her thoughts. Suppose that a subject meets the anti-individualist’s conditions for having the concepts

<!-- page: pdf=0184 printed=none -->

expressed by two terms. It is part of anti-individualist theory that a subject can have the concept expressed by a term even if she is ignorant of some of the empirical factors that individuate it. This opens up the possibility of a mismatch between the subject’s view about sameness and difference of content and the facts. 

For instance, the subject might take it that she expresses different concepts by two terms even though her environmental relations determine that she expresses the same concept by them, say, because the terms express the same concept in her linguistic community or refer to the same natural kind. As a result, she may fail to realize that some of her beliefs can be combined in simple valid inferences. Further, she may fail to realize that certain of her beliefs are inconsistent. To correct her view she would need to gain empirical information about her environment. Alternatively, a subject might take it that she expresses the same concept by a pair of terms, but her environmental relations determine that she expresses different concepts by them, say, because the terms have different meanings in her linguistic community, or refer to different natural kinds. As a result, she may take certain inferences to be valid that are in fact invalid. To correct her view she would need to gain empirical information about her environment. 

As a result of this sort of line of reasoning, some have argued that anti-individualism threatens a fundamental part of our conception of a rational agent. They admit that even a rational subject may make mistakes in her reasoning, and that she may fail to see logical relations the grasp of which requires complex and/or sophisticated reasoning. But, they claim, it is part of the concept of a rational subject that, in good conditions (e.g., when she is not distracted and when given adequate time to reflect), she can grasp the

<!-- page: pdf=0185 printed=none -->

Anti-Individualism and Reasoning 

simple logical properties of her thoughts a priori and so would not make simple invalid inferences or form obviously contradictory beliefs. Further, she would make simple valid inferences from her thoughts, or at least those that are relevant to her current interests (I will leave this qualification implicit in the following discussion). 

The slow switch argument considered in chapter 2 shows that anti-individualism may undermine a subject’s ability to tell a priori whether two thoughts that she has at different times have the same or different content. A subject unwittingly switched between Earth and Twin Earth would be disposed to judge falsely that the thought she now expresses by ‘Water is wet’ has the same content as the thought she used to express in this way. However, it is a subject’s ability to grasp sameness and difference of content between simultaneously held thoughts that seems relevant to rationality. It does not undermine a subject’s rationality if she believes that _p_ at an earlier time, then later loses this belief and comes to believe instead that not- _p_ . Of course, we can ask whether the subject’s change of belief was rational, but merely believing that _p_ at one time and then believing that not- _p_ at another is not in itself indicative of irrationality. Indeed, the subject may have changed her mind for good reason. 

Thus, the relevant notion of a rational agent could be made more precise by saying that, with respect to simultaneously held thoughts, a rational subject should avoid simple contradictions in belief, make simple valid inferences, and avoid making simple invalid inferences. Correspondingly this chapter will focus on whether a subject can grasp a priori relations of sameness and difference of content between simultaneously held thoughts. More precisely, I consider whether anti-individualism is compatible with the following two principles:

<!-- page: pdf=0186 printed=none -->

**Transparency of sameness of content:** for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content then, at _t_ , _S_ can realize a priori that they have the same content. 

**Transparency of difference of content:** for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents then, at _t_ , _S_ can realize a priori that they have different contents. 

In the first part of the chapter, I consider the standard arguments that anti-individualism does undermine transparency. I extend these arguments by considering whether they apply to Fregean anti-individualism. In the second part of the chapter I consider whether it would be an objection to anti-individualism if it did undermine transparency. 

Throughout this chapter, as in the rest of the book, I follow an established use of “a priori” according to which knowledge may be a priori even if based on conscious attitudes. In this sense, a subject’s knowledge of her thought contents and the relations between them may be a priori. However, we may reformulate the issue and the ensuing discussion independently of this use as follows. According to antiindividualism, whether two of a subject’s thoughts have the same or different content depends partly on their environmental relations. So, it seems that a subject needs to know about those environmental relations in order to realize whether two of her thoughts have the same or different content; without such information, she might be mistaken. Sameness and difference of content are crucial to the logical relations between thoughts. This suggests that antiindividualism has the consequence that in order for a subject to know the logical properties of her thoughts she needs environmental information and that, without such informa-

<!-- page: pdf=0187 printed=none -->

Anti-Individualism and Reasoning 

tion, she might be mistaken. But, it is claimed, it is part of the concept of a rational agent that she can know the logical relations between her thoughts without investigation of her environment and that, at least in simple cases, she wouldn’t make mistakes about their logical relations. Thus, anti-individualism seems to undermine the idea that we are rational agents. 

### **2 Transparency of Sameness of Content** 

It has become commonplace to argue that anti-individualism is incompatible with transparency of sameness of content (see, e.g., Owens 1989; Boghossian 1992, 1994; Millikan 1993; Falvey and Owens 1994). According to antiindividualism, a subject’s thought contents are individuated partly by environmental factors. But since the subject may be ignorant of these environmental factors, it is argued that she may be unable to realize that two thoughts have the same content without empirical information. In Falvey and Owens’s example, Rudolf partially understands the terms ‘coriander’ and ‘cilantro’ and defers to experts for their correct explication. He knows that each term names a herb, although he is ignorant that they name the same herb. Rudolf knows cilantro as the fresh herb used in Mexican cooking and is familiar with its appearance and flavor. By contrast, he knows coriander as a dried herb and is again familiar with its appearance and flavor. In virtue of these facts, it seems that an anti-individualist would accept that Rudolf has the concepts expressed by ‘cilantro’ and ‘coriander’. Suppose that he assents both to ‘Cilantro should be used sparingly’ and ‘Coriander should be used sparingly’. Since ‘cilantro’ and ‘coriander’ have the same referent, Falvey and Owens argue that an anti-individualist should

<!-- page: pdf=0188 printed=none -->

hold that Rudolf expresses the same concept by these terms, and that he expresses the same thought by the relevant utterances. However, since Rudolf is ignorant of the fact that the terms are coreferential, he is not in a position to discover that he expresses the same thought by these two utterances without using empirical information about how the terms are used. Thus, Falvey and Owens conclude, anti-individualism is incompatible with transparency of sameness of content (Falvey and Owens 1994, pp. 110–111). 

If sameness of content is not transparent, a subject may fail to make a simple valid inference since she cannot realize a priori that it is valid. For example, suppose that Rudolf has two beliefs that he would express linguistically in the following way: 

- (1) Coriander grows in Britain. 

(2) Cilantro grows in France. 

If the thought constituents Rudolf expresses by ‘coriander’ and ‘cilantro’ have the same content, then there is a simple valid inference to the conclusion that something grows in both Britain and France.<sup>1</sup> However, since Rudolf is unable to realize a priori that the relevant thought constituents have the same content, he is unable to realize a priori that this inference is valid. To realize that it is valid, he needs to use the empirical information that the relevant constituents are coreferential. 

Rudolf’s inability to realize a priori that the relevant thought constituents have the same content may also undermine his ability to realize a priori that he has inconsistent thoughts. On the basis of two distinct articles, of which one uses only the term ‘cilantro’ and the other only the term ‘coriander’, Rudolf may come to have the beliefs he would

<!-- page: pdf=0189 printed=none -->

Anti-Individualism and Reasoning 

express by saying ‘Cilantro was known to the ancient Romans’ and ‘Coriander was not known to the ancient Romans’. However, he would not realize that these beliefs are inconsistent as he does not realize that the relevant thought constituents have the same content. To realize that these beliefs are inconsistent, he would need to acquire empirical information about his environment.<sup>2</sup> 

Although the Rudolf case uses natural kind terms, it is applicable to singular anti-individualism. Further, since Rudolf understands the terms partially and defers to the experts for their correct explication, in principle, the case seems applicable to social anti-individualism and not just natural kind anti-individualism. However, care is needed in applying the argument to Burge’s position, which combines social anti-individualism and the denial that synonymous terms express the same concept (Burge 1976, 1986b, pp. 115–117). Given this, one cannot show that Burge’s position is incompatible with transparency of sameness of content by considering a subject who partially understands two synonymous terms. On Burge’s view, the case cannot be developed into one in which a subject unwittingly expresses the same concept by two terms and can discover her mistake only empirically. However, we can demonstrate the incompatibility of Burge’s position and transparency of sameness of content using an example of Segal’s (Segal 2000, pp. 73–74). In Segal’s case, a subject mistakenly thinks that a term that in fact has just one meaning has two meanings, a generic and a more specific meaning. (Segal uses the example to support the different conclusion that, whether or not there is a type of content that is socially individuated, there is also a type of content that is individualist.) 

Suppose that Alf thinks that ‘optician’ has two meanings, denoting either any specialist in optics, or a specialist in

<!-- page: pdf=0190 printed=none -->

optics who is commercially involved in the correction of people’s sight. In fact, ‘optician’ has just one meaning, a specialist in optics who is commercially involved in the correction of people’s sight. Further, suppose that, in all his uses of ‘optician’, Alf would defer to experts in his community for its correct explication. In some of his uses of ‘optician’, Alf, if asked, would give the correct explication of the term. Given this and the fact that he defers to the experts, the social anti-individualist should hold that, in these uses, Alf expresses the same concept by the term as the experts. In other uses, Alf would provide an incorrect explication of the term, for he mistakenly thinks that there is a second use of ‘optician’. However, it seems that the social antiindividualist should hold that in these uses too, Alf expresses the same concept as the experts, for in these uses, he defers to the experts. In addition, his misunderstanding seems no more radical than, say, the misunderstanding of Burge’s arthritis patient to whom social anti-individualists attribute the concept arthritis. 

So, the social anti-individualist should accept that, in all Alf’s uses of ‘optician’, Alf expresses the same concept as the experts. Now the experts express just one concept by their uses of ‘optician’, for ‘optician’ has only one meaning. As a result, all of Alf’s uses express the same concept. However, Alf would suppose that his different uses of ‘optician’ express two different concepts. Further, he would need to gain empirical information about his language in order to realize that he associates the same concept with the two terms. Thus, it seems that social anti-individualism is inconsistent with transparency of sameness of content. This argument does not rest on the assumption that the experts associate the same concept with two synonymous terms: Alf’s uses of ‘optician’ lead back to only one expert term and concept. So, it applies even to Burge’s position, which com-

<!-- page: pdf=0191 printed=none -->

bines social anti-individualism and the denial that synonymous terms express the same concept. 

I have now outlined an argument for the claim that antiindividualism, whether natural kind, social, or singular, is incompatible with transparency of sameness of content. However, I will now show that the argument applies only to non-Fregean anti-individualism, and not to Fregean antiindividualism (these terms were introduced in chap. 1, sec. 6). Consider again the case of Rudolf, who is ignorant of the fact that ‘cilantro’ and ‘coriander’ name the same herb. Falvey and Owens argue that an anti-individualist should accept that Rudolf expresses the same thought by ‘Cilantro should be used sparingly’ and ‘Coriander should be used sparingly’, since ‘cilantro’ and ‘coriander’ are coreferential. However, they say, Rudolf cannot realize this a priori, since it is part of the case that he is ignorant that the terms name the same herb. Given Rudolf’s ignorance, he could take different attitudes to thoughts expressed by sentences involving the terms. For example, he may dissent from ‘Coriander is an herb characteristic of Mexican cuisine’ while assenting to ‘Cilantro is an herb characteristic of Mexican cuisine’. Recall that Fregeans individuate sense by potential difference of attitude: if it is possible rationally to believe that _p_ and not believe that _q_ , then the contents _p_ and _q_ are distinct (see, e.g. Frege 1892, 1980; Evans 1982, pp. 18–20; Peacocke 1983, p. 108; Campbell 1987, pp. 281–286.). Thus, Fregeans would hold that Rudolf associates different senses with the two terms although they have the same reference. 

So, on this Fregean view, the case of Rudolf is not a counterexample to transparency of sameness of content, which states that, for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have the same content, then, at _t_ , _S_ can realize a priori that they have the same content. On the Fregean view, the relevant thoughts

<!-- page: pdf=0192 printed=none -->

have different contents. As a result, the Fregean antiindividualist would deny that her position undermines a subject’s reasoning. Although Rudolf may assent to ‘Coriander was known to the ancient Romans’ and ‘Cilantro was not known to the ancient Romans’, he does not thereby express contradictory beliefs, for the concepts he expresses with ‘cilantro’ and ‘coriander’ have different contents. Further, although Rudolf fails to combine the beliefs he would express by ‘Coriander grows in Britain’ and ‘Cilantro grows in France’ to draw the conclusion he would express by ‘Something grows in both Britain and France’, he does not fail to draw a valid inference. On the Fregean view, Rudolf associates different concepts with the relevant terms, and the inference is not valid. 

In conclusion, it is straightforward to show that nonFregean anti-individualism is incompatible with transparency of sameness of content. As a result, non-Fregean anti-individualism has the consequence that a subject cannot always grasp a priori that two thoughts are contradictory or that an inference is valid, even in simple cases. By contrast, a Fregean anti-individualist would reject the arguments for the incompatibility of her position and transparency of sameness of content by appeal to the notion of sense. Before investigating the consequences of these conclusions for rationality, let us consider whether antiindividualism threatens transparency of difference of content. 

### **3 Transparency of Difference of Content** 

Slow switch cases have been used to argue that antiindividualism is incompatible with transparency of difference of content (see, e.g., Boghossian 1992; Falvey and

<!-- page: pdf=0193 printed=none -->

Anti-Individualism and Reasoning 

Owens 1994; Goldberg 1999). Suppose that Sally is a member of the current Earth community and has the term ‘aluminum’ in her repertoire although she does not know the chemical composition of aluminum. Nevertheless, antiindividualists accept that in virtue of her interactions with aluminum and her membership of the Earth community, Sally has various beliefs involving the concept of aluminum, say, that aluminum is a metal, that it is gray, and that it is light. In addition, as a result of a school geography lesson, Sally has the belief she would express with 

### (1) Aluminum is mined in Australia. 

Even now, she can vividly recall the interesting lesson on Australia. 

Now suppose that one night Sally is whisked off to Twin Earth unawares, where she starts interacting with twaluminum. Most anti-individualists accept that, after a period, Sally acquires a new concept. For simplicity I will assume that the new concept is the concept twaluminum. (There is disagreement among anti-individualists about whether she comes to have a twin or an amalgam concept. See Ludlow 1995b; Tye 1998; Heal 1998.) Along with other new beliefs, she acquires the belief that she would express with 

### (2) Aluminum is mined in the Soviet Union. 

This belief is based on Twin Earth newspaper reports about the Twin Soviet Union and involves the concept twaluminum. Since Sally is unaware of the switch, it seems that she is also unaware of the change in her thoughts. Although she has thoughts involving distinct concepts at different times, she would mistakenly suppose that they involve the same concept. Further, it seems that Sally could find out that

<!-- page: pdf=0194 printed=none -->

the relevant thoughts involve different concepts only by using empirical information about the switch. 

The case does not yet constitute a counterexample to transparency of difference of content, which states that, for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents, then, at _t_ , _S_ can realize a priori that they have different contents. To provide such a counterexample we need to assume that, as a result of the switch, Sally not only acquires a new concept, but also retains her old concept. In fact, many anti-individualists would accept that, after the switch, Sally has two concepts that she expresses with the term ‘aluminum’, say, the concepts aluminum and twaluminum. In particular, they would argue that, after the switch, the belief Sally expresses by (1) involves the concept aluminum, whereas the belief she expresses by (2) involves the concept twaluminum. I will examine this two-concept view in more detail later (sec. 4). But, in outline, the view may be defended by arguing that the two beliefs differ in their causal and deferential connections (see, e.g., Boghossian 1992, pp. 19–20) and/or that it is part of the function of memory to preserve the contents of earlier thoughts so as to make them available at later times (see, e.g., Burge 1998). If the beliefs Sally expresses by (1) and (2) post-switch involve different concepts, then since Sally is ignorant of the switch, she would be ignorant of the fact that these beliefs involve different concepts. To find out that they involve different concepts, she would need to use empirical information. As a result of her ignorance, Sally would be mistakenly disposed to put these beliefs together in inference. For example, she might put the beliefs (1) and (2) together in inference to form the conclusion she would express by ‘Something is mined in Australia and the Soviet Union’. In fact, this inference is a simple invalid one, but

<!-- page: pdf=0195 printed=none -->

Sally is unable to realize this without using empirical information and, in particular, the information that the relevant terms refer to different substances.<sup>3</sup> 

This argument for the incompatibility of anti-individualism and transparency of difference of content could be applied to anti-individualism about singular thoughts and natural kind thoughts, as well as social anti-individualism. Further, the argument applies to both Fregean and nonFregean anti-individualism. We saw earlier that the Fregean would deny that her position leads to a failure of transparency of sameness of content. In particular, where a nonFregean anti-individualist holds that a subject has two thoughts with the same content without realizing it, the Fregean invokes the notion of sense to argue for a difference of sense and thus thought content. However, the Fregean cannot use the notion of sense in a similar way to avoid the conclusion that her position undermines transparency of difference of content. If the concepts Sally expresses by ‘aluminum’ in (1) and (2) differ in extension then they differ in content, whether or not they differ in sense. The notion of sense might introduce further differences in their content, but it cannot be used to argue that the relevant thoughts have the same content. (In chap. 6, I apply the argument for the incompatibility of anti-individualism and transparency of difference of content to Fregean anti-individualism about perceptual demonstrative thoughts.) 

It seems, then, that both Fregean and non-Fregean antiindividualism are incompatible with transparency of difference of content and may lead a subject to make a simple invalid inference that she can know to be invalid only by using empirical information. Thus, both views undermine the conception of a rational agent as one who would not make simple invalid inferences and can know the logical

<!-- page: pdf=0196 printed=none -->

properties of her thoughts a priori. Given its implications for rationality, it is important to see if the anti-individualist can respond to the argument that her position is incompatible with transparency of difference of content. There are two main ways in which an anti-individualist might try to do so. First, she might reject the claim that, as a result of a slow switch, a subject acquires two distinct concepts that she expresses by a single word. On this view, the case would fail to show either that an anti-individualist should reject transparency of difference of content, or that she should accept that a subject may make a simple invalid inference owing to an equivocation of concepts. Second, the anti-individualist might accept that a subject may acquire two concepts as a result of a slow switch and thus that anti-individualism undermines transparency of difference of content, but deny that this would lead her to make a simple invalid inference. I discuss each of these possible responses in the next two sections. 

### **4 Slow Switch and Conceptual Change** 

Some anti-individualists reject the view that, as a result of a slow switch, a subject may come to have two distinct concepts that she expresses by a single word. Instead, they argue that, at any point in the switch, the subject has just one concept, though a different one before and after the switch. Applying this view to the case of Sally, she may argue that, before the switch, Sally has the concept aluminum; after the switch, she gains a new concept, say twaluminum, and loses the old concept. I will consider several arguments against the two-concept view. We will see that whether an anti-individualist accepts the two-concept view in part depends on her account of thought content.

<!-- page: pdf=0197 printed=none -->

Anti-Individualism and Reasoning 

Tye (1998) argues against the two-concept view by claiming that the content of a memory is not determined by the environment in which the memory is formed, but rather by the environment at the time of recollection. He considers a case in which a subject, MT, spends his youth on Earth where he acquires the concept of water before being switched to Twin Earth. After he has spent many years on Twin Earth, MT attempts to reminisce about his youth, expressing his reminiscences thus (the numerals are added merely for convenience of reference): 

- (1) Water is the only thing I now drink before 5 p.m. 

(2) Many years ago, however, I drank water fortified with gin in the afternoons. 

- (3) I enjoyed those afternoons. 

- (4) Water is improved by mixing it with gin. 

Tye argues that MT uses a single concept, twater, throughout this inference, including (2), which is based on memories of MT’s youth on Earth. If that is right, then MT misremembers his doings in his youth, misremembering events involving water as instead involving twater. If all of MT’s memories have their contents determined in this way by the environment at the time of recollection, then, as a result of the switch, MT would lose the concept water and would acquire only the concept twater. 

Tye takes it as granted that (1) and (4) involve the concept twater, for by stipulation, (1) expresses a belief about the current environment formed in the Twin Earth setting, and (4) is a tenseless belief. Tye then exploits the rationalizing links between (1)–(4) to argue that (2) also involves the concept twater. Tye says that (2) intuitively involves the very

<!-- page: pdf=0198 printed=none -->

same concept as (1): (1) and (2) involve MT’s comparing his drinking of the very same stuff in his youth and later life (1998, p. 81). Further, since (4) involves the concept twater, so does (2), for (4) is offered as an explanation of (3), but “[t]his would hardly make sense if what [he] really believed is that [he] drank water with gin during those afternoons” (ibid.). Again, Tye says, “it seems obvious that [he] cannot rationally offer such an explanation, unless [he] believes that [he] drank twater with gin on those occasions” (p. 84). Tye’s example focuses on a water thought, but the argument could be applied to any version of anti-individualism. 

However, Tye’s argument against the two-concept view cannot be used to defend the compatibility of antiindividualism and transparency of difference of content, for it implicitly relies on the assumption of transparency of difference of content, namely that for any two thoughts, or thought constituents, that _S_ entertains at time _t_ , if they have different contents then, at _t_ , _S_ can realize a priori that they have different contents. Suppose, instead, that a subject could mistakenly suppose that two thought constituents have the same content. If that were possible, then Tye could not infer that (1) and (2) involve the same concept from the fact that the subject takes it that they do. Further, the subject could rationally offer (4) as an explanation of (3) even if (2) and (4) involve different concepts. Given that Tye’s argument rests on the unargued assumption of transparency of difference of content, it provides no independent grounds for the claim that anti-individualism is compatible with transparency of difference of content. 

Heal (1998) argues against the two-concept view in the case of natural kind thoughts by arguing that the concept a subject expresses by her use of a natural kind term at a time is fixed by what exemplars she would then regard as

<!-- page: pdf=0199 printed=none -->

Anti-Individualism and Reasoning 

173 

standard-setting; the term applies to _x_ if and only if _x_ is of the same underlying nature as the standard-setting exemplars. Consider a standard switch scenario in which a subject is initially on Earth and applies ‘water’ to samples of water. At this stage, the subject would select examples of water as standard-setting, and thus she expresses the concept water by ‘water’. However, after she is switched to Twin Earth, Heal plausibly claims that the subject’s standard-setting exemplars would include not only specimens from Twin Earth, but also some from Earth, which she might pick out using such descriptions as ‘the stuff I swam in as a child’, or ‘the stuff the chemistry teacher poured out of the bottle labeled “distilled water” when I was at school’. Heal concludes that, after the switch, the subject would lose the concept water and gain an amalgam concept whose extension includes both H2O and XYZ. 

One could develop an analogous view for Burge’s antiindividualism. On this analogous view, the concept a subject expresses by her use of a term at a time depends on which individuals she would then defer to for the correct explication of that term. Consider a subject switched between two linguistic communities, say the U.K. and the United States, whose linguistic practices diverge, although she is unaware of this. While initially in the U.K. and before the switch, it seems likely that she would defer to various U.K. experts for the correct explication of her thoughts. However, after the switch to the United States, she would start to cite U.S. experts as well as U.K. ones to explain the content of her thoughts. If that is right, then, the slow switch would not result in the subject acquiring two distinct concepts that she expresses by a single term. Rather, where U.K. and U.S. practice differs, say, in the meaning of ‘chicory’, she would lose the concept expressed in the U.K. with ‘chicory’ and

<!-- page: pdf=0200 printed=none -->

instead associate with the term an amalgam concept that applies to the extensions of both the U.K. and U.S. terms. 

Heal’s argument against the two-concept view is based on a particular anti-individualist view about content individuation: the content of a subject’s thoughts at a time, _t_ , is determined by the samples (and possibly experts) that the subject herself would regard as standard-setting at _t_ . However, many anti-individualists (for instance, teleofunctionalists and causal theorists of content) reject this view and instead hold that the content of a thought is determined by certain past factors, not by the subject’s current dispositions. So, this argument against the two-concept view would not be accepted by many anti-individualists. 

The idea that content is determined by historical factors stands in an interesting relation to the debate about the conceptual impact of a slow switch: it may be used to argue for or against the two-concept view. Consider the thoughts that the subject would express with the term ‘water’ after being switched to Twin Earth. Some of these thoughts are caused and sustained only by events on Earth, such as those based on memories of events on Earth. By contrast, others are mainly caused and sustained by events involving twater, such as thoughts formed on Twin Earth as a result of interaction with twater. If the anti-individualist treats all the thoughts the subject expresses with ‘water’ as of a single type whose content is determined by their causal relations then, after the switch, the subject does not express two distinct concepts with ‘water’. Instead, the anti-individualist may argue that with ‘water’, the subject expresses an amalgam concept that applies to both water and twater. Alternatively, in virtue of the fact that water and twater do not form a single natural kind, she may argue that the

<!-- page: pdf=0201 printed=none -->

Anti-Individualism and Reasoning 

subject fails to express any concept with ‘water’. However, the causal view of content could instead be used to argue for the two-concept view. Suppose that the causal theorist holds that content is more locally determined, by the causal relations of particular thoughts considered individually, or by the causal relations of subgroups of thoughts. In that case, the causal theorist could use the different causal relations of the switch subject’s thoughts to argue that some of the relevant thoughts involve the concept water, whereas others involve the concept twater. 

A different way to defend the two-concept view is suggested by Burge, who argues that one of the functions of memory is to fix the content of a memory-induced thought to that of the remembered one. Thus, on his view, even after a slow switch, a subject retains her Earth concepts, and they figure in the content of certain thoughts based on memory. Burge’s view may be motivated at least in part by the idea discussed above that content depends on causal relations (see Burge 1998, p. 359). However, Burge also motivates the two-concept view with his account of the function of preservative memory, which he defends independently of anti-individualism. Burge (1993) rejects the view that long demonstrations must include premises about what the subject remembers (e.g., I remember earlier proving that _p_ ; I remember reading the symbols carefully). He allows that substantive memory of particular events may be part of a demonstration in specific circumstances in which memory is called into question. However, he says, normally, memory functions merely to preserve past thought contents and make them available later, rather than to contribute premises about remembered events (1993, pp. 462–465). Burge justifies this view by appeal to the intuition that a

<!-- page: pdf=0202 printed=none -->

demonstration, even a long one, can be purely logical or mathematical and need not involve possibly empirical claims about what the subject contingently recalls. 

In this section, I have been considering whether an antiindividualist can deny that her position is inconsistent with the transparency of difference of content by rejecting the two-concept view of slow switch cases. Heal rejects the two-concept view on the basis of her account of content. However, this account would be rejected by many antiindividualists. The more popular view, that content is determined by historical relations, could be used to argue either for or against the two-concept view. In addition, the two-concept view may be supported by Burge’s view of preservative memory. In conclusion, it seems that many anti-individualists would indeed accept that, as a result of a slow switch, a subject may have two concepts that she expresses by a single term. 

### **5 Two Concepts and Inference** 

An anti-individualist who accepts the two-concept view may nevertheless argue that this does not lead subjects to make simple invalid inferences. There are two ways in which she could do so. First, she could argue that even if a subject unwittingly has two distinct concepts, only one may figure in a single piece of reasoning. Second, she could argue that, even if a single piece of reasoning may involve two different concepts, the relevant inference implicitly contains an identity premise, so that the inference is valid although the identity premise is false. 

Burge argues that although a slow switch may result in a subject acquiring two distinct concepts, only one concept may figure in a single inference. Burge defends this view by

<!-- page: pdf=0203 printed=none -->

appeal to his notion of preservative memory. As we have seen, one of the functions of preservative memory is to preserve the contents of earlier thoughts so as to make them available later. However, Burge also holds that preservative memory functions to tie together the concepts used in the steps of a single piece of reasoning. He says that a subject “holds constant, through preservative memory within the argument, the concept used in the first premise in her thinking the second premise” (1998, p. 367). He argues that this rules out the possibility that, as a result of a slow switch, a subject may make an invalid inference that she can know to be invalid only empirically. 

To see how the function of preservative memory rules out this possibility, return to our earlier example of Sally who is switched from Earth to Twin Earth, which differ in the substance called ‘aluminum’. While on Earth, and before the switch, she has the belief she would express with (1) ‘Aluminum is mined in Australia’, which involves the concept aluminum. After the switch she forms the belief she would express with (2) ‘Aluminum is mined in the Soviet Union’, which involves the concept twaluminum. From the thoughts she expresses with (1) and (2), she then infers the thought she would express with (3) ‘So, something is mined in both Australia and the Soviet Union’. Although Burge accepts that, after the switch, Sally has both the concepts aluminum and twaluminum, he denies that both concepts can figure in a single piece of reasoning. He holds that since the first premise of Sally’s inference involves the concept of aluminum, so does the second. If Sally’s inference involves only the concept of aluminum, then the inference is valid. 

However, I will now argue that the combination of views that Burge holds—that a slow switch subject may unwittingly have two distinct concepts that she expresses by a

<!-- page: pdf=0204 printed=none -->

single term but that cannot both figure in a single piece of reasoning—is counterintuitive and poorly motivated. Burge’s position has the counterintuitive consequence that the order in which a subject reasons may affect the content of the thoughts reasoned about. To see this, reconsider the inference that Sally would express with (1)–(3) above. The belief Sally expresses with (1) was formed pre-switch and involves the concept of aluminum. So, if Sally starts her inference with this belief, Burge holds that the second premise also involves that same concept. However, suppose that Sally had instead started with the belief she would express with (2). This belief was formed post-switch and involves the concept of twaluminum. So, Burge would hold that if Sally had started the inference with this belief, then the second premise would also have involved this concept. Thus, Burge is forced to deny the intuitively plausible view that what thoughts a subject entertains is independent of the order of her reasoning. This is not merely an ad hominem argument against Burge’s particular position, but would apply to any position that combines the two-concept view with the denial that both the relevant concepts can figure in a single inference. 

One of the standard motivations for the two-concept view is that it enables subjects to recall their earlier thoughts even after a slow switch (see Ludlow 1995b, p. 315; Gibbons 1996, p. 305; Burge 1998, p. 357). However, this motivation is undermined if the two-concept view is combined with the view that the relevant concepts cannot both figure in a single inference. On the combined view, even if a slow switch subject can recall her earlier thoughts “neat,” she may not be able to do so in the context of an inference. In particular, if she starts an inference with a thought whose content is determined by the current post-switch environment, then

<!-- page: pdf=0205 printed=none -->

179 

this may lead her to misremember thoughts formed in the pre-switch environment. In addition, even when a subject can recall her earlier thoughts “neat,” this is of dubious value: surely the point of memory is not to enable us to bring our past thoughts to mind merely to contemplate them, but rather to use them in reasoning in combination with other thoughts, past and present. We ordinarily assume that, if a subject can remember a past thought, then she can freely use that thought in inference; but the combined view denies this. Thus, one of the main motivations for the two-concept view—that it enables slow switch subjects to recall their earlier thoughts—is undermined when that view is combined with the claim that the relevant concepts cannot both figure in a single inference. 

An alternative way of arguing that although the slow switch subject unwittingly has two distinct concepts, this does not lead her to make invalid inferences, is to claim that the relevant inferences contain an implicit identity premise. Suppose that Sally’s inference contained a judgment identifying the two concepts that she would express with the term ‘aluminum’. Then, even though the first and second premises involve different concepts, this does not lead her to make an invalid inference. Rather, the inference she makes is valid though unsound, since the identity premise is false. 

The identity view contrasts with the alternative view that Sally merely relies on the putative identity of the concepts she would express with ‘aluminum’ through the inference, rather than making an identity judgment. If Sally merely relies on the putative identity, then her inference is invalid after all. So, we need to ask: what might motivate the identity view as opposed to the view that Sally merely relies on the putative identity?

<!-- page: pdf=0206 printed=none -->

It would surely be ad hoc to argue that it is only when a subject unwittingly has two distinct concepts that inferences that turn on the putative identity of concepts contain an identity premise. Certainly we cannot justify this restricted claim by using the subject’s first-person perspective. It is part of the case that Sally is unaware that she expresses two distinct concepts with ‘aluminum’. The inference she would express using ‘aluminum’ seems to her just like one in which the relevant premises genuinely involve just one concept. It seems, then, that the identity-premise view must be part of a more general view that a subject cannot just rely on the identity of concepts in inference; rather, the relevant inference must involve an identity premise. However, we will see that the idea that one can never rely on the identity of concepts through an inference leads to an infinite regress. (The argument is based on Campbell’s argument for the related view that a subject must sometimes be able to rely on the coreference of singular terms in inference: see Campbell 1987, p. 276.) 

Let us set aside Sally’s inference concerning aluminum and consider instead an inference made by an ordinary nonswitch subject. Suppose that Susan is an ordinary Earth subject who has never been switched and who expresses just one concept by ‘water’. Further, she has never heard of antiindividualism and does not realize that changes in the environment can affect thought content. She makes the inference she would express thus: 

- (1) Water is clear. 

- (2) Water is good to drink. 

- (3) So something is clear and good to drink.

<!-- page: pdf=0207 printed=none -->

Anti-Individualism and Reasoning 

Since Susan expresses just one concept by ‘water’, the inference is valid as it stands. However, on the view that one can never rely on the identity of concepts through an inference, the inference implicitly contains an identity premise that Susan would express with 

### (4) Water is water. 

But, even with the addition of this identity premise, the argument still relies on the identity of concepts. In particular, it relies on the fact that the concept expressed by the first use of ‘water’ in (4) is identical with the concept expressed by the use of ‘water’ in (1); and, that the concept expressed by the second use of ‘water’ in (4) is identical with the concept expressed by the use of ‘water’ in (2). If one can never rely on the identity of concepts through an inference, the argument needs supplementing with further identity premises. But we have now started a regress. Any additional identity premise of the form ‘Water is water’ relies on an identity between the concept expressed by the first use of ‘water’ in this premise and that expressed by the use of ‘water’ in some other premise. If one is never allowed to rely on the identity of concepts, the inference must involve a further identity premise. But the same issue arises with any such further premise. 

Someone might hope to break the regress by adding a different kind of additional premise, say, the premise that there is no conceptual equivocation between the first two premises, or that the concept expressed with ‘water’ in the first premise is identical with the concept expressed with ‘water’ in the second. However, it seems implausible that Susan’s inference must contain any premise that involves the concept of a concept. Surely Susan could make a ground-

<!-- page: pdf=0208 printed=none -->

floor inference about water without invoking a premise that involves the concept of a concept. It seems, then, that to block the regress without making implausible assumptions, we need to accept that a subject can sometimes rely on the identity of concepts used in an inference. But, this opens up the possibility that a subject may make an invalid inference through equivocation of concepts. This happens, as in the case of Sally’s aluminum inference when, owing to environmental factors of which she is ignorant, she equivocates between two different concepts. 

In conclusion, once an anti-individualist has accepted that a subject can unwittingly express two distinct concepts by a single term, it is hard for her to deny that this may lead the subject to make simple invalid inferences. The view that although a subject may have two distinct concepts, they cannot figure in a single inference, has counterintuitive consequences and undermines one of the main motivations for the two-concept view. In addition, it seems hard to motivate the view that an inference containing the two concepts must involve an identity premise, given that, in any case, we should accept that a subject can sometimes rely on the identity of concepts through an inference. 

### **6 Rationality and A Priority** 

In the last two sections, I have argued that a great variety of anti-individualist views are incompatible with either transparency of sameness of content or transparency of difference of content and, as a result, undermine a subject’s ability to grasp the logical properties of her thoughts a priori. In more detail, non-Fregean anti-individualism is incompatible with the transparency of sameness of content and has the conse-

<!-- page: pdf=0209 printed=none -->

quence that a subject cannot always realize a priori that two of her beliefs are contradictory or that a certain simple valid inference is valid. A variety of anti-individualist views, including both those that reject Fregean sense and those that accept it, are incompatible with the transparency of difference of content and have the consequence that a subject may make an invalid inference that she can realize is invalid only empirically. 

Some have taken it to be a serious objection to antiindividualism that it undermines a subject’s a priori grasp of the logical properties of her thoughts, for, they say, this is incompatible with our conception of a rational agent. Boghossian (1992) claims that it is a key part of our intuitive conception of ourselves as rational agents that “the logical properties of the inferences we engage in must be judgeable purely a priori” (p. 17). Boghossian (1994) expands his account of what our intuitive conception of a rational agent involves: 

What does a person have to do in order to count as a good reasoner? Clearly, it is not at all a question of knowing empirical facts, of having lots of justified true beliefs about the external world. Rather, it is a matter of being able, and of being disposed, to make one’s thoughts conform to the principles of logic on an a priori basis. A surreptitiously envatted brain—transplanted from its normal adult body into a vat and attached to a computer that seamlessly duplicated and continued its previous course of experience—could be as good a reasoner as it ever was, despite the sharp escalation in the number of its false beliefs about the external world. . . . Since rationality is taken to consist in the ability and disposition to conform to the principles of logic on an a priori basis, any rational subject, regardless of his external conditions, may be expected to obey certain laws (or counterfactual-supporting generalisations): namely, those generalisations that mirror the introspectively obvious consequences of a person’s propositional attitudes. (p. 42)

<!-- page: pdf=0210 printed=none -->

On Boghossian’s conception, “rationality is taken to consist in the ability and disposition to conform [one’s thoughts] to the principles of logic on an a priori basis.” Anti-individualism undermines this conception of rationality by undermining the transparency of content. We have seen that if content is not transparent, then, even in simple cases, a subject may fail to make valid inferences, may have contradictory beliefs, and may make invalid inferences. If a subject needs empirical information in order to grasp sameness and difference of content, then she needs empirical information in order to grasp the logical properties of her thoughts. Boghossian concludes that anti-individualism undermines the notion that ordinary subjects are rational. 

However, it is not clear that it is an objection to antiindividualism that it has the consequence that ordinary subjects are not rational in the sense Boghossian outlines (henceforth, _B-rational_ ), for anti-individualism gives us reason to reject the idea that ordinary subjects are B-rational by undermining transparency. No matter how sophisticated a subject’s grasp of logic, if sameness and difference of content is not transparent to her, she will be unable to make her thoughts conform to the principles of logic a priori. Even the world’s best logician would be unable to do so if content is not transparent. Thus, by undermining transparency, antiindividualism gives us reason to reject the idea that ordinary subjects are B-rational. Instead, anti-individualism suggests that we should distinguish two abilities—the ability to grasp a priori that thoughts specified as having a certain form have certain logical properties, and the ability to grasp a priori of what form one’s thoughts are (Campbell 1987). Given failure of transparency, the anti-individualist argues that a subject could have the first of these abilities while lacking the second. For example, a subject may grasp a

<!-- page: pdf=0211 printed=none -->

priori that an inference of the form “ _p_ , if _p_ then _q_ , _q_ ” is valid. But, if sameness of content is not transparent, then she may need to use empirical information to grasp that certain of her thoughts instantiate this form and thus constitute a valid inference. 

The rejection of the idea that ordinary subjects are B- rational is also motivated by considerations that are independent of the truth of anti-individualism. There is much evidence that subjects do not always conform their thoughts to the laws of logic a priori. Subjects sometimes make mistakes in their reasoning, or have inconsistent beliefs, when only a little logical acumen is required to reveal the mistake. For example, recalling an earlier conversation with my partner, I may be disposed to assent to both ‘Rupert is in London today’ and (recalling reading the relevant page in his diary) ‘Rupert is meeting Helen in her office today’. I may also believe that Helen’s office is in Edinburgh, and that if Rupert is in Edinburgh today, then he’s not in London. However, I may fail to put these beliefs together or notice the inconsistency. Psychologists have shown that even subjects of above average intelligence and education are systematically prone to certain kinds of mistakes in both probabilistic and nonprobabilistic reasoning (Wason and Johnson-Laird 1972; Kahneman 1982; Tversky and Kahneman 1983). 

For example, Wason’s famous selection task involves a deck of cards each of which has a number on one side and a letter on the other. Subjects are presented with four cards, each with only one side visible; they show ‘A’, ‘K’, ‘4’, and ‘7’ respectively. Subjects are asked which cards they need to turn over in order to test the truth of the rule: ‘If a card has a vowel on one side, then it has an even number on the other’. Most subjects answered either that they needed to see both sides of the ‘A’ and ‘4’ cards, or just both sides

<!-- page: pdf=0212 printed=none -->

of the ‘A’ card. In fact they need to look at the ‘A’ and ‘7’ cards. But very few subjects said they needed to see the ‘7’ card. Further, a large number of these subjects found it hard to recover from their mistake. Even once it had been explained to them, they continued to make it in repeat trials, and some insisted that their original choice was still correct. Given this study, it does not seem that such subjects are able and disposed to conform their thoughts to the laws of logic a priori. 

Owens has argued that transparency fails regardless of the truth of anti-individualism. It that were the case, it could hardly be an objection to anti-individualism in particular that it undermines transparency and so the idea that ordinary subjects are B-rational. Owens’s most persuasive argument<sup>4</sup> starts from the fact that philosophers have disagreed over whether the following sentences express the same proposition: 

(i) No one doubts that whoever believes that Mary is a physician believes that Mary is a physician. 

(ii) No one doubts that whoever believes that Mary is a physician believes that Mary is a doctor. 

Kripke and Church hold that (i) and (ii) express the same proposition, one that is true (Kripke 1979, n. 23, 45; Church 1954). However, Burge and Mates argue that although (i) is true, (ii) is false, and so they conclude that (i) and (ii) differ in content (Burge 1976; Mates 1952). This disagreement about whether the sentences (i) and (ii) express the same proposition can be used to argue that there is a pair of thoughts that each philosopher thinks although they disagree about whether these thoughts have the same or different content. Each philosopher believes that the thought

<!-- page: pdf=0213 printed=none -->

he expresses when he utters either of these sentences is the thought expressed by the sentence in the public language (Falvey and Owens 1994, p. 113). This seems prima facie plausible, for we may suppose that each philosopher would correctly explicate each of the terms in (i) and (ii) and correctly understands how the meaning of each sentence is built up out of the meaning of its parts. If, by (i) and (ii), each philosopher expresses the thought expressed by the sentence in the public language, then there is a pair of thought contents that, say, both Kripke and Burge entertain, although they disagree about whether these contents are of the same or different type. Of course, one of these philosophers must be wrong. Further, Owens argues that introspection is not enough to determine which is wrong; empirical investigation is required (Owens 1989, pp. 305–311; Falvey and Owens 1994, pp. 112–113). Thus, either transparency of sameness or difference of content fails: either the pair of thoughts have the same content and one philosopher falsely believes that they have different contents, where this mistake can be corrected only empirically; or, the thoughts have different contents and one philosopher falsely believes that they have the same content, where this mistake can be corrected only empirically. 

Let us now assess whether this argument shows that, regardless of the truth of anti-individualism, transparency is false. To do so, we must consider whether it is compatible with individualism to hold that all of Burge, Mates, Church, and Kripke have the thoughts expressed by (i) and (ii) while disagreeing about whether those thoughts have the same or different content. It might be said that this description of the case is incompatible with individualism, since a motivation for the Burge/Mates view that (i) and (ii) express different thoughts is Burge’s anti-individualist

<!-- page: pdf=0214 printed=none -->

position. This position combines social anti-individualism and the view that synonymous terms do not express the same concept. Social anti-individualism allows that a subject may have a concept without fully understanding it. For example, it allows that a subject could have the concepts doctor and physician although, because she misunderstands the concept physician, she sincerely asserts ‘Mary is a doctor’, but denies ‘Mary is a physician’. Further, if ‘physician’ and ‘doctor’ express different concepts, then a subject might believe that Mary is a doctor but fail to believe that Mary is a physician. (If the two terms express the same concept, then it is impossible for a single subject to believe simultaneously that Mary is a doctor but not believe that Mary is a physician.) Thus anyone who accepts Burge’s position should hold that (i) is true while (ii) is false and, thus, that (i) and (ii) express different thoughts. 

However, although the view that (i) and (ii) express different thoughts is motivated by Burge’s position, that view does not require that Burge’s position is correct. Rather, a subject persuaded by Burge’s views would hold that (i) and (ii) express different thoughts even if, unknown to her, Burge’s position were in fact false. Holding that (i) and (ii) have different contents does not require that ‘doctor’ and ‘physician’ express different concepts, or that any subject actually has a concept while incompletely understanding it, but only that one accepts these claims. In particular, it is part of the case that Burge and Mates do fully understand the terms ‘doctor’ and ‘physician’. They are motivated to suppose that (i) and (ii) express different contents not by incomplete understanding of any of the relevant terms, but rather by their theoretical commitments regarding synonymous terms and anti-individualism. Thus, individualism is

<!-- page: pdf=0215 printed=none -->

Anti-Individualism and Reasoning 

compatible with all of Burge et al. having the thoughts expressed by (i) and (ii).<sup>5</sup> 

It seems, then, that whether or not anti-individualism is true, psychological experiments on reasoning and the Mates argument show that subjects ordinarily judged rational may make mistakes about content and the simple logical properties of their thoughts, where these mistakes are persistent and not easily correctable. As a result, it seems that ordinary subjects are not B-rational: they are not disposed to conform their thoughts to the laws of logic. Thus, it can hardly be an objection to anti-individualism in particular that it has the consequence that ordinary subjects are not B-rational. 

However, even if subjects are not B-rational, we still need a conception of rationality if we are to continue to assess reasoning as rational, or irrational, and to predict and explain action. In explaining and predicting action, we seem implicitly to use general psychological principles that mirror the laws of logic, for example: 

If _S_ occurrently believes _p_ and occurrently intends to _F_ if _p_ , and if _S_ has no independent reason for not _F_ -ing, then _S_ will intend to _F_ or, at the very least, will be disposed to intend to _F_ ; and, 

If a subject wants _q_ and believes that if she _F_ s then _q_ , believes that she can _F_ , has no conflicting desires, and does not believe that there is a better way to obtain _q_ , then _S_ will be disposed to _F_ . 

(See Churchland 1970; Boghossian 1992; Fodor 1987; Millikan 1993.) Boghossian (1994) thinks that it will be difficult for an anti-individualist to reconfigure a notion of rationality to use in predicting and explaining action. He

<!-- page: pdf=0216 printed=none -->

says that any adequate refashioning of the notion of rationality needs to reflect our intuitive distinction between cases of contradiction in belief and invalid inference where a subject is absolved from fault, and cases where she is not. Boghossian rejects two suggestions about when a subject is absolved from believing a contradiction: (1) when she doesn’t or can’t see the contradiction and (2) when the contradictory character of the proposition she believes is inaccessible to mere a priori reflection (pp. 42–46). He rejects (1) since, he says, irrationality often consists in not being able to see a contradiction. He rejects (2) since, he claims, if antiindividualism is true, any contradictory proposition will be such that its contradictory character cannot be accessed merely by a priori reflection.<sup>6</sup> 

However, anti-individualism is in a better position than Boghossian thinks. Even if there are counterexamples to transparency, we may still be able to use the psychological principles outlined above as a guide to prediction and explanation.<sup>7</sup> As long as cases in which a subject unwittingly has synonymous terms, or unwittingly expresses two different concepts by a single term, are infrequent, then the psychological generalizations will still be generally true. Thus, we can continue to use these principles as a basis for prediction and explanation tempered by evidence about whether the subject realizes the relations of sameness and difference between her thought contents. The anti-individualist may also suggest a way of drawing the distinction between those logical failings for which we blame agents, and those for which we do not. It does indeed seem intuitive to say that Rudolf is blameless for holding contradictory beliefs and that Sally is blameless for making an invalid inference. By contrast, someone who believed that there is a single herb, cilantro, that both was and was not known to the ancient

<!-- page: pdf=0217 printed=none -->

Anti-Individualism and Reasoning 

Romans would indeed be rationally at fault; such a belief would indicate something wrong with her reasoning. One way to draw this distinction would be to say that a subject is blameless for having a pair of contradictory beliefs of the form _a_ is _F_ and _a_ is not _F_ if, were the question to arise, she would doubt or deny that the beliefs concern the same object. Similarly, we may say that a subject is blameless for making an inference that is invalid through a fallacy of equivocation if she would mistakenly affirm the relevant identity, were the question to be raised. These principles seem to separate clearly the cases Boghossian plausibly takes to be cases of blameless logical failing from those for which we would properly blame the agent: on being asked whether cilantro is coriander, Rudolf would either say he’s unsure or deny it. And, were Sally to be asked whether the relevant beliefs she expresses by ‘aluminum’ concern the same stuff, she would respond affirmatively. 

### **7 Conclusion** 

I have been examining the objection that anti-individualism is incompatible with the transparency of content and thus undermines a subject’s reasoning. I have argued that antiindividualism of a variety of kinds is incompatible with transparency of difference of content, and/or transparency of sameness of content. More precisely, non-Fregean anti-individualism is incompatible with transparency of sameness of content and a variety of anti-individualist views, both Fregean and non-Fregean, are incompatible with transparency of difference of content. As a result, antiindividualism undermines a subject’s ability to grasp a priori the logical properties of her thoughts. Thus, if antiindividualism is true then, even in simple cases, a subject

<!-- page: pdf=0218 printed=none -->

may have contradictory beliefs, make invalid inferences, or fail to make valid inferences. 

However, I have argued that it is no objection to antiindividualism that it has these consequences. Antiindividualism provides reason to reject the concept of a rational subject as one who is able and disposed to conform her thoughts to the laws of logic a priori. Further, regardless of whether anti-individualism is true, there is reason to reject the idea that subjects ordinarily judged rational are disposed to conform their thoughts to the laws of logic a priori. Despite this, I have argued that an anti-individualist can still regard psychological principles that mirror the laws of logic as providing useful generalizations for the purposes of prediction and explanation. I have also suggested that the anti-individualist can make sense of the distinction between those logical failings for which we blame agents and those for which we do not.
