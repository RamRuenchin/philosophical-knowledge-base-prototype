---
title: "Index"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 375
locator_end: 379
---

# Index

<!-- page: pdf=0375 printed=none -->

## **Index** 

- Achievement problem, 234, 237, 274, 309. _See also_ Discrimination argument; Illusion argument 

- Agnosticism, 294–298, 300–301 

- Anti-individualism, 2–5, 8–9. _See also_ Illusion version of antiindividualism; Descriptive version of anti-individualism 

- Fregean, 1, 20–22, 25, 29–30, 78, 193–231, 311 ( _see also_ Transparency of difference of content, and Fregean antiindividualism; Transparency of sameness of content, and Fregean anti-individualism) 

- natural kind, 1, 9–13, 17, 38–45, 142–145, 147, 152, 163, 169, 172–175, 234, 271, 274–290, 293–294, 300–301 

- non-Fregean, 20, 193–203 ( _see also_ Transparency of difference of content, and non-Fregean antiindividualism; Transparency of sameness of content, and nonFregean anti-individualism) 

- singular, 1, 13–15, 38, 76–111, 126–129, 145–152, 163, 165, 169, 206–210, 213–216, 222–225, 289–294 

- social, 1, 17–20, 38, 138–142, 152, 163–165, 169, 173–175, 188, 278, 294–301 

- A priori knowledge, 22–25 

- of entailments from thought to world, 31, 237–238, 272–302 

- of logical properties, 158–159, 162–163, 166, 168–170, 177, 182–191, 224–231 

- of sameness and difference of 

- content, 157–161 ( _see also_ 

- Transparency of difference of content; Transparency of sameness of content) 

- of thought, 24–28, 30–37 ( _see also_ Privileged access) 

- of the world, 30–32, 235–240, 242, 254–257, 269 

- Architecturalism argument, 305–306 

- Area of search, 82–83, 98–108 actual, 98–105, 107–108 estimated, 98–102, 106, 316n2 

Bad case, 283–287, 289, 291, 293 Beebee, Helen, 259 

- BIV argument, 243–244, 246, 248, 250–252, 257–258, 262

<!-- page: pdf=0376 printed=none -->

336 

Boghossian, Paul, 15, 183–184, 189–191, 278, 285 B-rational, 184–189 Brewer, Bill, 238 Burge, Tyler, 163–164, 175–178 Campbell, John, 180, 206–210, 213–214 Circular, 243–244, 258–260, 269. _See also_ Conditional analysis Closure of knowledge, 239, 241–243, 288–289, 304–307 of warrant, 239, 305–307 Conditional analysis, 246–257, 306 Consequence problem, 234–237, 310. _See also_ Reductio argument Davies, Martin, 31, 234, 236, 238–244, 257–269, 288, 303–306 DeRose, Keith, 238 Descriptive model of thought. _See_ Thinking of an object, by description Descriptive thought. _See_ Thinking of an object, by description Descriptive version of antiindividualism, 16, 85, 114, 116, 126, 151 and the discrimination argument, 38–39, 137 and the reductio, 279–283, 285, 292 Discrimination argument, 26–28, 37–73, 75–77, 83–97, 100, 103–106, 110–117, 135–137, 154, 309 standard response to, 26–27, 43–73, esp. 43–45, 309 Discriminative abilities and knowledge, 26–28, 41–42, 44–47, 59–73, 75, 83, 93–96, 109–110, 136, 154, 310 

and knowledge of thought, 26–28, 38, 40, 44, 58, 69–71, 75–77, 83–85, 88–91, 96, 110–113, 116, 136–138, 309 required for thought, 9, 28, 73, 76–96, 98, 106–109, 111, 136, 215–217, 223–224 and thought, 26–28, 38, 40, 44, 48–59, 69–77, 84–106, 110–113, 116, 136–138, 140, 309 Distinguishing kinds, 108–110, 144 Distinguishing objects, 9, 28, 77–89, 92, 98, 106–111, 215, 223 Dretske, Fred, 240–242 Evans, Gareth, 3, 73, 75–112, 136, 213–216, 223–224 Externalism (epistemological), 68, 249–251, 257, 263, 266–268 Falvey, Kevin, 64–71, 161–162, 165, 297 Frances, Bryan, 217–225 Frege, Gottlob, 20–21. _See also_ Anti-individualism, Fregean; Sense 

Generality problem, 132–133 Gettier, Edmund, 124–125, 263–269 Global reliabilist approach, 121, 124–129, 132 Global reliability, 28, 121, 123–134, 155, 267, 315n9 Goal argument, 260–263 Goldman, Alvin, 45–47, 59–63, 120–121, 124–126, 250–251, 264, 267–268 

Heal, Jane, 172–174 Illusion argument, 26, 28, 30, 37, 113–119, 121–123, 129–137, 155, 309

<!-- page: pdf=0377 printed=none -->

Illusions of thought, 1, 15–16, 26, 28, 37, 39, 78, 85, 90–91, 114–119, 122–123, 129, 133–135, 137, 148, 151, 155, 207, 214, 255, 279–289, 291–294, 300, 303, 309 

Illusion version of antiindividualism, 1, 16–17, 77, 126, 151. _See also_ Illusions of thought; Illusion argument and the discrimination argument, 38–39, 84–85, 90–91, 115–116 and the reductio, 279–283, 292–293 Internalism (epistemological), 249, 251, 263, 266–268 

Local reliabilist approach, 121, 124–129 Local reliability, 28, 120–129, 134, 155, 268–269, 315n9 

McGinn, Colin, 46–47, 120–121, 124–126, 130–131 McKinsey, Michael, 236 McLaughlin, Brian, 67–71, 297, 323n6, 325n14, 326n4 Memory preservative, 168, 175–177 and slow switch, 55–58, 92–93, 171, 178–179, 215 ( _see also_ Twoconcept view) Merricks, Trenton, 325n18 Moore’s proof of the external world, 243, 261 

Nondescriptive model of thought. _See_ Thinking of an object, nondescriptively No-reference case, 15–16, 39, 84–85, 111–117, 135, 137, 147–154 Nozick, Robert, 120–121, 240–242 

Owens, Joseph, 64–71, 161–162, 165, 186–187 

Perceptual demonstrative thoughts, 6, 13–15, 76–77, 80–81 and the discrimination argument, 83–84, 86–96, 145–151, 154 and the illusion argument, 115–135, 147–151, 154 and the reductio, 289–294 and transparency, 206–210, 213–217, 222–225 Plantinga, Alvin, 325n18 Pritchard, Duncan, 323n6 Privileged access, 36–37, 152–156, 233–236. _See also_ A priori knowledge, of thought; Discrimination argument; Illusion argument; Reductio argument Pryor, James, 323n9 

Question-begging, 258–259, 269, 323n4 Rational agent, concept of, 25, 29, 32, 158–161, 166, 169–170, 182–184, 190–192, 195, 224, 229–231, 310. _See also_ B-rational Rationality and arguments for sense, 30, 196–204, 209, 217, 226–230 Recognitional capacities, 6–7, 79, 81–84, 96–112, 143–145, 150, 153 Recognition-based thoughts, 6–7, 81–83, 96–112, 135, 143–145, 147, 149, 150, 153 Reductio argument, 1, 31, 236–239, 241–242, 246, 251, 254–257, 269–274, 303–307, 310. _See also_ Illusion version of antiindividualism, and the reductio

<!-- page: pdf=0378 printed=none -->

Reductio argument (cont.) Sense, 1, 20–22, 25, 32, 194. _See also_ argument; Relevant alternatives, Anti-individualism, Fregean and the reductio argument; a priori knowledge of difference Water argument of sense, 221–222, 224 and natural kind antiarguments for, 30, 196–203, 226, individualism, 274–289, 293–294, 228, 230 300–301 object-dependent, 22, 29–30, and singular anti-individualism, 194–195, 206, 214, 311 289–294 transparency of, 206–210 and social anti-individualism, transparency of difference of 294–301 content and, 169, 208, 212, Relevant alternatives, 27–28, 32, 220–221, 224 41–43, 46–48, 58–62, 64–73, transparency of sameness of 75–77, 83–88, 120–123, 135–138, content and, 165–166, 169, 205, 152–155, 310 207–209, 212 and illusion of thought, 117–118, Skepticism, 30–31, 41–42, 62, 134, 147–151 238–239, 246–247, 251–254, 257, and perceptual demonstrative 262 thought, 86–96, 145–147 Slow switch, 37–45, 48–59, 64–73, and recognitional capacities, 87–96, 138–142, 153, 159, 97–110 166–180, 206–219, 223–224, 226 and recognition-based thought, 97–105, 107–112, 143–145 Thinking of an object and the reductio, 249, 258–269, by description, 5–8, 11–16, 21, 39, 298–299, 304 79–80, 94–96, 114, 137, 141, 151, and social anti-individualism, 194, 279–286, 289–294 ( _see also_ 138–142 Descriptive version of antiReliabilist account of warrant, 250, individualism) 267–269 nondescriptively, 6–8, 14–15, 77, Reliability. _See also_ Local reliability; 280, 282, 291, 293 Local reliabilist approach; Global Transmission reliability; Global reliabilist of knowledge, 31, 239, 242–243, approach 287–289, 303–304 and discriminative abilities, of warrant, 31, 239, 243–246, 248, 43–73, 154 251, 254, 256–266, 270, 304–306 and illusion argument, 116–119, Transparency of difference of 121–123, 129–137 content, 29, 160, 166–170, 172, and knowledge, 27–28, 45–47, 176, 182–187, 191, 310, 319n2 59–73, 135–137, 154 and Fregean anti-individualism, about thoughts, 27, 43–44 29, 160, 169, 195–196, 210–230 and non-Fregean antiSawyer, Sarah, 238, 314n3 individualism, 29, 169, 195–196, Segal, Gabriel, 163 216–217, 222, 230 

Sawyer, Sarah, 238, 314n3 Segal, Gabriel, 163

<!-- page: pdf=0379 printed=none -->

Index 

339 

Transparency of sameness of content, 29, 160–166, 182–187, 191, 310, 319n2 and arguments for sense ( _see_ Sense, arguments for) and Fregean anti-individualism, 29, 160, 165–166, 169, 195–196, 200–210, 212, 225–230 and non-Fregean antiindividualism, 29, 165–166, 195–196, 200–204, 209, 230 Two-concept view, 168, 170–183, 210–220 Tye, Michael, 67–71, 171–172, 297, 326n4 Warfield, Ted, 238 Water argument, 240–246, 248, 254–258, 261 Wright, Crispin, 31, 239–258, 269, 288, 303–304, 306–307 Zebra argument, 241, 243–248, 251–252, 257–262
