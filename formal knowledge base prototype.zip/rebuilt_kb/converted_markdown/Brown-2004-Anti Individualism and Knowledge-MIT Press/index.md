---
title: "Brown-2004-Anti Individualism and Knowledge-MIT Press"
source_type: "book"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
---

# Brown-2004-Anti Individualism and Knowledge-MIT Press

## Contents

1. [[complete|Complete transcription]]
2. [[00-front-matter|Front Matter and Contents]]
3. [[01-preface|Preface]]
4. [[02-chapter-1-anti-individualism|Chapter 1: Anti-Individualism]]
5. [[03-chapter-2-knowledge-and-discrimination|Chapter 2: Knowledge and Discrimination]]
6. [[04-chapter-3-thought-and-discriminative-abilities-evans|Chapter 3: Thought and Discriminative Abilities—Evans]]
7. [[05-chapter-4-the-illusion-argument|Chapter 4: The Illusion Argument]]
8. [[06-chapter-5-anti-individualism-and-reasoning|Chapter 5: Anti-Individualism and Reasoning]]
9. [[07-chapter-6-anti-individualism-and-fregean-sense|Chapter 6: Anti-Individualism and Fregean Sense]]
10. [[08-chapter-7-the-reductio-argument-transmission-of-warrant|Chapter 7: The Reductio Argument: Transmission of Warrant]]
11. [[09-chapter-8-the-reductio-argument-entailments-between-thought-and-the-world|Chapter 8: The Reductio Argument: Entailments between Thought and the World]]
12. [[10-chapter-9-conclusion|Chapter 9: Conclusion]]
13. [[11-notes|Notes]]
14. [[12-references|References]]
15. [[13-index|Index]]
