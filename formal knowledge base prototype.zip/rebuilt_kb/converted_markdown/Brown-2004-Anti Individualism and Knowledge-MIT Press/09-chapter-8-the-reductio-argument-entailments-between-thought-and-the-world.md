---
title: "Chapter 8: The Reductio Argument: Entailments between Thought and the World"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 303
locator_end: 339
---

# Chapter 8: The Reductio Argument: Entailments between Thought and the World

<!-- page: pdf=0303 printed=none -->

**8** 

**The Reductio Argument: Entailments between Thought and the World** 

### **1 Introduction** 

In this chapter, we continue our examination of the reductio argument for the incompatibility of anti-individualism and privileged access. In the last chapter, we examined and rejected Davies’s and Wright’s responses to the reductio, that warrant and knowledge fail to transmit across the relevant inference. In this chapter, I want to examine a different response. To situate this response, it is useful to recall the steps of the reductio argument. 

According to the reductio argument, the joint assumptions of anti-individualism and privileged access have the absurd consequence that a subject can have a priori knowledge of substantive facts about the world. We may illustrate the argument using natural kind anti-individualism. Suppose that Sally is an Earth subject who is ignorant of the chemical composition of water. Despite this, natural kind anti-individualists accept that in virtue of Sally’s interactions with samples of water she has the concept of water and thinks, for example, that water is wet. The main steps of the argument proceed as follows:

<!-- page: pdf=0304 printed=none -->

272 

Chapter 8 

(R1) Sally can know a priori that she thinks that water is wet. _(From the assumption of privileged access.)_ 

(R2) Sally can know a priori that if she thinks that water is wet, then her environment contains water. _(From the assumption of anti-individualism.)_ 

(R3) Sally can know a priori that her environment contains water. _(From (R1) and (R2).)_ 

(R4) But (R3) is absurd. 

(R5) So, anti-individualism and privileged access are incompatible. _(From (R1)–(4).)_ 

Notice that the reductio can be formulated independently of the notion of the a priori: it seems absurd to suppose that a subject can have knowledge of substantive facts about the world on the basis of her thoughts and philosophy (see chap. 7, sec. 1). 

In the last chapter, I rejected a number of objections to the argument: that (R1) does not follow from the assumption of privileged access, that (R3) does not follow from (R1) and (R2), and that (R4) is false. If my rejection is correct, then the reductio can be challenged only by arguing that (R2) does not follow from the assumption of antiindividualism. In the rest of the chapter I will pursue this strategy (cf. Gallois and O’Leary-Hawthorne 1996; McLaughlin and Tye 1998). Proponents of the reductio argue that (R2) and analogous principles for other types of antiindividualism follow from the fact that anti-individualism is established by philosophical arguments. However, I will argue that even if we grant that anti-individualism is established by philosophical arguments, knowledge of those arguments would not allow Sally to know a priori that if she

<!-- page: pdf=0305 printed=none -->

Entailments between Thought and the World 273 

thinks that water is wet then her environment contains water. More generally, I argue that where the thought that _p_ is partly individuated by some environmental condition _E_ , knowledge of the arguments for anti-individualism does not enable a subject who thinks that _p_ to know a priori that if she thinks that _p_ then _E_ . 

As a first step in the discussion, notice that knowledge of the Twin Earth arguments alone is unlikely to yield a priori knowledge that if one thinks that _p_ then _E_ . First, the Twin Earth arguments concern a subject stipulated to be in certain environmental conditions, say, that she has interacted with samples of water (Putnam), or that she is part of a linguistic community (Burge). But, a subject could have only empirical knowledge that she is in such conditions and thus that the Twin Earth arguments apply to her. Second, these arguments most obviously establish a counterfactual dependence of thought on environment. They ask us to consider a subject in certain conditions and argue that, if she had been in different conditions, then she would have had a different thought. For instance, if instead of being brought up on Earth interacting with water, the subject had been brought up on Twin Earth interacting with twater, then she would have had the concept twater rather than the concept water. But this does not show that having a certain kind of thought, say, one involving the concept water, entails some particular environmental condition, say, that one’s environment contains water. For instance, Burge accepts that if an Earth subject who actually has the concept of water but who is ignorant of the chemical composition of water, had instead been brought up on Twin Earth, she would have lacked the concept of water. But he denies that this shows that having the concept water entails that one’s environment contains water, and indeed he rejects this claim. Instead, he says, one

<!-- page: pdf=0306 printed=none -->

could have the concept water in a waterless world in which there are other speakers or in which one knows that water is H2O. (See Burge 1982, p. 116. See also Brueckner 1992b; Gallois and O’Leary-Hawthorne 1996, pp. 11–12.) 

Nevertheless, perhaps a subject could use antiindividualism to gain a priori knowledge of conditional principles of the form: if a subject is in a certain psychological condition and certain other conditions hold, then her environment must be some particular way. If a subject could know a priori that she meets the antecedent of one of these conditionals, then perhaps she could use it to gain a priori knowledge of some specific connection between her thoughts and the environment. I will investigate this idea in the rest of the chapter. Although I argue that each type of anti-individualism establishes conditional principles of the relevant form, I argue that a subject cannot know priori that she meets the antecedent of these conditionals. Thus, it turns out that a subject cannot use these conditional principles to gain a priori knowledge of some specific connection between her thoughts and the environment. I conclude that the reductio fails. 

Combined with my earlier discussion of the achievement problem (chaps. 2–4), this concludes my defense of the compatibility of anti-individualism and privileged access. The argument below draws on some earlier work (Brown 1995 and 2001) but represents a change of mind: in those earlier papers, I argued that the reductio does indeed show that anti-individualism is incompatible with privileged access. 

### **2 Natural Kind Anti-Individualism** 

In this section, we focus on natural kind anti-individualism, setting aside other anti-individualist theses. (Combinations

<!-- page: pdf=0307 printed=none -->

Entailments between Thought and the World 

275 

of anti-individualist theses are considered in sec. 5.) According to natural kind anti-individualism, a subject’s thought contents are individuated partly by the natural kinds that are in her environment. We have already seen that the Twin Earth arguments do not obviously support the idea that a subject could know a priori that, say, having the concept water entails that one’s environment contains water. Rather, our question is whether a subject could use natural kind anti-individualism to gain a priori knowledge of a conditional principle of the form: if a subject is in certain psychological and other conditions, then her environment contains a certain natural kind. If the subject could know a priori that she meets the antecedent of such a conditional, she might be able to gain a priori knowledge that, say, if she thinks that water is wet then her environment contains water. 

Let us start our investigation of this strategy by considering a subject who has a concept of a natural kind, that is, a concept that names, or refers to, a natural kind. In what circumstances could a subject have such a concept? She could have such a concept even if there are no instances of the relevant kind in her environment as long as she knows the fundamental nature of that kind, say, its chemical composition. For example, a subject who has the concepts of hydrogen and oxygen could put them together to yield the concept H2O even if there are no samples of H2O in her environment. So, let us restrict our attention to a subject who is ignorant of the fundamental nature of the relevant natural kind and has an atomic concept of that kind, that is, a concept that is not built up out of component concepts in the manner of H2O.<sup>1</sup> (From now on, I will use the expression “chemically indifferent” to describe a subject ignorant of the fundamental properties of the relevant natural kind.) Suppose she has

<!-- page: pdf=0308 printed=none -->

the concept gold. Natural kind anti-individualism allows that a subject who has interacted with samples of gold could have the concept gold even if she is ignorant of its fundamental nature. Now consider a counterfactual situation in which this same subject while being chemically ignorant is instead brought up in an environment in which there is no gold. It is hard to see how she could have the concept gold in this counterfactual situation. She is ignorant of the chemical composition of gold; and in this counterfactual situation, there is no gold in her environment. At the moment, we are considering only natural kind anti-individualism and setting aside other anti-individualist theses, such as social anti-individualism. So, even if there are other speakers, they cannot help her to have the concept gold. Thus, whatever concept, if any, she expresses with ‘gold’, it cannot be the concept gold. It seems, then, that natural kind anti-individualism establishes the following conditional principle: 

(A) If _S_ has a concept that names a natural kind _ki_ , and she is chemically indifferent, then her environment contains instances of _ki_ . 

(Here, and in the following principles, I abbreviate the claim that her environment now, or used to, contain instances of _ki_ by the claim that her environment contains instances of _ki_ .) Suppose that a subject could have a priori knowledge of this principle (for a full defense of this claim and (A) itself, see Brown 1995, 2001). If she could also have a priori knowledge that she meets the antecedent of the principle, then she could use it to gain a priori knowledge of connections between her thoughts and the world. 

For instance, consider Sally, the subject of the Twin Earth thought experiment. She has the concept water in virtue of

<!-- page: pdf=0309 printed=none -->

Entailments between Thought and the World 

277 

interacting with water despite the fact that she is chemically indifferent. If she could know a priori that she has the concept water, that it names a natural kind and that she is chemically indifferent, she could know a priori that if she thinks that water is wet then her environment contains water. But, unfortunately for the defender of the reductio, Sally cannot know a priori that she meets the antecedent of this principle, in particular, that she has a concept that names a natural kind. To show this, we need only rely on the widely held view that _S_ ’s true belief that _p_ is knowledge only if, were _p_ false, she would not believe that _p_ .<sup>2</sup> Consider a possible situation in which, although Sally intends ‘water’ to name a natural kind, it fails to do so. This could occur if she is on Motley Earth, where the stuff in rivers and lakes forms a motley of various natural kinds. Alternatively, it could occur if she is on Dry Earth, where, although it seems as if there are rivers and lakes full of a watery liquid, in fact there are no such rivers and lakes; rather, Sally and her community are just under the illusion that there are. In either scenario she would still believe that ‘water’ names a natural kind. She could correct her view only empirically. Thus, in the actual situation, she does not know a priori that ‘water’ names a natural kind. In general, it is an empirical matter whether a term intended to name a natural kind in fact does so. There are numerous examples of terms that were intended to name natural kinds but in fact fail to do so, such as ‘phlogiston’ and ‘jade’. (E.g., see Brown 1995; Gallois and O’Leary-Hawthorne 1996, pp. 6–7; Boghossian 1997, p. 168.) 

It seems, then, that our first attempt to defend (R2) has failed. A subject cannot have a priori knowledge that she meets the antecedent of principle (A), in particular, that she has a concept that names a natural kind. Two main ways of

<!-- page: pdf=0310 printed=none -->

circumventing this problem have been suggested. In my (1995), I recommend broadening the target of the reductio from natural kind anti-individualism to a position that combines natural kind and social anti-individualism. The idea is that a reductio formulated against this broader position would not require a priori knowledge that a concept names a natural kind since the broader position applies to all concepts, not just a particular type of concept. I will discuss this strategy in section 5 below. 

By contrast, Boghossian (1997) retains the target of the reductio as natural kind anti-individualism alone, but reformulates the reductio using the notion of a term that is intended to name a natural kind. It seems much more plausible that Sally could know a priori that she intends a certain term to name a natural kind, than that the term actually names a natural kind. The idea, then, is to show that someone who knows the arguments for anti-individualism could thereby gain a priori knowledge of an entailment from thought to world of the form: If _S_ has a term _t_ that she intends to name a natural kind and . . . , then _t_ refers to a natural kind and her environment contains instances of that kind. If Sally could have a priori knowledge of such an entailment, she might be able to use it to gain a priori knowledge of connections between her thoughts and the world. For instance, if she can know a priori that she intends ‘water’ to name a natural kind and that she meets the other conditions in the antecedent, then she may be able to know a priori that if she thinks that water is wet then her environment contains water. I examine this general strategy here. 

Let us consider, then, what natural kind anti-individualism would say about a term that is intended to name a natural kind. Suppose that Sally has a term _t_ that she intends to name a natural kind, although she is ignorant of the fun-

<!-- page: pdf=0311 printed=none -->

Entailments between Thought and the World 

279 

damental properties of that supposed kind. If her use of the term is suitably connected to a natural kind, then natural kind anti-individualists would hold that she uses the term to express a concept of that kind. Now suppose that she is brought up in a situation in which, although she has the same history of individualistic states and intends that _t_ name a natural kind, it fails to do so. This might be either because the stuff to which _t_ is applied is a motley collection of natural kinds, or because (more radically) there is no stuff to which it is applied and Sally suffers illusory perceptual experiences. As we know, there are two possible views for a defender of natural kind anti-individualism to take about such cases: according to the illusion view, the term fails to express any concept at all, and the subject suffers an illusion of thought; according to the rival descriptive view, the term expresses a descriptive concept of the form the _F_ , such as the liquid that actually falls from the skies around here (chap. 1, sec. 4). (Note that it does not follow from the descriptive view that when the term does succeed in naming a natural kind it expresses a descriptive concept.) These different anti-individualist views yield different principles about the case where a subject intends a term to name a natural kind but it fails to do so. The illusion view establishes the following principle: 

(B) If a chemically indifferent subject _S_ intends _t_ to name a natural kind although it fails to do so, then _S_ suffers an illusion of thought. 

By contrast, a different principle follows from the descriptive view: 

(C) If a chemically indifferent subject _S_ intends a term to name a natural kind although it fails to do so, then _t_ expresses a descriptive concept of the form, the _F_ .<sup>3</sup>

<!-- page: pdf=0312 printed=none -->

In what follows I will set aside the reasons that might motivate someone to adopt the illusion or the descriptive view. Instead, I will consider each view in turn and consider whether either could be used to defend (R2): Sally can know a priori that if she thinks that water is wet then her environment contains water. 

As a first step in examining this issue, notice that [If (( _P_ and _Q_ ) and _R_ ) then _S_ ] is logically equivalent to [If (( _P_ and _Q_ ) and not- _S_ ), then not- _R_ ]. So principles (B) and (C) above are logically equivalent to: 

(B¢) If a chemically indifferent subject _S_ intends a term _t_ to name a natural kind and it’s not the case that _S_ suffers an illusion of thought, then _t_ names a natural kind. 

(C¢) If a chemically indifferent subject _S_ intends a term _t_ to name a natural kind and _t_ does not express a descriptive concept of the form, the _F_ , then _t_ names a natural kind. 

The reformulated principles (B¢) and (C¢) state entailments from certain psychological conditions to the claim that a certain term names a natural kind. If Sally knows a priori that she meets the conditions mentioned in the antecedent of one of these principles and that the principle is true, then she could use this knowledge to gain a priori knowledge of connections between her thoughts and the world. For instance, suppose that she has a priori knowledge of (B¢), that she is chemically indifferent, that she intends ‘water’ to name a natural kind, and that it’s not the case that she suffers an illusion of thought. In that case, perhaps, she could come to know a priori that if she thinks that water is wet, then there is water in her environment. On the assumption that there are philosophical arguments that settle the

<!-- page: pdf=0313 printed=none -->

debate between the illusion and descriptive views, Sally could use knowledge of these arguments to gain a priori knowledge of that anti-individualist view and the corresponding principle. So, the key question is whether she can have a priori knowledge that she meets the conditions in the antecedent. 

It seems plausible that Sally could know a priori that she meets two of the conditions mentioned in the antecedent of each principle, namely that she is chemically indifferent and that she intends _t_ to name a natural kind. In particular, it seems that she can know a priori that she has no idea of the chemical composition of what she calls ‘water’ and that she intends ‘water’ to name a natural kind. However, the antecedent of each principle contains a further condition: that it is not the case that Sally suffers an illusion of thought (B¢); and that it is not the case that ‘water’ expresses a descriptive concept (C¢). So, the success of the reductio turns on whether Sally can have a priori knowledge of these further conditions. However, I will argue that it is implausible that Sally can have such knowledge by using the claim that _S_ ’s true belief that _p_ is knowledge only if, were _p_ false, she would not believe that _p_ . 

Let us start by considering the illusion version of natural kind anti-individualism. Suppose that chemically indifferent Sally is actually on Earth where the lakes and rivers are full of water. Thus, she intends that ‘water’ name a natural kind, and it does so. Further, suppose that Sally is convinced of the truth of the illusion version of natural kind antiindividualism, and truly believes that she is not suffering an illusion of thought. Nonetheless, her belief is not a case of a priori knowledge, for were she suffering an illusion of thought, she would believe that she is not. Consider a counterfactual situation in which she is suffering an illusion of

<!-- page: pdf=0314 printed=none -->

thought. She would suffer such an illusion if she were on Dry Earth, where there is no liquid in the rivers and lakes although everyone suffers an illusion of there being such a liquid. Alternatively, Sally would suffer an illusion of thought if she were on Motley Earth, where although there is a tasteless, colorless, clear liquid in the rivers and lakes, it is composed of a motley of different natural kinds. In either scenario, it would seem to Sally as if there is a clear, colorless, liquid in the lakes and rivers. She would take it that there is a dominant natural kind in the lakes and rivers to which her term ‘water’ refers. Thus, if the question were to arise, she would deny that she is suffering an illusion of thought on Dry or Motley Earth, though she would be suffering such an illusion. 

Now consider the alternative anti-individualist view, that on Dry and Motley Earth Sally would not suffer an illusion of thought but instead would have a descriptive thought (I use the expression “descriptive thought” as an abbreviation of the more elaborate claim that her thought contains a descriptive component, here one corresponding to the term ‘water’). Suppose too that Sally were convinced of the descriptive version of anti-individualism. Even if she were, and the question were to arise, it seems that if she were on Dry or Motley Earth she would deny that she is having a descriptive thought. In either situation, it would seem to her as if there is a liquid present in the rivers and lakes. She would believe that her term ‘water’ names the dominant natural kind in the rivers and lakes. 

In summary, it seems that in the actual situation Sally cannot know a priori that she is not having either an illusion of thought, or a descriptive thought. If she were and the question were to arise, she would believe that she is not. It will be useful to have a shorter way of stating this con-

<!-- page: pdf=0315 printed=none -->

Entailments between Thought and the World 

clusion. Let the _bad case_ cover both the possibility that a subject is having an illusion of thought and the possibility that she is instead having a descriptive thought. Using this terminology, we may say that a subject cannot know a priori that she is not in a bad case, for if she were and the question were to arise, she would believe that she is not in a bad case. 

Let us review the results of our discussion so far. We have been considering whether the reductio is successful against natural kind anti-individualism and, in particular, whether Sally can have a priori knowledge that if she thinks that water is wet then her environment contains water. Twin Earth arguments establish only a counterfactual dependence of thought on world; they do not show that having the concept water entails the existence of water. However, I have argued that Sally could use knowledge of the arguments for natural kind anti-individualism to gain a priori knowledge of conditional principles of the form: if a subject is in certain psychological and other conditions, then her environment contains instances of a certain natural kind. Further, I have argued that if Sally can also know a priori that she meets the antecedent of such a principle, then she can gain a priori knowledge of links between her thought and the world, say, that if she thinks that water is wet, then her environment contains water. The antecedent of the first principle we considered, (A), contains the condition that the subject has a concept that names a natural kind. However, Sally cannot know a priori that a concept names a natural kind. We then considered principles whose antecedent states that the subject intends a term to name a natural kind and that she is not in a bad case, where the latter covers either the possibility that she is having an illusion of thought or a descriptive thought. Although a subject can know a

<!-- page: pdf=0316 printed=none -->

priori that she intends a term to name a natural kind, she cannot know a priori that she is not in a bad case, for if she were in a bad case and the question were to arise, she would believe that she is not. So, whether the conditional principles involve the notion of having a concept that names a natural kind, or the notion of having a concept that is merely intended to do so, the reductio is unsuccessful against natural kind anti-individualism. 

It is worth pausing to discuss one final issue before moving on to discuss other types of anti-individualism. Recall that the reductio examines what would follow if the assumptions of anti-individualism and privileged access were both true. So, it is legitimate for the proponent of the reductio to appeal to these assumptions and anything that follows from them. It might be claimed that it follows from the assumption of privileged access that a subject can know a priori that she is not in a bad case. If this were correct, then, despite the arguments given above, it would be possible to give a successful reductio of natural kind anti-individualism. 

### **_2.1 Privileged Access and the Bad Case_** 

According to the suggestion to be considered, privileged access involves more than merely the claim that a subject can have a priori knowledge of her thought contents, say, that she thinks that water is wet. In addition, it involves the claim that, if a subject is not in a bad case, she can know a priori that she is not in a bad case, that is, depending on the version of anti-individualism at issue, she can know a priori that she is not suffering either an illusion of thought or a descriptive thought.

<!-- page: pdf=0317 printed=none -->

Entailments between Thought and the World 285 

Before considering the merits of this view, note that this claim about privileged access is employed in Boghossian’s version of the reductio. Boghossian (1997) argues that the kind of anti-individualism supported by Putnam’s Twin Earth argument about water entails the illusion version of anti-individualism. In his defense of the reductio, he combines this claim with the idea that a subject can know a priori whether or not a term expresses a concept. In more detail, he argues that a subject who knows the philosophical arguments for Putnamian anti-individualism can have a priori knowledge of the following principle: if a chemically indifferent subject intends _t_ to express an atomic concept that names a natural kind, but there is no natural kind for _t_ to name, then _t_ fails to express any concept (pp. 170–174). He argues that a subject can have a priori knowledge that she is chemically indifferent and that she intends ‘water’ to express an atomic concept that names a natural kind. Thus, so long as a subject can also know a priori that ‘water’ does express a concept, then she can know a priori that ‘water’ names a natural kind and that there is water in her environment. Boghossian argues that it is a consequence of privileged access that a subject can know a priori whether or not a term expresses a concept: “privileged access assures him that he will be able to tell a priori whether or not a given term does express a concept” (p. 175). Thus, Boghossian concludes, Putnamian anti-individualism and privileged access have the absurd conclusion that a subject can have a priori knowledge that her environment contains a natural kind, say, water.<sup>4</sup> 

Let us consider, then, whether privileged access involves the claim that a subject can know a priori that she is not in a bad case, where the bad case is construed to involve either

<!-- page: pdf=0318 printed=none -->

an illusion of thought or a descriptive thought. As I have defined it, privileged access states that a subject can have a priori knowledge of her thought contents. This seems to amount only to the claim that, for any thought content _p_ that a subject thinks, she can know a priori that she thinks that _p_ . It does not obviously involve the claim that a subject can know a priori whether she is having a thought or, if she is, its type, say, whether it is descriptive. Further, the claim that anti-individualists have argued is consistent with their view is merely the claim that a subject can have a priori knowledge of her thought contents. They have not argued that a subject can know a priori that she is not in a bad case. For instance, defenders of the illusion version of antiindividualism have not argued that a subject can know a priori that she is not suffering an illusion of thought. In general, anti-individualists defend the claim that a subject can know a priori that she is thinking that _p_ even if she does not know much about that thought—the environmental facts which individuate it, whether it is the same or different in content from some other simultaneous thought, or how to properly explicate it (see chap. 2 and 5; and, for the last point, Burge 1988, p. 662). So, it seems unlikely that they would take privileged access to entail that a subject can know a priori whether some thought is descriptive or not. 

Last, anti-individualists standardly defend privileged access by pointing out that a subject’s second-order judgments of the form “I judge that I think that _p_ ” are selfverifying. Consider an Earth subject who thinks that water is wet and self-ascribes this thought. Were the environment so different that she no longer thinks that water is wet, she would no longer self-ascribe this thought. For instance, if she were instead on Twin Earth thinking that twater is wet, then she would believe that she thinks that twater is wet.

<!-- page: pdf=0319 printed=none -->

287 

Notice that this standard defense cannot be applied to show that a subject can know a priori that she is not in a bad case. A subject’s belief that she is not in a bad case is not selfverifying. Indeed, if a subject were in a bad case, she would believe that she is not in a bad case. 

It seems, then, that as defined here, and as anti-individualists understand it, privileged access does not directly involve the claim that a subject can know a priori whether she is in a bad case.<sup>5</sup> However, there might be some less direct link between the two. Someone might suggest that if a subject has privileged access to her thought contents, say, that she thinks that water is wet, then she can use this to gain by inference a priori knowledge that she is not suffering an illusion of thought. In the rest of the section I consider this suggestion. 

Suppose that Sally thinks that water is wet. Her having this thought entails that she is not instead suffering an illusion of thought. So, there is a possible inference from the premise that she thinks that water is wet to the conclusion that she is not suffering an illusion of thought: 

(T1) I think that water is wet. 

(T2) If I think that water is wet, then I am having a thought rather than an illusion of thought. 

(T3) I am having a thought rather than an illusion of thought. 

Given privileged access, Sally can have a priori knowledge of (T1). Further, merely in virtue of understanding the relevant concepts, Sally can have a priori knowledge of (T2). So, if knowledge always transmits across valid arguments, she could use her a priori knowledge of (T1) and (T2) to gain a

<!-- page: pdf=0320 printed=none -->

priori knowledge of (T3), that she is having a thought rather than an illusion of thought. 

In the last chapter, we saw that it is a contentious issue whether knowledge always transmits across a valid argument. Davies and Wright try to answer the reductio by arguing that there is a failure of transmission of knowledge across the inference: (W1) I think that water is wet; (W2) If I think that water is wet, then my environment contains water; (W3) My environment contains water. The point currently under consideration focuses on a different claim— that knowledge fails to transmit across the valid argument (T1)–(T3). 

We rejected Davies’s and Wright’s accounts of the failure of transmission of knowledge.<sup>6</sup> Nevertheless, I will argue that there is a failure of transmission of knowledge from (T1) and (T2) to (T3) on a different basis. In doing so, I will use the widely accepted view that _S_ knows that _p_ only if, were _p_ false, she wouldn’t believe that _p_ . As Nozick and Dretske point out, this condition entails counterexamples to closure, and thus transmission, of knowledge (chap. 7, sec. 2). It seems that the inference (T1)–(T3) is such a counterexample. In particular, Sally’s belief in (T3) fails the relevant condition for knowledge: if she were not having a thought but suffering an illusion of thought, she would falsely believe that she is having a thought rather than an illusion of thought.<sup>7</sup> However, there is no reason to suppose that Sally’s belief in (T1) and (T2) fails this condition for knowledge. Consider Sally’s belief in (T1): as anti-individualists stress, if conditions were so different that Sally would not think that water is wet, then she would no longer self-ascribe this thought. For instance, if she is instead on Twin Earth thinking that twater is wet, then she would believe that she thinks that twater is wet. If she were not thinking that water is wet,

<!-- page: pdf=0321 printed=none -->

Entailments between Thought and the World 

289 

but instead suffering an illusion of thought, she would no longer believe that she thinks that water is wet. Thus, the inference (T1)–(T3) is a counterexample to the transmission of knowledge. Further, it is a counterexample to the closure of knowledge: a subject could have a priori knowledge of (T1) and (T2) and lack knowledge of (T3), whether a priori or empirical, since she lacks empirical evidence that rules it out that she is suffering an illusion of thought. 

In conclusion, privileged access neither directly nor indirectly supports the claim that a subject can know a priori that she is not in a bad case, whether this involves her having an illusion of thought or having a descriptive thought. This argument concludes the last part of the discussion of applying the reductio to natural kind antiindividualism. I have argued that the reductio cannot be applied successfully to natural kind anti-individualism, for natural kind anti-individualism does not support (R2): Sally can know a priori that if she thinks that water is wet, then her environment contains water. However, the reductio might be successful against some other version of antiindividualism. In the following two sections, I consider singular anti-individualism and social anti-individualism. 

### **3 Singular Anti-Individualism** 

According to singular anti-individualism, some singular thoughts are individuated partly by the object(s) they are about. For example, suppose that Sally sees a particular apple and thinks the perceptual demonstrative thought that that apple is red. According to singular anti-individualism, her thought that that apple is red is individuated partly by the apple it is about. Thus, if she had been looking at a different apple or had merely suffered an illusion of seeing

<!-- page: pdf=0322 printed=none -->

an apple, she would have lacked the thought she actually has. Using this example, we might construct a reductio for singular anti-individualism with the original (R1)–(R3) replaced by (P1)–(P3): 

(P1) Sally knows a priori that she thinks that that apple is red. ( _From the assumption of privileged access_ .) 

(P2) Sally knows a priori that if she thinks that that apple is red, then that apple exists. ( _From the assumption of singular anti-individualism_ .) 

(P3) Sally knows a priori that that apple exists. ( _From P1–P2_ .) 

As with the case of natural kind anti-individualism, our focus will be on the second step. If Sally knows the arguments for singular anti-individualism, can she know a priori that her thinking that that apple is red entails that that apple exists? 

Anti-individualists do not typically claim that whenever a subject thinks about an object, her thought is individuated partly by that object. They accept that a subject may sometimes think of an object by description. Suppose that I don’t follow tennis and don’t know who the top-ranked players are. Nonetheless, I might surmise that the woman, whoever she is, who is the world’s top female tennis player is wealthy. Here, I think about a person via a description. If Venus Williams is in fact the top female tennis player, then I think about Venus. By contrast, if Capriati had been the top player, I would have thought about her instead. In such a case, my thought seems independent of the object it is about. In each situation, I think the same thought, but it is about different players. While accepting the possibility of such descriptive thoughts, anti-individualists argue that subjects

<!-- page: pdf=0323 printed=none -->

Entailments between Thought and the World 

may also have nondescriptive thoughts that are individuated partly by the objects they are about. For example, it has been claimed that perceptual demonstrative and recognition-based thoughts are individuated partly by the objects they are about. 

It might be suggested that a subject could use singular anti-individualism to gain a priori knowledge of certain conditionals of the form: if _S_ is in condition _C_ , then she is in a certain kind of environment. If she could also know a priori that she meets the antecedent of such a conditional, then perhaps she could gain a priori knowledge of links between her thoughts and the environment. However, I will argue that one cannot know a priori that one meets the antecedent, however condition _C_ is formulated. The argument may be sketched out as follows. One could formulate _C_ so that it involves a real-world relation to the environment, or one could formulate it more weakly so that it does not involve any such relation. When formulated so that it involves a real-world relation, a subject cannot know a priori that she meets condition _C_ . When formulated more weakly, it turns out that condition _C_ is compatible with the absence of a relevant object to refer to. Thus, it is compatible with the bad case, the possibility that the subject either suffers an illusion of thought or has a descriptive thought. But, since a subject cannot know a priori that she is not in a bad case, it turns out that this second weaker formulation cannot support the reductio. Let me illustrate this with the example of anti-individualism about perceptual demonstrative thoughts. 

Suppose that we take condition _C_ to be having a perceptual demonstrative thought about an object. Thus, the conditional might state, if a subject has a perceptual demonstrative thought about _x_ , then her environment contains _x_ .

<!-- page: pdf=0324 printed=none -->

However, so formulated the conditional cannot support the reductio. A subject has a perceptual demonstrative thought about an object only if she is perceiving an object. But a subject cannot know a priori that she is perceiving an object. Alternatively, we could formulate the conditional so that it does not involve any real-world relation. For instance, we could use the notion that a subject seems to see and refer to an object demonstratively. Let’s consider, then, what follows from the fact that, say, Sally seems to see a red apple and tries to refer to it demonstratively. If she sees apple _a_ and successfully refers to it, then her thought is individuated partly by _a_ . However, suppose instead that she suffers an illusion of seeing an apple and thus fails to refer demonstratively to any apple. There are two possible antiindividualist views about this case. According to the illusion view, Sally suffers an illusion of thought. On the rival descriptive view, she has a thought involving a descriptive concept of the apple, for example, she thinks that the apple she seems to see is red. These different versions give us two different conditionals linking thought and the world: 

(D) If a subject _S_ seems to see an object and attempts to refer to it in the perceptual demonstrative way but fails to do so, then _S_ suffers an illusion of thought. 

(E) If a subject _S_ seems to see an object and attempts to refer to it in the perceptual demonstrative way but fails to do so, then _S_ has a descriptive thought. 

These principles are logically equivalent to: 

(D¢) If a subject _S_ seems to see an object and attempts to refer to it in the perceptual demonstrative way, and does not suffer an illusion of thought, then there is an object _S_ sees.

<!-- page: pdf=0325 printed=none -->

Entailments between Thought and the World 

(E¢) If a subject _S_ seems to see an object and attempts to refer to it in the perceptual demonstrative way and does not have a descriptive thought, then there is an object _S_ sees. 

Principles (D¢) and (E¢) are analogous to the principles (B¢) and (C¢), considered in the discussion of applying the reductio to natural kind anti-individualism. Each of (D¢) and (E¢) states that if a subject is in certain psychological conditions then her environment is some specific way. Like the earlier principles, (B¢) and (C¢), a subject could use (D¢) or (E¢) to gain a priori knowledge of links between her thoughts and the environment only if she can know a priori that she meets their antecedents. To use (D¢) she needs to know a priori that she is not suffering an illusion of thought; to use (E¢) she needs to know a priori that she is not having a descriptive thought. However, as our earlier discussion of natural kind anti-individualism shows, a subject cannot have such knowledge. Even if a subject is not in a bad case, she cannot know this a priori, where the bad case covers both the possibility that she suffers an illusion of thought and the possibility that she has a descriptive thought. If she were in a bad case and the question were to arise, she would believe she is not in a bad case. 

For instance, suppose that Sally actually sees apple _a_ and thinks that that apple ( _a_ ) is red. Suppose that Sally also endorses the illusion version of anti-individualism and believes truly that she is not suffering an illusion of thought. This belief does not constitute a priori knowledge. Consider the situation in which Sally suffers an illusion of seeing an apple and thus suffers an illusion of thought. In such a situation, if the question arose, she would believe that she is not suffering an illusion of thought. Now consider the

<!-- page: pdf=0326 printed=none -->

alternative view that when she suffers an illusion of seeing and referring to an apple, she has a descriptive thought. On this alternative view too, were the question to arise, she would deny that she is having a descriptive thought. 

It seems, then, that the reductio fails against singular antiindividualism for the same reasons it failed against natural kind anti-individualism. In each case, the relevant type of anti-individualism fails to support the crucial second step of the reductio, according to which a subject can have a priori knowledge of some specific link between her thoughts and the environment. However, these arguments leave it open that the reductio works when applied to social anti-individualism. 

### **4 Social Anti-Individualism** 

According to social anti-individualism, a subject’s thought contents are individuated partly by the practices of her linguistic community. The key question is whether social antiindividualism supports the second step of the reductio, according to which Sally can have a priori knowledge of some specific link between her thoughts and the environment. As we have already seen, Burge’s arthritis thought experiment does not directly support the second step for it concerns a subject stipulated to be part of a linguistic community and establishes only a counterfactual dependence of thought on environment (sec. 1). Nevertheless, I will argue that social anti-individualism could be used to gain a priori knowledge of the following conditional principle, which does link thought and the world: 

(F) If a subject _S_ has a concept _c_ and is agnostic about _c_ , then _S_ is part of a linguistic community with the concept _c_ .

<!-- page: pdf=0327 printed=none -->

Entailments between Thought and the World 

295 

(See Brown 1995 and 2001. F’s consequent abbreviates the more complex condition that _S_ is now, or used to be, part of a linguistic community with the concept _c_ .)<sup>8</sup> If Sally could have a priori knowledge of (F) and that she meets the antecedent of (F), then she could use this knowledge to gain a priori knowledge that she is part of a linguistic community. But it seems absurd that someone could know that she is part of a linguistic community merely by reflection on her thought contents and some philosophy. 

Before examining (F) in more detail, it is important to understand the component notion of agnosticism. Agnosticism is a type of incomplete understanding of a concept distinct from misunderstanding. Misunderstanding amounts to supposing that a concept applies to certain kinds of thing to which it does not apply, or supposing that it fails to apply to certain kinds of thing to which it does apply. For example, one misunderstands the notion of arthritis if one thinks that it applies to problems of the thighs and joints (in fact, it applies only to problems of the joints). By contrast, agnosticism consists in being unsure whether the concept applies to certain kinds of thing where there is a determinate fact about whether or not the concept applies to that kind of thing (see Burge 1979, p. 77). For example, an English speaker who believes that ‘arthritis’ applies to problems of the joints, but is unsure whether it applies to problems of the thigh, is agnostic. 

I will now argue that (F) follows from social antiindividualism. My argument starts from the fact that every kind concept has conditions of correct and incorrect application. Notice that this is so even for concepts that are partly indeterminate or vague. For example, there are certain degrees of hair loss at which it is indeterminate whether one is bald. Despite this, there are some

<!-- page: pdf=0328 printed=none -->

conditions to which the concept determinately applies (e.g., having not a single hair on one’s head) and others to which it determinately does not apply (such as having a full head of hair). Thus, every concept has standards of correct and incorrect application, and these application conditions partly individuate the concept. So, for a subject to have some particular kind concept, something must make it the case that she has a concept with the relevant application conditions. 

Suppose that Sally applies ‘sofa’ to sofas, but is unsure whether it also applies to large armchairs. The concept sofa is individuated partly by the fact that it does not apply to large armchairs. Social anti-individualism allows that if Sally is part of a community of English speakers, then she expresses the concept sofa with ‘sofa’, despite her uncertainty. Thus, Sally fulfils the antecedent of (F)—she has the concept sofa while being agnostic about its application conditions. 

Now consider whether Sally could use ‘sofa’ to express the concept sofa if she had been brought up in an environment in which there are no other speakers. It seems not. A concept Sally possesses can be the concept sofa only if it fails to apply to large armchairs. But, in the counterfactual environment, there is nothing to determine that the concept Sally expresses with ‘sofa’ has these application conditions. Sally herself is unsure about whether the term ‘sofa’ applies to large armchairs. She has had no contact with other speakers. And, since the kind sofa is not a natural kind, her natural environment cannot help her to have the concept. (In any case, we are currently considering only social anti-individualism and ignoring natural kind antiindividualism. Thus, even if the relevant concept had been the concept of a natural kind, the natural environment could

<!-- page: pdf=0329 printed=none -->

Entailments between Thought and the World 

297 

not have helped the subject to acquire the concept.) Thus, in the counterfactual environment in which Sally is not part of a linguistic community, she cannot have the concept sofa given her uncertainty about whether it applies to large armchairs. 

Of course, in this counterfactual environment, Sally may express some concept other than the concept sofa with ‘sofa’. Thus, she may express some concept with ‘sofa’ while being unsure about whether that concept applies to large armchairs. Some critics have taken this to amount to a counterexample to (F), a case in which a subject has a concept and is agnostic about it but is not part of a community (see, e.g., McLaughlin and Tye 1998, p. 317; Falvey 2000, p. 142). However, this objection is based on a misunderstanding of agnosticism. Recall that a subject is agnostic about a concept only if she is unsure whether it applies to things of a certain type, and there is some definite fact of the matter about whether it does so apply. But, in the counterfactual situation in which Sally is the only speaker, there is nothing to determine whether or not the concept she expresses with ‘sofa’ applies, or fails to apply, to large armchairs. Sally herself is unsure whether it does so, and she has had no contact with no other speakers. So, even if Sally expresses a concept with ‘sofa’, and is unsure about whether it applies to large armchairs, she is not agnostic about it.<sup>9</sup> 

It seems, then, that anyone who holds social antiindividualism should accept (F). Further, it seems that Sally could have a priori knowledge of (F). Admittedly, the argument given for (F) above used a fact of which Sally is ignorant, that the concept sofa does not apply to large armchairs. However, the argument can be formulated independently of this assumption (Brown 2001). If Sally could have a priori

<!-- page: pdf=0330 printed=none -->

knowledge of (F) and of the fact that she meets the conditions mentioned in the antecedent of (F), then she could have a priori knowledge of connections between her thought and the world, say, that if she thinks that sofas are comfy then she is part of a linguistic community. So, the key question for the reductio is whether Sally can know a priori that she meets the antecedent of (F). In particular, can Sally know a priori that she has the concept sofa and that she is agnostic about it? 

It seems plausible that Sally may know a priori that she has the concept sofa. However, it is hard to see how she could know a priori that she is agnostic. A subject is agnostic if she is unsure about whether a concept applies to things of a certain kind and there is a determinate fact of the matter whether it does so apply. It seems plausible that Sally can know a priori that she is unsure whether the concept sofa applies to large armchairs. However, Sally may have no idea whether there is a determinate fact about whether the concept sofa applies to large armchairs. For all she knows, it may be indeterminate whether the concept sofa applies to such armchairs. After all, the extensions of some concepts are partly vague or indeterminate. Moreover, even if Sally does believe that there is a determinate fact about whether the concept sofa applies to large armchairs, this belief does not constitute a priori knowledge. Social antiindividualists hold that incomplete understanding of terms and concepts is a ubiquitous phenomenon (see, e.g., Burge 1979). So, it is a relevant alternative that there is no determinate fact whether ‘sofa’ applies to large armchairs and Sally’s belief is incorrect. But, Sally cannot rule out this alternative a priori. 

We might put the point more generally as follows. Social anti-individualism undermines the traditional idea that a

<!-- page: pdf=0331 printed=none -->

Entailments between Thought and the World 

299 

subject can gain a priori knowledge of how a term or concept applies in virtue of understanding it. On the traditional conception, a subject who understands the relevant concepts can know a priori that the concept of a bachelor applies to unmarried men, and that the concept of a toothbrush is the concept of an artifact. But a social antiindividualist should reject this conception. Consider Burge’s arthritis patient who has the concept arthritis while incompletely understanding it, believing that it applies to problems of the joints and thighs. He cannot know a priori that the concept in fact applies only to problems of the joints. However, even if the patient had instead truly believed that arthritis applies only to problems of the joints, this belief would not constitute a priori knowledge. Given the ubiquity of incomplete understanding it is a relevant alternative that he misunderstands the concept. But, he cannot rule out this possibility a priori. (See Brueckner 2002.) 

In summary, the reductio fails against social antiindividualism for the same reason it fails against natural kind and singular anti-individualism. In each case, the relevant type of anti-individualism fails to establish the crucial second step, according to which a subject can have a priori knowledge of some specific link between her thoughts and the environment. The classic Twin Earth arguments for antiindividualism establish only a counterfactual dependence of thought on the environment. Nevertheless we have seen that each of the types of anti-individualism supports some conditional claim that states that if a subject is in certain psychological and other conditions, then her environment is some particular way. A subject could use such conditionals to gain a priori knowledge of connections between her thoughts and the environment only if she can have a priori knowledge that she meets the conditions mentioned in the

<!-- page: pdf=0332 printed=none -->

antecedent of the conditional. But she cannot have such a priori knowledge. 

### **5 Combined Views** 

So far, we have seen that the reductio fails to show that privileged access is incompatible with various forms of anti-individualism when taken singly. At this stage, our discussion of the reductio may seem complete. However, there is one last possibility to be considered, whether the reductio would be successful against some combination of anti-individualist views. Someone might suggest that the objections we have raised to the reductio arise from the fact that we have considered different anti-individualist theses taken singly. So taken, anti-individualist theses establish that if a subject is in a certain condition, then her thought is individuated partly by the environment. Such a condition might be that she is having a perceptual demonstrative thought, or that she intends a term to express an atomic concept of a natural kind and is not suffering an illusion of thought. However, as we have seen, a subject cannot know a priori that she is in such specific conditions. By contrast, a combination of anti-individualist views would apply to a larger range of thoughts and so might not require that a subject can know a priori that she is in such a specific condition. 

This line of thought lay behind my suggestion (Brown 1995, 2001) to formulate a reductio of the combination of natural kind and social anti-individualism. I argued that on this combined view, the following principle would be correct: 

(G) If a subject _S_ has the concept _c_ and is agnostic about _c_ , then either _c_ is a concept of a natural kind and _S_ ’s

<!-- page: pdf=0333 printed=none -->

Entailments between Thought and the World 

environment contains instances of that kind, or _S_ is part of a community with the concept _c_ . 

Unlike earlier principles, (G) just talks of a subject’s having a concept, rather than her having a particular type of concept, such as a natural kind concept. (G) reflects the idea that if both natural kind and social anti-individualism are true, then a subject can have a concept despite being agnostic, either by being in an environment with instances of a suitable natural kind, or by being part of a suitable linguistic community. 

However, in fact, once again it is hard to see how (G) could be used in a successful reductio. It could be so used only if a subject could know a priori that she meets the antecedent of (G), in particular, that she is agnostic about a concept. But we have already seen that social antiindividualism undermines the claim that a subject can have such knowledge. This conclusion seems unaffected even if natural kind anti-individualism is also true. It seems, then, that the reductio is no more successful against antiindividualist views when combined than when taken singly. 

### **6 Conclusion** 

I have argued that the reductio fails to show that antiindividualism is incompatible with privileged access. Antiindividualism fails to support the crucial second step, according to which a subject can have a priori knowledge of some specific link between her thoughts and the environment. The Twin Earth arguments support only the counterfactual dependence of thought on world; they do not show that having a certain concept, say, water, entails that one’s environment is some way, say that it contains water.

<!-- page: pdf=0334 printed=none -->

302 

Chapter 8 

Someone could use anti-individualism to gain a priori knowledge of certain conditional principles that state that if a subject is in certain psychological and other conditions, then her environment is some particular way. However, such conditional principles could be used to defend a successful reductio only if one can know a priori that one meets the conditions mentioned in the antecedent. But, I have argued that such knowledge is not available.

<!-- page: pdf=0335 printed=none -->

**Appendix to Chapter 8: Comparison with Davies and Wright** 

I have argued that the reductio fails to show that antiindividualism and privileged access are incompatible since anti-individualism fails to support the second step, according to which a subject can have a priori knowledge of some specific link between her thoughts and the environment. This response to the reductio contrasts with that offered by Davies and Wright, who challenge the transition from the first two premises of the reductio to the third. Despite this difference, I am committed to making one of the claims that they make, namely that there are counterexamples to the transmission of knowledge. 

In chapter 8, section 2.1, I denied that a subject could gain a priori knowledge that she is thinking a thought rather than suffering an illusion of thought by inference from her a priori knowledge that she thinks, say, that water is wet, and her a priori knowledge that if she thinks that water is wet, then she is having a thought rather than suffering an illusion of thought. However, my grounds for limiting the transmission of knowledge are different from those endorsed by Wright and Davies. They argue that there is a limitation on the transmission of knowledge since warrant is a necessary condition for knowledge and there is a

<!-- page: pdf=0336 printed=none -->

limitation on the transmission of warrant. Wright argues that warrant fails to transmit across a valid argument when the warrant for one of the premises is conditional on having prior and independent warrant for the conclusion. Davies argues that warrant fails to transmit across a valid argument when warrant for the premises fails to rule out salient or relevant alternatives to the conclusion. I have argued that there is a limitation on the transmission of knowledge on the grounds that _S_ ’s true belief that _p_ is knowledge only if, were _p_ false, she would not believe that _p_ . So long as warrant is not defined as whatever makes the difference between true belief and knowledge, this does not entail that there are counterexamples to the transmission of warrant. 

Given my different reasons for denying the transmission of knowledge, my account does not face the objections raised to Davies’s and Wright’s accounts in chapter 7. Further, my account has different consequences. First, a limitation on the transmission of knowledge grounded on the above conception of knowledge could not be used to argue for a failure of transmission across the inference (W1) I think that water is wet; (W2) If I think that water is wet, then my environment contains water; (W3) My environment contains water—for (W3) meets the relevant condition for knowledge. Consider a possible situation in which one’s environment does not contain water. Given the antiindividualism underlying (W2), in such an environment one would lack the concept water, and thus could not falsely believe that one’s environment contains water. 

Davies and Wright might object that my solution to the reductio involves denying the closure of knowledge. However, although Davies tries to separate his denial of the transmission of warrant from a denial of the closure of knowledge, in fact his account is committed to denying

<!-- page: pdf=0337 printed=none -->

Appendix to Chapter 8 

closure also. To see this, consider Davies’s architecturalism argument, which considers the consequences of the view that there are philosophical arguments that provide a priori knowledge that any creature capable of thought has a cognitive architecture that meets the conditions for the language of thought, or LOT (Davies 1998). If this assumption is combined with the assumption of privileged access it might seem to offer an objectionably a priori route to knowledge about the structure of a thinker’s brain via reasoning analogous to that central to the reductio: 

(A1) I think that water is wet. ( _From the assumption of privileged access_ .) 

(A2) If I think that water is wet, then LOT is true of me. ( _From the assumption that philosophical arguments enable one to know a priori any thinker meets the conditions for LOT_ .) 

(A3) LOT is true of me. ( _From (A1) and (A2)_ .) 

However, it seems absurd to suppose that a subject could gain a priori knowledge of the structure of her brain merely by reflection on her thoughts and philosophical arguments. 

Since Davies finds it plausible that one has a priori knowledge of the premises of the architecturalism argument (p. 343), he attempts to avoid a priori knowledge of the conclusion by arguing that the argument is a counterexample to the transmission of warrant. Thus, it seems that Davies holds that someone might have an a priori warrant for (A1) by reflection and an a priori warrant for (A2) by philosophical argument without thereby having an a priori warrant for (A3). Given this, Davies can avoid denying closure of warrant only if anyone with such a priori warrant for (A1) and (A2) has some warrant for (A3) independent of the inference. But it is hard to see how this could be the case.

<!-- page: pdf=0338 printed=none -->

As Davies notes, one could have the relevant a priori warrants for (A1) and (A2) without having any empirical evidence for (A3). But it seems that any justification of (A3) that is independent of the inference from (A1) and (A2) would have to be empirical. Thus, it seems that Davies is committed to holding that the inference (A1)–(A3) is a counterexample to closure of warrant. Given his further view that knowledge requires warrant, he cannot avoid denying closure of knowledge. 

By contrast, Wright’s conditional analysis is not committed to denying the closure of warrant or knowledge. According to this analysis, warrant fails to transmit across a valid argument if warrant for one of the premises is conditional on prior and independent warrant for the conclusion. Thus, his analysis does not generate the possibility that one could have warrant for the premises of a valid argument yet fail to have warrant for the conclusion. But the very feature that enables the conditional analysis to avoid denying closure is responsible for one of the main objections to it, namely that it has the counterintuitive consequence that a subject can have a priori knowledge of substantive facts about the world (see chap. 7). 

Suppose that one has a priori warrant for the premises of an argument across which warrant fails to transmit. To avoid denying the closure of a priori warrant, Wright must say that one has a priori warrant for the premises only if one has prior and independent a priori warrant for the conclusion. The reductio is just such an argument. Wright accepts that Sally has a priori warrant and knowledge that she is thinking that water is wet, and that if she is thinking that water is wet then her environment contains water, but he denies that Sally could thereby come to have a priori warrant and knowledge that her environment contains

<!-- page: pdf=0339 printed=none -->

Appendix to Chapter 8 

307 

water. Thus, to avoid denying closure, Wright must accept that Sally has prior and independent a priori warrant and knowledge that her environment contains water. 

Thus, as argued in chapter 7, Wright’s solution to the reductio is no less problematic than the problem it aims to solve: it is committed to the claim that a subject can have a priori knowledge of substantial facts about the nature of her environment. (This closure argument presents a consideration additional to that presented in chap. 7 for supposing that Wright must accept that Sally has prior and independent a priori warrant for the claim that her environment contains water.)
