---
title: "Preface"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 11
locator_end: 16
---

# Preface

<!-- page: pdf=0011 printed=none -->

## **Preface** 

This book examines the epistemological consequences of a view that dominates contemporary philosophy of mind— anti-individualism. According to this view, a subject’s thought contents are partly individuated by her environment. By contrast, individualists deny this and argue that a subject’s thought contents are wholly individuated by her “internal” states, such as her brain states. Many have taken anti-individualism to have radical consequences for our knowledge of our minds, our ability to reason, and our knowledge of the world. In this book, I investigate whether anti-individualism does have such radical consequences. The discussion weaves together central topics in the philosophy of mind, such as rationality, psychological explanation and the nature of thought, with general issues in epistemology such as skepticism and the nature of knowledge and warrant. 

If, as anti-individualism suggests, what a subject thinks depends partly on her environment, it may seem that a subject can know what she thinks only by investigating the nature of her environment. But this seems deeply counterintuitive. A subject may use empirical evidence in forming a belief, but, once the belief is formed, it seems she can know

<!-- page: pdf=0012 printed=none -->

that she has this belief without further reliance on empirical evidence. Certainly, a subject can know what she thinks without investigating those features of the environment that anti-individualists have argued partly individuate her thoughts, such as the chemical composition of substances and the linguistic conventions of her community. It would be a serious objection to anti-individualism if it had the result that a subject can have only empirical knowledge of her thoughts. I examine the challenge raised to a priori knowledge of one’s thoughts both by standard versions of anti-individualism and by those versions that allow that a subject may suffer an illusion of thought. The main compatibilist response to this challenge emphasizes the reliability of a subject’s beliefs about her thoughts. I offer a different response, which focuses on the epistemic notion of a relevant alternative. The discussion of whether anti-individualism undermines a priori knowledge of thoughts involves an examination of the nature of knowledge—does knowledge require discriminative abilities or merely the ability to reliably form true beliefs? If the latter, what sort of reliability does knowledge require? 

It may seem to follow from the anti-individualist claim (that what thoughts a subject has depends partly on the environment) that a subject may need empirical information to know whether two thoughts or thought constituents have the same or different content. Sameness and difference of content are crucial to the logical relations between thoughts. Thus, anti-individualism seems to have the consequence that a subject may need empirical information to know the logical relations between her thoughts and that, without such empirical information, she may make mistakes about their relations. But, if so, then anti-individualism undermines the concept of a rational subject as one who would

<!-- page: pdf=0013 printed=none -->

not believe simple contradictions or make simple invalid inferences. I defend anti-individualism against this objection by rejecting this conception of rationality. However, I use the results of the discussion to raise a new problem for the attempt to combine anti-individualism and Fregean sense. I argue that the assumptions of transparency and rationality behind the Fregean argument for sense are in tension with anti-individualism. This argument applies even to the notion of object-dependent sense developed by modern defenders of Fregean anti-individualism, such as Evans, McDowell, and Peacocke. 

Even if anti-individualists can overcome the objection that their view is incompatible with a subject’s having a priori knowledge of her own thoughts, a further issue arises. If it were the case both that what a subject thinks depends on her environment and that she can have a priori knowledge of her thoughts, then this might seem to provide her with a novel and a priori route to knowledge of the world. Since anti-individualism is supported by philosophical arguments, it may seem that a subject could use those arguments to gain a priori knowledge that her having a certain thought entails that she is in a certain kind of environment. Combining this knowledge with her a priori knowledge of her thoughts she could come to have a priori knowledge that she is in a certain kind of environment. 

Some have taken this line of reasoning to show that antiindividualism can provide a novel response to skeptics who argue that we can never have knowledge of the existence and nature of the external world. Others have taken it to be an objection to anti-individualism since they think it absurd that one could gain knowledge of the nature of the world just by reflection on one’s thoughts and philosophy. Either way, it would be an interesting and substantive result if it

<!-- page: pdf=0014 printed=none -->

were a consequence of anti-individualism that one could gain a priori knowledge of the world. Davies and Wright have attempted to block the idea that anti-individualism has this consequence by arguing that warrant and hence knowledge do not always transmit across a valid inference. They suggest that a subject who knows the premises of a valid argument and knows that the argument is valid cannot always gain warrant for, and knowledge of, the conclusion by thinking through that argument. I argue against this limitation on the transmission of warrant and knowledge by considering the nature of warrant. Instead, I suggest a different reason for supposing that anti-individualism does not provide a novel a priori way of discovering facts about one’s environment, namely, that anti-individualism undermines the type of knowledge required to use a priori knowledge of one’s thoughts to gain a priori knowledge of the world. 

I conclude that anti-individualism does not have the kind of radical epistemic consequences many take it to have. Certainly, anti-individualism provides a new source of mistakes about the logical properties of thoughts; and this raises a problem for the attempt to combine anti-individualism even with the notion of object-dependent sense. However, antiindividualism’s potential threat to a priori knowledge of one’s own thoughts can be largely defused by appeal to the epistemological notion of a relevant alternative. In addition, on a proper understanding of rationality, anti-individualism does not undermine the notion that we are rational subjects. Last, anti-individualism does not provide a new a priori route to knowledge of the world. Many would agree that anti-individualism lacks the radical epistemic consequences commonly suggested. However, I support this conclusion by a range of new arguments that link central issues in the

<!-- page: pdf=0015 printed=none -->

philosophy of mind with the epistemological literature on knowledge, warrant, justification, and reliability. 

Most of the material in the book has not been previously published. However, the discussion in chapter 4 overlaps substantially with my earlier article, “Reliabilism, Knowledge, and Mental Content,” _Proceedings of the Aristotelian Society,_ 2000. Chapter 8 draws on, but reaches a different conclusion from, my previously published papers on the reductio: “The Incompatibility of Anti-Individualism and Privileged Access,” _Analysis_ 1995, “Boghossian and Privileged Access,” _Analysis_ 1999, and “Anti-Individualism and Agnosticism,” _Analysis_ 2001. My paper “The Reductio Argument and the Transmission of Warrant” (in _New Essays on Semantic Externalism and Self-Knowledge_ , edited by Susana Nuccetelli) contains material similar to some parts of chapter 7. I am grateful for permission to use material from these earlier papers. 

My work on the book has been generously supported by an AHRB Research Leave Award, a Bristol University Research Fellowship and a Philip Leverhulme Prize. Draft material has been presented at several conferences and departments, including the Joint Session 2001, The European Society for Philosophy and Psychology meetings in 2000 and 2001, and the philosophy departments at The Australian National University in Canberra and at the Universities of Bristol, Birmingham, Cambridge, Glasgow, Stirling, and Sydney. I am grateful for useful comments and stimulating discussion on these occasions. A number of individuals provided helpful feedback on parts of the draft including Helen Beebee, John Campbell, Patrick Greenough, Antti Karlajainen, James Ladyman, Brian McLaughlin, Laura Schroeder, and Daniel Stoljar. During the final stages of the book, I spent a very enjoyable two months at the

<!-- page: pdf=0016 printed=none -->

xiv 

Preface 

Philosophy Program of the Research School of Social Sciences at the Australian National University in Canberra. Many thanks to staff and students who participated in a reading group on the book. Special thanks to Martin Davies who has provided so much help and encouragement over the years and has commented on the whole manuscript. Last, I would like to thank my colleagues here at Bristol, and especially Chris Bertram and Keith Graham, for their warmth and support.
