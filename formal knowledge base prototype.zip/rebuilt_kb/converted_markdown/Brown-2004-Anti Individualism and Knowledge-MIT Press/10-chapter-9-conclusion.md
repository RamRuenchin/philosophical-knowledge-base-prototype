---
title: "Chapter 9: Conclusion"
source_type: "chapter"
source_format: "pdf"
source_path: "/home/ramruenchin/Documents/Knowledge Bases/Philosophy Knowledge Base/2.Raw/papers/Brown-2004-Anti Individualism and Knowledge-MIT Press.pdf"
source_id: "brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f"
source_sha256: "06fe3e2e723f51943a487d0b320bdf817f4a2fae07bdfbd9e363e2710e7127e9"
conversion_status: "extracted"
conversion_date: "2026-11-09T22:18:37+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "/home/ramruenchin/Documents/Codex/2026-11-09/philosophy-update-20261109-211907/work/literature-to-markdown/artifacts/manifests/brown-2004-anti-individualism-and-knowledge-mit-press-06fe3e2e723f-7a19f5c00c.json"
locator_kind: "page"
locator_start: 343
locator_end: 345
---

# Chapter 9: Conclusion

<!-- page: pdf=0343 printed=none -->

**9** 

## **Conclusion** 

Many have argued that anti-individualism has radical consequences for our knowledge of our own minds, our ability to reason, and our knowledge of the world. After examining these objections in detail, I have argued that antiindividualism does not have these consequences. 

The book started with a discussion of whether antiindividualism is compatible with privileged access, the plausible claim that a subject can have a priori knowledge of her thought contents. In the first part of the book, I examined the achievement problem for compatibility, the problem of how a subject can have privileged access to externally individuated thought contents. According to the discrimination argument, anti-individualism threatens privileged access since it undermines a subject’s ability to distinguish a priori between the actual situation and alternative situations in which she lacks the thought she has in the actual situation. According to the illusion argument, the illusion version of anti-individualism undermines privileged access by allowing that a subject may suffer an illusion of thought. Compatibilists standardly reply to the discrimination argument by allowing that the alternative situations are relevant and so potentially knowledge undermining, but

<!-- page: pdf=0344 printed=none -->

stressing the reliability of a subject’s judgments about her thought contents. By contrast, I have explored and developed the idea that the alternative situations are not relevant. This response finesses two issues facing the standard compatibilist view: the issue of whether knowledge requires discriminative abilities or only reliability, and what the reliabilist requirement for knowledge turns out to involve. As a result, the relevant alternatives strategy may be used by compatibilists with different epistemic views, including those who think that knowledge requires discriminative abilities and those who think that it requires only reliability. 

In the second part of the book, I argued that antiindividualism undermines transparency of content, that is, a subject’s ability to grasp a priori sameness and difference of content. Anti-individualism thus has the consequence that a subject cannot always grasp a priori the logical properties of her thoughts, so she may make simple logical mistakes. This undermines one idea of rationality, according to which a rational subject can always grasp a priori the simple logical properties of her thoughts and would not make simple logical mistakes. But I argue that anti-individualism does not undermine rationality when properly understood. 

In the last part of the book, I examined the consequence problem, the problem of what consequences would follow if anti-individualism and privileged access were both true. It has been argued that the joint assumptions of privileged access and anti-individualism have the consequence that a subject can have a priori knowledge of substantive facts about the world. Some have taken this to be a reductio of the joint assumptions of anti-individualism and privileged access; others have taken it to be an advantage of antiindividualism. However, I have argued that even if antiindividualism and privileged access were both true, they

<!-- page: pdf=0345 printed=none -->

would not enable a subject to gain a priori knowledge of the world. 

It seems, then, that anti-individualism does not have the problematic epistemic consequences often suggested. A quite different set of objections to anti-individualism arises from psychological explanation. It has been argued that anti-individualism is incompatible with the idea that a subject’s mental states and, in particular, their contents, causally explain her actions. Although this issue has not been my concern here, part of the argument of the book is relevant to anti-individualism’s consequences for psychological explanation. In chapter 6, I provided a new reason for thinking that anti-individualism is in tension with the notion of object-dependent sense developed by modern Fregeans. If that is right, then anti-individualists cannot hope to take advantage of the Fregean explanation of psychological phenomena. Thus, the choice between anti-individualism and individualism is also a choice between non-Fregean and Fregean explanations of action. A full defense of anti-individualism would need to address this issue as well as the question of the causal efficacy of content. However, these issues concerning psychological explanation are outside the scope of the present book and must be left for another occasion.
