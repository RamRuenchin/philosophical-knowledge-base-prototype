---
title: "Boghossian’s Inference Argument against Content Externalism Reversed*"
source_type: "paper"
source_format: "pdf"
source_path: "D:\\Local Knowledge Base\\2.Raw\\papers\\Otero-2012-Boghossian's Inference Argument against Content Externalism Reversed-Philosophy and Phenomenological Research.pdf"
source_id: "otero-2012-boghossian-s-inference-argument-against-content-externalism-reversed-philosophy-and-p-add1fbdaa3e4"
source_sha256: "add1fbdaa3e4a3ed2e6b864dc33542900a00d6c55f282dc69adc5d22063f2c57"
conversion_status: "extracted"
conversion_date: "2026-08-09T15:29:14+00:00"
page_marker_scheme: "pdf-and-printed"
locator_marker_scheme: "pdf-and-printed"
manifest_path: "D:\\Codex Working Folder\\2026-08-09\\obsidian-update-20260809-011416\\s214\\literature-to-markdown\\artifacts\\manifests\\otero-2012-boghossian-s-inference-argument-against-content-externalism-reversed-philosophy-and-p-add1fbdaa3e4-761a2d4a58.json"
---

# Boghossian’s Inference Argument against Content Externalism Reversed*

<!-- page: pdf=0001 printed=159 -->

Philosophy and Phenomenological Research Vol. LXXXIX No. 1, July 2014 doi: 10.1111/phpr.613 � 2012 Philosophy and Phenomenological Research, LLC 

# Boghossian’s Inference Argument against Content Externalism Reversed* 

## manuel pe´rez otero University of Barcelona 

I deal here with one of Boghossian’s arguments against content externalism, related to our inferential rationality (to use his term). According to his reasoning, the apriority of our logical abilities is inconsistent with certain externalist assumptions. Nevertheless, the problem constitutes an important challenge for any theory of content, not just for externalism. Furthermore, when we examine what internalists may propose to solve the problem, we see that externalists have at their disposal a more promising repertoire of possible replies than internalists. In that sense, insofar as Boghossian’s scenario is relevant to the debate externalism ⁄ internalism, it can be seen (against Boghossian’s original intention) as providing additional evidence for content externalism. 

### Introduction 

Several incompatibilist arguments have been presented against externalism that attempt to show that such a conception of the content (meaning) of our representations is inconsistent with self-knowledge of our 

- The main ideas in this work have been presented at several meetings: in a session of the Logos Seminar (Universidad de Barcelona, February 2010); in the workshop Anti-individualismo y conocimiento del significado (Universidad Auto´ noma de Madrid, May 2010), and in the II Workshop on Philosophy and Cognitive Science (Universidad de Buenos Aires, November 2010). They also appeared in a Spanish language article: Pe´ rez Otero (2010). The debate in a Logos Reading Group about externalism and self-knowledge that I coordinated during the course 2007–08 has been fruitful too. I am indebted to the respective audiences and to some other people who have read previous versions of this article and have made very helpful suggestions. Thanks particularly to Paulo Faria, Manuel Garcı´a-Carpintero, Ekain Garmendia, Jesu´ s Vega, Vı´ctor M. Verdejo-Aparicio, Ignacio Vicario and Agustı´n Vicente. Financial Support: Program CONSOLIDER-INGENIO 2010, ‘‘Perspectival Thoughts and Facts’’ (CSD2009-00056), MICINN (Spanish Government). Project ‘‘Knowledge, Reference and Realism’’ (FFI201129560-C02-01), MICINN (Spanish Government). Consolidated and Funded Research Group LOGOS (2009 SGR 1077), AGAUR (Catalan Government).

<!-- page: pdf=0002 printed=160 -->

thoughts. The ultimate goal of most of these arguments is to discredit externalism, since they claim that the theses regarding self-knowledge must be upheld. My position in relation to this debate is a compatibilist one. I believe that content externalism is fundamentally correct, and I include in this classification both linguistic externalism—according to which the meaning of (at least) some expressions depends on external factors that are not accessible to the subject via introspection—and intentional externalism—which proposes an analogous thesis with regard to mental states.<sup>1</sup> However, I also believe that we have a certain type of privileged access to our thoughts, and thus some thesis regarding self-knowledge of content (perhaps a modest thesis, but notwithstanding that, certainly a substantial one) is equally true. From my point of view, an appropriate compatibilist reply can be found to all the incompatibilist arguments (and many such replies have already been found). In this paper I concentrate on one such argument. It was presented by Boghossian and it is related to our inferential rationality (to use his term).<sup>2</sup> 

The main conclusion of Boghossian’s reasoning is that externalism is inconsistent with the fact that we know a priori whether an argument is logically valid or not (Boghossian refers to this supposed fact as the a priority of our logical abilities). This argument has also been replied to, from a range of positions. My main objective here is not to present a new externalist reply to that argument; rather, I aim to demonstrate that the problematic scenario described by Boghossian also constitutes a problem for internalist theories. Thus, the central thesis that I defend here is that the problematic situation that Boghossian describes represents an important challenge for any theory of content, not just for externalism. Furthermore, I will defend a stronger secondary thesis. This is that when we examine the different possible responses that externalism and internalism can deploy, it turns out that, to the extent that the problem bears on the externalism ⁄ internalism debate, it is the externalist side that comes out on top. I hope to show that the 

> 1 Putnam (1973, 1975) and Burge (1979), respectively, defended the two types of thesis based on their celebrated thought experiments concerning Twin Earths. Following a different route, Davidson (1987) arrived to a similar view. 

- 2 Cf. Boghossian (1992a, 1992b and 1994). A better-known and more widely-debated argument put forward by Boghossian which—like the one I consider here—aims to demonstrate that externalism is inconsistent with certain undeniable ideas regarding the transparency of content can be found in Boghossian (1989). I have considered and criticized one aspect of that other argument in my Pe´ rez Otero (2009). McKinsey (1991) developed a substantially different incompatibilist argument, related to the supposed a priori knowability of the existence of natural kinds such as water (and, quite exceptionally, he proposed that the flaw was in the theses regarding self-knowledge). I reply to it in Pe´ rez Otero (2004).

<!-- page: pdf=0003 printed=161 -->

repertoire of solutions that the externalists can call on is more promising than the set of solutions that the internalists can invoke. I will also tentatively suggest a hypothesis that could explain this stronger thesis: the debate favours externalism because the example analysed by Boghossian involves the use of a singular term, and with respect to singular terms, our externalist intuitions (as highlighted by Putnam and Burge in their thought experiments about Twin Earths) are even stronger than they are with respect to natural kind terms (which are usually invoked to illustrate the discussion). 

### 1. Peter’s Inference and Boghossian’s Challenge 

In order to facilitate exposition, Boghossian assumes that we carry out our mental operations in a language of thought, and indicates that nothing will hinge on this thesis. Here, I will accept both these ideas; my reply will not depend on this point. Taking into account this assumption regarding a language of thought, I will use expressions such as ‘‘Pavarotti’’ to refer indistinctly to the word ‘Pavarotti’ and also to the mental token corresponding to the term ‘Pavarotti’. 

Boghossian describes a variation of usual Twin Earth scenarios. Peter is an Earthling who is an opera buff. The sight of Pavarotti bathing in Lake Taupo (in New Zealand) makes a deep and memorable impression on Peter. Years later, without knowing it, Peter is transported to Twin Earth, where—along with the other counterparts of his previous fellow Earth dwellers—there is a twin of Pavarotti. Peter spends long enough on Twin Earth for it to be natural to consider that his new uses of ‘Pavarotti’ typically refer to twin Pavarotti, obviously without Peter being aware of any such change (the example is a case of what Burge called slow switch).<sup>3</sup> Boghossian emphasizes another point that is crucial to the set-up of the example. His externalist opponent should accept that although the tokens of ‘Pavarotti’ typically connected with the circumstances of the new setting (Twin Earth) now usually refer to twin Pavarotti, Peter’s memories—and his beliefs about the past based on those memories—also allow him to have thoughts about Pavarotti occasionally.<sup>4</sup> (This claim could be controversial, but for the purposes of my argument I will accept it as correct.) Then, one night, Peter goes to a concert given by twin Pavarotti. The next day, he is relaxing remembering both recent occurrences and others that are further back in his past. He has thoughts that he would express by saying ‘Pavarotti once swam in Lake Taupo’ and ‘The singer I heard

<!-- page: pdf=0004 printed=162 -->

yesterday is Pavarotti’. From these, Peter infers the following: ‘The singer I heard yesterday once swam in Lake Taupo’. Therefore, this is Peter’s inference: 

- P1: Pavarotti once swam in Lake Taupo. 

- P2: The singer I heard yesterday is Pavarotti. 

- C: Therefore: the singer I heard yesterday once swam in Lake Taupo. 

Boghossian points out that to Peter ‘‘the inference will appear blindingly valid’’. And he adds: 

But it isn’t. The first premise is intuitively about our Luciano. The entirely independent second premise expresses a memory of yesterday’s concert and is consequently about twin Luciano. True premises conspire, through a fallacy of equivocation that Peter is in principle not in a position to notice, to produce a false conclusion. (Boghossian 1992a, p. 22). 

What exactly is the problem? According to Boghossian, the situation that he has set up (or the way in which an externalist should describe it; cf. more on Boghossian’s ambiguity below) is inconsistent with what he considers to be ‘‘a very important aspect of our intuitive conception of the mind—namely, [it is inconsistent] with the a priority of our logical abilities’’ (op. cit., p. 17). This thesis, which I will call APLA, claims that subjects can know a priori whether an inference that they perform is logically valid or not. In order to simplify the discussion, we can assume that APLA is restricted to inferences with very few premises, none of which involves any great degree of syntactic complexity (just as in the case of Peter’s inference). Boghossian believes that APLA cannot be renounced because it plays a fundamental role in how we use propositional attitudes to rationalize our inferences (both theoretical and practical).<sup>5</sup> Apparently, Peter is perfectly rational. Nevertheless, the externalists would be obliged to accuse him of being irrational because his reasoning follows an argument that, despite Peter’s view to the contrary, is not logically valid.<sup>6</sup> 

- 5 Cf. Boghossian (1992a, p. 26) and (1992a, pp. 42–43). 

> 6 Whether or not the questions addressed in this paper could be more a case of a supposed conflict between externalism and self-knowledge of one’s mind will depend on whether the knowledge that APLA deals with (according to Boghossian, part of our intuitive conception of the mind) can be considered as self-knowledge, that is, knowledge of our own thoughts. However, this is really rather a secondary issue. The most important question will be whether APLA is true, and if it is, how we are to account for Peter’s inference.

<!-- page: pdf=0005 printed=163 -->

It is important to note that APLA is a particularly demanding epistemic requirement. It does not merely require that we know how to distinguish a priori logically valid forms of arguments from those that are not logically valid. According to APLA, we can even distinguish a priori whether a particular inference (containing particular premises and a specific conclusion, belonging to either a public language or to a language of thought) satisfies one of these logically valid forms or not. Boghossian is very well aware of the difference; he claims that externalism is not inconsistent with the weaker requirement that I have just mentioned (cf. ‘‘Externalism and Inference,’’ footnote 10). In this way, he tries to block an opponent who, in order to avoid the problem simply claims that Peter does not constitute a counterexample to our a priori knowledge of the logical validity of inferential patterns, by recognizing that what Peter does not know a priori is whether his specific inference satisfies a logically valid pattern or not. 

The problem that Boghossian sets out is an important challenge for any theory of content. Any conception of how representational content is determined, not just externalism, should provide an explanation of what happens in cases such as Peter’s inference. Maybe special attention is paid to what externalist theories would say about this problem due to the (contingent) fact that Boghossian presented it (mistakenly, from my point of view) as a challenge for externalism. However, the idea that externalists are faced here with a problem that is derived from their own assumptions will be difficult to maintain once we have carefully examined how internalism tackles the problem. 

### 2. Some Externalist Solutions 

I will mention some of the most important replies that externalists have offered. I will not examine them in detail nor will I consider which of them is preferable; that is not my aim in this section. I will give a schematic summary of these replies and also of the main problems they face with the objective of acquiring a certain perspective on the strategies that an externalist can adopt in order to refute Boghossian’s argument. My eventual aim is to compare this conception—with regards to this question—with internalism, whose possible answers to the problem will be examined in sections 3, 4 and 5. 

The proposed externalist solutions that I will consider accept a considerable part of the set-up of the situation just as it is presented by Boghossian. The two main replies differ in the answers they give to the question: Is Peter’s inference logically valid? 

Both Schiffer (1992) and Burge (1998) answer this question in the affirmative. The conclusion of the inference is certainly false, but they

<!-- page: pdf=0006 printed=164 -->

consider that Peter’s second premise, P2: ‘The singer I heard yesterday is Pavarotti’, is also false. That proposition would be false, because in it the term ‘Pavarotti’ does not refer to twin Pavarotti, but rather to Pavarotti. To support this idea, Schiffer and Burge elaborate (similar) hypotheses concerning restrictions on the referential relations of the terms and concepts that appear in the premises of an argument. In a slightly different context, Peter would refer to twin Pavarotti when he uses the name ‘Pavarotti’ in statement P2 (and likewise with respect to the thought) but since P2 is preceded by premise P1, ‘Pavarotti once swam in Lake Taupo’, in which Peter has used ‘Pavarotti’ to refer to Pavarotti, things are different. Given the intention of referring to the same person, the interpretation of the term in the second premise is restricted by the interpretation that it has to have in the first. The relation between the two occurrences of ‘Pavarotti’ is similar to that which exists in cases of anaphora between a given term and a pronoun which, due to its anaphoric relation with the term, has the same referent as it.<sup>7</sup> 

I will call this solution the Anaphorically-based Externalist solution. It allows us to completely uphold APLA, just as Boghossian wanted. Peter believes himself to be reasoning according to logically valid argumentation. Indeed, Schiffer and Burge accept that Peter’s inference is logically valid. The problem (that one of the premises is false, due to factors that the subject has no access to) is a feature that is perfectly acceptable for an externalist and which is no threat to any relevant thesis regarding the a priority of our logical capacities. 

I should mention the main criticisms that some authors have directed against the Anaphorically-based Externalist solution. The most important was surely put forward by Brown; it is concisely expressed thus: 

Burge’s position has the counterintuitive consequence that the order in which a subject reasons may affect the content of the thoughts reasoned about. [. . .] Burge is forced to deny the intuitively plausible view that what thoughts a subject entertains is independent of the order of her reasoning. (Brown 2004, pp. 177–178). 

A defender of the Anaphorically-based Externalist solution can reject this view as implausible or, at any rate, maintain that its plausibility is illusory. Ultimately, it is not difficult to specify other cases in which what thoughts a subject entertains is dependent on the order of her reasoning. For example, this is what happens with regard to the thought expressed by the statement q, according to whether it is the second premise of argument T, or the third premise of argument T’:

<!-- page: pdf=0007 printed=165 -->

|T:|p:|Eve is F|
|---|---|---|
||q:|but she is not G|
||r:|Sue admires every F|
||c:|Therefore: Sue admires someone that is not G|
|T’:|p:|Eve is F|
||r:|Sue admires every F|
||q:|but she is not G|
||c:|Therefore: Sue admires someone that is not G|


Another objection comes from Boghossian himself. According to Boghossian, given two sufficiently differentiated uses of ‘Pavarotti’ by Peter, such that in one of them the referent is Pavarotti and in the other the referent is twin Pavarotti, it would be perfectly conceivable that Peter later brought together the two corresponding beliefs and performed just the type of inference we are considering. He says: 

Now, just imagine a case—surely conceivable—in which Peter puts together two such memory beliefs, one stemming from an Earthly experience and the other from a Twearthly experience, in order to draw an identity conclusion he had not arrived at previously. I fail to see what could conceivably preclude this. (Boghossian 1992b, p. 42). 

There are two things that we should note about this reflection. One is a consideration ad hominem that I will make at the end of the next section. The other is by way of a counter-reply (somewhat imprecise, as is Boghossian’s own reflection). That criticism is based on a mere suggestion that nothing prevents the two memory beliefs (one concerning Pavarotti, the other, twin Pavarotti) being in some way ‘‘put together’’ in the same reasoning process. However, it could be assumed that the defender of the Anaphorically-based Externalist solution will propose that such a cognitive process of ‘‘putting together’’ the two beliefs will be subjected to the same anaphoric restrictions that applied to the original argument. It is not clear why Boghossian supposes otherwise. 

Other authors, in contrast, assume that Peter’s reasoning is not logically valid. They renounce the APLA thesis, but consider that this is not a serious sacrifice. They even accept some of Boghossian’s considerations regarding the link between APLA and the rationalization of our argumentations; Peter is not rational when he carries out his inference. His case exemplifies an important theoretical phenomenon, which deserve attention and analysis: logical luck. Sorensen (1998) and Faria (2009) exemplify this position.<sup>8</sup> For them, externalist theses would be applicable beyond issues about the determination of representational 

> 8 Both Sorensen and Faria respond directly to Boghossian’s challenge. Independently of this specific problem, Williamson (2000) defends a closely related conception of rationality which is also radically externalist.

<!-- page: pdf=0008 printed=166 -->

content (linguistic, or also intentional)—the field for which they have been postulated and mainly discussed. Subjects can sometimes be irrational; and not just due to errors that could be corrected if we were all sufficiently thoughtful and careful in our reasoning. On occasions, being rational or not depends on factors that are external to us and over which we have no control or epistemic access. In this sense, drawing an inference by following a logically valid argument is something that we cannot always control. Thus, this extends the notion of luck that some philosophers have postulated in relation to ethics to create the analogous concept of moral luck.<sup>9</sup> I will call this proposal the Logical Luck-based solution. 

One problem for the Logical Luck-based solution explanation is that it is committed to a particularly radical externalism which is apparently counterintuitive.<sup>10</sup> Besides whatever may be established by theories concerning representational content (whether linguistic or intentional), it would seem that a certain epistemic internalism must be valid at least in the areas of rationality and logical inference. However, the externalism derived from the Logical Luck-based solution (Inferential Externalism, we could call it) also denies that these qualities (to infer according to logically valid patterns, or more generally, to be rational) only depend on internal factors that a subject can access via introspection. 

Nevertheless, we should remember that the APLA principle, which these theses violate, is also very demanding. These inferential externalists do not also have to commit themselves (at least it does not follow from the discussion we are examining here) to rejecting the weaker postulate mentioned at the previous section (the requirement that we know how to distinguish a priori logically valid forms of arguments from those that are not logically valid).<sup>11</sup> 

> 9 Cf. Nagel (1976) and Williams (1976). 

> 10 Even though it is radical in a different way from Millian externalism, which I will mention in Section VI. 

> 11 Goldberg (1999) works out an argument similar to Boghossian’s for a related—but weaker—conclusion. He claims that some differences between Boghossian’s argument and his own are crucial because they show that the Schiffer-Burge solution cannot be generalized to dispose of his example. The differences emphasized by Goldberg are not—in my view—so relevant. However, there is one that seems to be crucial: Sally’s reasoning (Sally is the thinker in Goldberg’s example) takes place after she has discovered that, in the past, she had mistakenly been assuming that a certain expression had a unique sense. As a consequence, after the discovery Sally could not be rationally confident of simultaneously believing her two supposed premises (because of her ignorance about the provenance of the warrant for one of them), which goes against Goldberg’s description of the case. If, as Goldberg claims, the Schiffer-Burge solution cannot be applied to his case, it is because it has a ‘‘prior’’ solution: Sally would not accept the entertained premises.

<!-- page: pdf=0009 printed=167 -->

Other externalists accept that the argument P1-P2-C is not logically valid, but deny that the failure of APLA has the serious consequences about Peter’s rationality described by Boghossian. According to Brown (2004), we cannot say that Peter is irrational even if his reasoning is not correct. Sometimes, when a mistake in reasoning can be explained (and externalism can explain what happens in Peter’s case) the thinker is rational, in a weak but sufficiently relevant sense. For Garmendia (2010), Peter’s inference is valid if supplemented with an implicit premise (implying that Pavarotti is twin Pavarotti) that we should ascribe to him (cf. Burge 1998, p. 368, for a similar position regarding the cases where his solution does not apply). Campbell (1987), Brown (2004) and Faria (2009) claim that such a strategy launches an infinite regress. Garmendia can stop the regress, as a consequence of this thesis: a thinker uses one of the relevant premises (about identity or nonidentity of certain objects) in her reasoning only if supplementing the inference with the premise is required for it to count as logically valid. I will not deal here with the drawbacks in Brown’s and Garmendia’s views. The Anaphorically-based Externalist solution and the Logical Luck-based solution seem to me to be the least problematic externalist strategies and I will take them as the preferred externalist options.<sup>12</sup> 

### 3. Two Internalist Accounts, Implying Identity in Content 

It is now time to ask ourselves just what position an internalist can adopt when faced with the problem posed by Boghossian. I will describe and analyse six different explanations or accounts of Peter’s situation, each of which constitutes a distinct internalist alternative. Some readers may consider that one of these alternatives is clearly preferable to the others, thus making an analysis of the flaws in the others unnecessary. However, since all the proposals are problematic in one way or another, I believe it is worthwhile also mentioning the less reasonable alternatives, in order to help dispel any idea that maybe we have not explored the range of answers that internalism has to offer in enough detail. The main thrust of my argument points toward the 

> 12 An interesting point regarding the different externalist positions is that—as far as I know—none of them seems to recognize that internalism also has difficulties when it comes to accounting for Peter’s inference (as we will see in the final three sections). Brown, for instance, writes: ‘‘No matter how sophisticated a subject’s grasp of logic, if sameness and difference of content is not transparent to her, she will be unable to make her thoughts conform to the principles of logic a priori’’ (op. cit., p. 184). It would seem as if she and other externalists accept that it is only externalism that is affected by this problem. To the extent that this is so, my main thesis in this paper (that the problem affects any theory of content, not just externalism) also questions assumptions about the problem that these externalist positions share with Boghossian, either explicitly or implicitly.

<!-- page: pdf=0010 printed=168 -->

goals already mentioned: to defend a principal, weak thesis (that Peter’s inference constitutes a problem for any theory of the content, not just for externalism) and also an additional, stronger thesis (that internalist analyses of Peter’s inference are less plausible than externalist analyses). 

According to Boghossian, his example leads us to conclude the following: ‘‘the thesis of the a priority of logical abilities [APLA] is shown [. . .] to be inconsistent with externalist assumptions’’ (Boghossian 1992a, p. 22). I will begin by asking: What externalist assumptions is he referring to? Obviously, an internalist—or at least an internalist close to Boghossian’s position—will attempt to ensure that their analysis of Peter’s inference will typically include a rejection of such assumptions, thus avoiding the problem. 

What exactly are these externalist assumptions that are supposedly responsible for the problem? The first five internalist explanations I will describe (in the remained of this section and the following one) are motivated by the following answer to this question, which is probably the most natural hypothesis. The characteristically externalist thesis that lies at the heart of the matter is the idea that the standard uses of the symbol ‘Pavarotti’ (recall: both of the symbol in public language and of the symbol in the language of thought) on Earth and on Twin Earth typically differ in content, in meaning. Normally, whoever uses it on Earth refers to (thinks of) Pavarotti and whoever uses it on Twin Earth refers to (thinks of) a specific different entity: twin Pavarotti. This difference in reference would determine a difference in content. Starting from this idea, Boghossian—as has already been pointed out—claims that it is possible to attribute two other theses to the externalist: after staying for long enough on Twin Earth, Peter will usually refer to twin Pavarotti (and not to Pavarotti) with his new uses of ‘Pavarotti’; nevertheless, in virtue of his memories and of his beliefs based on those memories, Peter can still refer to Pavarotti and think about him. Specifically: the externalist would be committed to the idea that the content of ‘Pavarotti’ in the premise P1 of Peter’s inference involves Pavarotti and thereby differs from the content of ‘Pavarotti’ in premise P2, which does not involve Pavarotti but twin Pavarotti. It is precisely this difference in meaning between the two appearances of ‘Pavarotti’ that would give rise to the problem, according to this internalist interpretation. 

The hypothesis that Boghossian attributes the problem to this externalist assumption would also be supported by his reiterated allusions (when discussing this question) to the transparency of content, as a condition that presumably is not respected by externalism. For instance: ‘‘In the situation described, Peter’s externally individuated thought

<!-- page: pdf=0011 printed=169 -->

tokens are not transparent to him’’ (op. cit., p. 21). It would seem to Peter as if ‘Pavarotti’ did not differ in content in the two premises. According to externalism the content differs, and therefore Peter does not know the content of his thoughts, in contradiction of the principle of transparency defended by Boghossian. 

Guided by this hypothesis, we will study five different ways an internalist can propose that the contents of ‘Pavarotti’ in the two premises are individuated in such a way that they are the same (also postulating that the content of this symbol is the same, in general, independently of whether it is used on Earth or on Twin Earth): 

- (a) A singular term such as ‘Pavarotti’ expresses the same concept, whether it is used on Earth or on Twin Earth, and the same reference also corresponds to that concept; in addition, that reference is such that, not only the premises P1 and P2, but also the conclusion C are true. I will call this internalist proposal Same-Meaning ⁄ Same-UnifiedReference. 

It will be easier to understand this internalist explanation (in particular to avoid any confusion between this explanation and that set out in (b) below) if we consider how it would apply analogously to the case ‘water’. A defender of the Same-Meaning ⁄ Same-Unified-Reference thesis would reply to Putnam’s original experiment by rejecting the idea that the samples of water on Earth and the samples of what on Twin Earth is called ‘water’ belong to two different substances or natural kinds. Such a person would maintain (perhaps motivated by reflection provoked by Putnam) that the different atomic structures (H2O and XYZ, respectively; with the former only to be found on Earth and the latter only on Twin Earth) are not what determines the nature of the substance. 

It becomes somewhat more complicated to apply this proposal to ‘Pavarotti’; I believe that this is precisely because (as we will see in a moment) applied to ‘Pavarotti’ it becomes even less plausible. First, let us just consider some of the other consequences of this proposal. Peter considered his inference logically valid; according to the proposal we are examining here, the premises and the conclusion are all true, so there is no problem attributing logical validity to Peter’s inference. In this way the proposal meets one of Boghossian’s desiderata: APLA, the thesis of the a priority of logical abilities, is respected. 

One initial drawback is immediately recognizable. Boghossian explicitly states that Peter’s inference is not valid (see the first quotation from Boghossian 1992a, p. 22, above). It would seem then that the SameMeaning ⁄ Same-Unified-Reference thesis does not adequately represent Boghossian’s preferred internalist position. As a counter-reply to this position it could be claimed that when Boghossian states that Peter’s

<!-- page: pdf=0012 printed=170 -->

inference is not valid, the statement forms part of the position that Boghossian attributes to externalism and that it does not reflect his own point of view. In fact, some phrases in Boghossian do indeed point in this direction; for example, on one occasion he comments on the case by saying: ‘‘I [. . .] claimed that such a thinker would, as a result, be tempted to think logically valid inferences which are, on an externalist interpretation, invalid’’ (Boghossian 1992b, p. 39; the emphasis is mine). Nevertheless, Boghossian goes on to complete this sentence using words that seem once again to suggest the opposite position; they ‘‘ suggest that Boghossian considers the inference to be invalid: . . ., and that this would be a mistake’’. 

Whatever the case here, the fundamental difficulty with Same-Meaning ⁄ Same-Unified-Reference concerns the conclusion, C, which is true according to this proposal. What entities are people, and in particular singers, for C to be true? Such internalism leads to a very extravagant semantics, or to a very extravagant ontology; or to both. To be the singer Pavarotti is conceived in such a way that not only does such a property apply to both Pavarotti and twin Pavarotti, but it apples to both of them as being the same singer. (If we substitute ‘once swam’ by ‘completely submerged himself’ in the original argument, we obtain another inference that Peter could also have arrived at, and which demonstrates even more strongly that it is counterintuitive for C to be true.) 

The second option will surely be less confusing, despite sharing with Same-Meaning ⁄ Same-Unified-Reference the consequence that ‘Pavarotti’ has the same content and also the same reference on Earth and on Twin Earth: 

- (b) Given the existence of Twin Earth, a singular term such as ‘Pavarotti’ expresses an amalgam concept; both Pavarotti and twin Pavarotti fall under this concept. The role of ‘Pavarotti’ is similar to that of the term ‘jade’, which expresses the same type of concept—we could say, in a way which is also acceptable to externalists—insofar as it includes two different natural kinds: jadeite and nephrite. I will call this internalist proposal Same-Meaning ⁄ Same-Disjunctive-Reference. 

Once again, the analogy with the case of ‘water’ facilitates understanding. According to Same-Meaning ⁄ Same-Disjunctive-Reference, although H2O and XYZ are recognized as two different substances or natural kinds, ‘water’ has the same meaning and the same extension when it is used here and when it is used on Twin Earth; it expresses—in both contexts—a single amalgam concept whose unique extension includes samples of either of the two substances, just as in our usual context ‘jade’ expresses a single concept whose unique extension includes samples of jadeite and also samples of nephrite.

<!-- page: pdf=0013 printed=171 -->

The Same-Meaning ⁄ Same-Disjunctive-Reference option differs from the previous proposal (Same-Meaning ⁄ Same-Unified-Reference) primarily in that it considers the conclusion of the inference, C, to be false. This can be seen more clearly if we accept hypothetically that ‘water’ effectively functions as ‘jade’ does, and we consider a different inference that Peter also carried out: 

P1*: The water once froze in Lake Taupo. 

P2*: The substance that I drank yesterday is water. 

C*: Therefore: The substance that I drank yesterday once froze in Lake Taupo. 

Whoever believes, in keeping with Same-Meaning ⁄ Same-DisjunctiveReference, that ‘water’ covers two different substances (H2O and XYZ) will reject C as a false proposition. This is compatible with two alternatives with respect to P2*: 

- (i) Assuming that P2* is an identity statement, it is also rejected since, as water (which includes both H2O and XYZ) is not a single substance, it cannot be identified with the substance (XYZ) that Peter drank (just as jade is not identical to a certain substance, nephrite). 

- (ii) We interpret P2* as not being an identity statement. It this case it can be accepted as true, in the same sense in which it would be true to say of a certain substance, nephrite, that ‘‘it is jade’’. In both cases the sense of ‘is’ would be close to the inclusion relation: the substance in question (XYZ ⁄ nephrite) is included among the several substances that together constitute water ⁄ jade. 

Continuing with the same analogy, the conclusion of Peter’s original inference is false, since the proposed individuation of singers coincides with our common-sense, pre-theoretical individuation (as opposed to what happens in the case of the Same-Meaning ⁄ Same-Unified-Reference proposal) and the singer who Peter hears the previous night has never bathed (we can stipulate this) in Lake Taupo. Let us consider the analogous cases to (i) and (ii) relative to Peter’s first inference: 

- (b.i) Assuming that P2 is an identity statement, it is rejected; Pavarotti is not identical to one particular singer. To be Pavarotti is either to be the singer on Earth or to be the singer on Twin Earth.

<!-- page: pdf=0014 printed=172 -->

- (b.ii) We do not interpret P2 as an identity statement. Then it can be taken as true; the singer from the previous night ‘‘is’’ also Pavarotti, just as the other singer ‘‘was’’. 

The two alternatives, (b.i) and (b.ii), have different consequences with respect to APLA. According to (b.i), the ultimate situation with APLA is similar to that we encountered with Same-Meaning ⁄ SameUnified-Reference: the inference can be considered valid (although now it would not have true premises and conclusion: the conclusion and premise P2 would be false); therefore APLA is upheld. Once again, we encounter the problem mentioned above: Boghossian stated that the inference is not valid (to which the same reply as before could be made). If (b.ii) is assumed, then the inference is not valid (it has true premises and a false conclusion). However, this option contradicts APLA, since Peter believes that his reasoning is correct; the fact that the inference is not valid would be internally inaccessible to the subject. 

Under either of the two hypotheses, (b.i) and (b.ii), there is an additional problem (in the case of (b.i) it is surely the main problem). Although the idea does not seem as extravagant as Same-Meaning ⁄ SameUnified-Reference (because, according to Same-Meaning ⁄ Same-UnifiedReference, the conclusion, C, is true), the situation described, that to be Pavarotti consists either of being the singer on Earth or of being the singer on Twin Earth, is also very counterintuitive. For the case of water, the idea does not seem crazy; but ‘Pavarotti’ was pre-theoretically classified as a singular term. Once again, the idea contradicts our semantic intuitions, or our ontological intuitions; or both types of intuitions. 

### 4. Indexical Internalist Content 

The following three internalist options consider that a singular term such as ‘Pavarotti’ works as an indexical expression. 

- (c) ‘Pavarotti’ is an indexical. It has the same content-meaning on Earth and on Twin Earth. However, that content is not enough to determine its reference. The reference typically differs with such a change; on Earth it usually refers to Pavarotti, on Twin Earth it usually refers to twin Pavarotti. I will call this internalist proposal Same-IndexicalMeaning ⁄ Different-Reference. 

The meaning of the singular term would be analogous to the meaning of a normal indexical, but only to the extent that that meaning is appropriately expressed by a general rule typically known by the speaker (a rule that establishes for example—for the case of ‘I’—that the reference of the term on an occasion in which it is used is the speaker) without including

<!-- page: pdf=0015 printed=173 -->

the referent in that meaning (the sense in which the meaning can be identified with Kaplan’s character). Although in the case of ‘Pavarotti’ the contextual factors that determine the reference more specifically would typically involve perception, normal everyday contact (direct or indirect) with one or other singer, memories, etc. 

Someone who maintained such a Same-Indexical-Meaning ⁄ DifferentReference position would probably also apply it to natural kind terms, such as ‘water’. Here, I will not go over the objections that exist in the literature concerning that strong indexical interpretation of natural kind terms.<sup>13</sup> In this debate I want to draw attention—once more—to the fact that this hypothesis is particularly implausible if we leave natural kind terms aside and we attempt to extend it to expressions such as ‘Pavarotti’. To be Pavarotti would be like playing a certain role, which different people can perform in different contexts; something like being the president of the United States, for example. Correspondingly, ‘Pavarotti’ would work semantically in a similar way to ‘the president of the United States’ (or at least to one of the modes in which such a term can be systematically interpreted). Same-Indexical-Meaning ⁄ Different-Reference also blatantly contradicts our pre-theoretical opinions. 

This proposal also undermines the APLA thesis (and, therefore, undermines Boghossian’s attempt to lay the blame for the problem exclusively at the feet of externalism). Effectively, the premises of Peter’s inference are true, but his conclusion is false. 

- (d) There is another way to treat ‘Pavarotti’ as an indexical; ‘Pavarotti’ can be classified as a context-imprinting indexical. The referent of an expression of this type depends on the first context of use. In all Peter’s uses of ‘Pavarotti’ it is Pavarotti who is being named, because that was the entity named on the first occasion. The reference in that first context of use determines the reference in future uses. I will call this internalist proposal Same-Context-Imprinting-Indexical-Meaning ⁄ Same-Reference. 

To illustrate the notion of context-imprinting indexical and contrast it with a normal indexical expression, I will stipulate the following semantic rule for ‘tomorrow*’: used by S, ‘tomorrow*’ is a temporally rigid designator (that is, at any moment it refers to the same entity) whose referent 

> 13 I say that it is a strong indexical interpretation in order to distance it from the weaker sense in which Putnam himself describes the situation, pointing out that terms such as ‘water’ are indexical. In this stronger interpretation it is proposed that the meaning of ‘water’ is similar to that of an indexical, in the sense that a certain general rule (which when applied in a specific context determines a referent) entirely accounts for that meaning, excluding the referent in question from it; in contradiction of Putnam’s externalist motivation, since he prefers to hold that the meaning determines the reference. (Cf. Putnam 1975, p. 234.)

<!-- page: pdf=0016 printed=174 -->

in the first context in which it is used coincides with the referent of ‘tomorrow’ (if it were used by S in this same context). In other words: the first time it functions just as ‘tomorrow’ and on subsequent occasions it works as a proper name for the referent from the first time. 

Maybe there are no context-imprinting indexicals in natural language. Neither is it clear why it would be useful from a functional point of view tohavethem.However,inthecontextofourdiscussion,itisnotanarbitrary decision to coin this notion and offer it to the internalist, because SameContext-Imprinting-Indexical-Meaning ⁄ Same-Reference could turn out to be preferable to Same-Indexical-Meaning ⁄ Different-Reference. Effectively, Same-Context-Imprinting-Indexical-Meaning ⁄ Same-Referencewould imply that P2 is false. In this way it would once again be possible to consider Peter’s inference logically valid, and thereby to uphold APLA. 

As a response to this possibility we should first mention the already familiar objection concerning Boghossian’s declarations denying the logical validity of the inference; when faced with this objection we are already aware of a possible reply. In a second instance, an important part of our usual intuitions against the idea that ‘water’, or in particularly ‘Pavarotti’, are indexicals are also deployed against the hypothesis that they are context-imprinting indexicals. 

There now appears a doubt as to whether the Same-IndexicalMeaning ⁄ Different-Reference strategy, as laid out in (c), was the most appropriate way to interpret, charitably, the idea of considering ‘Pavarotti’ as an indexical of the normal type (not context-imprinting). This leads us to recognize another possibility: 

- (e) ‘Pavarotti’ works as an indexical, just as described in (c), but nothing stops the internalist from partially invoking Schiffer and Burge’s Anaphorically-based Externalist strategy. The general rule associated with the term would determine a reference for ‘Pavarotti’ in P1 that is different from the reference that would be determined for ‘Pavarotti’ in P2 only if the two premises were in different contexts (sufficiently isolated from each other). The intention of referring to (thinking of) the same individual also makes a contribution, leading to the result that in this argument, ‘Pavarotti’ in P2 does not refer to twin Pavarotti, but to Pavarotti. All of this is in line with the internalist thesis that the singular term is indexical (otherwise, this option would become confused with the Anaphorically-based Externalist solution).<sup>14</sup> I will call this internalist proposal Same-Indexical-Meaning ⁄ SameAnaphorically-based-Reference. 

> 14 I am indebted to M. Garcı´a-Carpintero for drawing my attention to this SameIndexical-Meaning ⁄ Same-Anaphorically-based-Reference option—an improved version of Same-Indexical-Meaning ⁄ Different-Reference, as I see it—which I had not initially considered.

<!-- page: pdf=0017 printed=175 -->

The advantage over Same-Indexical-Meaning ⁄ Different-Reference seems clear. This anaphoric solution, as was also the case with the externalist version (the Anaphorically-based Externalist solution), allows us to state that Peter’s inference is valid, thus upholding APLA. In this way the second of the problems mentioned in relation to Same-IndexicalMeaning ⁄ Different-Reference is avoided. It does not, however, avoid the first problem that affected it: our pre-theoretical opinion is that apart from the expressions that are commonly considered to be indexicals (‘I’, ‘this woman’, etc.) other referential terms are not indexicals; particularly, singular terms such as ‘Pavarotti’ are not indexicals. 

Regarding the exegetical question about how we should interpret Boghossian, if we attribute this Same-Indexical-Meaning ⁄ SameAnaphorically-based-Reference internalist solution to him, a further problem is raised, from which one could mount the ad hominem argument that I referred to in Section 2 against Boghossian. If the reason that Boghossian gives (see above) for rejecting the Anaphorically-based Externalist solution were correct, it would also apply to and disqualify this internalist anaphoric solution, Same-Indexical-Meaning ⁄ SameAnaphorically-based-Reference. It is clear that Same-IndexicalMeaning ⁄ Same-Anaphorically-based-Reference would also suffer from the other problem that affected the Anaphorically-based Externalist proposal, which refers to the order of the premises in an argument (the problem Brown pointed out). In short, the internalist option (SameIndexical-Meaning ⁄ Same-Anaphorically-based-Reference) would have to confront the two supposed drawbacks that the externalist option (the Anaphorically-based Externalist proposal) faces. But it would have the added drawback mentioned in the previous paragraph: it is counterintuitive to classify singular terms, such as ‘Pavarotti’, as indexicals. The first of these two reflections (that Same-Indexical-Meaning ⁄ SameAnaphorically-based-Reference shares with the Anaphorically-based Externalist proposal the two problems that supposedly affect this one) is evidence in favour of my main thesis (at least in terms of the contrast between Same-Indexical-Meaning ⁄ Same-Anaphorically-based-Reference and the Anaphorically-based Externalist proposal). The second reflection (regarding the added problem faced by the Same-IndexicalMeaning ⁄ Same-Anaphorically-based-Reference proposal) supports my stronger thesis. 

### 5. Different Content, Internally Determined 

The five internalist options I have commented on in the two preceding sections were motivated by the hypothesis that the thesis attributed to externalism, and which Boghossian considered responsible for the

<!-- page: pdf=0018 printed=176 -->

problem, was that the two occurrences of ‘Pavarotti’, in P1 and P2, had different contents (meanings). That is why those options proposed that the two occurrences shared their content. The internalist alternative that we will consider now takes the other path: 

- (f) The two occurrences of ‘Pavarotti’ have different contents, but that difference depends on internal factors that are accessible to the subject. Thus, the crucial and erroneous externalist assumption—according to this option—would be that the difference in content depends on external factors. I will call this internalist proposal Different-Internally-determined-Meaning. 

In accordance with this idea, Peter’s inference is not valid: his premises would be true and his conclusion false. This would imply, apparently, that this Different-Internally-determined-Meaning option likewise violates APLA, since Peter believes his reasoning to be valid. It would appear that the drawback of this option is even worse. It seems as if the internalist could not opt for Different-Internally-determined-Meaning precisely because Peter, who has access to all the internal factors that could contribute to determining content, unreservedly accepts making an inference according to P1–P2–C, showing that, from his point of view, the two occurrences of ‘Pavarotti’ share their content. Does this not prove that if there exists a difference, it must be derived from external factors? 

Internalists have some leeway for formulating a response to this. For example, they could claim that it was not their intention for it to be a neutral, uncontroversial component of the description of the situation that Peter performed such an inference; it is only the externalist (by maintaining that the difference in content between the two appearances of ‘Pavarotti’ depends on factors that are inaccessible to the subject) who is obliged to assume that Peter would not shrink from reasoning in this way. According to this internalist, Peter, as a rational subject, will not make the mistake of accepting the reasoning: P1–P2–C. 

However, such a reply is empirically very unsatisfying. That is, the conviction is very strong that if the circumstances described by Boghossian were indeed the case (regarding those aspects included in the neutral components of the description), the actions that an observer would empirically recognize in Peter, including his verbal conduct, would clearly indicate that he had actually made the inference; therefore, we have the firm conviction that Peter would reason in this way. 

A prudent internalist—who wanted to defend the Different-Internally-determined-Meaning option—would surely avoid this difficulty in a different way. Perhaps it has to be accepted that Peter makes his

<!-- page: pdf=0019 printed=177 -->

inference according to P1–P2–C, but this idea can be reconciled with APLA and with the transparency of content. Although Peter does in fact perform the inference, he has the means at his disposal not to infer in this way. Given that a priori reflection would allow him to access such differences of content and—being sufficiently thoughtful—that these differences (once he realizes that they could involve a difference in the referent of ‘Pavarotti’) would then allow him to cautiously abstain from deriving conclusion C from P1 and P2, it is perfectly legitimate—for the internalist—to attribute Peter with a certain irrationality when he makes an inference following P1–P2–C. If Peter were to reflect sufficiently he would have access to these differences and, in keeping with APLA, he would realize that the reasoning is not logically valid.<sup>15</sup> 

The externalist philosopher who postulates differences in content (between the two occurrences of ‘Pavarotti’) that are only derived from external factors is obliged to admit that the inference is not valid and that Peter cannot internally access the factors that determine that the inference is not valid (however much he thinks about it); therefore, APLA is violated and, consequently (accepting the connection postulated by Boghossian between APLA and rationality) there is no way open to the externalist to describe Peter’s error as a case of a mistake that could have been avoided had Peter been sufficiently thoughtful and rational. 

Here I wish to point out two problems. First, it is very hard to clarify exactly what type of differentiating factors an internalist can propose for the case of ‘Pavarotti’ (maybe she would invoke metalinguistic factors; though it is yet to be shown whether such factors can make a differential contribution while still reaming internal). It is so hard that some would consider this Different-Internally-determined-Meaning option to be practically unintelligible. In second place, the original externalist intuitions invoked by Putnam to support the idea that an external factor—the reference of ‘water’—contributes to determining the meaning of ‘water’ are also present, and more obviously so, in the case of singular terms such as ‘Pavarotti’. 

### 6. Another Externalist Solution 

It is now time to mention another strategy that an externalist could adopt to tackle Boghossian’s problem. If we suppose that the Different-Internally-determined-Meaning strategy that I have just commented on is able to resolve the first of the two difficulties mentioned (that is, supposing that it was able to clarify, at least minimally, the internal 

> 15 In this sense, Peter would be minimally rational (even if he does commit this error), according to Boghossian’s terminology (cf. Boghossian 1994, p. 42).

<!-- page: pdf=0020 printed=178 -->

factors postulated), an externalist could then make use of the advantages of Different-Internally-determined-Meaning, since the externalist has the possibility of invoking those internal factors which, according to Different-Internally-determined-Meaning, would determine the difference in contents between the two occurrences of ‘Pavarotti’. I will call this externalist proposal Different-Internally-and-Externally-determined-Meaning. 

It is important to stress that Different-Internally-and-Externallydetermined-Meaning is an open option to many externalists. Externalism claims that the difference in reference (denoting Pavarotti in one case; denoting twin Pavarotti in the other) is an external factor that makes for a difference in meaning. However, externalism is not committed to the idea that meaning is exhausted by such external factors. Only a radical version of externalism, inspired by Mill’s thesis about the semantics of proper names, proposes that the meaning of ‘Pavarotti’ is merely its referent. The Millian externalist cannot claim that other elements (which are introspectively accessible to the subject) are also semantically relevant; but no such limitation applies to other externalists. 

Boghossian is well aware that content externalism is, according to the standard characterization of this conception, compatible with a weak, non-Millian, version.<sup>16</sup> He recognizes that the case involving ‘London’ described in Kripke (1979) (a ‘‘converse’’ case with regard to the case of Peter) would only demonstrate the incompatibility between transparency of content and a Millian externalism. However, he later claims that another type of example (as set out by Loar) shows that the transparency of content contradicts any version of externalism. It this later case his argument is somewhat obscure and he seems to presuppose—without justification, in my view—that the scope of the internal factors that can be invoked by the non-Millian externalist is very limited. Whatever the case, if his argument were correct and there were no such internal factors, then neither would they be available to the internalist; that is, if the Different-Internally-and-Externallydetermined-Meaning option is not open to the externalist, then neither is the Different-Internally-determined-Meaning option open to the internalist.<sup>17</sup> 

In short, if the internalist Different-Internally-determined-Meaning option is not to be ruled out, then non-Millian externalism is in at least as good a position as that internalist theory when it comes to resolving 

> 16 Cf. Boghossian (1992a, pp. 36–37). 

> 17 The intervention of such internal factors does not commit the externalist to any notion of narrow content, because it does not in itself imply that they are sufficient for constituting anything that can be genuinely characterized as content.

<!-- page: pdf=0021 printed=179 -->

Boghossian’s problem, and also to upholding APLA. It is enough for such an externalist to appeal to those internal factors (to defend Different-Internally-and-Externally-determined-Meaning) and thus reap the benefits of Different-Internally-determined-Meaning. Such an externalist position is actually preferable given the last problem mentioned above in relation to Different-Internally-determined-Meaning, which also affects the other internalist options. As far as the Millian externalists are concerned, they can always invoke one of the other externalist solutions proposed in the literature, including the options that I consider most promising: the Anaphorically-based Externalist solution and the Logical Luck-based solution, mentioned in Section 2 above (the first of which also upholds APLA). 

### Conclusions 

Boghossian describes a case, involving the use of singular terms such as ‘Pavarotti’, from which he argues against externalism. He accuses externalism of being incompatible with the fact that we can know through introspection whether an inference is logically valid or not. Careful examination of the question reveals that an internalist would also have difficulties overcoming the problem described by Boghossian. 

We have examined several possible solutions that externalists and internalists could offer. Among the externalist explanations that different authors have proposed, I mentioned—initially—the Anaphorically-based Externalist solution and the Logical Luck-based solution, and I also detailed possible objections to them and possible responses to these objections (sec. 2). I then went on (secs. 3 and 4) to described five internalist explanations that postulate identity of meaning in the two occurrences of ‘Pavarotti’ in Peter’s inference: Same-Meaning ⁄ Same-Unified-Reference, Same-Meaning ⁄ Same-Disjunctive-Reference, Same-Indexical-Meaning ⁄ Different-Reference, Same-Context-ImprintingIndexical-Meaning ⁄ Same-Reference and Same-Indexical-Meaning ⁄ SameAnaphorically-based-Reference. Perhaps the least counterintuitive of these five internalist options is the last one. However, this Same-Indexical-Meaning ⁄ Same-Anaphorically-based-Reference option would face at least as many problems as the Anaphorically-based Externalist solution. Later (sec. 5) I set out another possible internalist option which postulates a difference in meaning between the two occurrences of ‘Pavarotti’: Different-Internally-determined-Meaning. However, if the Different-Internally-determined-Meaning option were feasible, then the non-Millian externalist option, Different-Internally-and-Externallydetermined-Meaning, would be at least as feasible as Different-Internally-determined-Meaning (sec. 6).

<!-- page: pdf=0022 printed=180 -->

Considering the different pre-theoretical intuitions that each alternative supports or undermines overall, I believe that Boghossian’s example is more problematic for internalism than it is for externalism. In short, the minimal thesis that I have defended (against Boghossian and even against some externalists) is that no specifically externalist assumption is responsible for the problem. I also maintain, however, a stronger thesis: ultimately the argument favours the externalist position, which is shown to be in a better position to provide an explanation of the case put forward by Boghossian. 

As we have studied the different options, I have pointed out several times (to support my stronger thesis) that, to a large extent, it is the common, externalist intuitions (that were invoked by Putnam and Burge in their original thought experiments) that tip the balance in favour of externalism. It would therefore seem that the present argument does not bring anything new to the debate between externalism and internalism. However, I propose, hypothetically, that the strong thesis is explained—in part—by the fact that our externalist intuitions are particularly prominent in the case of singular terms. Through constructing his example around a singular term, Boghossian, in spite of himself, has opened the door to new evidence against content internalism. 

### References 

Boghossian, P. A. 1989: ‘‘Content and Self-Knowledge’’. Philosophical Topics, 17, 5–26. 

- —— 1992a: ‘‘Externalism and Inference’’. Philosophical Issues, vol. 2, Rationality in Epistemology, 11–28. 

- —— 1992b: ‘‘Reply to Schiffer’’. Philosophical Issues, vol. 2, Rationality in Epistemology, 39–42. 

- —— 1994: ‘‘The Transparency of Mental Content’’. Philosophical Perspectives, vol. 8, Logic and Language, 33–50. 

- Brown, J. 2004: Anti-individualism and Knowledge. Cambridge: MIT Press. 

- Burge, T. 1979: ‘‘Individualism and the Mental’’. Midwest Studies in Philosophy, 4, 73–121. 

- —— 1988: ‘‘Individualism and Self-Knowledge’’. Journal of Philosophy, 85, 649–663. 

- —— 1998: ‘‘Memory and Self-Knowledge’’. In P. Ludlow and N. Martin (eds.), Externalism and Self-Knowledge. Stanford: CSLI Publications. 

Campbell, J. 1987: ‘‘Is Sense Transparent?’’. Proceedings of the Aristotelian Society, 88, 273–292.

<!-- page: pdf=0023 printed=181 -->

- Davidson, D. 1987: ‘‘Knowing One’s Own Mind’’, Proceedings and Addresses of the American Philosophical Association, 60, 441–458. 

- Faria, Paulo 2009: ‘‘Unsafe Reasoning: a Survey’’. Dois Pontos, 6, 185– 201. 

- Garmendia, E. 2010: Auto-conocimiento, memoria y racionalidad. (Estudio de tres argumentos antiexternistas). Doctoral Dissertation presented at the University of Barcelona. 

- Goldberg, S. C. 1999: ‘‘The Relevance of Discriminatory Knowledge of Content’’, Pacific Philosophical Quarterly, 80, 136–156. 

- Kripke, S. 1979: ‘‘A Puzzle About Belief’’. In A. Margalit (ed.), Meaning and Use. Dordrecht: Reidel. 

- McKinsey, M. 1991: ‘‘Anti-Individualism and Privileged Access’’. Analysis, 51, 9–16. 

- Nagel, T. 1976: ‘‘Moral Luck’’. Proceedings of the Aristotelian Society, supplementary volume 50. 

- Pe´ rez Otero, M. (2004): ‘‘Las consecuencias existenciales del externismo’’, Ana´lisis Filoso´fico, 24, 29–58. 

- —— (2009): ‘‘Conocimiento, discriminabilidad y acceso al contenido representacional’’, in J. Alcolea, V. Iranzo, A. Sa´ nchez and J. Valor (eds.), Actas del VI Congreso de la Sociedad de Lo´gica, Metodologı´a y Filosofı´a de la Ciencia en Espan˜a, Valencia, Universitat de Vale` ncia, 227–231. 

- —— (2010): ‘‘El debate entre externistas e internistas sobre la racionalidad inferencial’’, Ana´lisis Filoso´fico, 30, 163–186. 

- Putnam, H. 1973: ‘‘Meaning and Reference’’. Journal of Philosophy, 70, 699–711. 

- —— 1975: ‘‘The Meaning of ‘Meaning’’’. in H. Putnam, Mind, Language and Reality. Cambridge: University Press. 

- Schiffer, S. 1992: ‘‘Boghossian on Externalism and Inference’’. Philosophical Issues, vol. 2, Rationality in Epistemology, 29–38. 

- Sorensen, R. A. 1998: ‘‘Logical Luck’’. Philosophical Quarterly, 48, 319–334. 

- Williams, B. 1976: ‘‘Moral Luck’’. Proceedings of the Aristotelian Society, supplementary volume 50. 

- Williamson, T. 2000: Knowledge and its Limits. Oxford: Oxford University Press.
