---
title: Goldberg 2007 - Anti-Individualism, Content Preservation, and Discursive Justification
authors:
- Sanford C. Goldberg
year: '2007'
type: summary
publisher: Goldberg, S. C. (2007). Anti-individualism, content preservation, and discursive justification. Noûs. [Volume, issue, and page range unavailable in the source artifact.]
source_pdf: '[[raw_sources/Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification-Nous.pdf]]'
converted_markdown: '[[converted_markdown/Goldberg-2007-Anti-Individualism-Content-Preservation-Discursive-Justification]]'
aliases:
- Anti-Individualism, Content Preservation, and Discursive Justification
- Goldberg 2007
---
# Goldberg 2007 - Anti-Individualism, Content Preservation, and Discursive Justification

**Raw source:** [[raw_sources/Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification-Nous.pdf|PDF]] · **Converted Markdown:** [[converted_markdown/Goldberg-2007-Anti-Individualism-Content-Preservation-Discursive-Justification|Converted Markdown]]

## Abstract

Most explorations of the epistemic implications of Semantic AntiIndividualism (SAI) focus on issues of self-knowledge (first-person authority) and/or external-world skepticism. Less explored has been SAI’s implications for the epistemology of reasoning. In this paper I argue that SAI has some nontrivial implications on this score. I bring these out by reflecting on a problem first raised by Boghossian (1992). Whereas Boghossian’s main interest was in establishing the incompatibility of SAI and “the _a priority_ of logical abilities” (Boghossian 1992: 22), I argue that Boghossian’s argument is better interpreted as pointing to SAI’s implications for the nature of discursive justification.
Source: PDF p. 1.

## Main Summary

### 1. Introduction to the Basic Dialectic

Goldberg defines semantic anti-individualism (SAI) as the view that the mental natures of many states and events depend for their individuation on the subject’s social and physical environments. Rather than revisit the familiar questions of privileged self-knowledge and external-world skepticism, he asks what SAI implies about _discursive justification_: the justification that a belief acquires through inference. This matters independently because a subject’s knowledge of what she thinks must be integrated with the rest of her epistemic perspective. It also matters to any broader theory that grounds justification in actual or possible reasoning, since on that auxiliary assumption revisionary consequences for inferential justification become consequences for justification generally. Source: PDF pp. 1–2.

The paper begins from Boghossian’s claim that SAI conflicts with the _a priority_ of logical abilities. Schiffer and Burge answer that ordinary extended reasoning is governed by an intention to reuse non-indexical terms univocally, creating anaphoric, reference-preserving links that secure deductive validity. Goldberg accepts that this answer blocks Boghossian’s incompatibility claim, but argues that it imposes a cost: the reasoner secures validity by allowing at least one recalled premise to shift its content, thereby risking falsity, unsoundness, and a loss of justificatory strength. The central question therefore becomes not whether SAI destroys logical competence, but how content preservation in memory supports the justification of beliefs reached through reasoning. Source: PDF pp. 2–3.

### 2. Boghossian 1992 and the Schiffer/Burge Reply

Boghossian’s Peter first encounters Earth-Pavarotti swimming in Lake Taupo, later moves to Twin Earth, and comes to use “Pavarotti” for Twin-Pavarotti. Peter then reasons from the true claims that Pavarotti once swam in Lake Taupo and that the singer he heard yesterday was Pavarotti to the false conclusion that yesterday’s singer once swam in Lake Taupo. The two occurrences in the premises have different referents, but the equivocation is not detectable by introspection. Boghossian infers that, if SAI is true, Peter cannot determine _a priori_ whether his own apparent inference is formally valid. Source: PDF pp. 3–4.

Schiffer and Burge reply that a reasoner can intend all tokens of a non-indexical expression within a single extended inference to have the same semantic value. If this univocality intention succeeds, Peter’s reasoning contains anaphoric reference-preserving links and avoids the equivocation. Goldberg asks whether SAI itself could prevent such an intention from succeeding. He formulates a content-fixity principle (CF): a recalled belief expressed by the same non-indexical sentence must retain its original content. CF would force the two recalled “Pavarotti” beliefs to keep their distinct original contents and would therefore undermine Peter’s univocality intention. But SAI is not committed to CF. Burge’s claim that memory _can_ preserve content is not a claim that it invariably must, and the content-shift accounts of Ludlow and Gibbons provide coherent anti-individualist alternatives. Hence SAI permits reasoners to impose univocity during reasoning, and the Schiffer/Burge possibility suffices to defeat the alleged incompatibility between SAI and _a priori_ logical ability. Source: PDF pp. 4–6.

### 3. Semantic and Epistemic Implications of the Schiffer/Burge Reply

The reply secures validity only by changing the semantics of at least one recalled premise. Goldberg models the Peter case at three times. At _t_1 Peter’s Earth experience grounds a true and justified belief concerning Earth-Pavarotti; at _t_2 his Twin-Earth experience grounds a true and justified belief concerning Twin-Pavarotti; at _t_3 he draws a conclusion from the recalled premises. On Boghossian’s originary-content description, the premises remain true but the inference equivocates and the conclusion is false. On the Schiffer/Burge description, the occurrences at _t_3 are made univocal, so at least one occurrence differs in content from the belief originally acquired. Assuming for illustration that the first premise shifts, the remembered proposition becomes the false claim that Twin-Pavarotti swam in Lake Taupo. Peter’s argument is then valid but unsound. Source: PDF pp. 6–9.

This semantic shift also changes the premise’s epistemic support. Goldberg understands a belief as justified when its grounds objectively count toward the truth of its content. Peter’s original perceptual grounds—seeing Earth-Pavarotti swimming—support the original Earth-Pavarotti proposition, but do not support the shifted Twin-Pavarotti proposition in the same way. The shifted belief may therefore lose its justification altogether. Even if one grants that the original perceptual appearance provides some support for the shifted proposition because Earth-Pavarotti looked like Twin-Pavarotti, the support is weaker. A fact-caused belief produced through a reliable mechanism excludes more error possibilities than a belief grounded merely in an appearance compatible with nearby worlds where the proposition is false. Thus content shift removes the strong externalist support the original belief possessed, even if it leaves weaker appearance-based support. Source: PDF pp. 9–10.

The striking result is that Peter’s justificatory strength can decline although memory preserves his original grounds, he acquires no new counterevidence, his memory functions properly, and he reasonably takes himself to be recalling the same belief. Memory’s success at preserving univocity through the inference is therefore accompanied by its failure to preserve the original degree of justification. That failure affects the discursive justification of the conclusion drawn from the recalled premises. Source: PDF pp. 10–11.

### 4. SAI and the Epistemology of Discursive Justification

Goldberg distinguishes two reasoning-supporting roles of content-preserving memory. _Originary content preservation_ retains the content of a belief as it was first acquired. _Univocality-ensuring content preservation_ holds a term’s content fixed across the premises and conclusion of one extended inference. These roles ordinarily coincide but separate in Peter’s case. If memory plays the first role, Peter retains the strong justification of his original premises but equivocates; if it plays the second, Peter reasons validly but at least one premise shifts content and loses some or all of its original justification. Source: PDF pp. 11–12.

These roles correspond to two pretheoretically natural principles. (I1) says that, absent present cognitive malfunction, the conclusion of an apparently valid inference has at least the degree of justification of the conjunction of its premises at the time of reasoning. It expresses the justification-preserving character of valid deduction: grounds supporting justified premises support every proposition they entail. (I2) says that, absent cognitive malfunction and new relevant evidence, the justification of the premise conjunction at the time of reasoning is determined exclusively by the degrees of justification the individual premises possessed when acquired. It expresses the ordinary dependence of reasoning on memory: finite agents need not recall every original ground in order for properly sustained beliefs to retain their justificatory strength. Denying this preservation would invite broad skepticism about memory-supported justified belief. Source: PDF pp. 12–16.

SAI makes it impossible for both principles to govern every case in the reflectively accessible way the natural picture assumes. Under Boghossian’s originary-content description, the premises retain their strong support but the inference equivocates, so the conclusion can be false and less justified than the premise conjunction: (I1) fails without Peter being able to detect the failure. Under the Schiffer/Burge univocality description, the inference is valid and (I1) holds, but content shift weakens a premise relative to its original justification, so (I2) fails without Peter being able to detect that failure. Treating the loss of originary content as a cognitive malfunction is implausible because Peter’s system is choosing between incompatible cognitive aims rather than malfunctioning. Treating Twin-Earth experience as new relevant evidence concedes a closely related point: Peter cannot discern how evidence he has fully in mind bears on his other beliefs. Source: PDF pp. 16–18.

(I1) and (I2) ordinarily license a subject to align confidence in a deductive conclusion with confidence in the conjunction of the premises. The Peter case shows that reflection is not a sound general method for determining when that entitlement obtains. Even a logically competent subject free from cognitive malfunction may judge that both principles hold when one does not. Such counterpossibilities can become epistemically live not only for proper names but also for ordinary expressions with multiple lexical entries, such as “pragmatist.” Goldberg does not conclude that deductive justification disappears. His narrower claim is that it lacks a natural internalist feature: there is no sound and complete reflective procedure that always enables a subject to compute the justified confidence of a conclusion from the remembered justificatory strengths of its premises. Source: PDF pp. 18–20.

### 5. Conclusion

Whichever content-preserving role memory plays in a Peter-style case, at least one of (I1) and (I2) fails without the subject being able to recognize the failure by reflection. The subject therefore cannot always determine the justification of her reasoning-based belief as a function of the premises’ original justification, nor can she always know whether matching confidence in the conclusion to confidence in those premises violates the demand to proportion confidence to evidence. Goldberg presents this as a revisionary implication to be acknowledged by proponents of SAI, not as a refutation of SAI. The larger methodological lesson is that inquiry into anti-individualism’s epistemic consequences should extend beyond self-knowledge and skepticism to the relations among self-knowledge, memory, reasoning, and justified belief. Source: PDF pp. 20–21.

## Relevant Literature

- [Boghossian 1992, “Externalism and Inference”]
  Why relevant: Goldberg takes Boghossian’s Peter case and incompatibility argument as the paper’s central dialectical starting point. Source: PDF pp. 3–4.
- [Schiffer 1992, “Boghossian on Externalism and Inference”]
  Why relevant: Schiffer’s univocality reply helps show how SAI can coexist with _a priori_ logical ability while generating the epistemic costs Goldberg develops. Source: PDF pp. 4–6.
- [Burge 1996, “Memory and Self-Knowledge”]
  Why relevant: Burge’s account of anaphoric, reference-preserving links supplies the other principal version of the reply to Boghossian. Source: PDF pp. 4–6.
- [Burge 1993, “Content Preservation”]
  Why relevant: Goldberg draws on Burge’s account of memory’s capacity to preserve content and justification while denying that SAI requires invariant originary preservation. Source: PDF pp. 6, 13.
- [Ludlow 1995, “Social Externalism, Self-Knowledge, and Memory”]
  Why relevant: Ludlow’s content-shift treatment of memory is used to show that SAI is not committed to content-fixity and is exposed to Goldberg’s epistemic-cost argument. Source: PDF pp. 6, 23.
- [Gibbons 1996, “Externalism and Knowledge of Content”]
  Why relevant: Gibbons’s content-shift proposal plays the same role as Ludlow’s in Goldberg’s rejection of mandatory content-fixity and extension of the justificatory critique. Source: PDF pp. 6, 23.
  Summary link: [[4.Wiki/individual summaries/Gibbons 1996 - Externalism and Knowledge of Content]]
  Raw link: [[2.Raw/papers/Gibbons-1996-Externalism and Knowledge of Content-Philosophical Review.pdf]]

## Concepts

- [[Content Externalism]] (`S-01`; endorses [[Pure Wide Realist Content Externalism]] `P-116`; PDF p. 1)
- [[Content-Preserving Memory and Slow-Switching Dynamics]] (`C-05`; separates [[Two-Concept Originary Fixation Memory Definition]] `D-21` from [[Anaphoric Univocality-Preserving Memory Definition]] `D-22`; PDF pp. 4–12)
- [[A Priori Logical Abilities]] (`C-02`; discusses [[Token-Level Wide APLA Definition]] `D-09`; PDF pp. 1–6)
- **Discursive Justification** *(single-source, PDF pp. 1–2)*: `Discursive Justification` is the epistemic justification a thinker acquires or sustains for a conclusion belief through multi-step deductive reasoning over time, integrating both the memorial preservation of previously justified premises and the deductive transition from those premises to the conclusion.
  - **Reflectively Computable Discursive Justification Definition** *(single-source, rejects, PDF pp. 18–21)*: Discursive justification denotes inferential justification whose obtaining is fully computable from the thinker's reflective armchair perspective.
  - **Non-Reflective Externalist Discursive Justification Definition** *(single-source, endorses, PDF pp. 19–21)*: Discursive justification denotes inferential justification that depends on externalist content preservation and cognitive reliability rather than reflective computability.

## Propositions

- [[Content Externalism Holds]] (`P-40`) — endorses (PDF pp. 1–2, 20–21)
- [[Boghossian Peter Slow-Switching Setup Possibility]] (`P-46`) — endorses (PDF pp. 3–4, 6–9)
- [[Univocality of Referential Intent Secures Deductive Validity]] (`P-56`) — conditional (PDF pp. 4–6)
- [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`) — conditional (PDF pp. 4–10, 16–18)
- **Principle I1 Reflective Deductive Justification Preservation** *(single-source, discusses, PDF pp. 12–17)*: Every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion.
- **Principle I2 Memorial Justification Preservation** *(single-source, discusses, PDF pp. 12–18)*: Every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning.
- **Discursive Justification Is Reflectively Computable** *(single-source, rejects, PDF pp. 18–21)*: Every thinker can determine from reflection alone whether a diachronic deductive inference yields discursive justification.
- **Bridge - Content-Preservation Dilemma Defeats I1 or I2** *(single-source, endorses, PDF pp. 11–19)*: If both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then either it is not the case that every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion or it is not the case that every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning, inclusively.
- **Bridge - Reflective Computability Requires I1 and I2** *(single-source, endorses, PDF pp. 12–21)*: If every thinker can determine from reflection alone whether a diachronic deductive inference yields discursive justification, then both (every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion) and (every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning).

## Arguments

- [[Slow-Switching Equivocation Derivation]] (`ARG-01`) — discusses as blocked by `ARG-06` (PDF pp. 4–6)
- [[Schiffer Univocal Intent Blocks Slow-Switch Equivocation]] (`ARG-06`) — concedes against `ARG-01` (PDF pp. 4–6)

### Discursive Justification Horn Inconsistency (I1 vs. I2) *(§§3–4, PDF pp. 11–19)*

1. Some mental states have contents that constitutively depend on external environmental factors.
2. Possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise.
3. If both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then either it is not the case that every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion or it is not the case that every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning, inclusively.
4. Both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise).
5. Either it is not the case that every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion or it is not the case that every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning, inclusively.
6. Therefore, it is not the case that both (every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion) and (every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning).

### Content-Preservation Dilemma Against Reflective Discursive Justification *(§§4–5, PDF pp. 11–21)*

1. Some mental states have contents that constitutively depend on external environmental factors.
2. Possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise.
3. If both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then either it is not the case that every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion or it is not the case that every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning, inclusively.
4. If every thinker can determine from reflection alone whether a diachronic deductive inference yields discursive justification, then both (every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion) and (every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning).
5. Both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise).
6. Either it is not the case that every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion or it is not the case that every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning, inclusively.
7. It is not the case that both (every reflectively valid deductive inference without cognitive malfunction preserves premise-conjunction justification to its conclusion) and (every content-preserving memory without cognitive malfunction or new relevant evidence preserves original premise justification into later reasoning).
8. Therefore, it is not the case that every thinker can determine from reflection alone whether a diachronic deductive inference yields discursive justification.

## Assessment
