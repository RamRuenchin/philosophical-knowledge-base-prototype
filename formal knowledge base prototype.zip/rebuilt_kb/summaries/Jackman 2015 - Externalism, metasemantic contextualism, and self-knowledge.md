---
title: Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge
authors:
- Henry Jackman
year: '2015'
type: summary
publisher: 'Jackman, H. (2015). Externalism, metasemantic contextualism, and self-knowledge. In S. Goldberg (Ed.), Externalism, Self-Knowledge, and Skepticism: New Essays (pp. 228–247). Cambridge University Press.'
source_pdf: '[[raw_sources/Jackman-2015-Externalism Metasemantic Contextualism and Self-Knowledge-Externalism Self-Knowledge and Skepticism.pdf]]'
converted_markdown: '[[converted_markdown/Jackman-2015-Externalism Metasemantic Contextualism and Self-Knowledge-Externalism Self-Knowledge and Skepticism]]'
aliases:
- Externalism, metasemantic contextualism, and self-knowledge
- Jackman 2015
---
# Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge

**Raw source:** [[raw_sources/Jackman-2015-Externalism Metasemantic Contextualism and Self-Knowledge-Externalism Self-Knowledge and Skepticism.pdf|PDF]] · **Converted Markdown:** [[converted_markdown/Jackman-2015-Externalism Metasemantic Contextualism and Self-Knowledge-Externalism Self-Knowledge and Skepticism|Converted Markdown]]

## Abstract

The chapter has no standalone author-provided abstract. Examining the interactions among semantic holism, contextualism, and semantic externalism, Henry Jackman argues that an externalist metasemantics grounded in plausible assumptions about self-knowledge as speaker authority—captured by the Self-Interpretation Principle—is also a contextualist metasemantics. Because the relative weight or entrenchment of a speaker's commitments shifts across conversational contexts, the semantic value of a speaker's terms can vary from context to context. This metasemantic contextualism explains conflicting intuitions about standard externalist cases (such as Burge's "arthritis" and Putnam's Twin Earth "water") without positing systematic lexical ambiguity, accounts for reference shifts in proper-name and slow-switching memory cases (Donnellan vs. Evans, pluralist vs. monist views of memory content), and resolves Boghossian's externalism-and-inference puzzle by showing that because a single argument occupies a single interpretive context, slow-switching subjects do not commit introspectively undetectable fallacies of equivocation, thereby preserving the transparency of thought.
Source: pp. 228–247.

## Main Summary

### Introduction

Jackman examines how semantic holism, contextualism, and externalism interact, arguing for two main claims: first, an externalist metasemantics grounded in plausible assumptions about self-knowledge entails a contextualist metasemantics; second, this metasemantic contextualism resolves a prominent externalist problem concerning self-knowledge—namely, that switching cases appear to undermine the transparency of thought (our ability to tell a priori whether two occurrent thoughts exercise the same or different concepts). Source: p. 228.

### Metasematics, self-interpretation, and contextualism

Jackman distinguishes a *semantic theory*—which specifies the semantic values of expressions and how complex expressions depend compositionally on their parts—from a *metasemantic theory*—which explains how words acquire those semantic values (variously termed descriptive vs. foundational, formal vs. philosophical, or linguistic vs. metaphysical semantics by Stalnaker, Brandom, Speaks, Block, Davies, and Glüer). In a broadly Davidsonian framework, an atomistic truth-theoretic semantics assigns satisfaction conditions to terms (e.g., "Chicago" is satisfied by Chicago, "city" by cities), whereas Davidson's metasemantics (radical interpretation) is holistic: each term's satisfaction conditions depend on how other terms get theirs, determined by the assignment that maximizes the truth of the speaker's commitments under the Principle of Charity. Source: pp. 228–229.

Because Davidson's appeal to Charity explains why beliefs must be mostly true without explaining why interpretation must *maximize* truth between competing interpretations that both leave the speaker mostly right, Jackman grounds truth maximization in the *Self-Interpretation Principle*: when an agent has conflicting commitments, semantic values should be assigned so as to preserve the truth of the commitments the agent would retain if aware of the tension. For example, if a speaker believes both (1) that he has "arthritis" in his thigh and (2) that doctors study how to treat "arthritis" in medical school, whether his "arthritis" utterances refer to arthritis or *tharthritis* (covering both arthritis and similar extra-articular pains) depends on which belief he would treat as mistaken upon learning of the conflict—where treating a belief as mistaken is more substantial than merely adopting community usage (as a British expat might stop calling cookies "biscuits" without judging earlier utterances false). The Self-Interpretation Principle thus motivates Charity via first-person authority: capturing the agent's point of view requires maximizing a *weighted* total of truths, where commitment weights reflect comparative importance revealed in belief revision under manifest conflict (subject to idealization regarding unrecognized incompatibilities). Source: pp. 229–230.

A holistic metasemantics drawing on the Self-Interpretation Principle leaves meaning relatively stable and accommodates semantic externalism, while also underwriting *metasemantic contextualism*. Unlike *semantic contextualism*—which builds context into a term's semantic value or logical form via indexicals or hidden parameters (e.g., "tall for an $f$", as in Stanley)—metasemantic contextualism holds that terms can receive different invariant semantic values across contexts because the weight a speaker gives particular beliefs varies with context (akin to Ludlow's "cheap" contextualism and dynamic lexicon, and distinct from Bilgrami's reference-eschewing split between aggregate contents and contextually salient local belief subsets). Source: pp. 230–231, 233.

Two examples illustrate this shift. First, suppose 7-year-old Frank is adopted, and a speaker (unacquainted with either mother and regardless of knowing about the adoption) says: (1) "The principal should call Frank's mother" (after Frank vandalizes the school), and (2) "Frank probably gets those freckles from his mother." The extension of "mother" shifts between (1) and (2) not because the speaker gained or lost "mother" beliefs, but because disciplinary interests weight the belief that a mother brings up the child more heavily, whereas genetic interests weight the belief that a mother contributes genetic material more heavily. Explaining this via lexical ambiguity fails when a sheltered speaker is unaware that rearing and biological motherhood ever diverge, and proliferating pre-existing lexicon entries for birth, genetic, egg-donor, surrogate, adoptive, and step-mothers is implausible. Second, consider an ancient speaker whose putative extension for "Venus" is solely the planet Venus (pointed to morning and evening), but whose general characterization describes Venus as the goddess of love, wife of Vulcan, lover of Mars, and responder to prayers. Three profiles are possible: a devout worshiper who looks at the sky only to view the goddess would give up the putative extension upon learning the light is a lifeless planet (referring to the goddess, with apparent truths like "Venus is bright tonight" explained via speaker's reference vs. semantic reference); a practical navigator would abandon the goddess myths and refer exclusively to the planet; and an intermediate speaker—likely the largest group—weights goddess beliefs more heavily in religious contexts and navigation beliefs more heavily in others, so that the reference of "Venus" (and similarly "Moses" across historical vs. miraculous interests, echoing Wittgenstein) shifts across contexts. Source: pp. 231–233.

### Metasemantic contextualism, ambiguity, and externalist intuitions

Debates over semantic externalism turn on intuitions about thought experiments, yet philosophers disagree, and experimental studies (Weinberg, Nichols, and Stich; Machery et al.) find wide variation in nonphilosophical intuitions. Under metasemantic contextualism, seemingly conflicting intuitions are simply judgments about different contexts that appear incompatible only when treated as context-free claims about reference. Source: pp. 233–234.

In Burge's case of Bert, who applies "arthritis" to pains in his thigh, Burge holds that Bert refers to arthritis, while Davidson and Bilgrami argue he refers to tharthritis (Davidson later allowed reference to arthritis only given an explicit intention to defer to experts, which Burge rejects). Alongside beliefs true of both conditions, Bert has beliefs true only of tharthritis ("I have arthritis in my thigh," "My arthritis kept me from cleaning the garage") and beliefs true only of arthritis ("Doctors have studied how to treat arthritis," "The insurance man said people with arthritis should see a doctor"). When Bert complains to his brother about not mowing the lawn, the first set carries greater weight and he refers to tharthritis; when he consults his doctor, the second set dominates and he refers to arthritis. Burge focuses on clinical contexts while Davidson and Bilgrami focus on casual contexts, each overgeneralizing from a context-friendly case; moreover, underdescribed cases invite readers to project their own deferential or individualistic weightings onto Bert. Still, Jackman notes (fn. 19) that metasemantic contextualism sides with Burge on anti-individualism: referring to arthritis in *some* cases suffices to refute individualism, and even when Bert expresses an idiosyncratic concept in casual conversation, community usage still constrains which broader concept (e.g., *barthritis*, excluding lower-spine pain in a society with that usage) is attributed to him. Source: pp. 234–235.

Similarly, for Putnam's Twin Earth "water," speakers hold both functional-kind and natural-kind commitments that conflict when a substance shares water's perceptual/functional properties but has a different chemical structure. Putnam himself defined the cross-world relation $same_L$ via shared "important physical properties" (1975, p. 232) while stressing that importance is "an interest relative notion" (p. 239). Where functional properties matter more than microstructure, "water" picks out a functional kind; and in philosophical discussions where neither commitment is strongly preferred, speakers may accommodate their interlocutors (as in Lewis). Jackman contrasts this view with the ambiguity theory of Shaun Nichols, Ángel Pinillos, and Ron Mallon (2014), who argue that natural kind terms are ambiguous between causal-historical and descriptivist conventions, violating the constraint that a single theory of reference applies to a class of terms. Metasemantic contextualism preserves a *univocal* reference-fixing function (varying only the input weights), explains neutral reactions when incompatible commitments are equally weighted, and accounts for contextual shifts where *both* candidate meanings are causal. Source: pp. 235–238.

### ‘Switching’ cases

Contextual shifts that cannot be explained by causal-versus-descriptive ambiguity arise when the causal source of information associated with a term switches. Source: p. 238.

#### Donnellan and Evans on proper names

Evans and Donnellan disagree about proper names whose causal source of information changes over time. In Evans's "Napoleon" case—where Alpha is the source of pre-1814 information (the Senate, invading Russia) andBeta replaces him as the source of post-1814 information (Waterloo, Saint Helena)—Evans argues that a speaker refers invariantly across contexts to the *dominant* source of the total associated body of information. Evans takes Donnellan (1970) to defend *source-dependent contextualism*: the view that a name token refers to whichever bearer was the causal source of the specific belief that is the topic of that claim (making "Napoleon fought skillfully at Waterloo" refer to Beta and "...unlike his performance in the Senate" refer to Alpha). Source: pp. 238–239.

Jackman argues that Evans misreads Donnellan, whose actual claims fit metasemantic contextualism (as Stalnaker also notes). In Donnellan's J. L. Aston-Martin case, a student who has read the famous philosopher Aston-Martin's papers ("Other Bodies") spends an hour at a party talking to a man he mistakes for Aston-Martin. Donnellan holds that if the student tells his seminar the next day, "Last night I met J. L. Aston-Martin," his claim is *false* because the name refers to the philosopher; whereas if he tells friends about amusing party events ("Robinson tripped over Aston-Martin's feet"), it refers to the man at the party. On source-dependent contextualism, *both* utterances would refer to the party-goer. Instead, Donnellan ties reference to the *point* of the remark: in seminar the point is claiming acquaintance with a famous philosopher, weighting the philosophical dossier more heavily; among friends the point is what happened at the party, weighting the party encounter more heavily. Even if the student befriends the party-goer for years so that the friend typically dominates, boasting of knowing a famous man still shifts reference to the philosopher. Because both interpretations are causal (the philosopher remains the referent even if he stole credit for "Other Bodies," just as in Kripke's Gödel case, unless a dissertation writer cares only about the author of the text), this shift cannot be causal-versus-descriptive ambiguity. Source: pp. 239–241.

#### Memory content

Jackman applies this framework to slow-switching thought and memory cases (Burge, Boghossian, Parent). Suppose John is transported at age 12 from Earth ($\text{H}_2\text{O}$) to Twin Earth ($\text{XYZ}$, or *twater*) for forty years without noticing (or moves from Britain to the US without noticing "robin" picks out different birds). Externalists agree that by age 52 John's ordinary "water" utterances refer to twater, but divide over whether he retains his water concept alongside his new twater concept—the *pluralistic* or *conceptual addition* view (Boghossian, Burge, Gibbons, Heal)—or had his water concept replaced by the twater concept—the *monistic* or *conceptual replacement* view (Bernecker, Brueckner, Ludlow, Tye). When 52-year-old John thinks, "I remember swimming in Lake Ontario when I was 11 and thinking 'this water was freezing!'", monists hold that "water" refers to twater (so John misremembers his earlier thought), while pluralists hold that he applies his original water concept, making the memory true. Source: pp. 241–242.

Metasemantic contextualism is broadly pluralistic—agreeing with Heal that the switch is never completely total because water commitments do not vanish—while allowing that the monist is often right about particular memories. If 52-year-old John is simply reminiscing about his youth, his commitment to having experienced that freezing liquid is heavily weighted and his later twater beliefs are irrelevant, so "water" refers to water ($\text{H}_2\text{O}$). If instead the memory arises while debating whether to vacation with his family at a cold Great Lake north of them on Twin Earth, his current-environment commitments ("there is a Great Lake full of water north of me," "my children complain when swimming in cold water") dominate, so "water" refers to twater (or, in contexts like "Ever since I was 7, I've splashed cold water on my face every morning," to a functional kind covering both $\text{H}_2\text{O}$ and $\text{XYZ}$). This answers Bernecker's objection that pluralism lacks a *mechanism* determining which content appears in which context: the Self-Interpretation Principle provides a mechanism grounded in self-knowledge that metasemantically explains Goldberg's (2005) conditions for defeating the "Current Face Value Presumption," while avoiding source-dependent contextualism. Source: pp. 242–243.

### Externalism and inference

Metasemantic contextualism also answers Boghossian's (1992a, 2011) objection that externalism (under conceptual addition) undermines the a priori status of our logical abilities and the *transparency* of thought (that thinkers can know a priori whether two token thoughts have the same or distinct contents). In Boghossian's case, Earth opera fan Peter meets Luciano Pavarotti swimming in Lake Taupo; years after being unknowingly switched to Twin Earth, Peter hears Twin Pavarotti sing and reasons: (1) Pavarotti once swam in Lake Taupo; (2) The singer I heard yesterday is Pavarotti; (3) Therefore, the singer I heard yesterday once swam in Lake Taupo. Boghossian claims that "Pavarotti" refers to Earth's Pavarotti in (1) and Twin Pavarotti in (2), producing an introspectively undetectable fallacy of equivocation from true premises to a false conclusion. Source: pp. 244–245.

Jackman replies that Boghossian's argument presupposes *source-dependent contextualism* (Boghossian 1992b ties each memory belief's content strictly to its originating environment) and ignores that an introspectively surveyable argument occurs within a *single context*. Although Peter might utter (1) in isolation when reminiscing (referring to Pavarotti) and (2) in isolation when discussing recent concerts (referring to Twin Pavarotti), incorporating (1) and (2) into a single argument requires interpreting both within a single context and a single weighting of Peter's "Pavarotti" commitments (echoing Schiffer's point that the premises compress into "Pavarotti once swam in Lake Taupo, and is the singer I heard yesterday," while avoiding Stalnaker's reliance on the attributer's context). Thus "Pavarotti" receives a single semantic value across both premises—making the argument valid with one false premise rather than an equivocation from true premises. Moreover, unlike the quasi-anaphoric view Boghossian, Brown, Bernecker, and Goldberg discuss (attributed to Burge 1998 and Schiffer 1992), where the first occurrence fixes subsequent occurrences and makes the argument's subject depend implausibly on premise order, metasemantic contextualism assigns a single value across the argument independently of premise ordering. Source: pp. 245–247.

### Conclusion

Jackman concludes that metasemantic contextualism grounded in the Self-Interpretation Principle resolves externalist debates by showing that questions like "What does Bert mean by 'arthritis'?" or "What is the content of John's 'water' memories?" have context-dependent answers. Moreover, a metasemantics motivated by self-knowledge as speaker *authority* (where speakers' own judgments resolve conflicts among their commitments) in turn defends self-knowledge as *transparency* against externalist switching objections. Source: p. 247.

## Relevant Literature

- [Bernecker 2010, Memory: A Philosophical Study]
  Why relevant: Defends the monistic (conceptual replacement) view of slow switching and criticizes pluralistic accounts for lacking a mechanism to determine which concept is activated in which context.

- [Bilgrami 1992, Belief and Meaning]
  Why relevant: Argues that Burge's Bert refers to tharthritis rather than arthritis and proposes a rival form of metasemantic context sensitivity based on local subsets of aggregate belief contents rather than reference.

- [Boghossian 1989, Content and Self-Knowledge]
  Why relevant: Introduces slow-switching thought experiments to challenge the compatibility of semantic externalism with privileged self-knowledge and defends a pluralistic view of switched concepts.
  Summary link: [[4.Wiki/individual summaries/Boghossian 1989 - Content and Self-Knowledge]]
  Raw link: [[2.Raw/papers/Boghossian-1989-Content and Self-Knowledge-Philosophical Topics.pdf]]

- [Boghossian 1992a, Externalism and Inference]
  Why relevant: Formulates the Pavarotti slow-switching inference argument purporting to show that externalism undermines the a priori status of our logical abilities via undetectable equivocation.

- [Boghossian 1992b, Reply to Schiffer]
  Why relevant: Explicitly articulates the source-dependent assumption that memory beliefs originating in Earthly experiences are about Earth entities while those originating in Twin Earth experiences are about Twin Earth entities.

- [Boghossian 2011, The Transparency of Mental Content Revisited]
  Why relevant: Defines the transparency of mental content (sameness and difference of content known a priori) and criticizes both quasi-anaphoric and attributer-contextualist replies to the slow-switching inference problem.
  Summary link: [[4.Wiki/individual summaries/Boghossian 2011 - The transparency of mental content revisited]]
  Raw link: [[raw_sources/Boghossian-2011-The Transparency of Mental Content Revisited-Philosophical Studies.pdf]]

- [Burge 1979, Individualism and the Mental]
  Why relevant: Introduces the "arthritis" thought experiment used by Jackman as a central test case for the Self-Interpretation Principle and metasemantic contextualism.
  Summary link: [[4.Wiki/individual summaries/Burge 1979 - Individualism and the Mental]]
  Raw link: [[2.Raw/papers/Burge-1979-Individualism and the Mental-Midwest Studies in Philosophy.pdf]]

- [Burge 1988, Individualism and Self-Knowledge]
  Why relevant: Introduces slow-switching cases to argue that externalism is compatible with authoritative self-knowledge under a pluralistic view of concepts.

- [Burge 1998, Memory and Self-Knowledge]
  Why relevant: Rejects Boghossian's claim that "Pavarotti" equivocates within a single slow-switching inference, though read by Boghossian as relying on quasi-anaphoric premise-order dependence.

- [Davidson 1974/1984, On the Very Idea of a Conceptual Scheme]
  Why relevant: Articulates the holistic Principle of Charity in radical interpretation that Jackman refines and motivates through the Self-Interpretation Principle.
  Summary link: [[4.Wiki/individual summaries/Davidson 1974 - On the Very Idea of a Conceptual Scheme]]
  Raw link: [[2.Raw/papers/Davidson-1974-On-the-Very-Idea-of-a-Conceptual-Scheme-Inquiries into Truth and Interpretation.pdf]]

- [Davidson 1993, Reply to Tyler Burge]
  Why relevant: Contends against Burge that Bert's idiosyncratic use of "arthritis" should be interpreted as referring to tharthritis rather than arthritis.

- [Davidson 2003, Responses to Barry Stroud, John McDowell, and Tyler Burge]
  Why relevant: Reconsiders the "arthritis" case by allowing that Bert refers to arthritis only if he has an explicit intention to defer to expert usage.
  Summary link: [[4.Wiki/individual summaries/Davidson 2003 - Responses to Barry Stroud, John McDowell, and Tyler Burge]]
  Raw link: [[2.Raw/papers/Davidson-2003-Responses to Barry Stroud, John McDowell, and Tyler Burge-Philosophy and Phenomenological Research.pdf]]

- [Donnellan 1970, Proper Names and Identifying Descriptions]
  Why relevant: Provides the "J. L. Aston-Martin" party/philosopher switching example showing how the referent of a proper name shifts across contexts depending on the point of the speaker's remark.

- [Evans 1973, The Causal Theory of Names]
  Why relevant: Proposes the "Napoleon" (Alpha/Beta) switching case for his invariant dominant-source theory of names and mischaracterizes Donnellan as a source-dependent contextualist.
  Summary link: [[4.Wiki/individual summaries/Evans-1973-The Causal Theory of Names]]
  Raw link: [[2.Raw/collections of paper/Evans-1985-Collected Papers.pdf]]

- [Goldberg 2005, Memory Content: Against the Monist]
  Why relevant: Proposes conditions for the "defeat of the Current Face Value Presumption" in slow-switching memory cases whose predictions Jackman explains metasemantically via the Self-Interpretation Principle.

- [Goldberg 2007a, Anti-Individualism, Content Preservation, and Discursive Justification]
  Why relevant: Denies that "Pavarotti" equivocates in Boghossian's slow-switching argument and discusses anaphoric explanations of univocality across premises.
  Summary link: [[4.Wiki/individual summaries/Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]]
  Raw link: [[raw_sources/Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification-Nous.pdf]]

- [Heal 1998, Externalism and Memory]
  Why relevant: Defends a pluralistic view of slow-switching memory contents on which the switch to the new environment's concept is never completely total.
  Summary link: [[4.Wiki/individual summaries/Heal 1998 - Externalism and Memory]]
  Raw link: [[2.Raw/papers/Heal-1998-Externalism and Memory Jane Heal-Aristotelian Society Supplementary Volume.pdf]]

- [Jackman 2003, Charity, Self Interpretation, and Belief]
  Why relevant: Develops the Self-Interpretation Principle as a foundational motivation for truth-maximization and weighted commitments in a holistic Davidsonian metasemantics.
  Summary link: [[4.Wiki/individual summaries/Jackman 2003 - Charity, Self Interpretation, and Belief]]
  Raw link: [[2.Raw/papers/Jackman-2003-Charity Self-Interpretation and Belief-Journal of Philosophical Research.pdf]]

- [Ludlow 1999, Social Externalism, Self-Knowledge, and Memory]
  Why relevant: Uses slow-switching inference cases to attack the pluralistic (conceptual addition) view and defend the monistic (conceptual replacement) account of memory content.

- [Ludlow 2008, Cheap Contextualism]
  Why relevant: Defends a dynamic-lexicon form of contextualism closely aligned with Jackman's metasemantic contextualism.

- [Nichols, Pinillos, and Mallon 2014, Ambiguous Reference]
  Why relevant: Proposes a two-convention (causal-historical vs. descriptivist) ambiguity theory of natural kind terms that Jackman criticizes in favor of a univocal metasemantic contextualism.

- [Putnam 1975, The Meaning of 'Meaning']
  Why relevant: Introduces the Twin Earth "water" thought experiment and the interest-relative cross-world relation $same_L$, which Jackman uses to show how "water" can shift between natural and functional kinds across contexts.
  Summary link: [[4.Wiki/individual summaries/Putnam-n.d.l-The meaning of meaning]]
  Raw link: [[2.Raw/collections of paper/Putnam-n.d.-Philosophical Papers, Volume 2 Mind, Language and Reality.pdf]]

- [Schiffer 1992, Boghossian on Externalism and Inference]
  Why relevant: Argues against Boghossian that the two occurrences of "Pavarotti" in the slow-switching argument must receive the same interpretation and can be compressed into a single-token conjunction.

- [Stalnaker 2008, Our Knowledge of the Internal World]
  Why relevant: Offers a sympathetic contextualist reading of Donnellan and an account of slow-switching cases that Jackman contrasts with his own because Stalnaker prioritizes the attributer's context.

## Concepts

- [[Metasemantic Contextualism]] (`S-03`; endorses [[Speaker-Weighting Metasemantic Contextualism Holds]] `P-32`, pp. 229–233, 244–247; rejects [[Radical Interpreter-Relative Contextualism Holds]] `P-33`, p. 246, and [[Source-Dependent Contextualism Holds]] `P-34`, pp. 238–241, 243, 245)
- [[Content Externalism]] (`S-01`; endorses [[Contextualist Content Externalism]] `P-118`, pp. 234–235 fn. 19)
- [[Content-Preserving Memory and Slow-Switching Dynamics]] (`C-05`; discusses [[Two-Concept Originary Fixation Memory Definition]] `D-21`, [[Presentist Concept-Displacement Memory Definition]] `D-23`, and [[Anaphoric Univocality-Preserving Memory Definition]] `D-22`, pp. 241–247)
- [[Transparency of Mental Content]] (`C-01`; defends [[Comparative A Priori Transparency Definition]] `D-01`, pp. 228, 244–247)
- [[Knowledge of Content]] (`C-06`; uses [[Knowledge of Content Proper Definition]] `D-25`, pp. 229–230, 247)
- **Semantic Theory vs. Metasemantic Theory** `(single-source)` *(pp. 228–229)*: A semantic theory specifies the semantic values of expressions and how complex values compose from parts, whereas a metasemantic theory explains how expressions come to have those semantic values.
- **Self-Interpretation Principle** `(single-source)` *(pp. 229–230)*: The metasemantic principle that when an agent has conflicting commitments, semantic values should be assigned so as to preserve the truth of the commitments the agent would retain if made aware of the tension.

## Propositions

- [[Content Externalism Holds]] (`P-40`) — endorses (pp. 234–235 fn. 19)
- [[Metasemantic Contextualism Adequately Explains Mental Content]] (`P-06`) — endorses under `P-32` (pp. 228–247)
- [[Speaker-Weighting Metasemantic Contextualism Holds]] (`P-32`) — endorses (pp. 229–233, 244–247)
- [[Radical Interpreter-Relative Contextualism Holds]] (`P-33`) — rejects (p. 246)
- [[Source-Dependent Contextualism Holds]] (`P-34`) — rejects (pp. 238–241, 243, 245)
- [[Boghossian Peter Slow-Switching Setup Possibility]] (`P-46`) — endorses (pp. 244–245)
- [[Peter Commits Undetectable Equivocation]] (`P-47`) — rejects (pp. 245–247)
- [[Externalism Is Compatible with Knowledge of Content Proper]] (`P-30`) — endorses (pp. 228–230, 247)
- [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`) — discusses / critiques (p. 246)
- [[Intentional Realism]] (`P-42`) — discusses (pp. 244–247)
- [[The Common View of Mental Content]] (`P-44`) — discusses (pp. 244–247)
- **Self-Interpretation Principle and Variable Commitment Weights Hold** `(single-source)` — endorses (pp. 229–231): Every thinker's mental contents are fixed by weighted interpretive charity governed by the Self-Interpretation Principle, with commitment weights that vary across conversational contexts.
- **Bridge - Single-Context Commitment Weighting Forces Univocality in Peter** `(single-source)` — endorses (pp. 245–247): If both (a thinker's mental contents are assigned context-dependent semantic values by weighted interpretive charity governed by the thinker's own commitment priorities) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then it is not the case that (if a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise, then that thinker commits an introspectively undetectable equivocation between distinct wide contents).

## Arguments

- [[Slow-Switching Equivocation Derivation]] (`ARG-01`) — blocks by refuting `P-47` (pp. 244–247)
- [[Slow-Switch Equivocation vs. Transparency of Difference]] (`ARG-02`) — blocks via `P-32` (pp. 244–247)
- [[Slow-Switch Equivocation vs. Token-Wide APLA]] (`ARG-03`) — blocks via `P-32` (pp. 244–247)

### Jackman Single-Context Refutation of Peter Equivocation *(pp. 244–247)*

1. A thinker's mental contents are assigned context-dependent semantic values by weighted interpretive charity governed by the thinker's own commitment priorities.
2. Possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise.
3. If both (a thinker's mental contents are assigned context-dependent semantic values by weighted interpretive charity governed by the thinker's own commitment priorities) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then it is not the case that (if a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise, then that thinker commits an introspectively undetectable equivocation between distinct wide contents).
4. Both (a thinker's mental contents are assigned context-dependent semantic values by weighted interpretive charity governed by the thinker's own commitment priorities) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise).
5. Therefore, it is not the case that (if a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise, then that thinker commits an introspectively undetectable equivocation between distinct wide contents).

### From the Self-Interpretation Principle to Metasemantic Contextualism *(pp. 229–231)*

1. If both (the metasemantic function that fixes the semantic values of a speaker's terms maximizes the weighted total of true commitments in accordance with the Self-Interpretation Principle) and (the relative weights of a speaker's commitments vary across conversational contexts), then the semantic values assigned to a speaker's terms can vary across conversational contexts.
2. The metasemantic function that fixes the semantic values of a speaker's terms maximizes the weighted total of true commitments in accordance with the Self-Interpretation Principle.
3. The relative weights of a speaker's commitments vary across conversational contexts.
4. Both (the metasemantic function that fixes the semantic values of a speaker's terms maximizes the weighted total of true commitments in accordance with the Self-Interpretation Principle) and (the relative weights of a speaker's commitments vary across conversational contexts).
5. Therefore, the semantic values assigned to a speaker's terms can vary across conversational contexts.

## Assessment
