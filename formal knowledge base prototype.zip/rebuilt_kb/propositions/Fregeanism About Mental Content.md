---
id: P-43
type: proposition
kind: thesis
title: Fregeanism About Mental Content
aliases:
- P-43
status_kind: sharpened
constituted_by:
- '[[Cognitive Value]]'
schools:
- '[[Fregeanism and Mental-File Semantics]]'
plausibility: contested
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Goldberg-2008-Must Differences in Cognitive Value be Transparent]]'
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Fregeanism About Mental Content (`P-43`)

## Formulation

Mental contents are individuated by Fregean modes of presentation rather than solely by external objects and properties.

## Explanation

This thesis says that what distinguishes one thought from another is not merely which external object or property it refers to, but also the specific *Fregean mode of presentation* (or *cognitive value*)—the particular way that object is presented to the thinker's mind. That explains why a rational thinker can believe the Morning Star is bright while doubting the Evening Star is bright even though both names pick out the exact same planet (Venus). In externalist debates, Fregeanism is hotly contested: Paul Boghossian treats it as part of [[The Common View of Mental Content]] (`P-44`), whereas Robert Stalnaker rejects it for unstructured possible-worlds propositions, and Jessica Brown uses her non-switched Frances case—where Frances learns "einsteinium" and "fermium" under identical textbook descriptions while deferring to chemists—to show that even Fregean externalism fails transparency of difference of content (`TDC`, `P-11`).

## Inferential Relations
### Leads To
- Its negation (`~P-43`) structurally entails the negation of [[The Common View of Mental Content]] (`P-44`).

### Led To By / Challenged By
- Structurally entailed by [[The Common View of Mental Content]] (`P-44`).
- Directly challenged by [[Unstructured Possible-Worlds Propositions Suffice Without Concepts]] (`P-90`), which dispenses with Fregean modes of presentation and sub-propositional concepts ([[Boghossian 2011 - The transparency of mental content revisited]], [[Schroeter 2013 - Are Concepts Creatures of Darkness]]).

## Usage in Literature

In [[Boghossian 2011 - The transparency of mental content revisited]], [[Paul Boghossian]] endorses Fregeanism as the second conjunct of [[The Common View of Mental Content]] (`P-44`), observing that Twin Earth arguments are surprising precisely because they claim even Fregean senses are externally individuated. By contrast, [[Robert Stalnaker]] (reconstructed in [[Boghossian 2011 - The transparency of mental content revisited]]) rejects Fregeanism in favor of unstructured possible-worlds propositions (`P-90`), and [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]) defends non-Fregean anti-individualism while deploying `P-43` conditionally in Frances Element Case Refutes Fregean Transparency of Difference ([[Brown 2004 - Anti-Individualism and Knowledge#Arguments]]) to show that even Fregean anti-individualism violates Transparency of Difference (`P-11`). The Fregean link between content individuation and cognitive significance is further examined in [[Goldberg-2008-Must Differences in Cognitive Value be Transparent]] (which defends public-standard cognitive value without TDC) and [[Gertler 2015 - Internalism, Externalism, and Accessibilism]] (which argues for narrow cognitive value via Differential Dubitability).

## Assessment