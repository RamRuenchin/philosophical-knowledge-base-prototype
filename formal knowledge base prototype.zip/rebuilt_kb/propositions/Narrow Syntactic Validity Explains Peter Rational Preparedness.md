---
id: P-61
type: proposition
kind: thesis
title: Narrow Syntactic Validity Explains Peter Rational Preparedness
aliases:
- P-61
status_kind: sharpened
constituted_by:
- '[[A Priori Logical Abilities]]'
- '[[Rationality and Inferential Normativity]]'
plausibility: contested
sources:
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Narrow Syntactic Validity Explains Peter Rational Preparedness (`P-61`)

## Formulation

A priori sensitivity to narrow syntactic validity independently explains slow-switched thinkers' rational preparedness.

## Explanation

In Boghossian's slow-switching scenario (`P-46`), Peter unknowingly moves from Earth to Twin Earth and draws an inference combining an Earth memory (about water or Pavarotti) with a Twin-Earth perception (about "twater" or Twin Pavarotti). Even if his premises secretly differ in their environmentally determined ("wide") contents, the internal mental representations inside his head share the same *narrow syntactic* (purely formal, internal-shape) structure, making the inference syntactically valid. This thesis claims that Peter's *a priori* (non-empirical) sensitivity to that narrow syntactic validity independently explains why he is rationally prepared to draw the conclusion, preserving [[A Priori Logical Abilities]] at the syntactic level.

## Inferential Relations
### Leads To
- Defeasibly supports [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`) by instantiating a non-wide syntactic rationalizing level ([[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]]).

### Led To By / Challenged By
- Directly supported by [[Narrow-Syntactic APLA Holds]] (`P-23`) ([[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]]).

## Usage in Literature

[[Paul Boghossian]] introduces and endorses `P-61` in [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]] to block `ARG-07` via modus tollens: while conceding that a narrow syntactic account has its own difficulties, Boghossian argues that it explains why Peter is rationally prepared to make the inference and that [[Manuel Pérez Otero]] has not shown it inferior to externalist anaphoric or logical-luck replies. [[Manuel Pérez Otero]] rejects `P-61` in the `ARG-07` dialectic (reconstructed across [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]] and [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]]), treating internalist narrow strategies as either straining semantic intuitions or replicable within non-Millian externalism (`P-59`, `P-60`).

### Participating Arguments
- [[Otero Comparative Reversal vs. Boghossian Narrow-Syntax Reply]] (`ARG-07`, negated)

## Assessment