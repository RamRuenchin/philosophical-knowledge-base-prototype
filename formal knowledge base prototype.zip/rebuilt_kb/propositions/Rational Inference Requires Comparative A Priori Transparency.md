---
id: P-13
type: proposition
kind: thesis
title: Rational Inference Requires Comparative A Priori Transparency
aliases:
- P-13
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
- '[[Rationality and Inferential Normativity]]'
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
---

# Rational Inference Requires Comparative A Priori Transparency (`P-13`)

## Formulation

Rational inference requires comparative a priori transparency of mental content.

## Explanation

This thesis sharpens [[Rational Inference Requires Transparency of Mental Content]] (`P-01`) under [[Comparative A Priori Transparency Definition]] (`D-01`), capturing Paul Boghossian's claim that genuine rational reasoning and reason-giving explanation require full comparative transparency (`P-12`)—being able to tell purely from reflection both when two thoughts share the same meaning (transparency of sameness of content, `TSC`) and when they have different meanings (transparency of difference of content, `TDC`). The motivation is to keep a clean boundary between ordinary empirical ignorance and logical blunder: if you cannot tell from inside whether a repeated word in your argument secretly changes meaning, then whether your step is valid or equivocal can no longer be evaluated purely from your own rational perspective.

## Inferential Relations
### Leads To
- Its negation (`~P-13`) removes the comparative-transparency barrier against non-transparency models of rationality, supporting [[Externalism Is Compatible with Contingent-Form Rationality]] (`P-25`), [[Externalism Is Compatible with Blameless Identity-Sensitivity Rationality]] (`P-26`), [[Externalism Is Compatible with Competence-Based Rationality]] (`P-27`), and [[Externalism Is Compatible with Logical-Luck Rationality]] (`P-28`) ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]], [[Faria 2009 - Unsafe reasoning A survey]]).

### Led To By / Challenged By
- Defeasibly challenged by empirical Wason-task fallacies and Mates puzzles, which indicate that ordinary rational thinkers lack a priori comparative access to content relations ([[Brown 2004 - Anti-Individualism and Knowledge]]).

## Usage in Literature

[[Paul Boghossian]] endorses `P-13` across [[Boghossian 1992 - Externalism and Inference]] and [[Boghossian 1994 - The Transparency of Mental Content]], pairing it with the failure of comparative transparency under externalism (`~P-12`) in `ARG-05` to refute [[Wide Content Alone Suffices for Rationalizing Explanation]] (`P-54`). [[Jessica Brown]] rejects `P-13` in [[Brown 2004 - Anti-Individualism and Knowledge]] as an overly idealized "a priori logician" model of rationality, and [[Stephen Schiffer]] rejects it in [[Schiffer 1992 - Boghossian on Externalism and Inference]] in favor of contingent-form rationality. [[Mikkel Gerken]] in [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]] deliberately bypasses `P-13` altogether in formulating his Validity Argument, noting that `P-13` is far more controversial than a de facto validity requirement.

### Participating Arguments
- [[Collapse of Pure Wide Rationalizing Explanation]] (`ARG-05`, asserted)

## Assessment