---
id: P-119
type: proposition
kind: theory
title: Accessibilist Justification Internalism
aliases:
- P-119
status_kind: sharpened
constituted_by:
- '[[Inferential Warrant]]'
schools:
- '[[Justification Internalism]]'
plausibility: contested
sources:
- '[[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]'
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Accessibilist Justification Internalism (`P-119`)

## Formulation

Necessarily, for every thinker and every belief of that thinker, if that belief is epistemically justified, then there is at least one sufficient justification-conferring factor for that belief that the thinker is in a position to know by reflection alone.

## Explanation

Accessibilist [[Justification Internalism]] (`S-02`)—formulated most sharply as *J-Factor Accessibility* (`JFA`) alongside closely related access-internalist supervenience principles (`SA` / `AI`)—requires that whenever a belief is justified, the believer must be able to recognize at least one sufficient justifying ground (a "J-factor") purely through armchair reflection. Unlike non-accessibilist [[Mentalist Justification Internalism]] (`P-120`), this requirement exposes internalism to a direct conflict with [[Two-Concept Content Externalism]] (`P-41`), because slow switching undermines reflective access to sameness of content across inferential steps.

## Inferential Relations
### Leads To
- Defeasibly entails [[Mentalist Justification Internalism]] (`P-120`) whenever every reflectively accessible justification-conferring factor is an internal mental state ([[Gertler 2015 - Internalism, Externalism, and Accessibilism]], [[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]).

## Usage in Literature

[[Mahmoud Morvarid]] targets accessibilist justification internalism (`JFA`) in [[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]], first showing that standard privileged-access arguments fail to establish incompatibility with content externalism (because a content-neutral demonstrative token `J-factor` `H` remains accessible), and then constructing a reliability-based transparency argument showing that [[Two-Concept Content Externalism]] (`P-41`) defeats [[Transparency of Sameness of Content]] (`P-10`) and blocks reflective access to every available `J-factor` for slow-switched Oscar's justified disjunctive belief, rendering `P-41` incompatible with `P-119` ([[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism#Arguments]]). [[Brie Gertler]] explicitly rejects accessibilism (`P-119`) in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]], separating it from [[Mentalist Justification Internalism]] (`P-120`) and arguing via Shoemaker's Rita case that rational updating requires only first-order sensitivity (`P-14`), not higher-order reflective access (`P-15`) ([[Gertler 2015 - Internalism, Externalism, and Accessibilism#Arguments]]). [[Sanford C. Goldberg]] ([[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]]) exposes an analogous conflict between anti-individualism and reflectively computable discursive justification.

## Assessment
