---
id: P-34
type: proposition
kind: thesis
title: Source-Dependent Contextualism Holds
aliases:
- P-34
status_kind: sharpened
constituted_by: []
schools:
- '[[Metasemantic Contextualism]]'
plausibility: low
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]'
---

# Source-Dependent Contextualism Holds (`P-34`)

## Formulation

Each memory or premise token in a slow-switched thinker's inference refers strictly to the historical causal source of the specific belief it expresses.

## Explanation

This thesis directly sharpens [[Metasemantic Contextualism Adequately Explains Mental Content]] (`P-06`) within [[Metasemantic Contextualism]] (`S-03`). In plain terms, it says that whenever a slow-switched thinker such as Peter recalls a stored belief in an argument, the concept in that premise refers strictly to whichever external object or kind originally caused that specific belief to be formed—meaning two premises inside the very same inference can silently refer to different objects (Earth Pavarotti in a pre-switch memory, Twin Pavarotti in a post-switch perception) because their historical origins differ. Henry Jackman introduces this label not as a theory anyone explicitly defends, but to diagnose what he argues is an unexamined flaw behind Boghossian's slow-switching equivocation argument, contrasting it with his own single-context speaker-weighting view (`P-32`).

## Inferential Relations
### Leads To
- Directly opposes [[Speaker-Weighting Metasemantic Contextualism Holds]] (`P-32`) ([[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]).
- Defeasibly supports [[Peter Commits Undetectable Equivocation]] (`P-47`) by tying pre-switch memory tokens and post-switch experiential tokens to distinct historical acquisition sources ([[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]).

### Led To By / Challenged By
- Directly opposed by [[Speaker-Weighting Metasemantic Contextualism Holds]] (`P-32`) ([[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]).

## Usage in Literature

In [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]], [[Henry Jackman]] rejects source-dependent contextualism—arguing first that it misinterprets Donnellan's Aston-Martin case (where conversational point, not belief provenance, determines reference) and second that [[Paul Boghossian]]'s slow-switching equivocation argument (as presented in [[Boghossian 2011 - The transparency of mental content revisited]] and earlier work tying memory beliefs to their originating environments) implicitly presupposes it while ignoring that a unified inference occupies a single deliberative context. Neither Boghossian nor Jackman endorses source-dependent contextualism as an explicit contextualist theory; rather, Jackman attributes it as an unexamined presupposition of originary-fixation accounts of Peter's inference.

## Assessment