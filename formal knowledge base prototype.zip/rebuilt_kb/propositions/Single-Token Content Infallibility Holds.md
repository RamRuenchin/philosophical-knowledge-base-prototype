---
id: P-17
type: proposition
kind: thesis
title: Single-Token Content Infallibility Holds
aliases:
- P-17
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: high
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Single-Token Content Infallibility Holds (`P-17`)

## Formulation

Content externalism is compatible with authoritative single-token first-person knowledge of what one is thinking.

## Explanation

Sharpening [[Mental Content Is Epistemically Transparent]] (`P-02`) under [[Content Infallibility Definition]] (`D-02`), this widely accepted thesis says that even if your physical environment and community partly determine what your thoughts mean, you still enjoy authoritative, *cogito*-style first-person knowledge of any single thought you are currently having. When you think "I am hereby thinking that water is wet," your higher-order self-ascription automatically inherits whatever external meaning your first-order thought has, making it self-verifying without requiring you to compare two different thoughts against each other (closely paralleling [[Externalism Is Compatible with Knowledge of Content Proper]], `P-30`).

## Inferential Relations
### Leads To
- Structurally equivalent to [[Externalism Is Compatible with Knowledge of Content Proper]] (`P-30`).

### Led To By / Challenged By
- Structurally equivalent to [[Externalism Is Compatible with Knowledge of Content Proper]] (`P-30`).

## Usage in Literature

`P-17` enjoys rare cross-camp consensus in the corpus. [[Tyler Burge]] defends it as the cornerstone of externalist privileged access; [[Jessica Brown]] endorses it in [[Brown 2004 - Anti-Individualism and Knowledge]] via relevant alternatives; [[Brie Gertler]] endorses it in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]] via content inheritance; and [[Paul Boghossian]] explicitly concedes `P-17` in [[Boghossian 1994 - The Transparency of Mental Content]] and [[Boghossian 2011 - The transparency of mental content revisited]], pivoting his anti-externalist critique away from single-token self-knowledge toward comparative transparency (`P-12`) and inference.

## Assessment