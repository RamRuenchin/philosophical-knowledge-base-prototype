---
id: P-117
type: proposition
kind: theory
title: Mixed Internal-External Content Externalism
aliases:
- P-117
status_kind: sharpened
constituted_by:
- '[[Cognitive Value]]'
schools:
- '[[Content Externalism]]'
incompatible_with:
- P-116
plausibility: contested
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
---

# Mixed Internal-External Content Externalism (`P-117`)

## Formulation

Both some mental states have contents that constitutively depend on external environmental factors and mental content incorporates internal cognitive differentiators that partly individuate how thinkers represent external referents.

## Explanation

Unlike [[Pure Wide Realist Content Externalism]] (`P-116`), this hybrid (non-Millian) version of [[Content Externalism]] (`S-01`) holds that although what a thought refers to depends on the external environment ("wide content"), mental states also carry internal psychological features or modes of presentation that distinguish how a thinker grasps a referent. Manuel Pérez Otero highlights this mixed framework to show that externalists can match every viable internalist explanation of slow-switched Peter's reasoning without suffering internalism's semantic distortions, whereas Paul Boghossian replies that invoking internal differentiators concedes the inadequacy of wide content alone and Jessica Brown rejects mixed externalism in favor of symmetric non-Fregean wide content (`P-116`).

## Inferential Relations
### Leads To
- Structurally entails [[Content Externalism Holds]] (`P-40`).
- Directly incompatible with [[Pure Wide Realist Content Externalism]] (`P-116`) (implies its negation).
- Defeasibly supports [[Non-Millian Externalism Matches Internalist Differentiators]] (`P-60`) ([[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]).

### Led To By / Challenged By
- Directly incompatible with [[Pure Wide Realist Content Externalism]] (`P-116`) (negated by it).

## Usage in Literature

[[Manuel Pérez Otero]] treats mixed internal-external content externalism as a viable option in his pluralist externalist repertoire in [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]], arguing that it matches internalist cognitive differentiators (`P-60`) and underpins his comparative reversal of Boghossian's inference argument (`ARG-07`, `P-57`). [[Paul Boghossian]] replies in [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]] that appealing to internal differentiators concedes that pure wide content cannot explain rational inference, while [[Jessica Brown]] rejects `P-117` in [[Brown 2004 - Anti-Individualism and Knowledge]] after arguing via her Frances case that even neo-Fregean anti-individualism fails transparency of difference (`P-11`).

## Assessment
