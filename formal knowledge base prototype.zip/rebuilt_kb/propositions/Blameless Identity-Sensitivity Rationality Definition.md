---
id: D-14
type: proposition
kind: definition
title: Blameless Identity-Sensitivity Rationality Definition
aliases:
- D-14
status_kind: sharpened
defines: '[[Rationality and Inferential Normativity]]'
constituted_by:
- '[[Rationality and Inferential Normativity]]'
plausibility: contested
sources:
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
---

# Blameless Identity-Sensitivity Rationality Definition (`D-14`)

## Formulation
Rationality and inferential normativity denotes blameless sensitivity to logical relations that permits non-culpable brute logical error under abnormal externalist conditions.

## Explanation
This revised standard of rationality says a thinker who reasons carefully and responsibly from their own internal perspective stays fully rational even if an abnormal, undetectable change in their environment—like slow switching from Earth to Twin Earth—causes them to commit an unwitting equivocation (a "brute logical error"). Endorsed by Jessica Brown as a replacement for Boghossian's stringent a priori logical-conformity rationality ("B-rationality," [[A Priori Logical-Conformity Rationality Definition]], `D-12`), it accepts that externalism allows blameless logical mistakes, though critics such as Mikkel Gerken argue that being blameless alone is not enough for genuine epistemic warrant. Under this reading, [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) sharpens into [[Externalism Is Compatible with Blameless Identity-Sensitivity Rationality]] (`P-26`).

**Defines:** [[Rationality and Inferential Normativity]] (`C-03`)

## Usage in Literature

[[Jessica Brown]] endorses this refashioned rationality norm in [[Brown 2004 - Anti-Individualism and Knowledge]] as the proper response to the failure of B-rationality (`D-12`), preserving folk-psychological explanation alongside brute logical error (`P-93`). [[John M. Collins]] treats `D-14` as plausible in [[Collins 2008 - Content Externalism and Brute Logical Error]] while leaving open the ultimate shape of refashioned logical norms.

## Assessment