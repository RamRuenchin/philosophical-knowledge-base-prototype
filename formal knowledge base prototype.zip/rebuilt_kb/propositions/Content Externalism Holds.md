---
id: P-40
type: proposition
kind: thesis
title: Content Externalism Holds
aliases:
- P-40
status_kind: sharpened
constituted_by: []
schools:
- '[[Content Externalism]]'
plausibility: high
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]]'
- '[[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]'
---

# Content Externalism Holds (`P-40`)

## Formulation

Some mental states have contents that constitutively depend on external environmental factors.

## Explanation

Often called *semantic anti-individualism*, this foundational thesis in philosophy of mind claims that what at least some of your thoughts are about is not fixed solely by what happens inside your brain or subjective experience—it depends constitutively on your physical surroundings or linguistic community. Classic motivations include Hilary Putnam's Twin Earth (where an Earthling and a molecule-for-molecule twin on a planet with chemically different "twater" think different thoughts with the word "water") and Tyler Burge's arthritis case (where actual and counterfactual Bert are physically and experientially identical yet differ in what their "arthritis" thoughts mean solely because their communities use the word differently). Because `P-40` says only *some* mental states depend on external factors, it serves as the shared starting point for debates over discriminatory knowledge of content (`DKC`, telling from reflection alone whether two thoughts share or differ in meaning) and deductive/memorial justification-preservation principles (`I1`/`I2`), while sharper clashes turn on stronger add-ons like slow-switching cohabitation (`P-41`) or global externalism.

## Inferential Relations
### Leads To
- Its negation (`~P-40`) structurally entails the negation of [[Two-Concept Content Externalism]] (`P-41`).
- Defeasibly challenges [[Strong Meaning Rationalism Holds]] (`P-20`) by undermining infallible purely internal grasp of concept identity, difference, and non-emptiness ([[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]).

### Led To By / Challenged By
- Structurally entailed by [[Two-Concept Content Externalism]] (`P-41`), [[Pure Wide Realist Content Externalism]] (`P-116`), [[Mixed Internal-External Content Externalism]] (`P-117`), and [[Contextualist Content Externalism]] (`P-118`).
- Structurally entailed by **Global Content Externalism** in [[de Sá Pereira 2019 - Dangerous Liaisons#Propositions]].

## Usage in Literature

Content externalism is the baseline premise endorsed by the majority of authors in this corpus—including [[Tyler Burge]], [[Sanford C. Goldberg]] ([[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]], [[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]]), [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]), [[John M. Collins]] ([[Collins 2008 - Content Externalism and Brute Logical Error]]), [[Mikkel Gerken]] ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]), [[Manuel Pérez Otero]] ([[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]), [[Paulo Faria]], [[Henry Jackman]], [[Tadeusz Szubka]], [[Ruth Garrett Millikan]], and [[Roberto Horácio de Sá Pereira]] ([[de Sá Pereira 2019 - Dangerous Liaisons]])—and also serves as a conjunct of [[Two-Concept Content Externalism]] (`P-41`). By contrast, [[Paul Boghossian]] ([[Boghossian 1992 - Externalism and Inference]]) and [[Mahmoud Morvarid]] ([[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]) assume it conditionally inside incompatibility arguments probing its tension with transparency, a priori logic, and justification internalism. Across its participating arguments, `P-40` combines with co-reference, memory, or switching cases to challenge Transparency of Sameness (`ARG-04`), Fregean Transparency of Difference ([[Brown 2004 - Anti-Individualism and Knowledge#Arguments]]), DKC irrelevance ([[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content#Arguments]]), and reflective discursive justification ([[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification#Arguments]]).

### Participating Arguments
- [[Pierre and Paderewski Opacity vs. Transparency of Sameness]] (`ARG-04`, asserted)

## Assessment