---
id: P-47
type: proposition
kind: case-verdict
title: Peter Commits Undetectable Equivocation
aliases:
- P-47
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
- '[[Content-Preserving Memory and Slow-Switching Dynamics]]'
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
- '[[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]'
incompatible_with:
- P-49
---

# Peter Commits Undetectable Equivocation (`P-47`)

## Formulation

If a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise, then that thinker commits an introspectively undetectable equivocation between distinct wide contents.

## Explanation

In Boghossian's slow-switching thought experiment (`P-46`), Peter is unknowingly moved from Earth to Twin Earth and draws an apparently valid syllogism combining an Earth memory (about Earth Pavarotti or water) with a Twin-Earth perception (about Twin Pavarotti or Twin Earth's chemically distinct "twater"). This verdict says that Peter's inference really commits an equivocation—a hidden shift in meaning—because his pre-switch memory still refers to the Earthly subject while his post-switch perception refers to its Twin-Earth counterpart. Because both thoughts feel identical from the inside, Peter cannot detect this difference in environmentally determined ("wide") content by introspection alone, making his subjectively sensible reasoning objectively invalid.

**Direct incompatibility:** Directly incompatible with [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`).

## Inferential Relations
### Leads To
- Directly incompatible with [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`) (implies its negation).
- Directly supports [[Brute Logical Error Is Possible]] (`P-93`) ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]]).

### Led To By / Challenged By
- Directly incompatible with [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`) (negated by it).
- Defeasibly supported by [[Source-Dependent Contextualism Holds]] (`P-34`) ([[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]) and shielded against the enthymematic identity-premise escape by [[Empirical Coreference Presuppositions Are Not Additional Premises]] (`P-103`) ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]]).

## Usage in Literature

[[Paul Boghossian]] ([[Boghossian 1992 - Externalism and Inference]], [[Boghossian 1994 - The Transparency of Mental Content]]) derives `P-47` conditionally from two-concept externalism inside [[Slow-Switching Equivocation Derivation]] (`ARG-01`) to drive reductios against Transparency of Difference (`ARG-02`) and Token-Wide APLA (`ARG-03`). Externalists [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]), [[John M. Collins]] ([[Collins 2008 - Content Externalism and Brute Logical Error]]), and [[Mikkel Gerken]] ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]) outright endorse `P-47`, accepting slow-switch equivocation while revising traditional logical or warrant norms. Conversely, [[Stephen Schiffer]] (`ARG-06`), [[Tyler Burge]] (via anaphoric memory `P-49`), and [[Henry Jackman]] ([[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]], via single-context speaker-weighting) reject `P-47`, arguing that Peter's premises remain univocal.

### Participating Arguments
- [[Slow-Switching Equivocation Derivation]] (`ARG-01`, negated)
- [[Slow-Switch Equivocation vs. Transparency of Difference]] (`ARG-02`, asserted)
- [[Slow-Switch Equivocation vs. Token-Wide APLA]] (`ARG-03`, asserted)
- [[Schiffer Univocal Intent Blocks Slow-Switch Equivocation]] (`ARG-06`, asserted)

## Assessment