---
id: P-15
type: proposition
kind: thesis
title: Rational Inference Requires Reflective Explicatory Access
aliases:
- P-15
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
- '[[Rationality and Inferential Normativity]]'
plausibility: low
sources:
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Rational Inference Requires Reflective Explicatory Access (`P-15`)

## Formulation

Necessarily, every agent who performs rational inference is in possession of higher-order reflective explicatory access.

## Explanation

Sharpening [[Rational Inference Requires Transparency of Mental Content]] (`P-01`) under [[Reflective Explicatory Access Definition]] (`D-07`), this demanding thesis claims that you cannot perform a genuinely rational inference unless you also possess higher-order reflective access enabling you to articulate your justifying grounds and spell out the truth conditions of your concepts. Brie Gertler argues that this hyper-intellectualized requirement misrepresents internalism and refutes it with Shoemaker's Rita case: Rita updates her beliefs and plans rationally through ground-level responsiveness to her beliefs even though she cannot reflectively articulate her inferential grounds or define what makes her concepts apply.

## Inferential Relations
### Leads To
- Directly incompatible with [[Rational Inference Requires First-Order Rational Sensitivity]] (`P-14`) (implies its negation).

### Led To By / Challenged By
- Directly incompatible with [[Rational Inference Requires First-Order Rational Sensitivity]] (`P-14`) (negated by it).

## Usage in Literature

Sharpening [[Rational Inference Requires Transparency of Mental Content]] (`P-01`) under [[Reflective Explicatory Access Definition]] (`D-07`), `P-15` is rejected by [[Brie Gertler]] in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]]. Gertler diagnoses `P-15` as an accessibilist distortion wrongly attributed to content internalism and refutes it via Shoemaker's Rita case ([[Gertler 2015 - Internalism, Externalism, and Accessibilism#Arguments]]; Rita Reasons Rationally Without Explicatory Access, [[Gertler 2015 - Internalism, Externalism, and Accessibilism#Propositions]]), showing that rational belief updating requires only first-order rational sensitivity (`P-14`), not higher-order articulation of truth conditions.

## Assessment