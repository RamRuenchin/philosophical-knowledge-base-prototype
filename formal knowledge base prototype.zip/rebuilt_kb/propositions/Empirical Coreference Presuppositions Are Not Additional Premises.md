---
id: P-103
type: proposition
kind: thesis
title: Empirical Coreference Presuppositions Are Not Additional Premises
aliases:
- P-103
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
- '[[Inferential Warrant]]'
plausibility: high
sources:
- '[[Faria 2009 - Unsafe reasoning A survey]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
---

# Empirical Coreference Presuppositions Are Not Additional Premises (`P-103`)

## Formulation

No empirical coreference presupposition required for a concrete inference to instantiate a valid logical form can be converted into an explicit identity premise of that inference.

## Explanation

For a multi-step inference to be valid, different occurrences of a term or concept across its premises must actually refer to the same thing—an empirical background condition rather than an extra hidden premise. Suppose someone tries to rescue a thinker who unknowingly mixes up two things—such as [[Paulo Faria]]'s reasoner confusing two look-alike Golden Retrievers, Harry and Barry, across separate encounters, or a slow switcher combining an Earth memory with a Twin-Earth perception—by claiming the thinker tacitly relies on a false identity premise like "Harry = Barry" or "water = twater." By the Campbell-Carroll regress (named after John Campbell and Lewis Carroll), adding that explicit identity premise solves nothing, because the terms inside the newly added premise still require fresh coreference presuppositions linking them back to the original premises, launching an infinite regress.

## Inferential Relations
### Leads To
- Defeasibly supports [[Externalism Is Compatible with Logical-Luck Rationality]] (`P-28`) and defeasibly challenges [[Token-Level Wide APLA Holds]] (`P-21`) by showing that concrete inferential validity depends on non-premise empirical coreference presuppositions ([[Faria 2009 - Unsafe reasoning A survey]], [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]).
- Shields [[Peter Commits Undetectable Equivocation]] (`P-47`) and [[Brute Logical Error Is Possible]] (`P-93`) by blocking the enthymematic identity-premise escape ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]], [[Faria 2009 - Unsafe reasoning A survey]]).

### Led To By / Challenged By
- Supported by the Campbell–Carroll infinite regress consideration, whereby converting coreference presuppositions into explicit identity premises generates endless fresh coreference presuppositions ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]], [[Faria 2009 - Unsafe reasoning A survey]]).

## Usage in Literature

[[Jessica Brown]] endorses `P-103` in [[Brown 2004 - Anti-Individualism and Knowledge]] (applying Campbell's regress) to refute the implicit identity-premise reply to slow-switch equivocation, adding that meta-conceptual premises ("there is no equivocation") absurdly over-intellectualize ground-floor reasoning. [[John M. Collins]] endorses `P-103` in [[Collins 2008 - Content Externalism and Brute Logical Error]] to defeat the enthymeme blocking strategy against [[Brute Logical Error Is Possible]] (`P-93`), arguing that an astute reasoner regards identity premises as superfluous and that [[Tyler Burge]]'s fallback to mistaken presuppositions does not validate an equivocal inference. [[Paulo Faria]] endorses `P-103` in [[Faria 2009 - Unsafe reasoning A survey]] via the Harry-and-Barry Golden Retriever case, concluding that empirical presuppositions of existence, uniqueness, persistence, and coreference enable valid inference without entering it as premises.

## Assessment