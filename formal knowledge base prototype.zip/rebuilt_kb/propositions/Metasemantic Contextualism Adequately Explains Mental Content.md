---
id: P-06
type: proposition
kind: thesis
title: Metasemantic Contextualism Adequately Explains Mental Content
aliases:
- P-06
status_kind: umbrella
constituted_by: []
schools:
- '[[Metasemantic Contextualism]]'
interpretations:
- P-32
- P-33
- P-34
plausibility: contested
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Schroeter 2013 - Are Concepts Creatures of Darkness]]'
- '[[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]'
---

# Metasemantic Contextualism Adequately Explains Mental Content (`P-06`)

## Formulation

Metasemantic contextualism provides a viable account of mental content across slow-switching contexts.

## Explanation

This umbrella thesis holds that [[Metasemantic Contextualism]] (`S-03`)—the methodology treating the underlying content-determination function for a thinker's words and thoughts as varying across contexts—can satisfactorily explain mental content even when a thinker unknowingly travels between Earth and Twin Earth. It sharpens directly into three competing contextualist theses depending on *what* drives those contextual shifts: the thinker's own weighted priorities in a single chain of reasoning, an outside interpreter's changing explanatory goals, or the separate historical origins of each individual memory.

### Disambiguation Sharpenings
- [[Speaker-Weighting Metasemantic Contextualism Holds]] (`P-32`): what a thinker's concepts refer to shifts according to the thinker's own weighted commitments in the current reasoning context, keeping repeated terms unified within a single argument.
- [[Radical Interpreter-Relative Contextualism Holds]] (`P-33`): the truth conditions of a person's standing beliefs vary with an outside interpreter's shifting conversational interests, with no context-neutral content facts underneath.
- [[Source-Dependent Contextualism Holds]] (`P-34`): each individual memory or premise refers strictly to whatever external object originally caused that particular belief to be formed.

## Usage in Literature

[[Henry Jackman]] endorses `P-06` under speaker-weighting contextualism (`P-32`) in [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]], rejecting both interpreter-relative (`P-33`) and source-dependent (`P-34`) variants as flawed alternatives. [[Robert Stalnaker]] endorses radical interpreter-relative contextualism (`P-33`), which [[Laura Schroeter]] refutes in [[Schroeter 2013 - Are Concepts Creatures of Darkness]] via normative belief-revision stability (Schroeter Normative Belief Revision Argument Against Radical Contextualism ([[Schroeter 2013 - Are Concepts Creatures of Darkness#Arguments]])) and which [[Paul Boghossian]] criticizes in [[Boghossian 2011 - The transparency of mental content revisited]] as threatening attributional regress unless Intentional Realism holds for some contents.

## Assessment
