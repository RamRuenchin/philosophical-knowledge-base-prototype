---
id: P-02
type: proposition
kind: thesis
title: Mental Content Is Epistemically Transparent
aliases:
- P-02
status_kind: umbrella
constituted_by:
- '[[Transparency of Mental Content]]'
interpretations:
  D-01: P-12
  D-02: P-17
  D-03: P-18
  D-04: P-19
  D-05: P-20
plausibility: contested
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]'
---

# Mental Content Is Epistemically Transparent (`P-02`)

## Formulation

Mental content is epistemically transparent to the thinker.

## Explanation

This broad claim says that thinkers enjoy direct, non-empirical inward access to what their own thoughts mean. In the literature on [[Transparency of Mental Content]] (`C-01`), however, that slogan covers five very different claims—ranging from the widely accepted idea that you know what a single current thought is about, up to the demanding Cartesian claim that you can infallibly tell from reflection alone whether any two thoughts share or differ in meaning and whether your concepts actually refer to anything. Splitting these sharpenings keeps broadly accepted single-thought self-knowledge separate from far more controversial comparative and infallibilist claims.

### Disambiguation Sharpenings
- Under `D-01` ([[Comparative A Priori Transparency Definition]]) -> [[Full Comparative Epistemic Transparency Holds]] (`P-12`): you can tell purely from reflection both when two of your thoughts have the same meaning (transparency of sameness of content) and when they have different meanings (transparency of difference of content).
- Under `D-02` ([[Content Infallibility Definition]]) -> [[Single-Token Content Infallibility Holds]] (`P-17`): you have authoritative, self-verifying first-person knowledge of what a single current thought means ("I am now thinking that water is wet"), without needing to compare it against other thoughts.
- Under `D-03` ([[Qualified Contextual Transparency Definition]]) -> [[Qualified Contextual Transparency Holds]] (`P-18`): your thoughts count as transparent relative to your unspoken background assumptions and how an interpreter contextually describes your beliefs.
- Under `D-04` ([[Modest Synchronic Transparency Definition]]) -> [[Modest Synchronic Transparency Holds]] (`P-19`): at any single moment in time, you can tell from reflection whether two meanings you currently have in mind are the same or different, even if your environment partly fixes what your thoughts are about.
- Under `D-05` ([[Strong Meaning Rationalism Definition]]) -> [[Strong Meaning Rationalism Holds]] (`P-20`): you have an infallible, purely inward grasp of whether your concepts match, differ, have a single clear meaning, and actually refer to something real, even across time.

## Usage in Literature

Apparent disagreement over `P-02` reflects incompatible choices of sharpening across the corpus. [[Tyler Burge]] (reconstructed across [[Boghossian 1994 - The Transparency of Mental Content]] and [[Boghossian 2011 - The transparency of mental content revisited]]) endorses single-token content infallibility (`P-17`, which [[Paul Boghossian]] also concedes while arguing externalism defeats `P-12`); [[Robert Stalnaker]] endorses qualified contextual transparency (`P-18`); and [[Tadeusz Szubka]] endorses modest synchronic transparency (`P-19`) in [[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]] while conceding externalism refutes Strong Meaning Rationalism (`P-20`). On the rejecting side, [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]) and [[John M. Collins]] ([[Collins 2008 - Content Externalism and Brute Logical Error]]) reject comparative transparency (`P-12`), while [[Ruth Garrett Millikan]] (via [[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]) rejects both Strong Meaning Rationalism (`P-20`) and modest synchronic transparency (`P-19`).

## Assessment