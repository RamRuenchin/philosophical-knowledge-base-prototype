---
id: P-04
type: proposition
kind: thesis
title: Content Externalism Is Compatible with Rational Inference
aliases:
- P-04
status_kind: umbrella
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
interpretations:
  D-12: P-24
  D-13: P-25
  D-14: P-26
  D-15: P-27
  D-16: P-28
  D-17: P-29
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Schiffer 1992 - Boghossian on Externalism and Inference]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[de Sá Pereira 2019 - Dangerous Liaisons]]'
---

# Content Externalism Is Compatible with Rational Inference (`P-04`)

## Formulation

Content externalism is compatible with rational inference and rationalizing explanation.

## Explanation

This umbrella claim asks whether [[Content Externalism]] (`S-01`)—the view that what your thoughts are about depends partly on your physical environment and language community—can coexist with rational reasoning and explaining people's actions through their reasons. Philosophers give opposing answers mainly because they assume different standards for [[Rationality and Inferential Normativity]] (`C-03`): if rationality requires knowing from reflection alone that your externally fixed terms match, slow-switching puzzles seem to break it, whereas weaker standards based on blamelessness, normal-environment competence, or environmental luck preserve compatibility.

### Disambiguation Sharpenings
- Under `D-12` ([[A Priori Logical-Conformity Rationality Definition]]) -> [[Externalism Is Compatible with A Priori Conformity Rationality]] (`P-24`): externalism fits Boghossian's demanding standard of a priori logical-conformity rationality (`B-rationality`), which requires knowing from reflection alone how one's externally fixed thoughts logically relate.
- Under `D-13` ([[Contingent-Form Rationality Definition]]) -> [[Externalism Is Compatible with Contingent-Form Rationality]] (`P-25`): externalism fits a standard on which reasoning is justified whenever it follows a valid deductive pattern, even though it is a contingent worldly fact whether repeated terms actually share the same meaning.
- Under `D-14` ([[Blameless Identity-Sensitivity Rationality Definition]]) -> [[Externalism Is Compatible with Blameless Identity-Sensitivity Rationality]] (`P-26`): externalism fits a standard of blameless logical sensitivity that allows a wholly rational person to commit an undetectable, non-culpable "brute logical error" in abnormal environments.
- Under `D-15` ([[Competence-Based Normal-Environment Rationality Definition]]) -> [[Externalism Is Compatible with Competence-Based Rationality]] (`P-27`): externalism fits a standard on which reasoning is rational and warranted whenever it exercises a cognitive competence that reliably produces valid inferences in normal environments.
- Under `D-16` ([[Logical-Luck Externalist Rationality Definition]]) -> [[Externalism Is Compatible with Logical-Luck Rationality]] (`P-28`): externalism fits a standard that accepts "logical luck," meaning whether a concrete inference counts as valid can depend on environmental facts outside the thinker's inward control.
- Under `D-17` ([[Dual Internal-Blamelessness and Social-Material Rationality Definition]]) -> [[Externalism Is Compatible with Dual Social-Material Rationality]] (`P-29`): externalism fits rationality by splitting it into two tiers—keeping personal blamelessness inside the head while letting the objective identity and validity of reasoning depend on the environment and speech community.

## Usage in Literature

[[Paul Boghossian]] rejects `P-04` under `D-12` (`P-24`) in [[Boghossian 1992 - Externalism and Inference]], arguing that slow-switching equivocation defeats B-rationality for pure wide externalism. Most externalist respondents endorse `P-04` by shifting to alternative conceptions of rationality: [[Stephen Schiffer]] via contingent-form rationality (`P-25`) in [[Schiffer 1992 - Boghossian on Externalism and Inference]]; [[Jessica Brown]] via blameless identity-sensitivity (`P-26`) in [[Brown 2004 - Anti-Individualism and Knowledge]]; [[Mikkel Gerken]] via competence-based normal-environment rationality (`P-27`) in [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]; [[Roberto Horácio de Sá Pereira]] via dual social-material rationality (`P-29`) in [[de Sá Pereira 2019 - Dangerous Liaisons]]; and [[Tyler Burge]] via anti-individualist preservative memory and warrant. [[Manuel Pérez Otero]] ([[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]) and [[Paulo Faria]] ([[Faria 2009 - Unsafe reasoning A survey]]) likewise treat logical-luck externalism (`P-28`) as a plausible compatibilist path.

## Assessment