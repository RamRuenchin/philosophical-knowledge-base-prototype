---
id: P-28
type: proposition
kind: thesis
title: Externalism Is Compatible with Logical-Luck Rationality
aliases:
- P-28
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
plausibility: contested
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Faria 2009 - Unsafe reasoning A survey]]'
---

# Externalism Is Compatible with Logical-Luck Rationality (`P-28`)

## Formulation

Content externalism is compatible with an externalist conception of inferential rationality that admits environmental logical luck.

## Explanation

This thesis sharpens [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) under [[Logical-Luck Externalist Rationality Definition]] (`D-16`). By analogy with *moral luck* (where factors outside your control affect moral assessment), it says that whether a concrete inference succeeds in being logically valid—and therefore meets objective inferential norms—can legitimately depend on contingent worldly facts outside your inward control. Paulo Faria motivates this with everyday cases like confusing two identical-looking Golden Retrievers, Harry and Barry (showing that ordinary valid reasoning already relies on unstated empirical identity assumptions), while Manuel Pérez Otero notes that in slow-switching cases like Peter's (unknowingly mixing an Earth memory with a Twin Earth perception), accepting logical luck lets externalists drop concrete token-level a priori logical abilities (`APLA`, `P-21`) while still keeping a priori knowledge of abstract logical forms (`P-22`).

## Inferential Relations
### Led To By / Challenged By
- Supported by [[Empirical Coreference Presuppositions Are Not Additional Premises]] (`P-103`) and **Concrete Inferential Validity Is Subject to Logical Luck** in [[Faria 2009 - Unsafe reasoning A survey#Propositions]] ([[Faria 2009 - Unsafe reasoning A survey]], [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]).
- Supported by rejecting [[Rational Inference Requires Comparative A Priori Transparency]] (`~P-13`) and motivated when [[Token-Level Wide APLA Holds]] (`P-21`) and [[Externalism Is Compatible with A Priori Conformity Rationality]] (`P-24`) are abandoned ([[Faria 2009 - Unsafe reasoning A survey]], [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]]).

## Usage in Literature

In [[Faria 2009 - Unsafe reasoning A survey]], [[Paulo Faria]] treats logical-luck externalism as a plausible path after showing (via the Golden Retrievers Harry and Barry case and the Campbell–Carroll regress, `P-103`) that ordinary valid inference already relies on contingent empirical co-reference presuppositions that cannot be converted into explicit premises. In [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]], [[Manuel Pérez Otero]] likewise treats the logical-luck strategy (attributed to Sorensen and Faria) as one of the two most promising externalist responses to Peter's slow-switching case, noting that abandoning token-level APLA (`P-21`) still preserves a priori grasp of abstract logical forms (`P-22`).

## Assessment