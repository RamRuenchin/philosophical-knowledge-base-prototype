---
id: P-33
type: proposition
kind: thesis
title: Radical Interpreter-Relative Contextualism Holds
aliases:
- P-33
status_kind: sharpened
constituted_by: []
schools:
- '[[Metasemantic Contextualism]]'
plausibility: low
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Schroeter 2013 - Are Concepts Creatures of Darkness]]'
---

# Radical Interpreter-Relative Contextualism Holds (`P-33`)

## Formulation

The truth conditions of a thinker's standing beliefs vary with an interpreter's shifting explanatory context.

## Explanation

This thesis directly sharpens [[Metasemantic Contextualism Adequately Explains Mental Content]] (`P-06`), capturing Robert Stalnaker's radical brand of [[Metasemantic Contextualism]] (`S-03`). Instead of treating beliefs as having fixed, interpreter-independent representational contents (`P-42`), it holds that attributing a belief merely locates the believer's situation within whatever space of relevant possibilities suits an interpreter's current conversational and explanatory purposes—so the very truth conditions of a standing belief can shift from one interpreter's "spot-check" to another. Critics object that this dissolves the stable truth conditions needed for rational belief revision (Laura Schroeter) and triggers an infinite regress unless the interpreter's own beliefs have determinate, interpreter-independent contents (Paul Boghossian).

## Inferential Relations
### Leads To
- Directly incompatible with [[Intentional Realism]] (`P-42`) (implies its negation, and thereby the negation of [[The Common View of Mental Content]] (`P-44`)).

### Led To By / Challenged By
- Directly incompatible with [[Intentional Realism]] (`P-42`) and [[The Common View of Mental Content]] (`P-44`) (negated by them).

## Usage in Literature

[[Robert Stalnaker]] (as reconstructed across [[Boghossian 2011 - The transparency of mental content revisited]], [[Schroeter 2013 - Are Concepts Creatures of Darkness]], and [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]) endorses this view to dissolve Cartesian transparency puzzles without positing concepts. It is rejected by [[Laura Schroeter]] in [[Schroeter 2013 - Are Concepts Creatures of Darkness]] via Schroeter Normative Belief Revision Argument Against Radical Contextualism ([[Schroeter 2013 - Are Concepts Creatures of Darkness#Arguments]]), arguing that interest-relative spot-checks destabilize normative belief revision; by [[Paul Boghossian]] in [[Boghossian 2011 - The transparency of mental content revisited]], who argues that attributor-relative content presupposes attributor-independent Intentional Realism somewhere in the chain to avoid regress; and by [[Henry Jackman]] in [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]], who replaces attributor-relativity with speaker-anchored weighting (`P-32`).

## Assessment