---
id: D-06
type: proposition
kind: definition
title: First-Order Rational Sensitivity Definition
aliases:
- D-06
status_kind: sharpened
defines: '[[Transparency of Mental Content]]'
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: contested
sources:
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# First-Order Rational Sensitivity Definition (`D-06`)

## Formulation
Transparency of mental content denotes first-order rational sensitivity to content relations in belief updating and inference without requiring higher-order articulable access.

## Explanation
On this definition, your thoughts are "transparent" to reasoning simply when sameness and difference of meaning reliably guide how you form, connect, and revise your beliefs at the ground level—even if you cannot step back and explain your reasons in words. Brie Gertler illustrates this with Sydney Shoemaker's case of Rita, who updates her beliefs rationally without being able to articulate the justification behind her shifts, separating practical first-order sensitivity from explicit higher-order explanation ([[Reflective Explicatory Access Definition]], `D-07`). Under this reading, [[Rational Inference Requires Transparency of Mental Content]] (`P-01`) sharpens into [[Rational Inference Requires First-Order Rational Sensitivity]] (`P-14`).

**Defines:** [[Transparency of Mental Content]] (`C-01`)

## Usage in Literature

[[Brie Gertler]] introduces and endorses this sharpening in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]], arguing that debates over content transparency routinely conflate first-order rational sensitivity (`D-06`) with higher-order explicatory access (`D-07`). Drawing on Shoemaker's Rita case, Gertler maintains that rational inference requires `D-06` (`P-14`) but not `D-07` (`P-15`).

## Assessment