---
id: D-23
type: proposition
kind: definition
title: Presentist Concept-Displacement Memory Definition
aliases:
- D-23
status_kind: sharpened
defines: '[[Content-Preserving Memory and Slow-Switching Dynamics]]'
constituted_by:
- '[[Content-Preserving Memory and Slow-Switching Dynamics]]'
plausibility: low
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
---

# Presentist Concept-Displacement Memory Definition (`D-23`)

## Formulation
Content-preserving memory across slow switching denotes one-concept displacement in which a newly acquired Twin-Earth concept wholly replaces the older Earthly concept in memory.

## Explanation
Instead of letting Earth and Twin-Earth concepts coexist side by side ([[Two-Concept Originary Fixation Memory Definition]], `D-21`), this "presentist" displacement model claims that once a slow-switched thinker fully adapts to Twin Earth, the new Twin-Earth concept completely overwrites the old Earth concept across all stored memories. That prevents mixed-premise equivocation because every post-switch thought uses the same current concept, but philosophers widely reject it because it retroactively distorts genuine memories—turning true memories about Earth into false beliefs about Twin Earth.

**Defines:** [[Content-Preserving Memory and Slow-Switching Dynamics]] (`C-05`)

## Usage in Literature

[[Paul Boghossian]] ([[Boghossian 1992 - Externalism and Inference]]), [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]), and [[John M. Collins]] ([[Collins 2008 - Content Externalism and Brute Logical Error]]) explicitly reject this displacement model because it turns true Earthly memories into false Twin-Earth beliefs and conflicts with genuine memory preservation. [[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]] also contrasts one-concept replacement with the two-concept model (`D-21`) used in his argument.

## Assessment