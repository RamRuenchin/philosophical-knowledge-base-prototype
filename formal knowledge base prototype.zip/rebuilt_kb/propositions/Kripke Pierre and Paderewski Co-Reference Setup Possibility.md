---
id: P-50
type: proposition
kind: case-setup
title: Kripke Pierre and Paderewski Co-Reference Setup Possibility
aliases:
- P-50
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
- '[[Cognitive Value]]'
plausibility: high
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Schroeter 2013 - Are Concepts Creatures of Darkness]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
---

# Kripke Pierre and Paderewski Co-Reference Setup Possibility (`P-50`)

## Formulation

Possibly, a rational thinker holds two distinct co-referential mental guises without realizing that they co-refer.

## Explanation

This proposition states the possibility of familiar unwitting co-reference puzzles, such as Saul Kripke's Pierre and Paderewski cases (and Jessica Brown's Rudolf variant). In Kripke's cases, Pierre learns in French that "Londres" is pretty and later moves to an unattractive part of London, learning in English that "London" is not pretty, without realizing both names refer to the same city; likewise, a rational thinker hears of "Paderewski" once as a pianist and once as a Polish politician without realizing they are the same man. In each scenario, a fully rational thinker holds two separate mental "guises" or files for one external object while remaining empirically unaware that they co-refer.

## Usage in Literature

[[Paul Boghossian]] ([[Boghossian 1994 - The Transparency of Mental Content]]), [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]), and [[Laura Schroeter]] ([[Schroeter 2013 - Are Concepts Creatures of Darkness]]) all endorse the possibility of these co-reference cases. Boghossian and Brown both deploy `P-50` inside [[Pierre and Paderewski Opacity vs. Transparency of Sameness]] (`ARG-04`) to refute externalist Transparency of Sameness (`P-10`), while Schroeter uses Kripke's Pierre alongside Peter to argue against Stalnaker that even externalist semantics requires minimalist person-level mental files to track apparent *de jure* co-reference.

### Participating Arguments
- [[Pierre and Paderewski Opacity vs. Transparency of Sameness]] (`ARG-04`, asserted)

## Assessment