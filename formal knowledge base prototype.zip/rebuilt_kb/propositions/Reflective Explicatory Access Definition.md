---
id: D-07
type: proposition
kind: definition
title: Reflective Explicatory Access Definition
aliases:
- D-07
status_kind: sharpened
defines: '[[Transparency of Mental Content]]'
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: low
sources:
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Reflective Explicatory Access Definition (`D-07`)

## Formulation
Transparency of mental content denotes higher-order reflective explicatory access enabling a thinker to articulate inferential grounds and content identities from the armchair.

## Explanation
This demanding, intellectualized definition says that mental content is transparent only if a thinker can reflect on their own mind and explicitly articulate what their thoughts mean, whether they match, and why a step of reasoning is justified. Unlike [[First-Order Rational Sensitivity Definition]] (`D-06`), which only requires beliefs to update rationally in practice, reflective explicatory access requires conscious, verbalizable higher-order knowledge—a requirement Brie Gertler rejects using Shoemaker's case of Rita, who reasons and updates beliefs rationally without being able to articulate her grounds. Under this reading, [[Rational Inference Requires Transparency of Mental Content]] (`P-01`) sharpens into [[Rational Inference Requires Reflective Explicatory Access]] (`P-15`).

**Defines:** [[Transparency of Mental Content]] (`C-01`)

## Usage in Literature

[[Gertler 2015 - Internalism, Externalism, and Accessibilism]] isolates this explicatory-access sharpening (connecting it to concerns raised by Goldberg and to the "simple argument for explicatory access") in order to reject its necessity for rational inference (`P-15`) via Shoemaker's Rita case. Neither [[Brie Gertler]] nor other authors in the corpus endorse `D-07` as the proper definition of inferential transparency.

## Assessment