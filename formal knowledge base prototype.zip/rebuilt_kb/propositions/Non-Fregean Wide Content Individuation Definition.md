---
id: D-36
type: proposition
kind: definition
title: Non-Fregean Wide Content Individuation Definition
aliases:
- D-36
status_kind: sharpened
defines: '[[Cognitive Value]]'
constituted_by:
- '[[Cognitive Value]]'
plausibility: contested
sources:
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
---

# Non-Fregean Wide Content Individuation Definition (`D-36`)

## Formulation
Cognitive value denotes non-Fregean, environmentally individuated wide content without Fregean modes of presentation.

## Explanation
Rather than trying to keep Fregean modes of presentation inside an externalist theory (as in [[Social-Externalist Public Cognitive Value Definition]], `D-35`), this definition drops Fregean senses altogether and individuates mental content purely by environmentally determined ("wide") reference. Jessica Brown endorses this approach alongside content externalism, noting that non-switching cases like Frances (who learns "einsteinium" and "fermium" under identical textbook descriptions) defeat Transparency of Difference of Content (TDC) even for Fregean externalists, while cases like Kripke's Pierre and Paderewski (holding two unrecognized guises for one city or person) defeat Transparency of Sameness of Content (TSC) for non-Fregeans.

**Defines:** [[Cognitive Value]] (`C-10`)

## Usage in Literature

[[Jessica Brown]] endorses `D-36` in [[Brown 2004 - Anti-Individualism and Knowledge]] alongside [[Content Externalism Holds]] (`P-40`), arguing that anti-individualism stands in deep tension with [[Fregeanism About Mental Content]] (`P-43`) because non-switch cases like Frances's element case defeat transparency of difference even for Fregean anti-individualism (Frances Element Case Refutes Fregean Transparency of Difference ([[Brown 2004 - Anti-Individualism and Knowledge#Arguments]])), while Rudolf/Paderewski cases defeat transparency of sameness under non-Fregean anti-individualism ([[Pierre and Paderewski Opacity vs. Transparency of Sameness]], `ARG-04`).

## Assessment