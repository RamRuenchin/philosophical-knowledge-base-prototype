---
id: P-11
type: proposition
kind: thesis
title: Transparency of Difference of Content
aliases:
- P-11
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: low
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
- '[[Goldberg-2008-Must Differences in Cognitive Value be Transparent]]'
---

# Transparency of Difference of Content (`P-11`)

## Formulation

Every thinker can know a priori, for every two different-content thought tokens of that thinker, that they differ in content.

## Explanation

Often abbreviated `TDC` (or `Tr-D`, *transparency of difference of content*), this thesis says that whenever two of your thoughts actually have different meanings, you can tell purely from reflection—without empirical investigation—that they differ. Under content externalism (the view that your physical or social environment partly fixes what your thoughts mean), `TDC` faces powerful counterexamples: slow-switched Peter unknowingly moves from Earth to Twin Earth and mixes a pre-switch memory of Earth Pavarotti with a post-switch perception of Twin Pavarotti without noticing any difference; Jessica Brown's non-switched Frances learns "einsteinium" and "fermium" under identical textbook descriptions while deferring to chemists, so her two concepts differ invisibly; and Sanford Goldberg's slow-switched Schmidt can rationally doubt one thought while believing another without being able to tell from inside that their contents differ.

## Inferential Relations
### Leads To
- Its negation (`~P-11`) structurally entails the negation of [[Full Comparative Epistemic Transparency Holds]] (`P-12`) and [[Strong Meaning Rationalism Holds]] (`P-20`).

### Led To By / Challenged By
- Structurally entailed by [[Full Comparative Epistemic Transparency Holds]] (`P-12`) and by the stronger [[Strong Meaning Rationalism Holds]] (`P-20`).

## Usage in Literature

Abbreviated TDC (or Tr-D) and conjoined with [[Transparency of Sameness of Content]] (`P-10`) in [[Full Comparative Epistemic Transparency Holds]] (`P-12`), `P-11` is widely rejected across externalist literature. [[Jessica Brown]] rejects `P-11` in [[Brown 2004 - Anti-Individualism and Knowledge]], showing via Frances's non-switch element case ([[Brown 2004 - Anti-Individualism and Knowledge#Arguments]]) that even Fregean anti-individualism violates TDC. [[John M. Collins]] rejects `P-11` in [[Collins 2008 - Content Externalism and Brute Logical Error]] via slow-switch equivocation (`ARG-02`), and [[Paulo Faria]] likewise rejects `P-11` in [[Faria 2009 - Unsafe reasoning A survey]] while surveying unsafe reasoning. [[Sanford C. Goldberg]] rejects `P-11` in [[Goldberg-2008-Must Differences in Cognitive Value be Transparent]], arguing via Schmidt that Frege's differential dubitability test does not presuppose TDC (Rational Differential Dubitability Requires TDC ([[Goldberg-2008-Must Differences in Cognitive Value be Transparent#Propositions]]); Schmidt Differential Dubitability Without TDC ([[Goldberg-2008-Must Differences in Cognitive Value be Transparent#Arguments]])). [[Paul Boghossian]] in [[Boghossian 1994 - The Transparency of Mental Content]] and [[Boghossian 2011 - The transparency of mental content revisited]] derives `~P-11` from slow-switching equivocation (`ARG-02`) as a conditional reductio against pure wide anti-individualism rather than endorsing `~P-11` for mental content generally.

### Participating Arguments
- [[Slow-Switch Equivocation vs. Transparency of Difference]] (`ARG-02`, asserted)

## Assessment