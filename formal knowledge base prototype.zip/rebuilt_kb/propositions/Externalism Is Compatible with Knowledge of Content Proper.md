---
id: P-30
type: proposition
kind: thesis
title: Externalism Is Compatible with Knowledge of Content Proper
aliases:
- P-30
status_kind: sharpened
constituted_by:
- '[[Knowledge of Content]]'
schools:
- '[[Content Externalism]]'
plausibility: high
sources:
- '[[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Externalism Is Compatible with Knowledge of Content Proper (`P-30`)

## Formulation

Content externalism is compatible with authoritative first-person knowledge of the content of an individual occurrent thought.

## Explanation

This thesis sharpens [[Content Externalism Is Compatible with Introspective Knowledge of Content]] (`P-05`) under [[Knowledge of Content Proper Definition]] (`D-25`). Here *Knowledge of Content Proper* (`KC`, also called *privileged access*) means authoritative first-person knowledge of what a single current thought of yours is about—for instance, knowing directly that you are now thinking that water is wet—without needing empirical investigation. Most philosophers across both externalist and internalist camps accept `KC` compatibility (through Tyler Burge's self-verifying self-ascriptions, Jessica Brown's relevant-alternatives framework, or Brie Gertler's content inheritance), while carefully separating it from the much harder question of *Discriminatory Knowledge of Content* (`DKC`, `P-31`), which requires telling from introspection alone whether two thoughts share or differ in meaning.

## Inferential Relations
### Leads To
- Structurally equivalent to [[Single-Token Content Infallibility Holds]] (`P-17`).

### Led To By / Challenged By
- Structurally equivalent to [[Single-Token Content Infallibility Holds]] (`P-17`).

## Usage in Literature

[[Tyler Burge]] (as reconstructed across [[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]] and other sources), [[Jessica Brown]] (in [[Brown 2004 - Anti-Individualism and Knowledge]], using a relevant-alternatives framework to defeat the discrimination objection), and [[Brie Gertler]] (in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]]) all endorse this compatibilist thesis. [[Sanford C. Goldberg]] (in [[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]]) treats it as plausible for dialectical purposes—bracketing earlier doubts to grant KC compatibilism while arguing that failures of DKC still affect reasoning—and [[Henry Jackman]] (in [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]]) likewise treats it as plausible within his speaker-authority metasemantics.

## Assessment