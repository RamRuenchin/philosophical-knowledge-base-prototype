---
id: P-66
type: proposition
kind: bridge
title: Bridge - Opaque Co-Reference Defeats Transparency of Sameness
aliases:
- P-66
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
- '[[Cognitive Value]]'
plausibility: high
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
---

# Bridge - Opaque Co-Reference Defeats Transparency of Sameness (`P-66`)

## Formulation

If both (both (some mental states have contents that constitutively depend on external environmental factors) and (possibly, a rational thinker holds two distinct co-referential mental guises without realizing that they co-refer)) and (if a rational thinker holds two distinct co-referential mental guises without realizing that they co-refer, then that thinker cannot know a priori that the corresponding thought tokens share wide content), then it is not the case that every thinker can know a priori, for every two same-content thought tokens of that thinker, that they have the same content.

## Explanation

*Transparency of Sameness of Content* (TSC, `P-10`) is the thesis that whenever two of a thinker's thought tokens share the same content, the thinker can know *a priori* (by reflection alone) that they do. This bridge links [[Content Externalism]] (`P-40`) with unwitting co-reference cases (`P-50`, `P-51`), such as Kripke's Pierre (who does not realize "Londres" and "London" name the same city) or the Paderewski puzzle (where a thinker encounters one person as a pianist and as a politician without realizing they are the same man). Under non-Fregean externalism—where co-referential guises share the same environmentally determined ("wide") content—a thinker's inability to detect that co-reference from the armchair directly refutes TSC.

## Usage in Literature

Both [[Paul Boghossian]] in [[Boghossian 1994 - The Transparency of Mental Content]] and [[Jessica Brown]] in [[Brown 2004 - Anti-Individualism and Knowledge]] endorse `P-66` in `ARG-04` to derive the failure of TSC (`P-10`) from co-referential guise opacity (`P-50`, `P-51`). Boghossian illustrates the point using Kripke's Pierre ("London"/"Londres") and Loar's Paul ("cats"/"chats") to show that externalist content violates TSC, while Brown applies the same bridge to Rudolf/Paderewski cases as part of demonstrating that non-Fregean anti-individualism is incompatible with TSC.

### Participating Arguments
- [[Pierre and Paderewski Opacity vs. Transparency of Sameness]] (`ARG-04`, asserted)

## Assessment