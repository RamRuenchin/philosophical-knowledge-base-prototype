---
id: P-10
type: proposition
kind: thesis
title: Transparency of Sameness of Content
aliases:
- P-10
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: contested
sources:
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]]'
---

# Transparency of Sameness of Content (`P-10`)

## Formulation

Every thinker can know a priori, for every two same-content thought tokens of that thinker, that they have the same content.

## Explanation

Often abbreviated `TSC` (*transparency of sameness of content*), this thesis says that whenever two of your thoughts actually mean the same thing, you can tell purely from reflection—without checking the outside world—that they share the same content. It is tested by Kripke-style co-reference puzzles (such as Pierre, Paderewski, or Rudolf), where a rational thinker holds two unrecognized mental guises for a single city or person—like thinking of Paderewski the musician and Paderewski the statesman as two different men—and thus cannot tell from inside that both thoughts refer to the same individual. It is also challenged by Mahmoud Morvarid's slow-switched Oscar case, in which a thinker who unknowingly moved between Earth and Twin Earth infers `p or q` while his inward judgments about whether two thoughts share content have become unreliable—a failure Morvarid uses to attack J-factor accessibility (`JFA`, the internalist rule that every justified belief must have a justifying reason accessible by reflection).

## Inferential Relations
### Leads To
- Its negation (`~P-10`) structurally entails the negation of [[Full Comparative Epistemic Transparency Holds]] (`P-12`) and [[Strong Meaning Rationalism Holds]] (`P-20`).

### Led To By / Challenged By
- Structurally entailed by [[Full Comparative Epistemic Transparency Holds]] (`P-12`) and by the stronger [[Strong Meaning Rationalism Holds]] (`P-20`).

## Usage in Literature

Commonly abbreviated TSC and paired with [[Transparency of Difference of Content]] (`P-11`) as a conjunct of [[Full Comparative Epistemic Transparency Holds]] (`P-12`), `P-10` plays a dual dialectical role across the corpus. [[Jessica Brown]] unconditionally rejects `P-10` in [[Brown 2004 - Anti-Individualism and Knowledge]], using non-Fregean anti-individualism and Kripke-style Rudolf/Paderewski co-reference cases to refute TSC (`ARG-04`). [[Paul Boghossian]] (in [[Boghossian 1994 - The Transparency of Mental Content]] and [[Boghossian 2011 - The transparency of mental content revisited]]) treats `P-10` as a desideratum violated by pure wide externalism in `ARG-04`, feeding into his broader reductio of pure wide rationalizing explanation (`ARG-05`). [[Mahmoud Morvarid]] in [[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism]] derives `~P-10` conditionally ([[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism#Arguments]]) from [[Two-Concept Content Externalism]] (`P-41`) and a reliability constraint on Oscar's slow-switched sameness judgments, then leverages `~P-10` to show incompatibility with J-Factor Accessibility Holds ([[Morvarid 2021 - A new argument for the incompatibility of content externalism with justification internalism#Propositions]]).

### Participating Arguments
- [[Pierre and Paderewski Opacity vs. Transparency of Sameness]] (`ARG-04`, asserted)

## Assessment