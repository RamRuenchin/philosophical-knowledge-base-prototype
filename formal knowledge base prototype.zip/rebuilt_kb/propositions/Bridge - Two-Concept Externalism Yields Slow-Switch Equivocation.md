---
id: P-63
type: proposition
kind: bridge
title: Bridge - Two-Concept Externalism Yields Slow-Switch Equivocation
aliases:
- P-63
status_kind: sharpened
constituted_by:
- '[[Content-Preserving Memory and Slow-Switching Dynamics]]'
schools:
- '[[Content Externalism]]'
plausibility: medium
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
---

# Bridge - Two-Concept Externalism Yields Slow-Switch Equivocation (`P-63`)

## Formulation

If both (both some mental states have contents that constitutively depend on external environmental factors and slow switching produces two-concept cohabitation with originary memory fixation) and (possibly, a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise), then if a slow-switched thinker performs a subjectively valid syllogism combining a pre-switch memory premise with a post-switch experiential premise, then that thinker commits an introspectively undetectable equivocation between distinct wide contents.

## Explanation

This bridge connects *two-concept content externalism* (`P-41`)—the view that mental contents depend on one's external environment and that an unwitting traveler between Earth and Twin Earth retains pre-switch Earth concepts (*water*, *Pavarotti*) in [[Content-Preserving Memory and Slow-Switching Dynamics|memory]] while acquiring separate post-switch Twin-Earth concepts (*twater*, *Twin Pavarotti*) under the same words—to the equivocation verdict on Peter (`P-47`). If that two-concept model holds and Peter's slow-switching scenario is possible (`P-46`), then whenever Peter combines a pre-switch Earth memory with a post-switch Twin-Earth perception in a subjectively valid syllogism, he commits an introspectively undetectable equivocation between distinct environmentally determined ("wide") contents.

## Usage in Literature

[[Paul Boghossian]] endorses `P-63` in [[Boghossian 1992 - Externalism and Inference]] and [[Boghossian 1994 - The Transparency of Mental Content]] as a reductio lemma in `ARG-01`, arguing that causal memory retention and present-environment fixation jointly produce introspectively indistinguishable equivocation across Peter's premises. Both [[Jessica Brown]] in [[Brown 2004 - Anti-Individualism and Knowledge]] and [[John M. Collins]] in [[Collins 2008 - Content Externalism and Brute Logical Error]] also endorse `P-63` from within externalism: Brown accepts slow-switch equivocation as a genuine externalist consequence, and Collins systematically refutes the displacement (Tye), broadening (Heal), anaphoric (Schiffer/Burge), and enthymeme blocking strategies to vindicate `ARG-01`.

### Participating Arguments
- [[Slow-Switching Equivocation Derivation]] (`ARG-01`, asserted)

## Assessment