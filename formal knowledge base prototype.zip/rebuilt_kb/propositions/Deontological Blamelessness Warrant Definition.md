---
id: D-39
type: proposition
kind: definition
title: Deontological Blamelessness Warrant Definition
aliases:
- D-39
status_kind: sharpened
defines: '[[Inferential Warrant]]'
constituted_by:
- '[[Inferential Warrant]]'
plausibility: low
sources:
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
---

# Deontological Blamelessness Warrant Definition (`D-39`)

## Formulation
Inferential warrant denotes the mere cognitive or deontological blamelessness of a reasoner in executing an inference.

## Explanation
On this "epistemic deontologist" definition, a thinker earns inferential warrant for a conclusion simply by doing their subjective best and violating no intellectual duty, regardless of whether their reasoning method actually tends to produce valid arguments. Mikkel Gerken rejects this view—contrasting it with [[Competence Validity-Conduciveness Warrant Definition]] (`D-38`)—using his case of blameless Pete, who commits the gambler's fallacy through no personal fault yet still lacks inferential warrant because his reasoning exercises no validity-conducive competence.

**Defines:** [[Inferential Warrant]] (`C-11`)

## Usage in Literature

In [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]], [[Mikkel Gerken]] rejects `D-39` and its associated thesis Cognitive Blamelessness Suffices for Inferential Warrant ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Propositions]]) to prevent his competence-based account (`D-38`) from collapsing into permissive deontologism. Through Pete's gambler's fallacy case (Gambler Fallacy Refutation of Epistemic Deontologism ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Arguments]]); Pete Is Cognitively Blameless Yet Lacks Inferential Warrant ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Propositions]])), Gerken shows that a reasoner can be entirely blameless while still lacking inferential warrant because the fallacy exercises no validity-conducive competence.

## Assessment