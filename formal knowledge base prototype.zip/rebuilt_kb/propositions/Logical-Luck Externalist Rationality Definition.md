---
id: D-16
type: proposition
kind: definition
title: Logical-Luck Externalist Rationality Definition
aliases:
- D-16
status_kind: sharpened
defines: '[[Rationality and Inferential Normativity]]'
constituted_by:
- '[[Rationality and Inferential Normativity]]'
plausibility: contested
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Faria 2009 - Unsafe reasoning A survey]]'
---

# Logical-Luck Externalist Rationality Definition (`D-16`)

## Formulation
Rationality and inferential normativity denotes an externalist inferential normativity that tolerates environmental logical luck.

## Explanation
Just as externalists in epistemology accept that empirical knowledge depends partly on favorable environmental luck outside one's head, this definition accepts that avoiding equivocation in deductive reasoning can likewise depend on lucky environmental stability—such as not having been secretly switched from Earth to Twin Earth. On this view, discussed by Manuel Pérez Otero and Paulo Faria, tolerating "logical luck" and occasional non-culpable brute logical errors dissolves the demand for armchair guarantees of validity, though critics worry it gives up logic's special insulation from empirical accidents. Under this reading, [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) sharpens into [[Externalism Is Compatible with Logical-Luck Rationality]] (`P-28`).

**Defines:** [[Rationality and Inferential Normativity]] (`C-03`)

## Usage in Literature

[[Manuel Pérez Otero]] treats this logical-luck option as a plausible externalist reply in [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]], and [[Paulo Faria]] likewise treats it as a plausible path in [[Faria 2009 - Unsafe reasoning A survey]] when surveying unsafe reasoning and brute logical error (`P-93`).

## Assessment