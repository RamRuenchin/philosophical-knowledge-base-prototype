---
id: D-03
type: proposition
kind: definition
title: Qualified Contextual Transparency Definition
aliases:
- D-03
status_kind: sharpened
defines: '[[Transparency of Mental Content]]'
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: contested
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
---

# Qualified Contextual Transparency Definition (`D-03`)

## Formulation
Transparency of mental content denotes epistemic transparency qualified relative to the thinker's tacit contextual presuppositions and interpreter-relative content attribution.

## Explanation
Rather than demanding that a thinker always know from armchair reflection whether two thoughts share or differ in environmentally determined ("wide") meaning across every possible scenario, this definition makes transparency relative to what the thinker takes for granted in a given conversational or interpretive context. On Robert Stalnaker's approach, a slow-switched thinker unknowingly moved between Earth and Twin Earth still has transparent access to their thoughts relative to their unspoken assumption that their environment has not changed—though critics worry that tying content to tacit assumptions and outside interpretation is circular. Under this reading, [[Mental Content Is Epistemically Transparent]] (`P-02`) sharpens into [[Qualified Contextual Transparency Holds]] (`P-18`).

**Defines:** [[Transparency of Mental Content]] (`C-01`)

## Usage in Literature

[[Robert Stalnaker]] endorses this qualified contextual sharpening (as reconstructed and criticized in [[Boghossian 2011 - The transparency of mental content revisited]]), arguing that slow-switched thinkers retain transparency relative to their tacit presuppositions that their environment has not shifted. [[Paul Boghossian]] objects in [[Boghossian 2011 - The transparency of mental content revisited]] that relying on tacit presuppositions to preserve transparency is circular or renders content attribution unstable.

## Assessment