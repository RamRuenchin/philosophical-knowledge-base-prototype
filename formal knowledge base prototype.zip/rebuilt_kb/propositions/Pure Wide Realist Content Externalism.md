---
id: P-116
type: proposition
kind: theory
title: Pure Wide Realist Content Externalism
aliases:
- P-116
status_kind: sharpened
constituted_by:
- '[[Cognitive Value]]'
schools:
- '[[Content Externalism]]'
incompatible_with:
- P-117
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
- '[[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]]'
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Pure Wide Realist Content Externalism (`P-116`)

## Formulation

Both some mental states have contents that constitutively depend on external environmental factors and every genuine mental content entering psychological explanation is purely environmentally individuated without any explanatory level of narrow content.

## Explanation

This uncompromising version of [[Content Externalism]] (`S-01`)—often called *pure anti-individualism* or *pure wide intentional realism*—holds that the only genuine mental contents used to explain thought, inference, and action are "wide" contents fixed partly by a thinker's physical and social environment, with no separate internal ("narrow") layer of meaning inside the head. It directly rules out hybrid two-factor theories that add internal cognitive differentiators ([[Mixed Internal-External Content Externalism]], `P-117`) and contrasts with contextualist externalism ([[Contextualist Content Externalism]], `P-118`), making it the primary target of Paul Boghossian's slow-switching and transparency arguments.

## Inferential Relations
### Leads To
- Structurally entails [[Content Externalism Holds]] (`P-40`).
- Directly incompatible with [[Mixed Internal-External Content Externalism]] (`P-117`) (implies its negation).
- Defeasibly supports [[Wide Content Alone Suffices for Rationalizing Explanation]] (`P-54`) ([[Boghossian 1992 - Externalism and Inference]], [[Boghossian 2011 - The transparency of mental content revisited]]).
- Defeasibly challenges [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`) ([[Boghossian 1992 - Externalism and Inference]], [[Boghossian 2011 - The transparency of mental content revisited]]).

### Led To By / Challenged By
- Directly incompatible with [[Mixed Internal-External Content Externalism]] (`P-117`) (negated by it).
- Challenged by [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`) ([[Boghossian 1992 - Externalism and Inference]], [[Boghossian 2011 - The transparency of mental content revisited]]).

## Usage in Literature

[[Paul Boghossian]] targets pure wide realist content externalism in [[Boghossian 1992 - Externalism and Inference]] and [[Boghossian 2011 - The transparency of mental content revisited]], arguing that without an internal intentional or syntactic level it cannot sustain rationalizing explanation under slow switching (`ARG-05`). [[Jessica Brown]] ([[Brown 2004 - Anti-Individualism and Knowledge]]), [[John M. Collins]] ([[Collins 2008 - Content Externalism and Brute Logical Error]]), and [[Sanford C. Goldberg]] ([[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]], [[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification]], [[Goldberg-2008-Must Differences in Cognitive Value be Transparent]]) endorse `P-116` while accepting revisionary consequences for transparency, rationality norms, and discursive justification. [[Manuel Pérez Otero]] contrasts `P-116` with [[Mixed Internal-External Content Externalism]] (`P-117`) in [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]].

## Assessment
