---
id: P-22
type: proposition
kind: thesis
title: Form-Level APLA Holds
aliases:
- P-22
status_kind: sharpened
constituted_by:
- '[[A Priori Logical Abilities]]'
plausibility: high
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Form-Level APLA Holds (`P-22`)

## Formulation

Every thinker possesses a priori knowledge of abstract logical forms and validity schemas.

## Explanation

This thesis sharpens [[Thinkers Possess A Priori Logical Abilities]] (`P-03`) under [[Form-Level APLA Definition]] (`D-10`), where `APLA` stands for *a priori logical abilities*. It makes the modest, widely accepted claim that thinkers can recognize purely through reflection which *abstract logical patterns* are valid—for example, knowing that any argument of the shape "if p, then q; p; therefore q" is logically valid—without needing empirical information about what specific words refer to in the outside world. Manuel Pérez Otero emphasizes that content externalists can easily keep this form-level logical competence even if slow-switching cases (like Peter unknowingly moving from Earth to Twin Earth and mixing an Earth memory with a Twin Earth perception) force them to give up the much stronger token-level claim (`P-21`).

## Inferential Relations
### Led To By / Challenged By
- Structurally entailed by the stronger [[Token-Level Wide APLA Holds]] (`P-21`).

## Usage in Literature

This thesis sharpens [[Thinkers Possess A Priori Logical Abilities]] (`P-03`) via [[Form-Level APLA Definition]] (`D-10`). In [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]], [[Manuel Pérez Otero]] endorses Form-Level APLA as the modest core of a priori logical competence that remains intact even if externalists abandon the far stronger token-level thesis [[Token-Level Wide APLA Holds]] (`P-21`) in response to slow-switching cases. The exchange with [[Paul Boghossian]] in [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]] focuses not on disputing abstract form-level competence, but on whether narrow syntactic validity (`P-23`, `P-61`) or externalist replies better explain why switched Peter is rationally prepared to draw his concrete inference.

## Assessment