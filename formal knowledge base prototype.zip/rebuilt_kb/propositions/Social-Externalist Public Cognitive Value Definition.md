---
id: D-35
type: proposition
kind: definition
title: Social-Externalist Public Cognitive Value Definition
aliases:
- D-35
status_kind: sharpened
defines: '[[Cognitive Value]]'
constituted_by:
- '[[Cognitive Value]]'
plausibility: contested
sources:
- '[[Goldberg-2008-Must Differences in Cognitive Value be Transparent]]'
- '[[Gertler 2015 - Internalism, Externalism, and Accessibilism]]'
---

# Social-Externalist Public Cognitive Value Definition (`D-35`)

## Formulation
Cognitive value denotes a Fregean mode of presentation partly individuated by public linguistic standards and a thinker's semantic deference to their speech community.

## Explanation
This definition combines Frege's notion of cognitive value (the aspect of meaning that explains rational belief and doubt) with social content externalism by making shared public linguistic norms and a thinker's deference to experts and testimony partly constitutive of how they think of things. Endorsed by Sanford Goldberg along Tyler Burge's lines, it contrasts with purely internal narrow cognitive value ([[Narrow Fregean Cognitive Value Definition]], `D-34`) and allows Frege's differential-doubt test to survive even without Transparency of Difference of Content (TDC)—the armchair ability to always tell when two thoughts differ in meaning.

**Defines:** [[Cognitive Value]] (`C-10`)

## Usage in Literature

[[Sanford C. Goldberg]] endorses `D-35` in [[Goldberg-2008-Must Differences in Cognitive Value be Transparent]], building on [[Tyler Burge]]'s social anti-individualism to argue that semantic deference and testimonial communication entail [[Public Linguistic Standards Partly Determine Cognitive Value]] (`P-79`), allowing Frege's differential dubitability test to survive without [[Transparency of Difference of Content]] (`P-11`). [[Brie Gertler]] challenges this externalization of Fregean sense in [[Gertler 2015 - Internalism, Externalism, and Accessibilism]], arguing that Burge's public-method modification breaks the tight link between cognitive value and first-order rational sensitivity (`D-34`).

## Assessment