---
id: D-10
type: proposition
kind: definition
title: Form-Level APLA Definition
aliases:
- D-10
status_kind: sharpened
defines: '[[A Priori Logical Abilities]]'
constituted_by:
- '[[A Priori Logical Abilities]]'
plausibility: contested
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Form-Level APLA Definition (`D-10`)

## Formulation
A priori logical abilities denotes the a priori capacity to recognize abstract logical forms and validity schemas independently of empirical facts about co-reference.

## Explanation
On this more modest definition, a priori logical abilities (APLA) consist in grasping abstract logical patterns—for instance, knowing from armchair reflection that any inference of the form "All F are G; a is F; therefore a is G" is valid—without needing armchair certainty about whether two concrete thoughts actually refer to the same external thing. Manuel Pérez Otero defends this reading so content externalists can keep logical competence intact even when slow switching hides empirical differences in reference, contrasting it with [[Token-Level Wide APLA Definition]] (`D-09`) and [[Narrow-Syntactic APLA Definition]] (`D-11`). Under this reading, [[Thinkers Possess A Priori Logical Abilities]] (`P-03`) sharpens into [[Form-Level APLA Holds]] (`P-22`).

**Defines:** [[A Priori Logical Abilities]] (`C-02`)

## Usage in Literature

[[Manuel Pérez Otero]] endorses this sharpening in [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]] to preserve APLA (`P-22`) under content externalism while rejecting Boghossian's stronger token-level wide reading (`D-09`). [[Paul Boghossian]] engages this distinction in [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]], pressing whether form-level competence alone explains concrete rational preparedness without narrow syntax (`D-11`).

## Assessment