---
id: P-67
type: proposition
kind: bridge
title: Bridge - Comparative Superiority for Otero Reversal
aliases:
- P-67
status_kind: sharpened
constituted_by: []
schools:
- '[[Content Externalism]]'
plausibility: medium
sources:
- '[[Otero 2012 - Boghossian''s Inference Argument against Content Externalism Reversed]]'
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Bridge - Comparative Superiority for Otero Reversal (`P-67`)

## Formulation

If both (both (both (slow-switching puzzles arise neutrally for both content externalism and content internalism) and (same-content internalist accounts of slow switching strain standard semantic and ontological intuitions)) and (non-Millian content externalism incorporates every viable internal cognitive differentiator available to content internalism)) and (it is not the case that a priori sensitivity to narrow syntactic validity independently explains slow-switched thinkers' rational preparedness), then non-Millian content externalism has a strictly superior repertoire of replies to slow-switching puzzles compared to content internalism.

## Explanation

This bridge captures the comparative-dominance logic of Manuel Pérez Otero's reversal on slow-switched Peter (`P-46`, where Peter unknowingly moves from Earth to Twin Earth and reasons across an Earth memory and a Twin-Earth perception). If the puzzle confronts content externalism and content internalism equally (`P-58`), every same-content internalist solution strains ordinary semantic and ontological intuitions (`P-59`), *non-Millian* [[Content Externalism]] (externalism that includes internal cognitive modes alongside external reference) can adopt every workable internal differentiator (`P-60`), and *a priori* sensitivity to narrow syntactic validity fails to independently explain Peter's rational preparedness (`~P-61`), then non-Millian externalism comes out ahead with a strictly superior repertoire of replies (`P-57`).

## Usage in Literature

[[Manuel Pérez Otero]] endorses `P-67` in [[Otero 2012 - Boghossian's Inference Argument against Content Externalism Reversed]] to execute `ARG-07` by modus ponens and establish externalism's comparative advantage (`P-57`). In [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]], [[Paul Boghossian]] accepts the comparative framework encoded in `P-67` rather than disputing the bridge itself, blocking `ARG-07` via modus tollens by defending narrow syntactic validity (`P-61`) as a viable internalist explanation of Peter's rational preparedness.

### Participating Arguments
- [[Otero Comparative Reversal vs. Boghossian Narrow-Syntax Reply]] (`ARG-07`, asserted)

## Assessment