---
id: P-26
type: proposition
kind: thesis
title: Externalism Is Compatible with Blameless Identity-Sensitivity Rationality
aliases:
- P-26
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
plausibility: medium
sources:
- '[[Brown 2004 - Anti-Individualism and Knowledge]]'
- '[[Collins 2008 - Content Externalism and Brute Logical Error]]'
---

# Externalism Is Compatible with Blameless Identity-Sensitivity Rationality (`P-26`)

## Formulation

Content externalism is compatible with blameless identity-sensitivity rationality that permits non-culpable brute logical error.

## Explanation

This thesis sharpens [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) under [[Blameless Identity-Sensitivity Rationality Definition]] (`D-14`). Rather than treating rationality as an idealized "a priori logician" who can never unknowingly equivocate, it defines rationality as careful, blameless sensitivity to logical relations—allowing that an entirely rational thinker can still commit a non-culpable *brute logical error* (`P-93`, an introspectively undetectable invalidity) when placed in an abnormal externalist situation like slow switching from Earth to Twin Earth. Jessica Brown and John M. Collins use this revised norm to accept slow-switch equivocation candidly without abandoning content externalism, though critics like Mikkel Gerken object that mere blamelessness cannot separate abnormal warranted reasoning from blameless fallacies like the gambler's fallacy.

## Inferential Relations
### Led To By / Challenged By
- Supported by [[Traditional Norms of Logic and Rationality Must Be Refashioned]] (`P-94`), by rejecting [[Rational Inference Requires Comparative A Priori Transparency]] (`~P-13`), and as a fallback when [[Externalism Is Compatible with A Priori Conformity Rationality]] (`P-24`) fails ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]]).
- Defeasibly challenged by blameless-fallacy counterexamples (e.g., Gerken's Pete gambler's-fallacy case), which suggest mere cognitive blamelessness is too weak for inferential warrant ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]).

## Usage in Literature

In [[Brown 2004 - Anti-Individualism and Knowledge]], [[Jessica Brown]] endorses this thesis after accepting slow-switch equivocation (`P-47`) and refuting both Transparency of Sameness and Transparency of Difference: rather than abandoning anti-individualism, externalists should replace the idealized "a priori logician" model with refashioned norms (`P-94`) permitting blameless logical error. In [[Collins 2008 - Content Externalism and Brute Logical Error]], [[John M. Collins]] likewise defends the reality of brute logical error under content externalism (`P-93`) and treats this refashioned blameless-rationality model (`D-14`, `P-94`) as a serious candidate response while stopping short of settling how externalists should resolve the resulting dilemma over logical norms. [[Mikkel Gerken]] challenges this blamelessness-based model via Pete's gambler's-fallacy case in [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Arguments]], warning that it risks collapsing inferential warrant into mere epistemic deontologism.

## Assessment