---
id: P-90
type: proposition
kind: thesis
title: Unstructured Possible-Worlds Propositions Suffice Without Concepts
aliases:
- P-90
status_kind: sharpened
constituted_by:
- '[[Mental Representation Vehicle]]'
plausibility: low
sources:
- '[[Schroeter 2013 - Are Concepts Creatures of Darkness]]'
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
---

# Unstructured Possible-Worlds Propositions Suffice Without Concepts (`P-90`)

## Formulation

Unstructured possible-worlds propositions suffice for mental content attribution without minimalist person-level mental files.

## Explanation

This anti-representationalist thesis holds that we can explain what people think and believe using only unstructured possible-worlds propositions—identifying each thought's content simply with the set of possible worlds in which it is true ([[Unstructured Possible-Worlds Propositions Definition]], `D-43`)—without positing fine-grained concepts, Fregean modes of presentation, or mental files. To handle classic puzzles of rationality—such as Kripke's Pierre holding conflicting beliefs about London under the unrecognized guises "*Londres*" and "London," or Boghossian's slow-switched Peter combining an Earth memory with a Twin-Earth perception—proponents rely on context-sensitive content attribution and diagonalized propositions rather than structured mental vehicles.

## Inferential Relations
### Leads To
- Directly incompatible with **Externalist Semantics Requires Minimalist Mental Files** in [[Schroeter 2013 - Are Concepts Creatures of Darkness#Propositions]] (implies its negation).
- Directly challenges [[Fregeanism About Mental Content]] (`P-43`) and [[The Common View of Mental Content]] (`P-44`) by dispensing with Fregean modes of presentation and sub-propositional concepts ([[Boghossian 2011 - The transparency of mental content revisited]], [[Schroeter 2013 - Are Concepts Creatures of Darkness]]).

### Led To By / Challenged By
- Directly incompatible with **Externalist Semantics Requires Minimalist Mental Files** in [[Schroeter 2013 - Are Concepts Creatures of Darkness#Propositions]] (negated by it).

## Usage in Literature

As reconstructed via [[Schroeter 2013 - Are Concepts Creatures of Darkness]] and [[Boghossian 2011 - The transparency of mental content revisited]], [[Robert Stalnaker]] endorses `P-90` alongside [[Radical Interpreter-Relative Contextualism Holds]] (`P-33`), rejecting concepts as lingering Cartesian "creatures of darkness." [[Laura Schroeter]] rejects `P-90` in [[Schroeter 2013 - Are Concepts Creatures of Darkness]], arguing that unstructured sets of possible worlds cannot directly represent stable internal mind–mind relations (apparent *de jure* co-reference) and therefore force a fragmented "spot-check" picture of cognition ([[Schroeter 2013 - Are Concepts Creatures of Darkness#Arguments]]); [[Boghossian 2011 - The transparency of mental content revisited]] also examines Stalnaker's possible-worlds framework as a contextualist attempt to absorb slow-switching into diagonalized or tacit presuppositions.

## Assessment