---
id: P-24
type: proposition
kind: thesis
title: Externalism Is Compatible with A Priori Conformity Rationality
aliases:
- P-24
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 1992 - Reply to Schiffer]]'
- '[[Boghossian 1994 - The Transparency of Mental Content]]'
- '[[Schiffer 1992 - Boghossian on Externalism and Inference]]'
---

# Externalism Is Compatible with A Priori Conformity Rationality (`P-24`)

## Formulation

Content externalism is compatible with a priori logical-conformity rationality.

## Explanation

This thesis sharpens [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) under [[A Priori Logical-Conformity Rationality Definition]] (`D-12`), testing whether content externalism (the view that what your thoughts mean depends partly on your external environment and community) can satisfy Paul Boghossian's demanding standard of *a priori logical-conformity rationality* (called `B-rationality`). Under `B-rationality`, a thinker's reasoning counts as rational only if they have a priori inward access to the logical relations among their thoughts' externally fixed meanings. Boghossian denies compatibility because slow-switched Peter—who unknowingly moves from Earth to Twin Earth and combines a pre-switch Earth memory with a post-switch Twin Earth perception—commits an undetectable equivocation; defenders like Stephen Schiffer and Tyler Burge try to save compatibility by arguing that Peter's memory links back to the same concept (*anaphoric preservative memory*) or that his referential intentions keep his terms univocal.

## Inferential Relations
### Leads To
- Its negation (`~P-24`) motivates [[Traditional Norms of Logic and Rationality Must Be Refashioned]] (`P-94`) and fallback non-transparency externalist models of rationality—[[Externalism Is Compatible with Contingent-Form Rationality]] (`P-25`), [[Externalism Is Compatible with Blameless Identity-Sensitivity Rationality]] (`P-26`), [[Externalism Is Compatible with Competence-Based Rationality]] (`P-27`), [[Externalism Is Compatible with Logical-Luck Rationality]] (`P-28`), and [[Externalism Is Compatible with Dual Social-Material Rationality]] (`P-29`) ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]], [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]], [[Faria 2009 - Unsafe reasoning A survey]], [[de Sá Pereira 2019 - Dangerous Liaisons]]).

### Led To By / Challenged By
- Defeasibly supported by [[Peter Inference Remains Univocal via Anaphoric Memory]] (`P-49`), which blocks the primary slow-switching counterexample to a priori logical conformity ([[Schiffer 1992 - Boghossian on Externalism and Inference]], [[Boghossian 1994 - The Transparency of Mental Content]]).
- Challenged by [[Traditional Norms of Logic and Rationality Must Be Refashioned]] (`P-94`), which abandons the idealized a priori logical-conformity standard ([[Brown 2004 - Anti-Individualism and Knowledge]], [[Collins 2008 - Content Externalism and Brute Logical Error]]).

## Usage in Literature

[[Paul Boghossian]] rejects this thesis across [[Boghossian 1992 - Externalism and Inference]], [[Boghossian 1992 - Reply to Schiffer]], and [[Boghossian 1994 - The Transparency of Mental Content]], arguing that slow switching renders wide logical validity introspectively opaque and thereby forces externalists either to abandon B-rationality or to posit a non-wide intentional level. Conversely, [[Stephen Schiffer]] (in [[Schiffer 1992 - Boghossian on Externalism and Inference]]) and [[Tyler Burge]] (as reconstructed across [[Boghossian 1994 - The Transparency of Mental Content]] and later debates) endorse compatibility by arguing that univocal referential intent and anaphoric preservative memory (`P-49`, `P-56`) block slow-switch equivocation in Peter's inference—though [[Sanford C. Goldberg]] argues in [[Goldberg-2007-Anti-Individualism, Content Preservation, and Discursive Justification#Arguments]] that even anaphoric univocality shifts remembered content and undermines memorial justification preservation (`I2`).

## Assessment