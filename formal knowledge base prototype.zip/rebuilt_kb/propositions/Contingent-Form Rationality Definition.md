---
id: D-13
type: proposition
kind: definition
title: Contingent-Form Rationality Definition
aliases:
- D-13
status_kind: sharpened
defines: '[[Rationality and Inferential Normativity]]'
constituted_by:
- '[[Rationality and Inferential Normativity]]'
plausibility: contested
sources:
- '[[Schiffer 1992 - Boghossian on Externalism and Inference]]'
- '[[Boghossian 1992 - Reply to Schiffer]]'
---

# Contingent-Form Rationality Definition (`D-13`)

## Formulation
Rationality and inferential normativity denotes deductive-form justification that is compatible with contingent sameness of wide content across premises.

## Explanation
On this definition, an inference counts as rational so long as its premises actually fit a valid deductive pattern, even if the fact that two premise terms share the same environmentally determined ("wide") meaning is a contingent matter of external history and the thinker's intention to stay on the same topic rather than something guaranteed from armchair reflection. Stephen Schiffer uses this view to argue that slow-switched Peter's inference remains valid and rational without positing internal "narrow" contents, whereas Paul Boghossian objects that merely contingent sameness of meaning fails to explain why Peter's reasoning makes sense from his own perspective. Under this reading, [[Content Externalism Is Compatible with Rational Inference]] (`P-04`) sharpens into [[Externalism Is Compatible with Contingent-Form Rationality]] (`P-25`).

**Defines:** [[Rationality and Inferential Normativity]] (`C-03`)

## Usage in Literature

[[Stephen Schiffer]] endorses this sharpening in [[Schiffer 1992 - Boghossian on Externalism and Inference]] to defend externalism against [[Paul Boghossian]]'s 1992 slow-switching argument without positing narrow content, contending that Peter's univocal referential intent secures valid form. Boghossian challenges this move in [[Boghossian 1992 - Reply to Schiffer]], arguing that merely contingent sameness of wide content leaves a gap in rationalizing explanation.

## Assessment