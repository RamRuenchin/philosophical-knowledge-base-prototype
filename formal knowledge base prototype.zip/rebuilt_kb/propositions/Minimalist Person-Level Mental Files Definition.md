---
id: D-42
type: proposition
kind: definition
title: Minimalist Person-Level Mental Files Definition
aliases:
- D-42
status_kind: sharpened
defines: '[[Mental Representation Vehicle]]'
constituted_by:
- '[[Mental Representation Vehicle]]'
plausibility: contested
sources:
- '[[Schroeter 2013 - Are Concepts Creatures of Darkness]]'
---

# Minimalist Person-Level Mental Files Definition (`D-42`)

## Formulation
Mental representation vehicle denotes minimalist person-level mental files that functionally bind and segregate attitudes to underwrite apparent de jure co-reference without entailing Cartesian transparency.

## Explanation
This definition treats a thinker's concepts as minimalist, person-level "mental files"—functional dossiers that group beliefs together or keep them apart so that two thoughts immediately strike the thinker as being about the same thing by default (apparent *de jure* co-reference), without assuming infallible Cartesian self-knowledge. Laura Schroeter defends these files against [[Unstructured Possible-Worlds Propositions Definition]] (`D-43`) to explain why slow-switched Peter immediately treats his Earth memory and Twin-Earth perception as about the same water while Kripke's Pierre keeps his two unrecognized guises of London segregated in separate files.

**Defines:** [[Mental Representation Vehicle]] (`C-13`)

## Usage in Literature

[[Laura Schroeter]] endorses `D-42` in [[Schroeter 2013 - Are Concepts Creatures of Darkness]], arguing that [[Robert Stalnaker]]'s own contextualist explanations of Pierre and Peter covertly presuppose this person-level filing architecture and therefore support Externalist Semantics Requires Minimalist Mental Files ([[Schroeter 2013 - Are Concepts Creatures of Darkness#Propositions]]) over [[Unstructured Possible-Worlds Propositions Suffice Without Concepts]] (`P-90`).

## Assessment