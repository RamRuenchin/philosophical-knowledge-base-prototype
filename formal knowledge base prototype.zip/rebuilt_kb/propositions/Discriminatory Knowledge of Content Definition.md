---
id: D-26
type: proposition
kind: definition
title: Discriminatory Knowledge of Content Definition
aliases:
- D-26
status_kind: sharpened
defines: '[[Knowledge of Content]]'
constituted_by:
- '[[Knowledge of Content]]'
plausibility: contested
sources:
- '[[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]]'
---

# Discriminatory Knowledge of Content Definition (`D-26`)

## Formulation
Knowledge of content denotes the introspective ability to discriminate whether two thought tokens share or differ in content.

## Explanation
Discriminatory Knowledge of Content (DKC) is the comparative introspective ability to tell from the inside whether two separate thoughts express the same concept or different concepts—closely paralleling comparative transparency ([[Comparative A Priori Transparency Definition]], `D-01`) rather than isolated single-thought self-knowledge (Knowledge of Content Proper, or KC, [[Knowledge of Content Proper Definition]], `D-25`). Sanford Goldberg argues that anti-individualism undermines DKC and that this failure impairs truth-directed reasoning, illustrated by his "Pragmatist Sally" case in which Sally forgets whether a remembered claim used "pragmatist" in its philosophical or everyday sense and cannot resolve the ambiguity by introspection alone. Under this reading, [[Content Externalism Is Compatible with Introspective Knowledge of Content]] (`P-05`) sharpens into [[Externalism Is Compatible with Discriminatory Knowledge of Content]] (`P-31`).

**Defines:** [[Knowledge of Content]] (`C-06`)

## Usage in Literature

[[Sanford C. Goldberg]] introduces and endorses this sharpening as the dialectically relevant sense of content knowledge in [[Goldberg 1999 - The Relevance of Discriminatory Knowledge of Content]], arguing via his Pragmatist Sally case that anti-individualism is incompatible with DKC (`P-31`) and that failures of DKC genuinely affect truth-directed reasoning.

## Assessment