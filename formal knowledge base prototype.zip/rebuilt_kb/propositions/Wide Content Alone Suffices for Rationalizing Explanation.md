---
id: P-54
type: proposition
kind: thesis
title: Wide Content Alone Suffices for Rationalizing Explanation
aliases:
- P-54
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Schiffer 1992 - Boghossian on Externalism and Inference]]'
incompatible_with:
- P-55
---

# Wide Content Alone Suffices for Rationalizing Explanation (`P-54`)

## Formulation

Wide content alone suffices for rationalizing psychological explanation.

## Explanation

"Wide content" is mental content fixed in part by a thinker's external physical or social environment (so thoughts about Earth's water and Twin Earth's chemically distinct "twater" have different wide contents). This thesis claims that wide content by itself is sufficient for *rationalizing psychological explanation*—accounting for why a person's beliefs, desires, and inferences make rational sense from their own perspective—without needing any purely internal ("narrow") content or extra psychological mode of presentation.

**Direct incompatibility:** Directly incompatible with [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`).

## Inferential Relations
### Leads To
- Directly incompatible with [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`) (implies its negation).

### Led To By / Challenged By
- Directly incompatible with [[Rationalizing Explanation Requires a Non-Wide Intentional Level]] (`P-55`) (negated by it).

## Usage in Literature

[[Paul Boghossian]] rejects `P-54` in [[Boghossian 1992 - Externalism and Inference]] via `ARG-05`: because slow-switched Peter's wide-content premises refer to distinct entities (Pavarotti and Twin Pavarotti) yet his practical reasoning genuinely rationalizes his intention from his point of view, pure wide content fails to capture his rationality and collapses as a sole basis for rationalizing explanation. [[Stephen Schiffer]] endorses `P-54` in [[Schiffer 1992 - Boghossian on Externalism and Inference]], blocking Boghossian's inference to the best explanation for narrow content by arguing both that univocal referential intent prevents equivocation (`P-56`) and that Peter's epistemic justification is adequately explained by his reasoning instantiating a deductive logical form guaranteed to succeed but for undetectable externalist contingencies (`P-25`).

### Participating Arguments
- [[Collapse of Pure Wide Rationalizing Explanation]] (`ARG-05`, asserted)

## Assessment