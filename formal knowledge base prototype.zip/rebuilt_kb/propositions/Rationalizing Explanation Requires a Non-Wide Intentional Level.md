---
id: P-55
type: proposition
kind: thesis
title: Rationalizing Explanation Requires a Non-Wide Intentional Level
aliases:
- P-55
status_kind: sharpened
constituted_by:
- '[[Rationality and Inferential Normativity]]'
schools:
- '[[Content Externalism]]'
plausibility: contested
sources:
- '[[Boghossian 1992 - Externalism and Inference]]'
- '[[Boghossian 1992 - Reply to Schiffer]]'
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
incompatible_with:
- P-54
---

# Rationalizing Explanation Requires a Non-Wide Intentional Level (`P-55`)

## Formulation

Both rationalizing psychological explanation requires a non-wide intentional or syntactic level and it is not the case that wide content alone suffices for rationalizing psychological explanation.

## Explanation

Because environmentally determined ("wide") contents can diverge without a thinker noticing—as when slow-switched Peter unknowingly combines an Earth memory of water or Pavarotti with a Twin-Earth perception of "twater" or Twin Pavarotti (`P-46`)—wide content alone fails to explain why the thinker's reasoning makes rational sense from their own point of view. This thesis claims that rationalizing psychological explanation therefore requires a non-wide level of description—such as purely internal ("narrow") content, a psychological mode of presentation, or narrow mental syntax—and that wide content alone is not enough.

**Direct incompatibility:** Directly incompatible with [[Wide Content Alone Suffices for Rationalizing Explanation]] (`P-54`).

## Inferential Relations
### Leads To
- Directly incompatible with [[Wide Content Alone Suffices for Rationalizing Explanation]] (`P-54`) (implies its negation).

### Led To By / Challenged By
- Directly incompatible with [[Wide Content Alone Suffices for Rationalizing Explanation]] (`P-54`) (negated by it).
- Defeasibly supported by [[Narrow Syntactic Validity Explains Peter Rational Preparedness]] (`P-61`), which offers a concrete non-wide syntactic level to rationalize slow-switched Peter ([[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]]).

## Usage in Literature

[[Paul Boghossian]] endorses `P-55` across [[Boghossian 1992 - Externalism and Inference]], [[Boghossian 1992 - Reply to Schiffer]], and [[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]], arguing first that traveler Peter and his unswitched counterfactual duplicate share the same rationalizing reasons despite diverging wide contents, and later appealing specifically to narrow syntactic validity (`P-61`) to explain Peter's rational preparedness. [[Stephen Schiffer]] rejects `P-55` in [[Schiffer 1992 - Boghossian on Externalism and Inference]], contending that univocal referential intent prevents equivocation (`P-56`) and that contingent-form rationality explains Peter's justification without introducing narrow content.

## Assessment