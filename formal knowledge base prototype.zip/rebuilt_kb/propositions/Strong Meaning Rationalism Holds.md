---
id: P-20
type: proposition
kind: thesis
title: Strong Meaning Rationalism Holds
aliases:
- P-20
status_kind: sharpened
constituted_by:
- '[[Transparency of Mental Content]]'
plausibility: low
sources:
- '[[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]'
---

# Strong Meaning Rationalism Holds (`P-20`)

## Formulation

Every thinker has an infallible a priori grasp of concept identity, difference, univocity, and non-emptiness purely from within.

## Explanation

Sharpening [[Mental Content Is Epistemically Transparent]] (`P-02`) under [[Strong Meaning Rationalism Definition]] (`D-05`), this thesis states the demanding Cartesian doctrine known as *Strong Meaning Rationalism* (`SMR`). It holds that purely from inward reflection—without any empirical check—every thinker infallibly knows four things about their own concepts: whether any two concepts are the same or different (even across time), whether a concept has a single unambiguous meaning (univocity), and whether it genuinely refers to something real rather than being empty. Both Ruth Garrett Millikan and Tadeusz Szubka reject `SMR`, since content externalism shows that you cannot guarantee from inside your head alone that your concepts stay unchanged over time or pick out real external things.

## Inferential Relations
### Leads To
- Structurally entails [[Full Comparative Epistemic Transparency Holds]] (`P-12`) (and thereby [[Transparency of Sameness of Content]] (`P-10`) and [[Transparency of Difference of Content]] (`P-11`)).
- Directly incompatible with **Strict Priority of the Third-Person Viewpoint Holds** in [[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content#Propositions]] ([[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]).

### Led To By / Challenged By
- Directly refuted by the negation of [[Full Comparative Epistemic Transparency Holds]] (`P-12`), [[Transparency of Sameness of Content]] (`P-10`), or [[Transparency of Difference of Content]] (`P-11`).
- Defeasibly challenged by [[Content Externalism Holds]] (`P-40`), which undermines infallible purely internal grasp of concept identity, difference, and non-emptiness ([[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]]).

## Usage in Literature

In [[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content]], both [[Ruth Garrett Millikan]] (as reconstructed by Szubka) and [[Tadeusz Szubka]] reject Strong Meaning Rationalism: Millikan argues that externalism eliminates this "last myth of the given," and Szubka concedes that externalism defeats it (noting that a priori givenness of non-emptiness would yield an implausibly easy refutation of external-world skepticism). Szubka instead uses its falsity (`~P-20`) inside Szubka Warrant-Based A Priori Without Strong Meaning Rationalism ([[Szubka 2000 - Meaning Rationalism, A Priori, and Transparency of Content#Arguments]]) to show that warrant-based a priori knowledge of logical possibilities survives without Strong Meaning Rationalism.

## Assessment