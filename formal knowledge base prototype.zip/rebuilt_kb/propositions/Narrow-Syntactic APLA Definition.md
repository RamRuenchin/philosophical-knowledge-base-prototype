---
id: D-11
type: proposition
kind: definition
title: Narrow-Syntactic APLA Definition
aliases:
- D-11
status_kind: sharpened
defines: '[[A Priori Logical Abilities]]'
constituted_by:
- '[[A Priori Logical Abilities]]'
plausibility: contested
sources:
- '[[Boghossian 2014 - Reply to Otero''s Boghossian''s Inference Argument against Content Externalism Reversed]]'
---

# Narrow-Syntactic APLA Definition (`D-11`)

## Formulation
A priori logical abilities denotes a priori sensitivity to narrow syntactic or psychological-mode logical form that explains a thinker's rational preparedness to draw inferences.

## Explanation
This definition locates a thinker's a priori logical abilities (APLA) in their armchair sensitivity to internal mental syntax or "narrow" psychological form—features inside the head that do not depend on the external environment. Paul Boghossian introduces this reading to press a challenge against externalists: even if thinkers know abstract logic schemas ([[Form-Level APLA Definition]], `D-10`), explaining why slow-switched Peter is concretely prepared to draw an inference from a mixed Earth memory and Twin-Earth perception seems to require internal syntactic vehicles that pure wide externalism refuses to posit. Under this reading, [[Thinkers Possess A Priori Logical Abilities]] (`P-03`) sharpens into [[Narrow-Syntactic APLA Holds]] (`P-23`).

**Defines:** [[A Priori Logical Abilities]] (`C-02`)

## Usage in Literature

[[Boghossian 2014 - Reply to Otero's Boghossian's Inference Argument against Content Externalism Reversed]] introduces this narrow-syntactic framing in replying to Otero, arguing that while [[Paul Boghossian]] holds that narrow syntactic validity explains Peter's rational preparedness (`P-61`), pure wide externalism cannot avail itself of that narrow level without conceding internalist explanatory resources.

## Assessment