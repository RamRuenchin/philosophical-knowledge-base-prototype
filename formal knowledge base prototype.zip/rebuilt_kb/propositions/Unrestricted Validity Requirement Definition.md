---
id: D-37
type: proposition
kind: definition
title: Unrestricted Validity Requirement Definition
aliases:
- D-37
status_kind: sharpened
defines: '[[Inferential Warrant]]'
constituted_by:
- '[[Inferential Warrant]]'
plausibility: contested
sources:
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
---

# Unrestricted Validity Requirement Definition (`D-37`)

## Formulation
Inferential warrant denotes a requirement of actual deductive validity for every token of purportedly deductive reasoning that confers conditional warrant on its conclusion.

## Explanation
Inferential warrant is the epistemic support a deductive argument gives its conclusion (conditional on the premises being warranted). This strict classical definition insists that a particular step of deductive reasoning confers warrant only if it is actually, factually ("de facto") logically valid—even without demanding introspective transparency—which contrasts with competence-based warrant ([[Competence Validity-Conduciveness Warrant Definition]], `D-38`) and mere subjective blamelessness ([[Deontological Blamelessness Warrant Definition]], `D-39`), and is the exact premise Mikkel Gerken shows drives an anti-externalist validity argument from slow switching.

**Defines:** [[Inferential Warrant]] (`C-11`)

## Usage in Literature

In [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]], [[Mikkel Gerken]] formulates this definition as the traditional left-to-right half of the classical biconditional on inferential warrant and shows how it drives the Validity Argument against anti-individualism without invoking transparency (Gerken Validity Argument Against Anti-Individualism ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Arguments]])). Gerken ultimately rejects `D-37` and its associated thesis Unrestricted Validity Requirement on Inferential Warrant ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Propositions]]), arguing that anti-individualism combined with fallible cognitive competencies supports Competence-Based Conditional Warrant Without Token Validity ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Propositions]]).

## Assessment