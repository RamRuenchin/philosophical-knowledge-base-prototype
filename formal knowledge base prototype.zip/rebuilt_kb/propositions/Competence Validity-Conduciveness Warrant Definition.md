---
id: D-38
type: proposition
kind: definition
title: Competence Validity-Conduciveness Warrant Definition
aliases:
- D-38
status_kind: sharpened
defines: '[[Inferential Warrant]]'
constituted_by:
- '[[Inferential Warrant]]'
plausibility: contested
sources:
- '[[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]]'
---

# Competence Validity-Conduciveness Warrant Definition (`D-38`)

## Formulation
Inferential warrant denotes epistemic warrant conferred by exercising a reasoning competence that is reliably validity-conducive in normal environments, even when abnormal slow switching renders a particular reasoning token invalid.

## Explanation
Paired with [[Competence-Based Normal-Environment Rationality Definition]] (`D-15`), Mikkel Gerken's competence-based definition holds that a deductive inference warrants its conclusion whenever it exercises a cognitive skill—such as keeping concepts uniform across premises—that reliably yields valid reasoning in normal environments, even if an abnormal event like undetectable slow switching makes one specific step equivocate. This avoids both the brittleness of demanding actual validity on every single token ([[Unrestricted Validity Requirement Definition]], `D-37`) and the permissiveness of treating mere blamelessness as sufficient ([[Deontological Blamelessness Warrant Definition]], `D-39`), since blameless Pete committing the gambler's fallacy still lacks a validity-conducive competence.

**Defines:** [[Inferential Warrant]] (`C-11`)

## Usage in Literature

[[Mikkel Gerken]] endorses `D-38` in [[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning]] to dissolve Gerken Validity Argument Against Anti-Individualism ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Arguments]]) while preserving both anti-individualism and Peter's inferential warrant (Competence-Based Conditional Warrant Without Token Validity ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Propositions]])). Gerken distinguishes `D-38` from epistemic deontologism by showing via Pete's gambler's fallacy that cognitive blamelessness alone fails to yield warrant because it lacks a validity-conducive competence (Gambler Fallacy Refutation of Epistemic Deontologism ([[Gerken 2011 - Conceptual Equivocation and Warrant by Reasoning#Arguments]])).

## Assessment