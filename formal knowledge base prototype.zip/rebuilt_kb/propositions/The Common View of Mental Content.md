---
id: P-44
type: proposition
kind: theory
title: The Common View of Mental Content
aliases:
- P-44
status_kind: sharpened
constituted_by:
- '[[Cognitive Value]]'
schools:
- '[[Content Externalism]]'
- '[[Fregeanism and Mental-File Semantics]]'
conjuncts:
- P-42
- P-43
plausibility: contested
sources:
- '[[Boghossian 2011 - The transparency of mental content revisited]]'
---

# The Common View of Mental Content (`P-44`)

## Formulation

Both intentional states have determinate, interpreter-independent representational contents and mental contents are individuated by Fregean modes of presentation rather than solely by external objects and properties.

## Explanation

Paul Boghossian coined *The Common View of Mental Content* to name the standard two-part framework shared by most participants in Twin Earth debates before Robert Stalnaker's contextualist challenge. In plain terms, it combines two claims: first, that beliefs and thoughts have definite, objective meanings independent of any outside interpreter's shifting goals (`P-42`); and second, that thoughts are distinguished by *Fregean modes of presentation*—the specific ways objects are conceived by the thinker, not merely the bare external objects themselves (`P-43`). Isolating this package clarifies that Stalnaker's contextualist escape from transparency puzzles works by rejecting both halves of this background picture rather than merely tinkering with externalism.

### Conjuncts
- [[Intentional Realism]] (`P-42`)
- [[Fregeanism About Mental Content]] (`P-43`)

## Inferential Relations
### Leads To
- Structurally entails [[Intentional Realism]] (`P-42`) and [[Fregeanism About Mental Content]] (`P-43`).
- Directly incompatible with [[Radical Interpreter-Relative Contextualism Holds]] (`P-33`) (via its conjunct `P-42`).

### Led To By / Challenged By
- Directly refuted by the negation of either [[Intentional Realism]] (`P-42`) or [[Fregeanism About Mental Content]] (`P-43`).
- Directly incompatible with [[Radical Interpreter-Relative Contextualism Holds]] (`P-33`) and directly challenged by [[Unstructured Possible-Worlds Propositions Suffice Without Concepts]] (`P-90`) ([[Boghossian 2011 - The transparency of mental content revisited]], [[Schroeter 2013 - Are Concepts Creatures of Darkness]]).

## Usage in Literature

In [[Boghossian 2011 - The transparency of mental content revisited]], [[Paul Boghossian]] endorses the Common View and argues that [[Robert Stalnaker]]'s contextualist dissolution of transparency puzzles works only by rejecting this background theory rather than anti-individualism itself. As reconstructed across [[Boghossian 2011 - The transparency of mental content revisited]], [[Schroeter 2013 - Are Concepts Creatures of Darkness]], and [[Jackman 2015 - Externalism, metasemantic contextualism, and self-knowledge]], Stalnaker rejects both conjuncts of the Common View in favor of radical interpreter-relative contextualism (`P-33`) and unstructured possible-worlds propositions (`P-90`).

## Assessment