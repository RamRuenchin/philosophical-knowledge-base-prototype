# Rebuilt Formal Philosophy Knowledge Base

This directory is a **standalone**, formally checkable Obsidian-ready Philosophy Knowledge Base prototype (v4) for the topic **[[Does rational inference require transparency of mental content]]** (`T-01`), bundling all `21` raw PDFs (`raw_sources/`), all `21` converted Markdown transcriptions (`converted_markdown/`), and `21` structured individual literature summaries (`summaries/`, including the adjacent extended-cognition vehicle-transparency paper [[Hauser-Naeem-2024-Phenomenal Transparency and the Boundary of Cognition]]). You can open `rebuilt_kb/` directly as its own Obsidian vault.

## Structure & Counts (v4)
All live counts below are verified by [ENGINE_REPORT.md](ENGINE_REPORT.md) (`138` compiled hard CNF clauses, `SAT`, `17/17` authors consistent, `8/8` arguments minimal, exact Global MaxSAT `90.0/90.0`):

- `concepts/` (`8` pure sub-propositional concepts: `C-01`, `C-02`, `C-03`, `C-05`, `C-06`, `C-10`, `C-11`, `C-13`) — promoted cross-source or partition-completing sub-propositional terms/predicates (`C-NN`)
- `schools/` (`4` schools: `S-01`–`S-04` — [[Content Externalism]], [[Justification Internalism]], [[Metasemantic Contextualism]], [[Fregeanism and Mental-File Semantics]]) — non-truth-apt broad philosophical research programs, methodologies, and camps (evaluated as flourishing vs. strained, NEVER compiled into SAT)
- `propositions/` (`98`: `31` definitions + `67` non-definitions, including `6` umbrella propositions and `3` direct pairwise `incompatible_with` pairs) — promoted cross-source or partition-completing definitions (`D-NN`) and non-definition propositions (`P-NN`: concept-induced dict-style and direct list-style umbrellas, sharpened theses, theories, thought-experiment setups/verdicts, single-purpose substantive bridges, optional `schools:` program links, and symmetric `incompatible_with` pairs)
- `arguments/` (`8`) — promoted cross-source readable argument notes (`ARG-NN`), each storing a strictly minimal, single-purpose directionless tautology (`inconsistent_literals`) in YAML frontmatter alongside its inconsistent-literal-set formulation, plain-language philosophical gist, canonical `CSOML-S5` reconstruction plus premise rejections/replies, and bare assessment
- `topics/` (`1`, with hybrid layered dialectical web PNG in `topics/_media/`) — picture-based erotetic problem spaces pairing an embedded 2D web (`![[does-rational-inference-require-transparency-of-mental-content-web.png|2400]]`) + legend with central question, round-by-round dialectical map across works, camps & schools breakdown, and bare assessment (`T-NN`)
- `authors/` (`17`) — categorical synchronic commitments (`endorses`/`rejects`), argument invocations (`invokes_arguments`), and non-categorical body `## Other Attitudes` (outside Hard CNF; `finds_plausible` disallowed) (`A-NN`)
- `summaries/` (`21`) — structured 7-section individual literature summaries (`Abstract`, `Main Summary`, `Relevant Literature`, compact `Concepts`/`Propositions`/`Arguments`, bare `Assessment`), each linking to both its raw PDF in `raw_sources/` and its converted Markdown in `converted_markdown/`
- `raw_sources/` (`21` PDFs) — standalone copies of all 21 raw source PDFs
- `converted_markdown/` (`21` sources: `20` single `.md` papers + `1` chaptered book folder for [[Brown 2004 - Anti-Individualism and Knowledge]]) — standalone copies of all 21 converted Markdown transcriptions

## Structured Note Body Convention (v4)
Notes in `concepts/`, `schools/`, `propositions/`, `arguments/`, `topics/`, and `summaries/` follow strict H2 (`## `) sequences (all internal subsections use `### `; see [../SCHEMA.md](../SCHEMA.md)):
- **`concepts/` and `arguments/`:** strictly `["Formulation", "Usage in Literature", "Assessment"]` or `["Formulation", "Explanation", "Usage in Literature", "Assessment"]`.
- **`propositions/`:** strictly `Formulation` → optional `Explanation` → optional `Inferential Relations` → `Usage in Literature` → `Assessment`.
- **`schools/`:** strictly `Guiding Idea` *(non-empty)* → `Core Apparatus` → `Development Across Literature` → `Assessment` *(bare empty heading)*.
- **`topics/`:** strictly `Picture` *(embedded image in `topics/_media/` + concise legend; NO Mermaid map)* → `Central Question` → `Dialectical Map` *(round-by-round literature exchanges + verbal vs. substantive fault lines)* → `Camps and Schools` *(linking `[[School]]` + authors)* → `Assessment` *(bare empty heading)*.
- **`summaries/`:** strictly `Abstract` → `Main Summary` *(full section-by-section narrative; `###` divisions)* → `Relevant Literature` → `Concepts` *(1-line wikilinks only for promoted wiki items; 1-sentence pure Formulation only for single-source items)* → `Propositions` *(1-line wikilink + stance `endorses`/`rejects`/`conditional`/`discusses` + locator only for promoted items; label + stance + 1-sentence pure `CSOML-S5` Formulation only for single-source items)* → `Arguments` *(1-line wikilink + role + locator only for promoted items; `### <Title> *(locator)*` + numbered `CSOML-S5` derivation only for single-source items)* → `Assessment` *(bare empty heading)*.

Section roles (`concepts/`, `propositions/`, `arguments/`):
1. `## Formulation` *(required, non-empty)* — pure minimal content only: definition/neutral characterization for concepts; one canonical `CSOML-S5` controlled-natural-language sentence (no `◇S:`/`S □-> V:` prefixes) for propositions; or ``- **Inconsistent literal set:** `¬(L_1 ∧ ... ∧ L_k)` `` (no equivalent CNF clause line) plus verbatim participating proposition formulations (marking asserted vs. negated) for arguments.
2. `## Explanation` *(optional)* — accessible plain-language "gist" understandable without reading any other note (unpacking jargon, acronyms, and cases in plain English; on propositions, also hosts `### Disambiguation Sharpenings` for umbrellas and `**Defines:**` for definitions; for arguments, the substantive philosophical gist of why the claims collide—never a syntactic proof-rule recital).
3. `## Inferential Relations` *(optional; `propositions/` ONLY)* — strictly **1-to-1 proposition-to-proposition inferential relations** (what single proposition `P` or `¬P` usually leads to, and what single proposition usually leads to `P` or `¬P`: direct structural unpacking, direct 1-to-1 incompatibilities, and 1-to-1 non-deductive evidential/heuristic support, citing literature only when non-obvious). Never include sharpenings/disambiguations (use `## Explanation`) or multi-proposition arguments (`ARG-NN` / multi-premise summary arguments belong in `## Usage in Literature`); omit completely when none exist.
4. `## Usage in Literature` *(required)* — sourced dialectical prose. For Propositions, lists multi-proposition arguments (`ARG-NN` or multi-premise summary arguments, e.g., under `### Participating Arguments`). For Arguments, defaults to one canonical `CSOML-S5` formal reconstruction (`### Classical Argument`) in the direction actually argued in the literature followed by `### Premise Rejections and Replies`, adding a second formal derivation only when an actual author in the corpus genuinely argues in the reverse direction.
5. `## Assessment` *(required; bare/empty during ingestion and rebuilding)* — stays empty during ingestion/rebuilding (0 warnings); reserved for research-heavy skills (`**AI assessment (YYYY-MM-DD):**`) and user notes (`**User:**`).

## Reading Sections via CLI
Use `scripts/kb_engine.py --read` to extract only the needed part without running the full SAT/MaxSAT suite (`--part`: `frontmatter`, `formulation`, `explanation`, `inferences`, `formulation+explanation`, `formulation+explanation+inferences`, `usage`, `assessment`, `all`; default `formulation`; on `schools/`, `formulation` → `Guiding Idea`, `explanation` → `Core Apparatus`, `usage` → `Development Across Literature`, `assessment` → `Assessment`):

```bash
# Read pure Formulation sections of specific notes (IDs, file paths, or category keywords)
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read P-01,ARG-01,C-01 --part formulation

# Read Schools (Guiding Idea by default, or full note with --part all)
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read schools --part formulation
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read S-01 --part all

# Read Formulation + optional Explanation (+ optional Inferential Relations on propositions)
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read P-01,C-01 --part formulation+explanation
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read P-01 --part inferences
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read P-01 --part formulation+explanation+inferences

# Read an Argument's Formulation with all referenced proposition pure Formulations inlined (no Explanations)
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read ARG-01 --part formulation --expand-formulation

# Read all Concept Formulations, or inspect another part
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read concepts --part formulation
python3 scripts/kb_engine.py --kb rebuilt_kb/ --read ARG-01 --part usage
```

## Formal Diagnostics
See [ENGINE_REPORT.md](ENGINE_REPORT.md) and [engine_report.json](engine_report.json) generated by `scripts/kb_engine.py`.
