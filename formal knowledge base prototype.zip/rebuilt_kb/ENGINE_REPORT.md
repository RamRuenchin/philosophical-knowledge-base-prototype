# Formal Philosophy KB Engine Report

**Counts:** 8 concepts, 4 schools, 98 propositions (31 definitions, 6 umbrella), 8 arguments, 3 direct incompatibilities, 1 topics, 17 authors, 21 summaries, 21 raw sources, 21 converted markdown.

## 1. Validation: PASS

## 2. Global Hard-CNF Consistency: SAT
- Compiled hard clauses: `138` across `98` propositions.
- Witness sharpening: `{'C-01': ['D-07'], 'C-02': ['D-10'], 'C-03': ['D-16'], 'C-05': ['D-23'], 'C-06': ['D-25'], 'C-10': ['D-35'], 'C-11': ['D-38'], 'C-13': ['D-42']}`

## 3. Supervaluationist Determinate Entailment
- Assumptions: `[]` (consistent: `True`)
- Determinately True (0): `[]`
- Determinately False (0): `[]`
- Indeterminate (98): `98` propositions
- Umbrella breakdown by sharpening:
  - `P-01`: `{'D-01': 'INDET', 'D-06': 'INDET', 'D-07': 'INDET', 'D-08': 'INDET'}`
  - `P-02`: `{'D-01': 'INDET', 'D-02': 'INDET', 'D-03': 'INDET', 'D-04': 'INDET', 'D-05': 'INDET'}`
  - `P-03`: `{'D-09': 'INDET', 'D-10': 'INDET', 'D-11': 'INDET'}`
  - `P-04`: `{'D-12': 'INDET', 'D-13': 'INDET', 'D-14': 'INDET', 'D-15': 'INDET', 'D-16': 'INDET', 'D-17': 'INDET'}`
  - `P-05`: `{'D-25': 'INDET', 'D-26': 'INDET'}`
  - `P-06`: `{'P-32': 'INDET', 'P-33': 'INDET', 'P-34': 'INDET'}`

## 4. Per-Author Consistency
- **A-01 (Paul Boghossian)**: CONSISTENT (34 commitments); forced sharpenings: `{'C-01': 'D-01', 'C-02': 'D-09', 'C-03': 'D-12', 'C-05': 'D-21'}`
- **A-02 (Stephen Schiffer)**: CONSISTENT (13 commitments); forced sharpenings: `{'C-03': 'D-13', 'C-05': 'D-22'}`
- **A-03 (Manuel Pérez Otero)**: CONSISTENT (11 commitments); forced sharpenings: `{'C-02': 'D-10'}`
- **A-04 (Robert Stalnaker)**: CONSISTENT (13 commitments); forced sharpenings: `{'C-01': 'D-03', 'C-13': 'D-43'}`
- **A-05 (Tyler Burge)**: CONSISTENT (16 commitments); forced sharpenings: `{'C-01': 'D-02', 'C-03': 'D-12', 'C-05': 'D-22', 'C-06': 'D-25', 'C-10': 'D-35'}`
- **A-06 (Sanford C. Goldberg)**: CONSISTENT (12 commitments); forced sharpenings: `{'C-05': 'D-21', 'C-06': 'D-26', 'C-10': 'D-35'}`
- **A-07 (Henry Jackman)**: CONSISTENT (8 commitments); forced sharpenings: `{'P-06': 'P-32'}`
- **A-08 (Mahmoud Morvarid)**: CONSISTENT (0 commitments); forced sharpenings: `{}`
- **A-09 (Laura Schroeter)**: CONSISTENT (6 commitments); forced sharpenings: `{'C-13': 'D-42'}`
- **A-10 (Tadeusz Szubka)**: CONSISTENT (5 commitments); forced sharpenings: `{'C-01': 'D-04'}`
- **A-11 (Ruth Garrett Millikan)**: CONSISTENT (5 commitments); forced sharpenings: `{'C-01': 'D-05'}`
- **A-12 (Jessica Brown)**: CONSISTENT (32 commitments); forced sharpenings: `{'C-01': 'D-01', 'C-03': 'D-14', 'C-05': 'D-21', 'C-10': 'D-36'}`
- **A-13 (John M. Collins)**: CONSISTENT (16 commitments); forced sharpenings: `{'C-01': 'D-01', 'C-05': 'D-21'}`
- **A-14 (Paulo Faria)**: CONSISTENT (4 commitments); forced sharpenings: `{}`
- **A-15 (Mikkel Gerken)**: CONSISTENT (14 commitments); forced sharpenings: `{'C-01': 'D-03', 'C-03': 'D-15', 'C-05': 'D-21', 'C-11': 'D-38'}`
- **A-16 (Brie Gertler)**: CONSISTENT (9 commitments); forced sharpenings: `{'C-01': 'D-06', 'C-10': 'D-34'}`
- **A-17 (Roberto Horácio de Sá Pereira)**: CONSISTENT (7 commitments); forced sharpenings: `{'C-01': 'D-08', 'C-03': 'D-17'}`

## 5. Verbal-Dispute Detector
- **VERBAL DISPUTE (local_verbal) on `P-04` (Content Externalism Is Compatible with Rational Inference)**: A-01 (rejects, defs `{'C-03': ['D-12']}`, entails `['~P-24']`) vs. A-12 (endorses, defs `{'C-03': ['D-14']}`, entails `['P-26']`).
- **VERBAL DISPUTE (pure_verbal) on `P-04` (Content Externalism Is Compatible with Rational Inference)**: A-01 (rejects, defs `{'C-03': ['D-12']}`, entails `['~P-24']`) vs. A-15 (endorses, defs `{'C-03': ['D-15']}`, entails `['P-27']`).
- **VERBAL DISPUTE (pure_verbal) on `P-01` (Rational Inference Requires Transparency of Mental Content)**: A-01 (endorses, defs `{'C-01': ['D-01'], 'C-03': ['D-12']}`, entails `['P-13']`) vs. A-17 (rejects, defs `{'C-01': ['D-08'], 'C-03': ['D-17']}`, entails `['~P-16']`).
- **VERBAL DISPUTE (pure_verbal) on `P-04` (Content Externalism Is Compatible with Rational Inference)**: A-01 (rejects, defs `{'C-03': ['D-12']}`, entails `['~P-24']`) vs. A-17 (endorses, defs `{'C-03': ['D-17']}`, entails `['P-29']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-04 (endorses, defs `{'C-01': ['D-03']}`, entails `['P-18']`) vs. A-11 (rejects, defs `{'C-01': ['D-05']}`, entails `['~P-19', '~P-20']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-04 (endorses, defs `{'C-01': ['D-03']}`, entails `['P-18']`) vs. A-12 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12', 'P-17']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-04 (endorses, defs `{'C-01': ['D-03']}`, entails `['P-18']`) vs. A-13 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12']`).
- **VERBAL DISPUTE (local_verbal) on `P-05` (Content Externalism Is Compatible with Introspective Knowledge of Content)**: A-05 (endorses, defs `{'C-06': ['D-25']}`, entails `['P-30']`) vs. A-06 (rejects, defs `{'C-06': ['D-26']}`, entails `['~P-31']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-05 (endorses, defs `{'C-01': ['D-02']}`, entails `['P-17']`) vs. A-11 (rejects, defs `{'C-01': ['D-05']}`, entails `['~P-19', '~P-20']`).
- **VERBAL DISPUTE (local_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-05 (endorses, defs `{'C-01': ['D-02']}`, entails `['P-17']`) vs. A-12 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12', 'P-17']`).
- **VERBAL DISPUTE (local_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-05 (endorses, defs `{'C-01': ['D-02']}`, entails `['P-17']`) vs. A-13 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12']`).
- **VERBAL DISPUTE (pure_verbal) on `P-06` (Metasemantic Contextualism Adequately Explains Mental Content)**: A-07 (endorses, defs `{'P-06': ['P-32']}`, entails `['P-32', '~P-33', '~P-34']`) vs. A-09 (rejects, defs `{'P-06': ['P-32', 'P-33', 'P-34']}`, entails `['~P-33']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-10 (endorses, defs `{'C-01': ['D-04']}`, entails `['P-19', '~P-20']`) vs. A-12 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12', 'P-17']`).
- **VERBAL DISPUTE (pure_verbal) on `P-02` (Mental Content Is Epistemically Transparent)**: A-10 (endorses, defs `{'C-01': ['D-04']}`, entails `['P-19', '~P-20']`) vs. A-13 (rejects, defs `{'C-01': ['D-01']}`, entails `['~P-12']`).
- **VERBAL DISPUTE (pure_verbal) on `P-01` (Rational Inference Requires Transparency of Mental Content)**: A-12 (rejects, defs `{'C-01': ['D-01'], 'C-03': ['D-14']}`, entails `['~P-13']`) vs. A-16 (endorses, defs `{'C-01': ['D-06'], 'C-03': ['D-12', 'D-13', 'D-14', 'D-15', 'D-16', 'D-17']}`, entails `['P-14', '~P-15']`).
- **VERBAL DISPUTE (pure_verbal) on `P-01` (Rational Inference Requires Transparency of Mental Content)**: A-16 (endorses, defs `{'C-01': ['D-06'], 'C-03': ['D-12', 'D-13', 'D-14', 'D-15', 'D-16', 'D-17']}`, entails `['P-14', '~P-15']`) vs. A-17 (rejects, defs `{'C-01': ['D-08'], 'C-03': ['D-17']}`, entails `['~P-16']`).
- Substantive umbrella disputes: 5

## 6. Aporetic Clusters & Equivocation Report
- **ARG-01 (Slow-Switching Equivocation Derivation)**: `['P-41', 'P-46', 'P-63', '~P-47']` — inconsistent=True, minimal
- **ARG-02 (Slow-Switch Equivocation vs. Transparency of Difference)**: `['P-46', 'P-47', 'P-64', 'P-11']` — inconsistent=True, minimal
- **ARG-03 (Slow-Switch Equivocation vs. Token-Wide APLA)**: `['P-46', 'P-47', 'P-114', 'P-21']` — inconsistent=True, minimal
- **ARG-04 (Pierre and Paderewski Opacity vs. Transparency of Sameness)**: `['P-40', 'P-50', 'P-51', 'P-66', 'P-10']` — inconsistent=True, minimal
- **ARG-05 (Collapse of Pure Wide Rationalizing Explanation)**: `['P-13', 'P-65', '~P-12', 'P-54']` — inconsistent=True, minimal
- **ARG-06 (Schiffer Univocal Intent Blocks Slow-Switch Equivocation)**: `['P-56', 'D-22', 'P-47']` — inconsistent=True, minimal
- **ARG-07 (Otero Comparative Reversal vs. Boghossian Narrow-Syntax Reply)**: `['P-58', 'P-59', 'P-60', '~P-61', 'P-67', '~P-57']` — inconsistent=True, minimal
- **ARG-19 (Argument from Logical Norms Dilemma (Brown and Collins))**: `['P-93', 'P-95', '~P-94']` — inconsistent=True, minimal
- No equivocation detected in invoked premise sets.

## 7. Plausibility-Weighted MaxSAT & Minimal-Cost Cluster Resolution
- **Global MaxSAT** (exact=True): satisfied `90.0/90.0` (violated `0.0`), sharpening `{'C-01': ['D-04'], 'C-02': ['D-10'], 'C-03': ['D-16'], 'C-05': ['D-21'], 'C-06': ['D-25'], 'C-10': ['D-35'], 'C-11': ['D-37'], 'C-13': ['D-42']}`.
- **ARG-01 (Slow-Switching Equivocation Derivation)**: cheapest feasible resolution = reject `P-41` (cost=1.5, plaus=contested, authors=[])
- **ARG-02 (Slow-Switch Equivocation vs. Transparency of Difference)**: cheapest feasible resolution = reject `P-11` (cost=1.0, plaus=low, authors=['A-06', 'A-12', 'A-13', 'A-14'])
- **ARG-03 (Slow-Switch Equivocation vs. Token-Wide APLA)**: cheapest feasible resolution = reject `P-21` (cost=1.5, plaus=contested, authors=[])
- **ARG-04 (Pierre and Paderewski Opacity vs. Transparency of Sameness)**: cheapest feasible resolution = reject `P-10` (cost=1.5, plaus=contested, authors=['A-12'])
- **ARG-05 (Collapse of Pure Wide Rationalizing Explanation)**: cheapest feasible resolution = reject `P-13` (cost=1.5, plaus=contested, authors=['A-02', 'A-12'])
- **ARG-06 (Schiffer Univocal Intent Blocks Slow-Switch Equivocation)**: cheapest feasible resolution = reject `D-22` (cost=1.5, plaus=contested, authors=[])
- **ARG-07 (Otero Comparative Reversal vs. Boghossian Narrow-Syntax Reply)**: cheapest feasible resolution = reject `~P-57` (cost=1.5, plaus=contested, authors=['A-03'])
- **ARG-19 (Argument from Logical Norms Dilemma (Brown and Collins))**: cheapest feasible resolution = reject `P-95` (cost=1.5, plaus=contested, authors=[])
